# V12NfsSettingsGlobalSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nfsv3Enabled** | Pointer to **bool** | True if NFSv3 is enabled. | [optional] 
**Nfsv3RdmaEnabled** | Pointer to **bool** | True if the RDMA is enabled for NFSv3. | [optional] 
**Nfsv4Enabled** | Pointer to **bool** | True if NFSv4 is enabled. | [optional] 
**RpcMaxthreads** | Pointer to **int32** | Specifies the maximum number of threads in the nfsd thread pool. | [optional] 
**RpcMinthreads** | Pointer to **int32** | Specifies the minimum number of threads in the nfsd thread pool. | [optional] 
**RquotaEnabled** | Pointer to **bool** | True if the rquota protocol is enabled. | [optional] 
**Service** | Pointer to **bool** | True if the NFS service is enabled. When set to false, the NFS service is disabled. | [optional] 

## Methods

### NewV12NfsSettingsGlobalSettings

`func NewV12NfsSettingsGlobalSettings() *V12NfsSettingsGlobalSettings`

NewV12NfsSettingsGlobalSettings instantiates a new V12NfsSettingsGlobalSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NfsSettingsGlobalSettingsWithDefaults

`func NewV12NfsSettingsGlobalSettingsWithDefaults() *V12NfsSettingsGlobalSettings`

NewV12NfsSettingsGlobalSettingsWithDefaults instantiates a new V12NfsSettingsGlobalSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNfsv3Enabled

`func (o *V12NfsSettingsGlobalSettings) GetNfsv3Enabled() bool`

GetNfsv3Enabled returns the Nfsv3Enabled field if non-nil, zero value otherwise.

### GetNfsv3EnabledOk

`func (o *V12NfsSettingsGlobalSettings) GetNfsv3EnabledOk() (*bool, bool)`

GetNfsv3EnabledOk returns a tuple with the Nfsv3Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv3Enabled

`func (o *V12NfsSettingsGlobalSettings) SetNfsv3Enabled(v bool)`

SetNfsv3Enabled sets Nfsv3Enabled field to given value.

### HasNfsv3Enabled

`func (o *V12NfsSettingsGlobalSettings) HasNfsv3Enabled() bool`

HasNfsv3Enabled returns a boolean if a field has been set.

### GetNfsv3RdmaEnabled

`func (o *V12NfsSettingsGlobalSettings) GetNfsv3RdmaEnabled() bool`

GetNfsv3RdmaEnabled returns the Nfsv3RdmaEnabled field if non-nil, zero value otherwise.

### GetNfsv3RdmaEnabledOk

`func (o *V12NfsSettingsGlobalSettings) GetNfsv3RdmaEnabledOk() (*bool, bool)`

GetNfsv3RdmaEnabledOk returns a tuple with the Nfsv3RdmaEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv3RdmaEnabled

`func (o *V12NfsSettingsGlobalSettings) SetNfsv3RdmaEnabled(v bool)`

SetNfsv3RdmaEnabled sets Nfsv3RdmaEnabled field to given value.

### HasNfsv3RdmaEnabled

`func (o *V12NfsSettingsGlobalSettings) HasNfsv3RdmaEnabled() bool`

HasNfsv3RdmaEnabled returns a boolean if a field has been set.

### GetNfsv4Enabled

`func (o *V12NfsSettingsGlobalSettings) GetNfsv4Enabled() bool`

GetNfsv4Enabled returns the Nfsv4Enabled field if non-nil, zero value otherwise.

### GetNfsv4EnabledOk

`func (o *V12NfsSettingsGlobalSettings) GetNfsv4EnabledOk() (*bool, bool)`

GetNfsv4EnabledOk returns a tuple with the Nfsv4Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv4Enabled

`func (o *V12NfsSettingsGlobalSettings) SetNfsv4Enabled(v bool)`

SetNfsv4Enabled sets Nfsv4Enabled field to given value.

### HasNfsv4Enabled

`func (o *V12NfsSettingsGlobalSettings) HasNfsv4Enabled() bool`

HasNfsv4Enabled returns a boolean if a field has been set.

### GetRpcMaxthreads

`func (o *V12NfsSettingsGlobalSettings) GetRpcMaxthreads() int32`

GetRpcMaxthreads returns the RpcMaxthreads field if non-nil, zero value otherwise.

### GetRpcMaxthreadsOk

`func (o *V12NfsSettingsGlobalSettings) GetRpcMaxthreadsOk() (*int32, bool)`

GetRpcMaxthreadsOk returns a tuple with the RpcMaxthreads field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRpcMaxthreads

`func (o *V12NfsSettingsGlobalSettings) SetRpcMaxthreads(v int32)`

SetRpcMaxthreads sets RpcMaxthreads field to given value.

### HasRpcMaxthreads

`func (o *V12NfsSettingsGlobalSettings) HasRpcMaxthreads() bool`

HasRpcMaxthreads returns a boolean if a field has been set.

### GetRpcMinthreads

`func (o *V12NfsSettingsGlobalSettings) GetRpcMinthreads() int32`

GetRpcMinthreads returns the RpcMinthreads field if non-nil, zero value otherwise.

### GetRpcMinthreadsOk

`func (o *V12NfsSettingsGlobalSettings) GetRpcMinthreadsOk() (*int32, bool)`

GetRpcMinthreadsOk returns a tuple with the RpcMinthreads field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRpcMinthreads

`func (o *V12NfsSettingsGlobalSettings) SetRpcMinthreads(v int32)`

SetRpcMinthreads sets RpcMinthreads field to given value.

### HasRpcMinthreads

`func (o *V12NfsSettingsGlobalSettings) HasRpcMinthreads() bool`

HasRpcMinthreads returns a boolean if a field has been set.

### GetRquotaEnabled

`func (o *V12NfsSettingsGlobalSettings) GetRquotaEnabled() bool`

GetRquotaEnabled returns the RquotaEnabled field if non-nil, zero value otherwise.

### GetRquotaEnabledOk

`func (o *V12NfsSettingsGlobalSettings) GetRquotaEnabledOk() (*bool, bool)`

GetRquotaEnabledOk returns a tuple with the RquotaEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRquotaEnabled

`func (o *V12NfsSettingsGlobalSettings) SetRquotaEnabled(v bool)`

SetRquotaEnabled sets RquotaEnabled field to given value.

### HasRquotaEnabled

`func (o *V12NfsSettingsGlobalSettings) HasRquotaEnabled() bool`

HasRquotaEnabled returns a boolean if a field has been set.

### GetService

`func (o *V12NfsSettingsGlobalSettings) GetService() bool`

GetService returns the Service field if non-nil, zero value otherwise.

### GetServiceOk

`func (o *V12NfsSettingsGlobalSettings) GetServiceOk() (*bool, bool)`

GetServiceOk returns a tuple with the Service field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetService

`func (o *V12NfsSettingsGlobalSettings) SetService(v bool)`

SetService sets Service field to given value.

### HasService

`func (o *V12NfsSettingsGlobalSettings) HasService() bool`

HasService returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


