# V10HealthcheckSchedulesExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Schedules** | Pointer to [**[]V10HealthcheckScheduleExtended**](V10HealthcheckScheduleExtended.md) |  | [optional] 

## Methods

### NewV10HealthcheckSchedulesExtended

`func NewV10HealthcheckSchedulesExtended() *V10HealthcheckSchedulesExtended`

NewV10HealthcheckSchedulesExtended instantiates a new V10HealthcheckSchedulesExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckSchedulesExtendedWithDefaults

`func NewV10HealthcheckSchedulesExtendedWithDefaults() *V10HealthcheckSchedulesExtended`

NewV10HealthcheckSchedulesExtendedWithDefaults instantiates a new V10HealthcheckSchedulesExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSchedules

`func (o *V10HealthcheckSchedulesExtended) GetSchedules() []V10HealthcheckScheduleExtended`

GetSchedules returns the Schedules field if non-nil, zero value otherwise.

### GetSchedulesOk

`func (o *V10HealthcheckSchedulesExtended) GetSchedulesOk() (*[]V10HealthcheckScheduleExtended, bool)`

GetSchedulesOk returns a tuple with the Schedules field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSchedules

`func (o *V10HealthcheckSchedulesExtended) SetSchedules(v []V10HealthcheckScheduleExtended)`

SetSchedules sets Schedules field to given value.

### HasSchedules

`func (o *V10HealthcheckSchedulesExtended) HasSchedules() bool`

HasSchedules returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


