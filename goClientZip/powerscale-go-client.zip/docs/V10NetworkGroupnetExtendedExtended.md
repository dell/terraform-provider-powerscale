# V10NetworkGroupnetExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllowWildcardSubdomains** | Pointer to **bool** | If enabled, SmartConnect treats subdomains of known dns zones as the known dns zone. This is required for S3 Virtual Host domains. Defaults to True. | [optional] 
**Description** | Pointer to **string** | A description of the groupnet. | [optional] 
**DnsCacheEnabled** | Pointer to **bool** | DNS caching is enabled or disabled. | [optional] 
**DnsOptions** | Pointer to **[]string** | List of DNS resolver options. | [optional] 
**DnsSearch** | Pointer to **[]string** | List of DNS search suffixes. | [optional] 
**DnsServers** | Pointer to **[]string** | List of Domain Name Server IP addresses. | [optional] 
**Name** | Pointer to **string** | The name of the groupnet. | [optional] 
**ServerSideDnsSearch** | Pointer to **bool** | Enable or disable appending nodes DNS search  list to client DNS inquiries directed at SmartConnect service IP. | [optional] 

## Methods

### NewV10NetworkGroupnetExtendedExtended

`func NewV10NetworkGroupnetExtendedExtended() *V10NetworkGroupnetExtendedExtended`

NewV10NetworkGroupnetExtendedExtended instantiates a new V10NetworkGroupnetExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NetworkGroupnetExtendedExtendedWithDefaults

`func NewV10NetworkGroupnetExtendedExtendedWithDefaults() *V10NetworkGroupnetExtendedExtended`

NewV10NetworkGroupnetExtendedExtendedWithDefaults instantiates a new V10NetworkGroupnetExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllowWildcardSubdomains

`func (o *V10NetworkGroupnetExtendedExtended) GetAllowWildcardSubdomains() bool`

GetAllowWildcardSubdomains returns the AllowWildcardSubdomains field if non-nil, zero value otherwise.

### GetAllowWildcardSubdomainsOk

`func (o *V10NetworkGroupnetExtendedExtended) GetAllowWildcardSubdomainsOk() (*bool, bool)`

GetAllowWildcardSubdomainsOk returns a tuple with the AllowWildcardSubdomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowWildcardSubdomains

`func (o *V10NetworkGroupnetExtendedExtended) SetAllowWildcardSubdomains(v bool)`

SetAllowWildcardSubdomains sets AllowWildcardSubdomains field to given value.

### HasAllowWildcardSubdomains

`func (o *V10NetworkGroupnetExtendedExtended) HasAllowWildcardSubdomains() bool`

HasAllowWildcardSubdomains returns a boolean if a field has been set.

### GetDescription

`func (o *V10NetworkGroupnetExtendedExtended) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V10NetworkGroupnetExtendedExtended) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V10NetworkGroupnetExtendedExtended) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V10NetworkGroupnetExtendedExtended) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDnsCacheEnabled

`func (o *V10NetworkGroupnetExtendedExtended) GetDnsCacheEnabled() bool`

GetDnsCacheEnabled returns the DnsCacheEnabled field if non-nil, zero value otherwise.

### GetDnsCacheEnabledOk

`func (o *V10NetworkGroupnetExtendedExtended) GetDnsCacheEnabledOk() (*bool, bool)`

GetDnsCacheEnabledOk returns a tuple with the DnsCacheEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsCacheEnabled

`func (o *V10NetworkGroupnetExtendedExtended) SetDnsCacheEnabled(v bool)`

SetDnsCacheEnabled sets DnsCacheEnabled field to given value.

### HasDnsCacheEnabled

`func (o *V10NetworkGroupnetExtendedExtended) HasDnsCacheEnabled() bool`

HasDnsCacheEnabled returns a boolean if a field has been set.

### GetDnsOptions

`func (o *V10NetworkGroupnetExtendedExtended) GetDnsOptions() []string`

GetDnsOptions returns the DnsOptions field if non-nil, zero value otherwise.

### GetDnsOptionsOk

`func (o *V10NetworkGroupnetExtendedExtended) GetDnsOptionsOk() (*[]string, bool)`

GetDnsOptionsOk returns a tuple with the DnsOptions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsOptions

`func (o *V10NetworkGroupnetExtendedExtended) SetDnsOptions(v []string)`

SetDnsOptions sets DnsOptions field to given value.

### HasDnsOptions

`func (o *V10NetworkGroupnetExtendedExtended) HasDnsOptions() bool`

HasDnsOptions returns a boolean if a field has been set.

### GetDnsSearch

`func (o *V10NetworkGroupnetExtendedExtended) GetDnsSearch() []string`

GetDnsSearch returns the DnsSearch field if non-nil, zero value otherwise.

### GetDnsSearchOk

`func (o *V10NetworkGroupnetExtendedExtended) GetDnsSearchOk() (*[]string, bool)`

GetDnsSearchOk returns a tuple with the DnsSearch field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsSearch

`func (o *V10NetworkGroupnetExtendedExtended) SetDnsSearch(v []string)`

SetDnsSearch sets DnsSearch field to given value.

### HasDnsSearch

`func (o *V10NetworkGroupnetExtendedExtended) HasDnsSearch() bool`

HasDnsSearch returns a boolean if a field has been set.

### GetDnsServers

`func (o *V10NetworkGroupnetExtendedExtended) GetDnsServers() []string`

GetDnsServers returns the DnsServers field if non-nil, zero value otherwise.

### GetDnsServersOk

`func (o *V10NetworkGroupnetExtendedExtended) GetDnsServersOk() (*[]string, bool)`

GetDnsServersOk returns a tuple with the DnsServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsServers

`func (o *V10NetworkGroupnetExtendedExtended) SetDnsServers(v []string)`

SetDnsServers sets DnsServers field to given value.

### HasDnsServers

`func (o *V10NetworkGroupnetExtendedExtended) HasDnsServers() bool`

HasDnsServers returns a boolean if a field has been set.

### GetName

`func (o *V10NetworkGroupnetExtendedExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10NetworkGroupnetExtendedExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10NetworkGroupnetExtendedExtended) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V10NetworkGroupnetExtendedExtended) HasName() bool`

HasName returns a boolean if a field has been set.

### GetServerSideDnsSearch

`func (o *V10NetworkGroupnetExtendedExtended) GetServerSideDnsSearch() bool`

GetServerSideDnsSearch returns the ServerSideDnsSearch field if non-nil, zero value otherwise.

### GetServerSideDnsSearchOk

`func (o *V10NetworkGroupnetExtendedExtended) GetServerSideDnsSearchOk() (*bool, bool)`

GetServerSideDnsSearchOk returns a tuple with the ServerSideDnsSearch field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerSideDnsSearch

`func (o *V10NetworkGroupnetExtendedExtended) SetServerSideDnsSearch(v bool)`

SetServerSideDnsSearch sets ServerSideDnsSearch field to given value.

### HasServerSideDnsSearch

`func (o *V10NetworkGroupnetExtendedExtended) HasServerSideDnsSearch() bool`

HasServerSideDnsSearch returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


