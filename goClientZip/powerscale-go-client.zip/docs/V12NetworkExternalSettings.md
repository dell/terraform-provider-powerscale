# V12NetworkExternalSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DefaultGroupnet** | **string** | Default client-side DNS settings for non-multitenancy aware programs | 
**Ipv6AutoConfigEnabled** | **bool** | True if rtsold daemon is enabled.  When set to false, the rtsold service is disabled, and IPv6 auto configuration is disabled | 
**Sbr** | **bool** | Enable or disable Source Based Routing (Defaults to false) | 
**ScRebalanceDelay** | **int32** | Delay in seconds for IP rebalance. | 
**TcpPorts** | **[]int32** | List of client TCP ports. | 

## Methods

### NewV12NetworkExternalSettings

`func NewV12NetworkExternalSettings(defaultGroupnet string, ipv6AutoConfigEnabled bool, sbr bool, scRebalanceDelay int32, tcpPorts []int32, ) *V12NetworkExternalSettings`

NewV12NetworkExternalSettings instantiates a new V12NetworkExternalSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NetworkExternalSettingsWithDefaults

`func NewV12NetworkExternalSettingsWithDefaults() *V12NetworkExternalSettings`

NewV12NetworkExternalSettingsWithDefaults instantiates a new V12NetworkExternalSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDefaultGroupnet

`func (o *V12NetworkExternalSettings) GetDefaultGroupnet() string`

GetDefaultGroupnet returns the DefaultGroupnet field if non-nil, zero value otherwise.

### GetDefaultGroupnetOk

`func (o *V12NetworkExternalSettings) GetDefaultGroupnetOk() (*string, bool)`

GetDefaultGroupnetOk returns a tuple with the DefaultGroupnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultGroupnet

`func (o *V12NetworkExternalSettings) SetDefaultGroupnet(v string)`

SetDefaultGroupnet sets DefaultGroupnet field to given value.


### GetIpv6AutoConfigEnabled

`func (o *V12NetworkExternalSettings) GetIpv6AutoConfigEnabled() bool`

GetIpv6AutoConfigEnabled returns the Ipv6AutoConfigEnabled field if non-nil, zero value otherwise.

### GetIpv6AutoConfigEnabledOk

`func (o *V12NetworkExternalSettings) GetIpv6AutoConfigEnabledOk() (*bool, bool)`

GetIpv6AutoConfigEnabledOk returns a tuple with the Ipv6AutoConfigEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpv6AutoConfigEnabled

`func (o *V12NetworkExternalSettings) SetIpv6AutoConfigEnabled(v bool)`

SetIpv6AutoConfigEnabled sets Ipv6AutoConfigEnabled field to given value.


### GetSbr

`func (o *V12NetworkExternalSettings) GetSbr() bool`

GetSbr returns the Sbr field if non-nil, zero value otherwise.

### GetSbrOk

`func (o *V12NetworkExternalSettings) GetSbrOk() (*bool, bool)`

GetSbrOk returns a tuple with the Sbr field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSbr

`func (o *V12NetworkExternalSettings) SetSbr(v bool)`

SetSbr sets Sbr field to given value.


### GetScRebalanceDelay

`func (o *V12NetworkExternalSettings) GetScRebalanceDelay() int32`

GetScRebalanceDelay returns the ScRebalanceDelay field if non-nil, zero value otherwise.

### GetScRebalanceDelayOk

`func (o *V12NetworkExternalSettings) GetScRebalanceDelayOk() (*int32, bool)`

GetScRebalanceDelayOk returns a tuple with the ScRebalanceDelay field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScRebalanceDelay

`func (o *V12NetworkExternalSettings) SetScRebalanceDelay(v int32)`

SetScRebalanceDelay sets ScRebalanceDelay field to given value.


### GetTcpPorts

`func (o *V12NetworkExternalSettings) GetTcpPorts() []int32`

GetTcpPorts returns the TcpPorts field if non-nil, zero value otherwise.

### GetTcpPortsOk

`func (o *V12NetworkExternalSettings) GetTcpPortsOk() (*[]int32, bool)`

GetTcpPortsOk returns a tuple with the TcpPorts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTcpPorts

`func (o *V12NetworkExternalSettings) SetTcpPorts(v []int32)`

SetTcpPorts sets TcpPorts field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


