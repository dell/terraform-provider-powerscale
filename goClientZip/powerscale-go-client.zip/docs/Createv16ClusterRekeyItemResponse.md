# Createv16ClusterRekeyItemResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RekeyMsg** | **string** | Non-error message reported to user about the rekey process. | 

## Methods

### NewCreatev16ClusterRekeyItemResponse

`func NewCreatev16ClusterRekeyItemResponse(rekeyMsg string, ) *Createv16ClusterRekeyItemResponse`

NewCreatev16ClusterRekeyItemResponse instantiates a new Createv16ClusterRekeyItemResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev16ClusterRekeyItemResponseWithDefaults

`func NewCreatev16ClusterRekeyItemResponseWithDefaults() *Createv16ClusterRekeyItemResponse`

NewCreatev16ClusterRekeyItemResponseWithDefaults instantiates a new Createv16ClusterRekeyItemResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRekeyMsg

`func (o *Createv16ClusterRekeyItemResponse) GetRekeyMsg() string`

GetRekeyMsg returns the RekeyMsg field if non-nil, zero value otherwise.

### GetRekeyMsgOk

`func (o *Createv16ClusterRekeyItemResponse) GetRekeyMsgOk() (*string, bool)`

GetRekeyMsgOk returns a tuple with the RekeyMsg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRekeyMsg

`func (o *Createv16ClusterRekeyItemResponse) SetRekeyMsg(v string)`

SetRekeyMsg sets RekeyMsg field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


