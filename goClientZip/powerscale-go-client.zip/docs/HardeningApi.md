# \HardeningApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateHardeningv3HardeningApplyItem**](HardeningApi.md#CreateHardeningv3HardeningApplyItem) | **Post** /platform/3/hardening/apply | 
[**CreateHardeningv3HardeningResolveItem**](HardeningApi.md#CreateHardeningv3HardeningResolveItem) | **Post** /platform/3/hardening/resolve | 
[**CreateHardeningv3HardeningRevertItem**](HardeningApi.md#CreateHardeningv3HardeningRevertItem) | **Post** /platform/3/hardening/revert | 
[**GetHardeningv3HardeningState**](HardeningApi.md#GetHardeningv3HardeningState) | **Get** /platform/3/hardening/state | 
[**GetHardeningv3HardeningStatus**](HardeningApi.md#GetHardeningv3HardeningStatus) | **Get** /platform/3/hardening/status | 



## CreateHardeningv3HardeningApplyItem

> Createv3HardeningApplyItemResponse CreateHardeningv3HardeningApplyItem(ctx).V3HardeningApplyItem(v3HardeningApplyItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HardeningApplyItem := *openapiclient.NewV3HardeningApplyItem() // V3HardeningApplyItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.CreateHardeningv3HardeningApplyItem(context.Background()).V3HardeningApplyItem(v3HardeningApplyItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.CreateHardeningv3HardeningApplyItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHardeningv3HardeningApplyItem`: Createv3HardeningApplyItemResponse
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.CreateHardeningv3HardeningApplyItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateHardeningv3HardeningApplyItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3HardeningApplyItem** | [**V3HardeningApplyItem**](V3HardeningApplyItem.md) |  | 

### Return type

[**Createv3HardeningApplyItemResponse**](Createv3HardeningApplyItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateHardeningv3HardeningResolveItem

> Createv3HardeningResolveItemResponse CreateHardeningv3HardeningResolveItem(ctx).V3HardeningResolveItem(v3HardeningResolveItem).Accept(accept).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HardeningResolveItem := *openapiclient.NewV3HardeningResolveItem() // V3HardeningResolveItem | 
    accept := true // bool | If true, execution proceeds to resolve all issues. If false, execution aborts. This is a required argument. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.CreateHardeningv3HardeningResolveItem(context.Background()).V3HardeningResolveItem(v3HardeningResolveItem).Accept(accept).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.CreateHardeningv3HardeningResolveItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHardeningv3HardeningResolveItem`: Createv3HardeningResolveItemResponse
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.CreateHardeningv3HardeningResolveItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateHardeningv3HardeningResolveItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3HardeningResolveItem** | [**V3HardeningResolveItem**](V3HardeningResolveItem.md) |  | 
 **accept** | **bool** | If true, execution proceeds to resolve all issues. If false, execution aborts. This is a required argument. | 

### Return type

[**Createv3HardeningResolveItemResponse**](Createv3HardeningResolveItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateHardeningv3HardeningRevertItem

> Createv3HardeningRevertItemResponse CreateHardeningv3HardeningRevertItem(ctx).V3HardeningRevertItem(v3HardeningRevertItem).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HardeningRevertItem := map[string]interface{}{ ... } // map[string]interface{} | 
    force := true // bool | If specified, revert operation continues even in case of a failure. Default is false in which case revert stops at the first failure. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.CreateHardeningv3HardeningRevertItem(context.Background()).V3HardeningRevertItem(v3HardeningRevertItem).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.CreateHardeningv3HardeningRevertItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHardeningv3HardeningRevertItem`: Createv3HardeningRevertItemResponse
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.CreateHardeningv3HardeningRevertItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateHardeningv3HardeningRevertItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3HardeningRevertItem** | **map[string]interface{}** |  | 
 **force** | **bool** | If specified, revert operation continues even in case of a failure. Default is false in which case revert stops at the first failure. | 

### Return type

[**Createv3HardeningRevertItemResponse**](Createv3HardeningRevertItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHardeningv3HardeningState

> V3HardeningState GetHardeningv3HardeningState(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.GetHardeningv3HardeningState(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.GetHardeningv3HardeningState``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHardeningv3HardeningState`: V3HardeningState
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.GetHardeningv3HardeningState`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetHardeningv3HardeningStateRequest struct via the builder pattern


### Return type

[**V3HardeningState**](V3HardeningState.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHardeningv3HardeningStatus

> V3HardeningStatus GetHardeningv3HardeningStatus(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HardeningApi.GetHardeningv3HardeningStatus(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HardeningApi.GetHardeningv3HardeningStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHardeningv3HardeningStatus`: V3HardeningStatus
    fmt.Fprintf(os.Stdout, "Response from `HardeningApi.GetHardeningv3HardeningStatus`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetHardeningv3HardeningStatusRequest struct via the builder pattern


### Return type

[**V3HardeningStatus**](V3HardeningStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

