# \UpgradeApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateUpgradev10ClusterFirmwareAssessItem**](UpgradeApi.md#CreateUpgradev10ClusterFirmwareAssessItem) | **Post** /platform/10/upgrade/cluster/firmware/assess | 
[**CreateUpgradev10ClusterFirmwareUpgradeItem**](UpgradeApi.md#CreateUpgradev10ClusterFirmwareUpgradeItem) | **Post** /platform/10/upgrade/cluster/firmware/upgrade | 
[**CreateUpgradev11ClusterPatchPatch**](UpgradeApi.md#CreateUpgradev11ClusterPatchPatch) | **Post** /platform/11/upgrade/cluster/patch/patches | 
[**CreateUpgradev12ClusterFirmwareUpgradeItem**](UpgradeApi.md#CreateUpgradev12ClusterFirmwareUpgradeItem) | **Post** /platform/12/upgrade/cluster/firmware/upgrade | 
[**CreateUpgradev12ClusterUpgradeItem**](UpgradeApi.md#CreateUpgradev12ClusterUpgradeItem) | **Post** /platform/12/upgrade/cluster/upgrade | 
[**CreateUpgradev3ClusterAddRemainingNode**](UpgradeApi.md#CreateUpgradev3ClusterAddRemainingNode) | **Post** /platform/3/upgrade/cluster/add_remaining_nodes | 
[**CreateUpgradev3ClusterArchiveItem**](UpgradeApi.md#CreateUpgradev3ClusterArchiveItem) | **Post** /platform/3/upgrade/cluster/archive | 
[**CreateUpgradev3ClusterAssessItem**](UpgradeApi.md#CreateUpgradev3ClusterAssessItem) | **Post** /platform/3/upgrade/cluster/assess | 
[**CreateUpgradev3ClusterCommitItem**](UpgradeApi.md#CreateUpgradev3ClusterCommitItem) | **Post** /platform/3/upgrade/cluster/commit | 
[**CreateUpgradev3ClusterPatchAbortItem**](UpgradeApi.md#CreateUpgradev3ClusterPatchAbortItem) | **Post** /platform/3/upgrade/cluster/patch/abort | 
[**CreateUpgradev3ClusterPatchPatch**](UpgradeApi.md#CreateUpgradev3ClusterPatchPatch) | **Post** /platform/3/upgrade/cluster/patch/patches | 
[**CreateUpgradev3ClusterRetryLastActionItem**](UpgradeApi.md#CreateUpgradev3ClusterRetryLastActionItem) | **Post** /platform/3/upgrade/cluster/retry_last_action | 
[**CreateUpgradev3ClusterRollbackItem**](UpgradeApi.md#CreateUpgradev3ClusterRollbackItem) | **Post** /platform/3/upgrade/cluster/rollback | 
[**CreateUpgradev3ClusterUpgradeItem**](UpgradeApi.md#CreateUpgradev3ClusterUpgradeItem) | **Post** /platform/3/upgrade/cluster/upgrade | 
[**CreateUpgradev5ClusterAssessItem**](UpgradeApi.md#CreateUpgradev5ClusterAssessItem) | **Post** /platform/5/upgrade/cluster/assess | 
[**CreateUpgradev5ClusterUpgradeItem**](UpgradeApi.md#CreateUpgradev5ClusterUpgradeItem) | **Post** /platform/5/upgrade/cluster/upgrade | 
[**CreateUpgradev7ClusterPatchPatch**](UpgradeApi.md#CreateUpgradev7ClusterPatchPatch) | **Post** /platform/7/upgrade/cluster/patch/patches | 
[**CreateUpgradev7ClusterPauseItem**](UpgradeApi.md#CreateUpgradev7ClusterPauseItem) | **Post** /platform/7/upgrade/cluster/pause | 
[**CreateUpgradev7ClusterResumeItem**](UpgradeApi.md#CreateUpgradev7ClusterResumeItem) | **Post** /platform/7/upgrade/cluster/resume | 
[**CreateUpgradev7ClusterUpgradeItem**](UpgradeApi.md#CreateUpgradev7ClusterUpgradeItem) | **Post** /platform/7/upgrade/cluster/upgrade | 
[**CreateUpgradev9ClusterUpgradeItem**](UpgradeApi.md#CreateUpgradev9ClusterUpgradeItem) | **Post** /platform/9/upgrade/cluster/upgrade | 
[**DeleteUpgradev11ClusterPatchPatch**](UpgradeApi.md#DeleteUpgradev11ClusterPatchPatch) | **Delete** /platform/11/upgrade/cluster/patch/patches/{v11ClusterPatchPatchId} | 
[**DeleteUpgradev3ClusterPatchPatch**](UpgradeApi.md#DeleteUpgradev3ClusterPatchPatch) | **Delete** /platform/3/upgrade/cluster/patch/patches/{v3ClusterPatchPatchId} | 
[**DeleteUpgradev7ClusterPatchPatch**](UpgradeApi.md#DeleteUpgradev7ClusterPatchPatch) | **Delete** /platform/7/upgrade/cluster/patch/patches/{v7ClusterPatchPatchId} | 
[**GetUpgradev10ClusterFirmwareDevice**](UpgradeApi.md#GetUpgradev10ClusterFirmwareDevice) | **Get** /platform/10/upgrade/cluster/firmware/device | 
[**GetUpgradev10ClusterFirmwareStatus**](UpgradeApi.md#GetUpgradev10ClusterFirmwareStatus) | **Get** /platform/10/upgrade/cluster/firmware/status | 
[**GetUpgradev11ClusterPatchPatch**](UpgradeApi.md#GetUpgradev11ClusterPatchPatch) | **Get** /platform/11/upgrade/cluster/patch/patches/{v11ClusterPatchPatchId} | 
[**GetUpgradev12ClusterDrainList**](UpgradeApi.md#GetUpgradev12ClusterDrainList) | **Get** /platform/12/upgrade/cluster/drain/list | 
[**GetUpgradev12ClusterDrainTimeout**](UpgradeApi.md#GetUpgradev12ClusterDrainTimeout) | **Get** /platform/12/upgrade/cluster/drain/timeout | 
[**GetUpgradev12ClusterNodes**](UpgradeApi.md#GetUpgradev12ClusterNodes) | **Get** /platform/12/upgrade/cluster/nodes | 
[**GetUpgradev3ClusterFirmwareProgress**](UpgradeApi.md#GetUpgradev3ClusterFirmwareProgress) | **Get** /platform/3/upgrade/cluster/firmware/progress | 
[**GetUpgradev3ClusterFirmwareStatus**](UpgradeApi.md#GetUpgradev3ClusterFirmwareStatus) | **Get** /platform/3/upgrade/cluster/firmware/status | 
[**GetUpgradev3ClusterNode**](UpgradeApi.md#GetUpgradev3ClusterNode) | **Get** /platform/3/upgrade/cluster/nodes/{v3ClusterNodeId} | 
[**GetUpgradev3ClusterNodes**](UpgradeApi.md#GetUpgradev3ClusterNodes) | **Get** /platform/3/upgrade/cluster/nodes | 
[**GetUpgradev3ClusterPatchPatch**](UpgradeApi.md#GetUpgradev3ClusterPatchPatch) | **Get** /platform/3/upgrade/cluster/patch/patches/{v3ClusterPatchPatchId} | 
[**GetUpgradev3UpgradeCluster**](UpgradeApi.md#GetUpgradev3UpgradeCluster) | **Get** /platform/3/upgrade/cluster | 
[**GetUpgradev4UpgradeCluster**](UpgradeApi.md#GetUpgradev4UpgradeCluster) | **Get** /platform/4/upgrade/cluster | 
[**GetUpgradev7ClusterPatchPatch**](UpgradeApi.md#GetUpgradev7ClusterPatchPatch) | **Get** /platform/7/upgrade/cluster/patch/patches/{v7ClusterPatchPatchId} | 
[**GetUpgradev7UpgradeCluster**](UpgradeApi.md#GetUpgradev7UpgradeCluster) | **Get** /platform/7/upgrade/cluster | 
[**ListUpgradev11ClusterPatchPatches**](UpgradeApi.md#ListUpgradev11ClusterPatchPatches) | **Get** /platform/11/upgrade/cluster/patch/patches | 
[**ListUpgradev3ClusterPatchPatches**](UpgradeApi.md#ListUpgradev3ClusterPatchPatches) | **Get** /platform/3/upgrade/cluster/patch/patches | 
[**ListUpgradev7ClusterPatchPatches**](UpgradeApi.md#ListUpgradev7ClusterPatchPatches) | **Get** /platform/7/upgrade/cluster/patch/patches | 
[**UpdateUpgradev12ClusterDrain**](UpgradeApi.md#UpdateUpgradev12ClusterDrain) | **Put** /platform/12/upgrade/cluster/drain | 
[**UpdateUpgradev12ClusterDrainTimeout**](UpgradeApi.md#UpdateUpgradev12ClusterDrainTimeout) | **Put** /platform/12/upgrade/cluster/drain/timeout | 
[**UpdateUpgradev12ClusterUpgrade**](UpgradeApi.md#UpdateUpgradev12ClusterUpgrade) | **Put** /platform/12/upgrade/cluster/upgrade | 
[**UpdateUpgradev3ClusterUpgrade**](UpgradeApi.md#UpdateUpgradev3ClusterUpgrade) | **Put** /platform/3/upgrade/cluster/upgrade | 
[**UpdateUpgradev5ClusterUpgrade**](UpgradeApi.md#UpdateUpgradev5ClusterUpgrade) | **Put** /platform/5/upgrade/cluster/upgrade | 
[**UpdateUpgradev7ClusterUpgrade**](UpgradeApi.md#UpdateUpgradev7ClusterUpgrade) | **Put** /platform/7/upgrade/cluster/upgrade | 
[**UpdateUpgradev9ClusterUnblock**](UpgradeApi.md#UpdateUpgradev9ClusterUnblock) | **Put** /platform/9/upgrade/cluster/unblock | 
[**UpdateUpgradev9ClusterUpgrade**](UpgradeApi.md#UpdateUpgradev9ClusterUpgrade) | **Put** /platform/9/upgrade/cluster/upgrade | 



## CreateUpgradev10ClusterFirmwareAssessItem

> map[string]interface{} CreateUpgradev10ClusterFirmwareAssessItem(ctx).V10ClusterFirmwareAssessItem(v10ClusterFirmwareAssessItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ClusterFirmwareAssessItem := *openapiclient.NewV10ClusterFirmwareAssessItem() // V10ClusterFirmwareAssessItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev10ClusterFirmwareAssessItem(context.Background()).V10ClusterFirmwareAssessItem(v10ClusterFirmwareAssessItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev10ClusterFirmwareAssessItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev10ClusterFirmwareAssessItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev10ClusterFirmwareAssessItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev10ClusterFirmwareAssessItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10ClusterFirmwareAssessItem** | [**V10ClusterFirmwareAssessItem**](V10ClusterFirmwareAssessItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev10ClusterFirmwareUpgradeItem

> map[string]interface{} CreateUpgradev10ClusterFirmwareUpgradeItem(ctx).V10ClusterFirmwareUpgradeItem(v10ClusterFirmwareUpgradeItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ClusterFirmwareUpgradeItem := *openapiclient.NewV10ClusterFirmwareUpgradeItem() // V10ClusterFirmwareUpgradeItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev10ClusterFirmwareUpgradeItem(context.Background()).V10ClusterFirmwareUpgradeItem(v10ClusterFirmwareUpgradeItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev10ClusterFirmwareUpgradeItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev10ClusterFirmwareUpgradeItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev10ClusterFirmwareUpgradeItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev10ClusterFirmwareUpgradeItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10ClusterFirmwareUpgradeItem** | [**V10ClusterFirmwareUpgradeItem**](V10ClusterFirmwareUpgradeItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev11ClusterPatchPatch

> CreateResponse CreateUpgradev11ClusterPatchPatch(ctx).V11ClusterPatchPatch(v11ClusterPatchPatch).SkipConflictCheck(skipConflictCheck).SkipRestrictedCheck(skipRestrictedCheck).SkipDependencyCheck(skipDependencyCheck).SkipVersionCheck(skipVersionCheck).ProcessType(processType).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11ClusterPatchPatch := *openapiclient.NewV11ClusterPatchPatch("Patch_example") // V11ClusterPatchPatch | 
    skipConflictCheck := true // bool | Bypass conflict checks. Defaults to false. (optional)
    skipRestrictedCheck := true // bool | Bypass restricted checks. Defaults to false. (optional)
    skipDependencyCheck := true // bool | Bypass dependency checks. Defaults to false. (optional)
    skipVersionCheck := true // bool | Bypass version checks. Defaults to false. (optional)
    processType := "processType_example" // string | Process type can be 'simultaneous', 'rolling', or 'parallel'. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev11ClusterPatchPatch(context.Background()).V11ClusterPatchPatch(v11ClusterPatchPatch).SkipConflictCheck(skipConflictCheck).SkipRestrictedCheck(skipRestrictedCheck).SkipDependencyCheck(skipDependencyCheck).SkipVersionCheck(skipVersionCheck).ProcessType(processType).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev11ClusterPatchPatch``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev11ClusterPatchPatch`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev11ClusterPatchPatch`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev11ClusterPatchPatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v11ClusterPatchPatch** | [**V11ClusterPatchPatch**](V11ClusterPatchPatch.md) |  | 
 **skipConflictCheck** | **bool** | Bypass conflict checks. Defaults to false. | 
 **skipRestrictedCheck** | **bool** | Bypass restricted checks. Defaults to false. | 
 **skipDependencyCheck** | **bool** | Bypass dependency checks. Defaults to false. | 
 **skipVersionCheck** | **bool** | Bypass version checks. Defaults to false. | 
 **processType** | **string** | Process type can be &#39;simultaneous&#39;, &#39;rolling&#39;, or &#39;parallel&#39;. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev12ClusterFirmwareUpgradeItem

> map[string]interface{} CreateUpgradev12ClusterFirmwareUpgradeItem(ctx).V12ClusterFirmwareUpgradeItem(v12ClusterFirmwareUpgradeItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12ClusterFirmwareUpgradeItem := *openapiclient.NewV12ClusterFirmwareUpgradeItem("UpgradeType_example") // V12ClusterFirmwareUpgradeItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev12ClusterFirmwareUpgradeItem(context.Background()).V12ClusterFirmwareUpgradeItem(v12ClusterFirmwareUpgradeItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev12ClusterFirmwareUpgradeItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev12ClusterFirmwareUpgradeItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev12ClusterFirmwareUpgradeItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev12ClusterFirmwareUpgradeItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12ClusterFirmwareUpgradeItem** | [**V12ClusterFirmwareUpgradeItem**](V12ClusterFirmwareUpgradeItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev12ClusterUpgradeItem

> map[string]interface{} CreateUpgradev12ClusterUpgradeItem(ctx).V12ClusterUpgradeItem(v12ClusterUpgradeItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12ClusterUpgradeItem := *openapiclient.NewV12ClusterUpgradeItem("UpgradeType_example") // V12ClusterUpgradeItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev12ClusterUpgradeItem(context.Background()).V12ClusterUpgradeItem(v12ClusterUpgradeItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev12ClusterUpgradeItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev12ClusterUpgradeItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev12ClusterUpgradeItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev12ClusterUpgradeItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12ClusterUpgradeItem** | [**V12ClusterUpgradeItem**](V12ClusterUpgradeItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev3ClusterAddRemainingNode

> map[string]interface{} CreateUpgradev3ClusterAddRemainingNode(ctx).V3ClusterAddRemainingNode(v3ClusterAddRemainingNode).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterAddRemainingNode := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev3ClusterAddRemainingNode(context.Background()).V3ClusterAddRemainingNode(v3ClusterAddRemainingNode).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev3ClusterAddRemainingNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev3ClusterAddRemainingNode`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev3ClusterAddRemainingNode`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev3ClusterAddRemainingNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterAddRemainingNode** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev3ClusterArchiveItem

> map[string]interface{} CreateUpgradev3ClusterArchiveItem(ctx).V3ClusterArchiveItem(v3ClusterArchiveItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterArchiveItem := *openapiclient.NewV3ClusterArchiveItem() // V3ClusterArchiveItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev3ClusterArchiveItem(context.Background()).V3ClusterArchiveItem(v3ClusterArchiveItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev3ClusterArchiveItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev3ClusterArchiveItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev3ClusterArchiveItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev3ClusterArchiveItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterArchiveItem** | [**V3ClusterArchiveItem**](V3ClusterArchiveItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev3ClusterAssessItem

> map[string]interface{} CreateUpgradev3ClusterAssessItem(ctx).V3ClusterAssessItem(v3ClusterAssessItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterAssessItem := *openapiclient.NewV3ClusterAssessItem() // V3ClusterAssessItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev3ClusterAssessItem(context.Background()).V3ClusterAssessItem(v3ClusterAssessItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev3ClusterAssessItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev3ClusterAssessItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev3ClusterAssessItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev3ClusterAssessItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterAssessItem** | [**V3ClusterAssessItem**](V3ClusterAssessItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev3ClusterCommitItem

> map[string]interface{} CreateUpgradev3ClusterCommitItem(ctx).V3ClusterCommitItem(v3ClusterCommitItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterCommitItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev3ClusterCommitItem(context.Background()).V3ClusterCommitItem(v3ClusterCommitItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev3ClusterCommitItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev3ClusterCommitItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev3ClusterCommitItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev3ClusterCommitItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterCommitItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev3ClusterPatchAbortItem

> map[string]interface{} CreateUpgradev3ClusterPatchAbortItem(ctx).V3ClusterPatchAbortItem(v3ClusterPatchAbortItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterPatchAbortItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev3ClusterPatchAbortItem(context.Background()).V3ClusterPatchAbortItem(v3ClusterPatchAbortItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev3ClusterPatchAbortItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev3ClusterPatchAbortItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev3ClusterPatchAbortItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev3ClusterPatchAbortItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterPatchAbortItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev3ClusterPatchPatch

> CreateResponse CreateUpgradev3ClusterPatchPatch(ctx).V3ClusterPatchPatch(v3ClusterPatchPatch).Override(override).Rolling(rolling).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterPatchPatch := *openapiclient.NewV11ClusterPatchPatch("Patch_example") // V11ClusterPatchPatch | 
    override := true // bool | Whether to ignore patch system validation and force the installation. (optional)
    rolling := true // bool | Whether to install the patch on one node at a time. Defaults to true. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev3ClusterPatchPatch(context.Background()).V3ClusterPatchPatch(v3ClusterPatchPatch).Override(override).Rolling(rolling).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev3ClusterPatchPatch``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev3ClusterPatchPatch`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev3ClusterPatchPatch`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev3ClusterPatchPatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterPatchPatch** | [**V11ClusterPatchPatch**](V11ClusterPatchPatch.md) |  | 
 **override** | **bool** | Whether to ignore patch system validation and force the installation. | 
 **rolling** | **bool** | Whether to install the patch on one node at a time. Defaults to true. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev3ClusterRetryLastActionItem

> map[string]interface{} CreateUpgradev3ClusterRetryLastActionItem(ctx).V3ClusterRetryLastActionItem(v3ClusterRetryLastActionItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterRetryLastActionItem := *openapiclient.NewV3ClusterRetryLastActionItem() // V3ClusterRetryLastActionItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev3ClusterRetryLastActionItem(context.Background()).V3ClusterRetryLastActionItem(v3ClusterRetryLastActionItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev3ClusterRetryLastActionItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev3ClusterRetryLastActionItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev3ClusterRetryLastActionItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev3ClusterRetryLastActionItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterRetryLastActionItem** | [**V3ClusterRetryLastActionItem**](V3ClusterRetryLastActionItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev3ClusterRollbackItem

> map[string]interface{} CreateUpgradev3ClusterRollbackItem(ctx).V3ClusterRollbackItem(v3ClusterRollbackItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterRollbackItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev3ClusterRollbackItem(context.Background()).V3ClusterRollbackItem(v3ClusterRollbackItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev3ClusterRollbackItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev3ClusterRollbackItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev3ClusterRollbackItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev3ClusterRollbackItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterRollbackItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev3ClusterUpgradeItem

> map[string]interface{} CreateUpgradev3ClusterUpgradeItem(ctx).V3ClusterUpgradeItem(v3ClusterUpgradeItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterUpgradeItem := *openapiclient.NewV3ClusterUpgradeItem() // V3ClusterUpgradeItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev3ClusterUpgradeItem(context.Background()).V3ClusterUpgradeItem(v3ClusterUpgradeItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev3ClusterUpgradeItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev3ClusterUpgradeItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev3ClusterUpgradeItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev3ClusterUpgradeItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterUpgradeItem** | [**V3ClusterUpgradeItem**](V3ClusterUpgradeItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev5ClusterAssessItem

> map[string]interface{} CreateUpgradev5ClusterAssessItem(ctx).V5ClusterAssessItem(v5ClusterAssessItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5ClusterAssessItem := *openapiclient.NewV3ClusterAssessItem() // V3ClusterAssessItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev5ClusterAssessItem(context.Background()).V5ClusterAssessItem(v5ClusterAssessItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev5ClusterAssessItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev5ClusterAssessItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev5ClusterAssessItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev5ClusterAssessItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v5ClusterAssessItem** | [**V3ClusterAssessItem**](V3ClusterAssessItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev5ClusterUpgradeItem

> map[string]interface{} CreateUpgradev5ClusterUpgradeItem(ctx).V5ClusterUpgradeItem(v5ClusterUpgradeItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5ClusterUpgradeItem := *openapiclient.NewV3ClusterUpgradeItem() // V3ClusterUpgradeItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev5ClusterUpgradeItem(context.Background()).V5ClusterUpgradeItem(v5ClusterUpgradeItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev5ClusterUpgradeItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev5ClusterUpgradeItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev5ClusterUpgradeItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev5ClusterUpgradeItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v5ClusterUpgradeItem** | [**V3ClusterUpgradeItem**](V3ClusterUpgradeItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev7ClusterPatchPatch

> CreateResponse CreateUpgradev7ClusterPatchPatch(ctx).V7ClusterPatchPatch(v7ClusterPatchPatch).SkipVersionCheck(skipVersionCheck).SkipConflictCheck(skipConflictCheck).SkipRestrictedCheck(skipRestrictedCheck).Simultaneous(simultaneous).Rolling(rolling).SkipDependencyCheck(skipDependencyCheck).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterPatchPatch := *openapiclient.NewV11ClusterPatchPatch("Patch_example") // V11ClusterPatchPatch | 
    skipVersionCheck := true // bool | Bypass version checks. Defaults to false. (optional)
    skipConflictCheck := true // bool | Bypass conflict checks. Defaults to false. (optional)
    skipRestrictedCheck := true // bool | Bypass restricted checks. Defaults to false. (optional)
    simultaneous := true // bool | Install the patch on all nodes at once. Defaults to false. (optional)
    rolling := true // bool | Install the patch on one node at a time.  Defaults to true. (optional)
    skipDependencyCheck := true // bool | Bypass dependency checks. Defaults to false. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev7ClusterPatchPatch(context.Background()).V7ClusterPatchPatch(v7ClusterPatchPatch).SkipVersionCheck(skipVersionCheck).SkipConflictCheck(skipConflictCheck).SkipRestrictedCheck(skipRestrictedCheck).Simultaneous(simultaneous).Rolling(rolling).SkipDependencyCheck(skipDependencyCheck).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev7ClusterPatchPatch``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev7ClusterPatchPatch`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev7ClusterPatchPatch`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev7ClusterPatchPatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ClusterPatchPatch** | [**V11ClusterPatchPatch**](V11ClusterPatchPatch.md) |  | 
 **skipVersionCheck** | **bool** | Bypass version checks. Defaults to false. | 
 **skipConflictCheck** | **bool** | Bypass conflict checks. Defaults to false. | 
 **skipRestrictedCheck** | **bool** | Bypass restricted checks. Defaults to false. | 
 **simultaneous** | **bool** | Install the patch on all nodes at once. Defaults to false. | 
 **rolling** | **bool** | Install the patch on one node at a time.  Defaults to true. | 
 **skipDependencyCheck** | **bool** | Bypass dependency checks. Defaults to false. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev7ClusterPauseItem

> map[string]interface{} CreateUpgradev7ClusterPauseItem(ctx).V7ClusterPauseItem(v7ClusterPauseItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterPauseItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev7ClusterPauseItem(context.Background()).V7ClusterPauseItem(v7ClusterPauseItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev7ClusterPauseItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev7ClusterPauseItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev7ClusterPauseItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev7ClusterPauseItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ClusterPauseItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev7ClusterResumeItem

> map[string]interface{} CreateUpgradev7ClusterResumeItem(ctx).V7ClusterResumeItem(v7ClusterResumeItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterResumeItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev7ClusterResumeItem(context.Background()).V7ClusterResumeItem(v7ClusterResumeItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev7ClusterResumeItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev7ClusterResumeItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev7ClusterResumeItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev7ClusterResumeItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ClusterResumeItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev7ClusterUpgradeItem

> map[string]interface{} CreateUpgradev7ClusterUpgradeItem(ctx).V7ClusterUpgradeItem(v7ClusterUpgradeItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterUpgradeItem := *openapiclient.NewV7ClusterUpgradeItem() // V7ClusterUpgradeItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev7ClusterUpgradeItem(context.Background()).V7ClusterUpgradeItem(v7ClusterUpgradeItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev7ClusterUpgradeItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev7ClusterUpgradeItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev7ClusterUpgradeItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev7ClusterUpgradeItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ClusterUpgradeItem** | [**V7ClusterUpgradeItem**](V7ClusterUpgradeItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateUpgradev9ClusterUpgradeItem

> map[string]interface{} CreateUpgradev9ClusterUpgradeItem(ctx).V9ClusterUpgradeItem(v9ClusterUpgradeItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9ClusterUpgradeItem := *openapiclient.NewV9ClusterUpgradeItem("UpgradeType_example") // V9ClusterUpgradeItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.CreateUpgradev9ClusterUpgradeItem(context.Background()).V9ClusterUpgradeItem(v9ClusterUpgradeItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.CreateUpgradev9ClusterUpgradeItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateUpgradev9ClusterUpgradeItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.CreateUpgradev9ClusterUpgradeItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateUpgradev9ClusterUpgradeItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v9ClusterUpgradeItem** | [**V9ClusterUpgradeItem**](V9ClusterUpgradeItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteUpgradev11ClusterPatchPatch

> DeleteUpgradev11ClusterPatchPatch(ctx, v11ClusterPatchPatchId).SkipConflictCheck(skipConflictCheck).SkipRestrictedCheck(skipRestrictedCheck).SkipDependencyCheck(skipDependencyCheck).SkipVersionCheck(skipVersionCheck).ProcessType(processType).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11ClusterPatchPatchId := "v11ClusterPatchPatchId_example" // string | Uninstall a patch.
    skipConflictCheck := true // bool | Bypass conflict checks. Defaults to false. (optional)
    skipRestrictedCheck := true // bool | Bypass restricted checks. Defaults to false. (optional)
    skipDependencyCheck := true // bool | Bypass dependency checks. Defaults to false. (optional)
    skipVersionCheck := true // bool | Bypass version checks. Defaults to false. (optional)
    processType := "processType_example" // string | Process type can be 'simultaneous', 'rolling', or 'parallel' (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.DeleteUpgradev11ClusterPatchPatch(context.Background(), v11ClusterPatchPatchId).SkipConflictCheck(skipConflictCheck).SkipRestrictedCheck(skipRestrictedCheck).SkipDependencyCheck(skipDependencyCheck).SkipVersionCheck(skipVersionCheck).ProcessType(processType).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.DeleteUpgradev11ClusterPatchPatch``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11ClusterPatchPatchId** | **string** | Uninstall a patch. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteUpgradev11ClusterPatchPatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **skipConflictCheck** | **bool** | Bypass conflict checks. Defaults to false. | 
 **skipRestrictedCheck** | **bool** | Bypass restricted checks. Defaults to false. | 
 **skipDependencyCheck** | **bool** | Bypass dependency checks. Defaults to false. | 
 **skipVersionCheck** | **bool** | Bypass version checks. Defaults to false. | 
 **processType** | **string** | Process type can be &#39;simultaneous&#39;, &#39;rolling&#39;, or &#39;parallel&#39; | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteUpgradev3ClusterPatchPatch

> DeleteUpgradev3ClusterPatchPatch(ctx, v3ClusterPatchPatchId).Override(override).Rolling(rolling).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterPatchPatchId := "v3ClusterPatchPatchId_example" // string | Uninstall a patch.
    override := true // bool | Whether to ignore patch system validation and force the uninstallation. (optional)
    rolling := true // bool | Whether to uninstall the patch on one node at a time. Defaults to true. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.DeleteUpgradev3ClusterPatchPatch(context.Background(), v3ClusterPatchPatchId).Override(override).Rolling(rolling).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.DeleteUpgradev3ClusterPatchPatch``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ClusterPatchPatchId** | **string** | Uninstall a patch. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteUpgradev3ClusterPatchPatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **override** | **bool** | Whether to ignore patch system validation and force the uninstallation. | 
 **rolling** | **bool** | Whether to uninstall the patch on one node at a time. Defaults to true. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteUpgradev7ClusterPatchPatch

> DeleteUpgradev7ClusterPatchPatch(ctx, v7ClusterPatchPatchId).SkipVersionCheck(skipVersionCheck).SkipConflictCheck(skipConflictCheck).SkipRestrictedCheck(skipRestrictedCheck).Simultaneous(simultaneous).Rolling(rolling).SkipDependencyCheck(skipDependencyCheck).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterPatchPatchId := "v7ClusterPatchPatchId_example" // string | Uninstall a patch.
    skipVersionCheck := true // bool | Bypass version checks. Defaults to false. (optional)
    skipConflictCheck := true // bool | Bypass conflict checks. Defaults to false. (optional)
    skipRestrictedCheck := true // bool | Bypass restricted checks. Defaults to false. (optional)
    simultaneous := true // bool | Uninstall the patch on all nodes at once. Defaults to false. (optional)
    rolling := true // bool | Install the patch on one node at a time.  Defaults to true. (optional)
    skipDependencyCheck := true // bool | Bypass dependency checks. Defaults to false. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.DeleteUpgradev7ClusterPatchPatch(context.Background(), v7ClusterPatchPatchId).SkipVersionCheck(skipVersionCheck).SkipConflictCheck(skipConflictCheck).SkipRestrictedCheck(skipRestrictedCheck).Simultaneous(simultaneous).Rolling(rolling).SkipDependencyCheck(skipDependencyCheck).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.DeleteUpgradev7ClusterPatchPatch``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ClusterPatchPatchId** | **string** | Uninstall a patch. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteUpgradev7ClusterPatchPatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **skipVersionCheck** | **bool** | Bypass version checks. Defaults to false. | 
 **skipConflictCheck** | **bool** | Bypass conflict checks. Defaults to false. | 
 **skipRestrictedCheck** | **bool** | Bypass restricted checks. Defaults to false. | 
 **simultaneous** | **bool** | Uninstall the patch on all nodes at once. Defaults to false. | 
 **rolling** | **bool** | Install the patch on one node at a time.  Defaults to true. | 
 **skipDependencyCheck** | **bool** | Bypass dependency checks. Defaults to false. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev10ClusterFirmwareDevice

> V10ClusterFirmwareDevice GetUpgradev10ClusterFirmwareDevice(ctx).Refresh(refresh).Devices(devices).Package_(package_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    refresh := true // bool | Re-gather firmware status. Default is false. (optional)
    devices := true // bool | Show devices. If false, this returns an empty list. Default is false. (optional)
    package_ := true // bool | Show package. If false, this returns an empty list. Default is false. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev10ClusterFirmwareDevice(context.Background()).Refresh(refresh).Devices(devices).Package_(package_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev10ClusterFirmwareDevice``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev10ClusterFirmwareDevice`: V10ClusterFirmwareDevice
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev10ClusterFirmwareDevice`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev10ClusterFirmwareDeviceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **refresh** | **bool** | Re-gather firmware status. Default is false. | 
 **devices** | **bool** | Show devices. If false, this returns an empty list. Default is false. | 
 **package_** | **bool** | Show package. If false, this returns an empty list. Default is false. | 

### Return type

[**V10ClusterFirmwareDevice**](V10ClusterFirmwareDevice.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev10ClusterFirmwareStatus

> V10ClusterFirmwareStatus GetUpgradev10ClusterFirmwareStatus(ctx).Refresh(refresh).Devices(devices).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    refresh := true // bool | Re-gather firmware status. Default is false. (optional)
    devices := true // bool | Show devices. If false, this returns an empty list. Default is false. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev10ClusterFirmwareStatus(context.Background()).Refresh(refresh).Devices(devices).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev10ClusterFirmwareStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev10ClusterFirmwareStatus`: V10ClusterFirmwareStatus
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev10ClusterFirmwareStatus`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev10ClusterFirmwareStatusRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **refresh** | **bool** | Re-gather firmware status. Default is false. | 
 **devices** | **bool** | Show devices. If false, this returns an empty list. Default is false. | 

### Return type

[**V10ClusterFirmwareStatus**](V10ClusterFirmwareStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev11ClusterPatchPatch

> V11ClusterPatchPatchesExtended GetUpgradev11ClusterPatchPatch(ctx, v11ClusterPatchPatchId).Local(local).Location(location).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11ClusterPatchPatchId := "v11ClusterPatchPatchId_example" // string | View a single patch.
    local := true // bool | View patch information on local node only. (optional)
    location := "location_example" // string | Path location of patch file. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev11ClusterPatchPatch(context.Background(), v11ClusterPatchPatchId).Local(local).Location(location).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev11ClusterPatchPatch``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev11ClusterPatchPatch`: V11ClusterPatchPatchesExtended
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev11ClusterPatchPatch`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11ClusterPatchPatchId** | **string** | View a single patch. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev11ClusterPatchPatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **local** | **bool** | View patch information on local node only. | 
 **location** | **string** | Path location of patch file. | 

### Return type

[**V11ClusterPatchPatchesExtended**](V11ClusterPatchPatchesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev12ClusterDrainList

> V12ClusterDrainList GetUpgradev12ClusterDrainList(ctx).DrainList(drainList).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    drainList := "drainList_example" // string | Delay or Skip list.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev12ClusterDrainList(context.Background()).DrainList(drainList).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev12ClusterDrainList``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev12ClusterDrainList`: V12ClusterDrainList
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev12ClusterDrainList`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev12ClusterDrainListRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **drainList** | **string** | Delay or Skip list. | 

### Return type

[**V12ClusterDrainList**](V12ClusterDrainList.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev12ClusterDrainTimeout

> V12ClusterDrainTimeout GetUpgradev12ClusterDrainTimeout(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev12ClusterDrainTimeout(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev12ClusterDrainTimeout``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev12ClusterDrainTimeout`: V12ClusterDrainTimeout
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev12ClusterDrainTimeout`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev12ClusterDrainTimeoutRequest struct via the builder pattern


### Return type

[**V12ClusterDrainTimeout**](V12ClusterDrainTimeout.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev12ClusterNodes

> V12ClusterNodesExtended GetUpgradev12ClusterNodes(ctx).ByDomain(byDomain).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    byDomain := true // bool | If true, tag nodes that are assigned to like-failure domains (optional) (default to false)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev12ClusterNodes(context.Background()).ByDomain(byDomain).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev12ClusterNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev12ClusterNodes`: V12ClusterNodesExtended
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev12ClusterNodes`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev12ClusterNodesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **byDomain** | **bool** | If true, tag nodes that are assigned to like-failure domains | [default to false]

### Return type

[**V12ClusterNodesExtended**](V12ClusterNodesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev3ClusterFirmwareProgress

> V3ClusterFirmwareProgress GetUpgradev3ClusterFirmwareProgress(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev3ClusterFirmwareProgress(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev3ClusterFirmwareProgress``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev3ClusterFirmwareProgress`: V3ClusterFirmwareProgress
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev3ClusterFirmwareProgress`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev3ClusterFirmwareProgressRequest struct via the builder pattern


### Return type

[**V3ClusterFirmwareProgress**](V3ClusterFirmwareProgress.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev3ClusterFirmwareStatus

> V10ClusterFirmwareDevice GetUpgradev3ClusterFirmwareStatus(ctx).Refresh(refresh).Devices(devices).Package_(package_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    refresh := true // bool | Re-gather firmware status. Default is false. (optional)
    devices := true // bool | Show devices. If false, this returns an empty list. Default is false. (optional)
    package_ := true // bool | Show package. If false, this returns an empty list. Default is false. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev3ClusterFirmwareStatus(context.Background()).Refresh(refresh).Devices(devices).Package_(package_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev3ClusterFirmwareStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev3ClusterFirmwareStatus`: V10ClusterFirmwareDevice
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev3ClusterFirmwareStatus`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev3ClusterFirmwareStatusRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **refresh** | **bool** | Re-gather firmware status. Default is false. | 
 **devices** | **bool** | Show devices. If false, this returns an empty list. Default is false. | 
 **package_** | **bool** | Show package. If false, this returns an empty list. Default is false. | 

### Return type

[**V10ClusterFirmwareDevice**](V10ClusterFirmwareDevice.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev3ClusterNode

> V3ClusterNodeExtendedExtended GetUpgradev3ClusterNode(ctx, v3ClusterNodeId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterNodeId := int32(56) // int32 | The node details useful during an upgrade or assessment.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev3ClusterNode(context.Background(), v3ClusterNodeId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev3ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev3ClusterNode`: V3ClusterNodeExtendedExtended
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev3ClusterNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ClusterNodeId** | **int32** | The node details useful during an upgrade or assessment. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev3ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3ClusterNodeExtendedExtended**](V3ClusterNodeExtendedExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev3ClusterNodes

> V3ClusterNodesExtended GetUpgradev3ClusterNodes(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev3ClusterNodes(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev3ClusterNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev3ClusterNodes`: V3ClusterNodesExtended
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev3ClusterNodes`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev3ClusterNodesRequest struct via the builder pattern


### Return type

[**V3ClusterNodesExtended**](V3ClusterNodesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev3ClusterPatchPatch

> V11ClusterPatchPatchesExtended GetUpgradev3ClusterPatchPatch(ctx, v3ClusterPatchPatchId).Local(local).Location(location).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterPatchPatchId := "v3ClusterPatchPatchId_example" // string | View a single patch.
    local := true // bool | Only view patch information on the local node. (optional)
    location := "location_example" // string | Path location of patch file. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev3ClusterPatchPatch(context.Background(), v3ClusterPatchPatchId).Local(local).Location(location).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev3ClusterPatchPatch``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev3ClusterPatchPatch`: V11ClusterPatchPatchesExtended
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev3ClusterPatchPatch`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ClusterPatchPatchId** | **string** | View a single patch. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev3ClusterPatchPatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **local** | **bool** | Only view patch information on the local node. | 
 **location** | **string** | Path location of patch file. | 

### Return type

[**V11ClusterPatchPatchesExtended**](V11ClusterPatchPatchesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev3UpgradeCluster

> V3UpgradeCluster GetUpgradev3UpgradeCluster(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev3UpgradeCluster(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev3UpgradeCluster``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev3UpgradeCluster`: V3UpgradeCluster
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev3UpgradeCluster`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev3UpgradeClusterRequest struct via the builder pattern


### Return type

[**V3UpgradeCluster**](V3UpgradeCluster.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev4UpgradeCluster

> V4UpgradeCluster GetUpgradev4UpgradeCluster(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev4UpgradeCluster(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev4UpgradeCluster``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev4UpgradeCluster`: V4UpgradeCluster
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev4UpgradeCluster`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev4UpgradeClusterRequest struct via the builder pattern


### Return type

[**V4UpgradeCluster**](V4UpgradeCluster.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev7ClusterPatchPatch

> V11ClusterPatchPatchesExtended GetUpgradev7ClusterPatchPatch(ctx, v7ClusterPatchPatchId).Local(local).Location(location).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterPatchPatchId := "v7ClusterPatchPatchId_example" // string | View a single patch.
    local := true // bool | View patch information on local node only. (optional)
    location := "location_example" // string | Path location of patch file. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev7ClusterPatchPatch(context.Background(), v7ClusterPatchPatchId).Local(local).Location(location).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev7ClusterPatchPatch``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev7ClusterPatchPatch`: V11ClusterPatchPatchesExtended
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev7ClusterPatchPatch`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ClusterPatchPatchId** | **string** | View a single patch. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev7ClusterPatchPatchRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **local** | **bool** | View patch information on local node only. | 
 **location** | **string** | Path location of patch file. | 

### Return type

[**V11ClusterPatchPatchesExtended**](V11ClusterPatchPatchesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetUpgradev7UpgradeCluster

> V7UpgradeCluster GetUpgradev7UpgradeCluster(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.GetUpgradev7UpgradeCluster(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.GetUpgradev7UpgradeCluster``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetUpgradev7UpgradeCluster`: V7UpgradeCluster
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.GetUpgradev7UpgradeCluster`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetUpgradev7UpgradeClusterRequest struct via the builder pattern


### Return type

[**V7UpgradeCluster**](V7UpgradeCluster.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListUpgradev11ClusterPatchPatches

> V11ClusterPatchPatches ListUpgradev11ClusterPatchPatches(ctx).Sort(sort).Resume(resume).Limit(limit).Location(location).Local(local).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    location := "location_example" // string | Path location of patch file. (optional)
    local := true // bool | View patches on the local node only. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.ListUpgradev11ClusterPatchPatches(context.Background()).Sort(sort).Resume(resume).Limit(limit).Location(location).Local(local).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.ListUpgradev11ClusterPatchPatches``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListUpgradev11ClusterPatchPatches`: V11ClusterPatchPatches
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.ListUpgradev11ClusterPatchPatches`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListUpgradev11ClusterPatchPatchesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **location** | **string** | Path location of patch file. | 
 **local** | **bool** | View patches on the local node only. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V11ClusterPatchPatches**](V11ClusterPatchPatches.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListUpgradev3ClusterPatchPatches

> V11ClusterPatchPatches ListUpgradev3ClusterPatchPatches(ctx).Sort(sort).Resume(resume).Limit(limit).Location(location).Local(local).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    location := "location_example" // string | Path location of patch file. (optional)
    local := true // bool | Whether to view patches on the local node only. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.ListUpgradev3ClusterPatchPatches(context.Background()).Sort(sort).Resume(resume).Limit(limit).Location(location).Local(local).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.ListUpgradev3ClusterPatchPatches``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListUpgradev3ClusterPatchPatches`: V11ClusterPatchPatches
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.ListUpgradev3ClusterPatchPatches`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListUpgradev3ClusterPatchPatchesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **location** | **string** | Path location of patch file. | 
 **local** | **bool** | Whether to view patches on the local node only. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V11ClusterPatchPatches**](V11ClusterPatchPatches.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListUpgradev7ClusterPatchPatches

> V11ClusterPatchPatches ListUpgradev7ClusterPatchPatches(ctx).Sort(sort).Resume(resume).Limit(limit).Location(location).Local(local).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    location := "location_example" // string | Path location of patch file. (optional)
    local := true // bool | View patches on the local node only. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.UpgradeApi.ListUpgradev7ClusterPatchPatches(context.Background()).Sort(sort).Resume(resume).Limit(limit).Location(location).Local(local).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.ListUpgradev7ClusterPatchPatches``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListUpgradev7ClusterPatchPatches`: V11ClusterPatchPatches
    fmt.Fprintf(os.Stdout, "Response from `UpgradeApi.ListUpgradev7ClusterPatchPatches`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListUpgradev7ClusterPatchPatchesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **location** | **string** | Path location of patch file. | 
 **local** | **bool** | View patches on the local node only. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V11ClusterPatchPatches**](V11ClusterPatchPatches.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateUpgradev12ClusterDrain

> UpdateUpgradev12ClusterDrain(ctx).V12ClusterDrain(v12ClusterDrain).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12ClusterDrain := *openapiclient.NewV12ClusterDrain("Action_example", []int32{int32(123)}, "Task_example") // V12ClusterDrain | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.UpdateUpgradev12ClusterDrain(context.Background()).V12ClusterDrain(v12ClusterDrain).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.UpdateUpgradev12ClusterDrain``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateUpgradev12ClusterDrainRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12ClusterDrain** | [**V12ClusterDrain**](V12ClusterDrain.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateUpgradev12ClusterDrainTimeout

> UpdateUpgradev12ClusterDrainTimeout(ctx).V12ClusterDrainTimeout(v12ClusterDrainTimeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12ClusterDrainTimeout := *openapiclient.NewV12ClusterDrainTimeout() // V12ClusterDrainTimeout | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.UpdateUpgradev12ClusterDrainTimeout(context.Background()).V12ClusterDrainTimeout(v12ClusterDrainTimeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.UpdateUpgradev12ClusterDrainTimeout``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateUpgradev12ClusterDrainTimeoutRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12ClusterDrainTimeout** | [**V12ClusterDrainTimeout**](V12ClusterDrainTimeout.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateUpgradev12ClusterUpgrade

> UpdateUpgradev12ClusterUpgrade(ctx).V12ClusterUpgrade(v12ClusterUpgrade).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12ClusterUpgrade := *openapiclient.NewV12ClusterUpgrade() // V12ClusterUpgrade | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.UpdateUpgradev12ClusterUpgrade(context.Background()).V12ClusterUpgrade(v12ClusterUpgrade).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.UpdateUpgradev12ClusterUpgrade``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateUpgradev12ClusterUpgradeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12ClusterUpgrade** | [**V12ClusterUpgrade**](V12ClusterUpgrade.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateUpgradev3ClusterUpgrade

> UpdateUpgradev3ClusterUpgrade(ctx).V3ClusterUpgrade(v3ClusterUpgrade).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterUpgrade := *openapiclient.NewV12ClusterUpgrade() // V12ClusterUpgrade | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.UpdateUpgradev3ClusterUpgrade(context.Background()).V3ClusterUpgrade(v3ClusterUpgrade).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.UpdateUpgradev3ClusterUpgrade``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateUpgradev3ClusterUpgradeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterUpgrade** | [**V12ClusterUpgrade**](V12ClusterUpgrade.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateUpgradev5ClusterUpgrade

> UpdateUpgradev5ClusterUpgrade(ctx).V5ClusterUpgrade(v5ClusterUpgrade).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5ClusterUpgrade := *openapiclient.NewV12ClusterUpgrade() // V12ClusterUpgrade | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.UpdateUpgradev5ClusterUpgrade(context.Background()).V5ClusterUpgrade(v5ClusterUpgrade).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.UpdateUpgradev5ClusterUpgrade``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateUpgradev5ClusterUpgradeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v5ClusterUpgrade** | [**V12ClusterUpgrade**](V12ClusterUpgrade.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateUpgradev7ClusterUpgrade

> UpdateUpgradev7ClusterUpgrade(ctx).V7ClusterUpgrade(v7ClusterUpgrade).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterUpgrade := *openapiclient.NewV12ClusterUpgrade() // V12ClusterUpgrade | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.UpdateUpgradev7ClusterUpgrade(context.Background()).V7ClusterUpgrade(v7ClusterUpgrade).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.UpdateUpgradev7ClusterUpgrade``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateUpgradev7ClusterUpgradeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ClusterUpgrade** | [**V12ClusterUpgrade**](V12ClusterUpgrade.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateUpgradev9ClusterUnblock

> UpdateUpgradev9ClusterUnblock(ctx).V9ClusterUnblock(v9ClusterUnblock).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9ClusterUnblock := *openapiclient.NewV9ClusterUnblock(false) // V9ClusterUnblock | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.UpdateUpgradev9ClusterUnblock(context.Background()).V9ClusterUnblock(v9ClusterUnblock).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.UpdateUpgradev9ClusterUnblock``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateUpgradev9ClusterUnblockRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v9ClusterUnblock** | [**V9ClusterUnblock**](V9ClusterUnblock.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateUpgradev9ClusterUpgrade

> UpdateUpgradev9ClusterUpgrade(ctx).V9ClusterUpgrade(v9ClusterUpgrade).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9ClusterUpgrade := *openapiclient.NewV12ClusterUpgrade() // V12ClusterUpgrade | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.UpgradeApi.UpdateUpgradev9ClusterUpgrade(context.Background()).V9ClusterUpgrade(v9ClusterUpgrade).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `UpgradeApi.UpdateUpgradev9ClusterUpgrade``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateUpgradev9ClusterUpgradeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v9ClusterUpgrade** | [**V12ClusterUpgrade**](V12ClusterUpgrade.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

