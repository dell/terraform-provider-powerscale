# Createv12KmipServerVerifyItemResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nodes** | Pointer to [**[]Createv12KmipServerVerifyItemResponseNode**](Createv12KmipServerVerifyItemResponseNode.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewCreatev12KmipServerVerifyItemResponse

`func NewCreatev12KmipServerVerifyItemResponse() *Createv12KmipServerVerifyItemResponse`

NewCreatev12KmipServerVerifyItemResponse instantiates a new Createv12KmipServerVerifyItemResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev12KmipServerVerifyItemResponseWithDefaults

`func NewCreatev12KmipServerVerifyItemResponseWithDefaults() *Createv12KmipServerVerifyItemResponse`

NewCreatev12KmipServerVerifyItemResponseWithDefaults instantiates a new Createv12KmipServerVerifyItemResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNodes

`func (o *Createv12KmipServerVerifyItemResponse) GetNodes() []Createv12KmipServerVerifyItemResponseNode`

GetNodes returns the Nodes field if non-nil, zero value otherwise.

### GetNodesOk

`func (o *Createv12KmipServerVerifyItemResponse) GetNodesOk() (*[]Createv12KmipServerVerifyItemResponseNode, bool)`

GetNodesOk returns a tuple with the Nodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodes

`func (o *Createv12KmipServerVerifyItemResponse) SetNodes(v []Createv12KmipServerVerifyItemResponseNode)`

SetNodes sets Nodes field to given value.

### HasNodes

`func (o *Createv12KmipServerVerifyItemResponse) HasNodes() bool`

HasNodes returns a boolean if a field has been set.

### GetResume

`func (o *Createv12KmipServerVerifyItemResponse) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *Createv12KmipServerVerifyItemResponse) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *Createv12KmipServerVerifyItemResponse) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *Createv12KmipServerVerifyItemResponse) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *Createv12KmipServerVerifyItemResponse) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *Createv12KmipServerVerifyItemResponse) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *Createv12KmipServerVerifyItemResponse) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *Createv12KmipServerVerifyItemResponse) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


