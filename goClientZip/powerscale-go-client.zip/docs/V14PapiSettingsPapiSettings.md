# V14PapiSettingsPapiSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AutoConfigureChildLimit** | Pointer to **bool** | If true, PAPI automatically configures the child limit. | [optional] [default to true]
**ChildSettings** | Pointer to [**V14PapiSettingsPapiSettingsChildSettings**](V14PapiSettingsPapiSettingsChildSettings.md) |  | [optional] 

## Methods

### NewV14PapiSettingsPapiSettings

`func NewV14PapiSettingsPapiSettings() *V14PapiSettingsPapiSettings`

NewV14PapiSettingsPapiSettings instantiates a new V14PapiSettingsPapiSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14PapiSettingsPapiSettingsWithDefaults

`func NewV14PapiSettingsPapiSettingsWithDefaults() *V14PapiSettingsPapiSettings`

NewV14PapiSettingsPapiSettingsWithDefaults instantiates a new V14PapiSettingsPapiSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAutoConfigureChildLimit

`func (o *V14PapiSettingsPapiSettings) GetAutoConfigureChildLimit() bool`

GetAutoConfigureChildLimit returns the AutoConfigureChildLimit field if non-nil, zero value otherwise.

### GetAutoConfigureChildLimitOk

`func (o *V14PapiSettingsPapiSettings) GetAutoConfigureChildLimitOk() (*bool, bool)`

GetAutoConfigureChildLimitOk returns a tuple with the AutoConfigureChildLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutoConfigureChildLimit

`func (o *V14PapiSettingsPapiSettings) SetAutoConfigureChildLimit(v bool)`

SetAutoConfigureChildLimit sets AutoConfigureChildLimit field to given value.

### HasAutoConfigureChildLimit

`func (o *V14PapiSettingsPapiSettings) HasAutoConfigureChildLimit() bool`

HasAutoConfigureChildLimit returns a boolean if a field has been set.

### GetChildSettings

`func (o *V14PapiSettingsPapiSettings) GetChildSettings() V14PapiSettingsPapiSettingsChildSettings`

GetChildSettings returns the ChildSettings field if non-nil, zero value otherwise.

### GetChildSettingsOk

`func (o *V14PapiSettingsPapiSettings) GetChildSettingsOk() (*V14PapiSettingsPapiSettingsChildSettings, bool)`

GetChildSettingsOk returns a tuple with the ChildSettings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChildSettings

`func (o *V14PapiSettingsPapiSettings) SetChildSettings(v V14PapiSettingsPapiSettingsChildSettings)`

SetChildSettings sets ChildSettings field to given value.

### HasChildSettings

`func (o *V14PapiSettingsPapiSettings) HasChildSettings() bool`

HasChildSettings returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


