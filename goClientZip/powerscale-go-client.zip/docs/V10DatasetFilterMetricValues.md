# V10DatasetFilterMetricValues

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExportId** | Pointer to **float32** | NFS export ID | [optional] 
**Groupname** | Pointer to **string** | groupname | [optional] 
**LocalAddress** | Pointer to **string** | Local IPv4, IPv6 address, address range, or subnet. | [optional] 
**Path** | Pointer to **string** | Path of tracked directory | [optional] 
**Protocol** | Pointer to **string** | The protocol used for the request | [optional] 
**RemoteAddress** | Pointer to **string** | Client IPv4 or IPv6 address, address range, or subnet. | [optional] 
**ShareName** | Pointer to **string** | SMB share name | [optional] 
**Username** | Pointer to **string** | username | [optional] 
**ZoneName** | Pointer to **string** | The zone name | [optional] 

## Methods

### NewV10DatasetFilterMetricValues

`func NewV10DatasetFilterMetricValues() *V10DatasetFilterMetricValues`

NewV10DatasetFilterMetricValues instantiates a new V10DatasetFilterMetricValues object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10DatasetFilterMetricValuesWithDefaults

`func NewV10DatasetFilterMetricValuesWithDefaults() *V10DatasetFilterMetricValues`

NewV10DatasetFilterMetricValuesWithDefaults instantiates a new V10DatasetFilterMetricValues object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExportId

`func (o *V10DatasetFilterMetricValues) GetExportId() float32`

GetExportId returns the ExportId field if non-nil, zero value otherwise.

### GetExportIdOk

`func (o *V10DatasetFilterMetricValues) GetExportIdOk() (*float32, bool)`

GetExportIdOk returns a tuple with the ExportId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExportId

`func (o *V10DatasetFilterMetricValues) SetExportId(v float32)`

SetExportId sets ExportId field to given value.

### HasExportId

`func (o *V10DatasetFilterMetricValues) HasExportId() bool`

HasExportId returns a boolean if a field has been set.

### GetGroupname

`func (o *V10DatasetFilterMetricValues) GetGroupname() string`

GetGroupname returns the Groupname field if non-nil, zero value otherwise.

### GetGroupnameOk

`func (o *V10DatasetFilterMetricValues) GetGroupnameOk() (*string, bool)`

GetGroupnameOk returns a tuple with the Groupname field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupname

`func (o *V10DatasetFilterMetricValues) SetGroupname(v string)`

SetGroupname sets Groupname field to given value.

### HasGroupname

`func (o *V10DatasetFilterMetricValues) HasGroupname() bool`

HasGroupname returns a boolean if a field has been set.

### GetLocalAddress

`func (o *V10DatasetFilterMetricValues) GetLocalAddress() string`

GetLocalAddress returns the LocalAddress field if non-nil, zero value otherwise.

### GetLocalAddressOk

`func (o *V10DatasetFilterMetricValues) GetLocalAddressOk() (*string, bool)`

GetLocalAddressOk returns a tuple with the LocalAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocalAddress

`func (o *V10DatasetFilterMetricValues) SetLocalAddress(v string)`

SetLocalAddress sets LocalAddress field to given value.

### HasLocalAddress

`func (o *V10DatasetFilterMetricValues) HasLocalAddress() bool`

HasLocalAddress returns a boolean if a field has been set.

### GetPath

`func (o *V10DatasetFilterMetricValues) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V10DatasetFilterMetricValues) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V10DatasetFilterMetricValues) SetPath(v string)`

SetPath sets Path field to given value.

### HasPath

`func (o *V10DatasetFilterMetricValues) HasPath() bool`

HasPath returns a boolean if a field has been set.

### GetProtocol

`func (o *V10DatasetFilterMetricValues) GetProtocol() string`

GetProtocol returns the Protocol field if non-nil, zero value otherwise.

### GetProtocolOk

`func (o *V10DatasetFilterMetricValues) GetProtocolOk() (*string, bool)`

GetProtocolOk returns a tuple with the Protocol field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProtocol

`func (o *V10DatasetFilterMetricValues) SetProtocol(v string)`

SetProtocol sets Protocol field to given value.

### HasProtocol

`func (o *V10DatasetFilterMetricValues) HasProtocol() bool`

HasProtocol returns a boolean if a field has been set.

### GetRemoteAddress

`func (o *V10DatasetFilterMetricValues) GetRemoteAddress() string`

GetRemoteAddress returns the RemoteAddress field if non-nil, zero value otherwise.

### GetRemoteAddressOk

`func (o *V10DatasetFilterMetricValues) GetRemoteAddressOk() (*string, bool)`

GetRemoteAddressOk returns a tuple with the RemoteAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteAddress

`func (o *V10DatasetFilterMetricValues) SetRemoteAddress(v string)`

SetRemoteAddress sets RemoteAddress field to given value.

### HasRemoteAddress

`func (o *V10DatasetFilterMetricValues) HasRemoteAddress() bool`

HasRemoteAddress returns a boolean if a field has been set.

### GetShareName

`func (o *V10DatasetFilterMetricValues) GetShareName() string`

GetShareName returns the ShareName field if non-nil, zero value otherwise.

### GetShareNameOk

`func (o *V10DatasetFilterMetricValues) GetShareNameOk() (*string, bool)`

GetShareNameOk returns a tuple with the ShareName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShareName

`func (o *V10DatasetFilterMetricValues) SetShareName(v string)`

SetShareName sets ShareName field to given value.

### HasShareName

`func (o *V10DatasetFilterMetricValues) HasShareName() bool`

HasShareName returns a boolean if a field has been set.

### GetUsername

`func (o *V10DatasetFilterMetricValues) GetUsername() string`

GetUsername returns the Username field if non-nil, zero value otherwise.

### GetUsernameOk

`func (o *V10DatasetFilterMetricValues) GetUsernameOk() (*string, bool)`

GetUsernameOk returns a tuple with the Username field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsername

`func (o *V10DatasetFilterMetricValues) SetUsername(v string)`

SetUsername sets Username field to given value.

### HasUsername

`func (o *V10DatasetFilterMetricValues) HasUsername() bool`

HasUsername returns a boolean if a field has been set.

### GetZoneName

`func (o *V10DatasetFilterMetricValues) GetZoneName() string`

GetZoneName returns the ZoneName field if non-nil, zero value otherwise.

### GetZoneNameOk

`func (o *V10DatasetFilterMetricValues) GetZoneNameOk() (*string, bool)`

GetZoneNameOk returns a tuple with the ZoneName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZoneName

`func (o *V10DatasetFilterMetricValues) SetZoneName(v string)`

SetZoneName sets ZoneName field to given value.

### HasZoneName

`func (o *V10DatasetFilterMetricValues) HasZoneName() bool`

HasZoneName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


