# V10HealthcheckChecklist

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Delivery** | Pointer to [**[]V10HealthcheckChecklistDeliveryItem**](V10HealthcheckChecklistDeliveryItem.md) | List of delivery addresses/methods for results | [optional] 
**Description** | Pointer to **string** | Description covering intended use | [optional] 
**History** | Pointer to **int32** | Number of evaluation results to keep | [optional] 
**Id** | Pointer to **string** | Unique identifier | [optional] 
**Items** | Pointer to [**[]V10HealthcheckChecklistItem**](V10HealthcheckChecklistItem.md) | Items to be evaluated | [optional] 

## Methods

### NewV10HealthcheckChecklist

`func NewV10HealthcheckChecklist() *V10HealthcheckChecklist`

NewV10HealthcheckChecklist instantiates a new V10HealthcheckChecklist object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckChecklistWithDefaults

`func NewV10HealthcheckChecklistWithDefaults() *V10HealthcheckChecklist`

NewV10HealthcheckChecklistWithDefaults instantiates a new V10HealthcheckChecklist object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDelivery

`func (o *V10HealthcheckChecklist) GetDelivery() []V10HealthcheckChecklistDeliveryItem`

GetDelivery returns the Delivery field if non-nil, zero value otherwise.

### GetDeliveryOk

`func (o *V10HealthcheckChecklist) GetDeliveryOk() (*[]V10HealthcheckChecklistDeliveryItem, bool)`

GetDeliveryOk returns a tuple with the Delivery field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDelivery

`func (o *V10HealthcheckChecklist) SetDelivery(v []V10HealthcheckChecklistDeliveryItem)`

SetDelivery sets Delivery field to given value.

### HasDelivery

`func (o *V10HealthcheckChecklist) HasDelivery() bool`

HasDelivery returns a boolean if a field has been set.

### GetDescription

`func (o *V10HealthcheckChecklist) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V10HealthcheckChecklist) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V10HealthcheckChecklist) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V10HealthcheckChecklist) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetHistory

`func (o *V10HealthcheckChecklist) GetHistory() int32`

GetHistory returns the History field if non-nil, zero value otherwise.

### GetHistoryOk

`func (o *V10HealthcheckChecklist) GetHistoryOk() (*int32, bool)`

GetHistoryOk returns a tuple with the History field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHistory

`func (o *V10HealthcheckChecklist) SetHistory(v int32)`

SetHistory sets History field to given value.

### HasHistory

`func (o *V10HealthcheckChecklist) HasHistory() bool`

HasHistory returns a boolean if a field has been set.

### GetId

`func (o *V10HealthcheckChecklist) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10HealthcheckChecklist) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10HealthcheckChecklist) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V10HealthcheckChecklist) HasId() bool`

HasId returns a boolean if a field has been set.

### GetItems

`func (o *V10HealthcheckChecklist) GetItems() []V10HealthcheckChecklistItem`

GetItems returns the Items field if non-nil, zero value otherwise.

### GetItemsOk

`func (o *V10HealthcheckChecklist) GetItemsOk() (*[]V10HealthcheckChecklistItem, bool)`

GetItemsOk returns a tuple with the Items field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetItems

`func (o *V10HealthcheckChecklist) SetItems(v []V10HealthcheckChecklistItem)`

SetItems sets Items field to given value.

### HasItems

`func (o *V10HealthcheckChecklist) HasItems() bool`

HasItems returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


