# \FilepoolApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateFilepoolv12FilepoolPolicy**](FilepoolApi.md#CreateFilepoolv12FilepoolPolicy) | **Post** /platform/12/filepool/policies | 
[**CreateFilepoolv1FilepoolPolicy**](FilepoolApi.md#CreateFilepoolv1FilepoolPolicy) | **Post** /platform/1/filepool/policies | 
[**CreateFilepoolv4FilepoolPolicy**](FilepoolApi.md#CreateFilepoolv4FilepoolPolicy) | **Post** /platform/4/filepool/policies | 
[**DeleteFilepoolv12FilepoolPolicy**](FilepoolApi.md#DeleteFilepoolv12FilepoolPolicy) | **Delete** /platform/12/filepool/policies/{v12FilepoolPolicyId} | 
[**DeleteFilepoolv1FilepoolPolicy**](FilepoolApi.md#DeleteFilepoolv1FilepoolPolicy) | **Delete** /platform/1/filepool/policies/{v1FilepoolPolicyId} | 
[**DeleteFilepoolv4FilepoolPolicy**](FilepoolApi.md#DeleteFilepoolv4FilepoolPolicy) | **Delete** /platform/4/filepool/policies/{v4FilepoolPolicyId} | 
[**GetFilepoolv12FilepoolPolicy**](FilepoolApi.md#GetFilepoolv12FilepoolPolicy) | **Get** /platform/12/filepool/policies/{v12FilepoolPolicyId} | 
[**GetFilepoolv1FilepoolDefaultPolicy**](FilepoolApi.md#GetFilepoolv1FilepoolDefaultPolicy) | **Get** /platform/1/filepool/default-policy | 
[**GetFilepoolv1FilepoolPolicy**](FilepoolApi.md#GetFilepoolv1FilepoolPolicy) | **Get** /platform/1/filepool/policies/{v1FilepoolPolicyId} | 
[**GetFilepoolv1FilepoolTemplate**](FilepoolApi.md#GetFilepoolv1FilepoolTemplate) | **Get** /platform/1/filepool/templates/{v1FilepoolTemplateId} | 
[**GetFilepoolv1FilepoolTemplates**](FilepoolApi.md#GetFilepoolv1FilepoolTemplates) | **Get** /platform/1/filepool/templates | 
[**GetFilepoolv4FilepoolDefaultPolicy**](FilepoolApi.md#GetFilepoolv4FilepoolDefaultPolicy) | **Get** /platform/4/filepool/default-policy | 
[**GetFilepoolv4FilepoolPolicy**](FilepoolApi.md#GetFilepoolv4FilepoolPolicy) | **Get** /platform/4/filepool/policies/{v4FilepoolPolicyId} | 
[**GetFilepoolv4FilepoolTemplate**](FilepoolApi.md#GetFilepoolv4FilepoolTemplate) | **Get** /platform/4/filepool/templates/{v4FilepoolTemplateId} | 
[**GetFilepoolv4FilepoolTemplates**](FilepoolApi.md#GetFilepoolv4FilepoolTemplates) | **Get** /platform/4/filepool/templates | 
[**ListFilepoolv12FilepoolPolicies**](FilepoolApi.md#ListFilepoolv12FilepoolPolicies) | **Get** /platform/12/filepool/policies | 
[**ListFilepoolv1FilepoolPolicies**](FilepoolApi.md#ListFilepoolv1FilepoolPolicies) | **Get** /platform/1/filepool/policies | 
[**ListFilepoolv4FilepoolPolicies**](FilepoolApi.md#ListFilepoolv4FilepoolPolicies) | **Get** /platform/4/filepool/policies | 
[**UpdateFilepoolv12FilepoolPolicy**](FilepoolApi.md#UpdateFilepoolv12FilepoolPolicy) | **Put** /platform/12/filepool/policies/{v12FilepoolPolicyId} | 
[**UpdateFilepoolv1FilepoolDefaultPolicy**](FilepoolApi.md#UpdateFilepoolv1FilepoolDefaultPolicy) | **Put** /platform/1/filepool/default-policy | 
[**UpdateFilepoolv1FilepoolPolicy**](FilepoolApi.md#UpdateFilepoolv1FilepoolPolicy) | **Put** /platform/1/filepool/policies/{v1FilepoolPolicyId} | 
[**UpdateFilepoolv4FilepoolDefaultPolicy**](FilepoolApi.md#UpdateFilepoolv4FilepoolDefaultPolicy) | **Put** /platform/4/filepool/default-policy | 
[**UpdateFilepoolv4FilepoolPolicy**](FilepoolApi.md#UpdateFilepoolv4FilepoolPolicy) | **Put** /platform/4/filepool/policies/{v4FilepoolPolicyId} | 



## CreateFilepoolv12FilepoolPolicy

> Createv1FilepoolPolicyResponse CreateFilepoolv12FilepoolPolicy(ctx).V12FilepoolPolicy(v12FilepoolPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12FilepoolPolicy := *openapiclient.NewV12FilepoolPolicy([]openapiclient.V1FilepoolDefaultPolicyAction{*openapiclient.NewV1FilepoolDefaultPolicyAction("ActionParam_example", "ActionType_example")}, *openapiclient.NewV1FilepoolPolicyFileMatchingPattern([]openapiclient.V1FilepoolPolicyFileMatchingPatternOrCriteriaItem{*openapiclient.NewV1FilepoolPolicyFileMatchingPatternOrCriteriaItem([]openapiclient.V1FilepoolPolicyFileMatchingPatternOrCriteriaItemAndCriteriaItem{*openapiclient.NewV1FilepoolPolicyFileMatchingPatternOrCriteriaItemAndCriteriaItem("Type_example")})}), "Name_example") // V12FilepoolPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.CreateFilepoolv12FilepoolPolicy(context.Background()).V12FilepoolPolicy(v12FilepoolPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.CreateFilepoolv12FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateFilepoolv12FilepoolPolicy`: Createv1FilepoolPolicyResponse
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.CreateFilepoolv12FilepoolPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateFilepoolv12FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12FilepoolPolicy** | [**V12FilepoolPolicy**](V12FilepoolPolicy.md) |  | 

### Return type

[**Createv1FilepoolPolicyResponse**](Createv1FilepoolPolicyResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateFilepoolv1FilepoolPolicy

> Createv1FilepoolPolicyResponse CreateFilepoolv1FilepoolPolicy(ctx).V1FilepoolPolicy(v1FilepoolPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1FilepoolPolicy := *openapiclient.NewV1FilepoolPolicy([]openapiclient.V1FilepoolDefaultPolicyDefaultPolicyAction{*openapiclient.NewV1FilepoolDefaultPolicyDefaultPolicyAction("ActionParam_example", "ActionType_example")}, *openapiclient.NewV1FilepoolPolicyFileMatchingPattern([]openapiclient.V1FilepoolPolicyFileMatchingPatternOrCriteriaItem{*openapiclient.NewV1FilepoolPolicyFileMatchingPatternOrCriteriaItem([]openapiclient.V1FilepoolPolicyFileMatchingPatternOrCriteriaItemAndCriteriaItem{*openapiclient.NewV1FilepoolPolicyFileMatchingPatternOrCriteriaItemAndCriteriaItem("Type_example")})}), "Name_example") // V1FilepoolPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.CreateFilepoolv1FilepoolPolicy(context.Background()).V1FilepoolPolicy(v1FilepoolPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.CreateFilepoolv1FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateFilepoolv1FilepoolPolicy`: Createv1FilepoolPolicyResponse
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.CreateFilepoolv1FilepoolPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateFilepoolv1FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1FilepoolPolicy** | [**V1FilepoolPolicy**](V1FilepoolPolicy.md) |  | 

### Return type

[**Createv1FilepoolPolicyResponse**](Createv1FilepoolPolicyResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateFilepoolv4FilepoolPolicy

> Createv1FilepoolPolicyResponse CreateFilepoolv4FilepoolPolicy(ctx).V4FilepoolPolicy(v4FilepoolPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4FilepoolPolicy := *openapiclient.NewV12FilepoolPolicy([]openapiclient.V1FilepoolDefaultPolicyAction{*openapiclient.NewV1FilepoolDefaultPolicyAction("ActionParam_example", "ActionType_example")}, *openapiclient.NewV1FilepoolPolicyFileMatchingPattern([]openapiclient.V1FilepoolPolicyFileMatchingPatternOrCriteriaItem{*openapiclient.NewV1FilepoolPolicyFileMatchingPatternOrCriteriaItem([]openapiclient.V1FilepoolPolicyFileMatchingPatternOrCriteriaItemAndCriteriaItem{*openapiclient.NewV1FilepoolPolicyFileMatchingPatternOrCriteriaItemAndCriteriaItem("Type_example")})}), "Name_example") // V12FilepoolPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.CreateFilepoolv4FilepoolPolicy(context.Background()).V4FilepoolPolicy(v4FilepoolPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.CreateFilepoolv4FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateFilepoolv4FilepoolPolicy`: Createv1FilepoolPolicyResponse
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.CreateFilepoolv4FilepoolPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateFilepoolv4FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4FilepoolPolicy** | [**V12FilepoolPolicy**](V12FilepoolPolicy.md) |  | 

### Return type

[**Createv1FilepoolPolicyResponse**](Createv1FilepoolPolicyResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFilepoolv12FilepoolPolicy

> DeleteFilepoolv12FilepoolPolicy(ctx, v12FilepoolPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12FilepoolPolicyId := "v12FilepoolPolicyId_example" // string | Delete file pool policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilepoolApi.DeleteFilepoolv12FilepoolPolicy(context.Background(), v12FilepoolPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.DeleteFilepoolv12FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12FilepoolPolicyId** | **string** | Delete file pool policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteFilepoolv12FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFilepoolv1FilepoolPolicy

> DeleteFilepoolv1FilepoolPolicy(ctx, v1FilepoolPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1FilepoolPolicyId := "v1FilepoolPolicyId_example" // string | Delete file pool policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilepoolApi.DeleteFilepoolv1FilepoolPolicy(context.Background(), v1FilepoolPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.DeleteFilepoolv1FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1FilepoolPolicyId** | **string** | Delete file pool policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteFilepoolv1FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFilepoolv4FilepoolPolicy

> DeleteFilepoolv4FilepoolPolicy(ctx, v4FilepoolPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4FilepoolPolicyId := "v4FilepoolPolicyId_example" // string | Delete file pool policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilepoolApi.DeleteFilepoolv4FilepoolPolicy(context.Background(), v4FilepoolPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.DeleteFilepoolv4FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4FilepoolPolicyId** | **string** | Delete file pool policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteFilepoolv4FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilepoolv12FilepoolPolicy

> V12FilepoolPoliciesExtended GetFilepoolv12FilepoolPolicy(ctx, v12FilepoolPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12FilepoolPolicyId := "v12FilepoolPolicyId_example" // string | Retrieve file pool policy information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.GetFilepoolv12FilepoolPolicy(context.Background(), v12FilepoolPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.GetFilepoolv12FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilepoolv12FilepoolPolicy`: V12FilepoolPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.GetFilepoolv12FilepoolPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12FilepoolPolicyId** | **string** | Retrieve file pool policy information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilepoolv12FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12FilepoolPoliciesExtended**](V12FilepoolPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilepoolv1FilepoolDefaultPolicy

> V1FilepoolDefaultPolicy GetFilepoolv1FilepoolDefaultPolicy(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.GetFilepoolv1FilepoolDefaultPolicy(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.GetFilepoolv1FilepoolDefaultPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilepoolv1FilepoolDefaultPolicy`: V1FilepoolDefaultPolicy
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.GetFilepoolv1FilepoolDefaultPolicy`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilepoolv1FilepoolDefaultPolicyRequest struct via the builder pattern


### Return type

[**V1FilepoolDefaultPolicy**](V1FilepoolDefaultPolicy.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilepoolv1FilepoolPolicy

> V1FilepoolPoliciesExtended GetFilepoolv1FilepoolPolicy(ctx, v1FilepoolPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1FilepoolPolicyId := "v1FilepoolPolicyId_example" // string | Retrieve file pool policy information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.GetFilepoolv1FilepoolPolicy(context.Background(), v1FilepoolPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.GetFilepoolv1FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilepoolv1FilepoolPolicy`: V1FilepoolPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.GetFilepoolv1FilepoolPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1FilepoolPolicyId** | **string** | Retrieve file pool policy information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilepoolv1FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1FilepoolPoliciesExtended**](V1FilepoolPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilepoolv1FilepoolTemplate

> V1FilepoolTemplatesExtended GetFilepoolv1FilepoolTemplate(ctx, v1FilepoolTemplateId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1FilepoolTemplateId := "v1FilepoolTemplateId_example" // string | List all templates.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.GetFilepoolv1FilepoolTemplate(context.Background(), v1FilepoolTemplateId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.GetFilepoolv1FilepoolTemplate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilepoolv1FilepoolTemplate`: V1FilepoolTemplatesExtended
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.GetFilepoolv1FilepoolTemplate`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1FilepoolTemplateId** | **string** | List all templates. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilepoolv1FilepoolTemplateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1FilepoolTemplatesExtended**](V1FilepoolTemplatesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilepoolv1FilepoolTemplates

> V1FilepoolTemplates GetFilepoolv1FilepoolTemplates(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.GetFilepoolv1FilepoolTemplates(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.GetFilepoolv1FilepoolTemplates``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilepoolv1FilepoolTemplates`: V1FilepoolTemplates
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.GetFilepoolv1FilepoolTemplates`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilepoolv1FilepoolTemplatesRequest struct via the builder pattern


### Return type

[**V1FilepoolTemplates**](V1FilepoolTemplates.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilepoolv4FilepoolDefaultPolicy

> V4FilepoolDefaultPolicy GetFilepoolv4FilepoolDefaultPolicy(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.GetFilepoolv4FilepoolDefaultPolicy(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.GetFilepoolv4FilepoolDefaultPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilepoolv4FilepoolDefaultPolicy`: V4FilepoolDefaultPolicy
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.GetFilepoolv4FilepoolDefaultPolicy`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilepoolv4FilepoolDefaultPolicyRequest struct via the builder pattern


### Return type

[**V4FilepoolDefaultPolicy**](V4FilepoolDefaultPolicy.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilepoolv4FilepoolPolicy

> V4FilepoolPoliciesExtended GetFilepoolv4FilepoolPolicy(ctx, v4FilepoolPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4FilepoolPolicyId := "v4FilepoolPolicyId_example" // string | Retrieve file pool policy information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.GetFilepoolv4FilepoolPolicy(context.Background(), v4FilepoolPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.GetFilepoolv4FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilepoolv4FilepoolPolicy`: V4FilepoolPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.GetFilepoolv4FilepoolPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4FilepoolPolicyId** | **string** | Retrieve file pool policy information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilepoolv4FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4FilepoolPoliciesExtended**](V4FilepoolPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilepoolv4FilepoolTemplate

> V4FilepoolTemplatesExtended GetFilepoolv4FilepoolTemplate(ctx, v4FilepoolTemplateId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4FilepoolTemplateId := "v4FilepoolTemplateId_example" // string | List all templates.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.GetFilepoolv4FilepoolTemplate(context.Background(), v4FilepoolTemplateId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.GetFilepoolv4FilepoolTemplate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilepoolv4FilepoolTemplate`: V4FilepoolTemplatesExtended
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.GetFilepoolv4FilepoolTemplate`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4FilepoolTemplateId** | **string** | List all templates. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilepoolv4FilepoolTemplateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4FilepoolTemplatesExtended**](V4FilepoolTemplatesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilepoolv4FilepoolTemplates

> V4FilepoolTemplates GetFilepoolv4FilepoolTemplates(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.GetFilepoolv4FilepoolTemplates(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.GetFilepoolv4FilepoolTemplates``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilepoolv4FilepoolTemplates`: V4FilepoolTemplates
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.GetFilepoolv4FilepoolTemplates`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilepoolv4FilepoolTemplatesRequest struct via the builder pattern


### Return type

[**V4FilepoolTemplates**](V4FilepoolTemplates.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListFilepoolv12FilepoolPolicies

> V12FilepoolPolicies ListFilepoolv12FilepoolPolicies(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.ListFilepoolv12FilepoolPolicies(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.ListFilepoolv12FilepoolPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListFilepoolv12FilepoolPolicies`: V12FilepoolPolicies
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.ListFilepoolv12FilepoolPolicies`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListFilepoolv12FilepoolPoliciesRequest struct via the builder pattern


### Return type

[**V12FilepoolPolicies**](V12FilepoolPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListFilepoolv1FilepoolPolicies

> V1FilepoolPolicies ListFilepoolv1FilepoolPolicies(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.ListFilepoolv1FilepoolPolicies(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.ListFilepoolv1FilepoolPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListFilepoolv1FilepoolPolicies`: V1FilepoolPolicies
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.ListFilepoolv1FilepoolPolicies`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListFilepoolv1FilepoolPoliciesRequest struct via the builder pattern


### Return type

[**V1FilepoolPolicies**](V1FilepoolPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListFilepoolv4FilepoolPolicies

> V4FilepoolPolicies ListFilepoolv4FilepoolPolicies(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilepoolApi.ListFilepoolv4FilepoolPolicies(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.ListFilepoolv4FilepoolPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListFilepoolv4FilepoolPolicies`: V4FilepoolPolicies
    fmt.Fprintf(os.Stdout, "Response from `FilepoolApi.ListFilepoolv4FilepoolPolicies`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListFilepoolv4FilepoolPoliciesRequest struct via the builder pattern


### Return type

[**V4FilepoolPolicies**](V4FilepoolPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFilepoolv12FilepoolPolicy

> UpdateFilepoolv12FilepoolPolicy(ctx, v12FilepoolPolicyId).V12FilepoolPolicy(v12FilepoolPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12FilepoolPolicyId := "v12FilepoolPolicyId_example" // string | Modify file pool policy. All input fields are optional, but one or more must be supplied.
    v12FilepoolPolicy := *openapiclient.NewV12FilepoolPolicyExtendedExtended([]openapiclient.V1FilepoolDefaultPolicyAction{*openapiclient.NewV1FilepoolDefaultPolicyAction("ActionParam_example", "ActionType_example")}) // V12FilepoolPolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilepoolApi.UpdateFilepoolv12FilepoolPolicy(context.Background(), v12FilepoolPolicyId).V12FilepoolPolicy(v12FilepoolPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.UpdateFilepoolv12FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12FilepoolPolicyId** | **string** | Modify file pool policy. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFilepoolv12FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12FilepoolPolicy** | [**V12FilepoolPolicyExtendedExtended**](V12FilepoolPolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFilepoolv1FilepoolDefaultPolicy

> UpdateFilepoolv1FilepoolDefaultPolicy(ctx).V1FilepoolDefaultPolicy(v1FilepoolDefaultPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1FilepoolDefaultPolicy := *openapiclient.NewV1FilepoolDefaultPolicyExtended([]openapiclient.V1FilepoolDefaultPolicyAction{*openapiclient.NewV1FilepoolDefaultPolicyAction("ActionParam_example", "ActionType_example")}) // V1FilepoolDefaultPolicyExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilepoolApi.UpdateFilepoolv1FilepoolDefaultPolicy(context.Background()).V1FilepoolDefaultPolicy(v1FilepoolDefaultPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.UpdateFilepoolv1FilepoolDefaultPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFilepoolv1FilepoolDefaultPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1FilepoolDefaultPolicy** | [**V1FilepoolDefaultPolicyExtended**](V1FilepoolDefaultPolicyExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFilepoolv1FilepoolPolicy

> UpdateFilepoolv1FilepoolPolicy(ctx, v1FilepoolPolicyId).V1FilepoolPolicy(v1FilepoolPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1FilepoolPolicyId := "v1FilepoolPolicyId_example" // string | Modify file pool policy. All input fields are optional, but one or more must be supplied.
    v1FilepoolPolicy := *openapiclient.NewV1FilepoolPolicyExtendedExtended([]openapiclient.V1FilepoolDefaultPolicyDefaultPolicyAction{*openapiclient.NewV1FilepoolDefaultPolicyDefaultPolicyAction("ActionParam_example", "ActionType_example")}) // V1FilepoolPolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilepoolApi.UpdateFilepoolv1FilepoolPolicy(context.Background(), v1FilepoolPolicyId).V1FilepoolPolicy(v1FilepoolPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.UpdateFilepoolv1FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1FilepoolPolicyId** | **string** | Modify file pool policy. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFilepoolv1FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1FilepoolPolicy** | [**V1FilepoolPolicyExtendedExtended**](V1FilepoolPolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFilepoolv4FilepoolDefaultPolicy

> UpdateFilepoolv4FilepoolDefaultPolicy(ctx).V4FilepoolDefaultPolicy(v4FilepoolDefaultPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4FilepoolDefaultPolicy := *openapiclient.NewV1FilepoolDefaultPolicyExtended([]openapiclient.V1FilepoolDefaultPolicyAction{*openapiclient.NewV1FilepoolDefaultPolicyAction("ActionParam_example", "ActionType_example")}) // V1FilepoolDefaultPolicyExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilepoolApi.UpdateFilepoolv4FilepoolDefaultPolicy(context.Background()).V4FilepoolDefaultPolicy(v4FilepoolDefaultPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.UpdateFilepoolv4FilepoolDefaultPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFilepoolv4FilepoolDefaultPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4FilepoolDefaultPolicy** | [**V1FilepoolDefaultPolicyExtended**](V1FilepoolDefaultPolicyExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFilepoolv4FilepoolPolicy

> UpdateFilepoolv4FilepoolPolicy(ctx, v4FilepoolPolicyId).V4FilepoolPolicy(v4FilepoolPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4FilepoolPolicyId := "v4FilepoolPolicyId_example" // string | Modify file pool policy. All input fields are optional, but one or more must be supplied.
    v4FilepoolPolicy := *openapiclient.NewV12FilepoolPolicyExtendedExtended([]openapiclient.V1FilepoolDefaultPolicyAction{*openapiclient.NewV1FilepoolDefaultPolicyAction("ActionParam_example", "ActionType_example")}) // V12FilepoolPolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilepoolApi.UpdateFilepoolv4FilepoolPolicy(context.Background(), v4FilepoolPolicyId).V4FilepoolPolicy(v4FilepoolPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilepoolApi.UpdateFilepoolv4FilepoolPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4FilepoolPolicyId** | **string** | Modify file pool policy. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFilepoolv4FilepoolPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v4FilepoolPolicy** | [**V12FilepoolPolicyExtendedExtended**](V12FilepoolPolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

