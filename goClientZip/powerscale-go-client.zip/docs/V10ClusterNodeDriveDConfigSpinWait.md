# V10ClusterNodeDriveDConfigSpinWait

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CheckDrive** | Pointer to **int32** | Seconds to wait between enabling a bay and checking for an inserted drive. | [optional] 
**Stagger** | Pointer to **int32** | Seconds to wait between enabling a bay and enabling another bay. | [optional] 

## Methods

### NewV10ClusterNodeDriveDConfigSpinWait

`func NewV10ClusterNodeDriveDConfigSpinWait() *V10ClusterNodeDriveDConfigSpinWait`

NewV10ClusterNodeDriveDConfigSpinWait instantiates a new V10ClusterNodeDriveDConfigSpinWait object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeDriveDConfigSpinWaitWithDefaults

`func NewV10ClusterNodeDriveDConfigSpinWaitWithDefaults() *V10ClusterNodeDriveDConfigSpinWait`

NewV10ClusterNodeDriveDConfigSpinWaitWithDefaults instantiates a new V10ClusterNodeDriveDConfigSpinWait object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCheckDrive

`func (o *V10ClusterNodeDriveDConfigSpinWait) GetCheckDrive() int32`

GetCheckDrive returns the CheckDrive field if non-nil, zero value otherwise.

### GetCheckDriveOk

`func (o *V10ClusterNodeDriveDConfigSpinWait) GetCheckDriveOk() (*int32, bool)`

GetCheckDriveOk returns a tuple with the CheckDrive field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCheckDrive

`func (o *V10ClusterNodeDriveDConfigSpinWait) SetCheckDrive(v int32)`

SetCheckDrive sets CheckDrive field to given value.

### HasCheckDrive

`func (o *V10ClusterNodeDriveDConfigSpinWait) HasCheckDrive() bool`

HasCheckDrive returns a boolean if a field has been set.

### GetStagger

`func (o *V10ClusterNodeDriveDConfigSpinWait) GetStagger() int32`

GetStagger returns the Stagger field if non-nil, zero value otherwise.

### GetStaggerOk

`func (o *V10ClusterNodeDriveDConfigSpinWait) GetStaggerOk() (*int32, bool)`

GetStaggerOk returns a tuple with the Stagger field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStagger

`func (o *V10ClusterNodeDriveDConfigSpinWait) SetStagger(v int32)`

SetStagger sets Stagger field to given value.

### HasStagger

`func (o *V10ClusterNodeDriveDConfigSpinWait) HasStagger() bool`

HasStagger returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


