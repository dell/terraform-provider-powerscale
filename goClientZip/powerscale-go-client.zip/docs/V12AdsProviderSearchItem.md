# V12AdsProviderSearchItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | Pointer to **string** | The user or group description to search for. | [optional] 
**Domain** | Pointer to **string** | The Active Directory provider name to search for. | [optional] 
**Filter** | Pointer to **string** | The LDAP filter to apply to the search. | [optional] 
**Limit** | Pointer to **int32** | Return no more than this many results at once (see resume). | [optional] 
**Password** | Pointer to **string** | The password for the domain if untrusted. | [optional] 
**Resume** | Pointer to **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | [optional] 
**SearchGroups** | Pointer to **bool** | If true, search for groups. | [optional] 
**SearchUsers** | Pointer to **bool** | If true, search for users. | [optional] 
**User** | Pointer to **string** | The user name for the domain if untrusted. | [optional] 

## Methods

### NewV12AdsProviderSearchItem

`func NewV12AdsProviderSearchItem() *V12AdsProviderSearchItem`

NewV12AdsProviderSearchItem instantiates a new V12AdsProviderSearchItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12AdsProviderSearchItemWithDefaults

`func NewV12AdsProviderSearchItemWithDefaults() *V12AdsProviderSearchItem`

NewV12AdsProviderSearchItemWithDefaults instantiates a new V12AdsProviderSearchItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDescription

`func (o *V12AdsProviderSearchItem) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V12AdsProviderSearchItem) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V12AdsProviderSearchItem) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V12AdsProviderSearchItem) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDomain

`func (o *V12AdsProviderSearchItem) GetDomain() string`

GetDomain returns the Domain field if non-nil, zero value otherwise.

### GetDomainOk

`func (o *V12AdsProviderSearchItem) GetDomainOk() (*string, bool)`

GetDomainOk returns a tuple with the Domain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomain

`func (o *V12AdsProviderSearchItem) SetDomain(v string)`

SetDomain sets Domain field to given value.

### HasDomain

`func (o *V12AdsProviderSearchItem) HasDomain() bool`

HasDomain returns a boolean if a field has been set.

### GetFilter

`func (o *V12AdsProviderSearchItem) GetFilter() string`

GetFilter returns the Filter field if non-nil, zero value otherwise.

### GetFilterOk

`func (o *V12AdsProviderSearchItem) GetFilterOk() (*string, bool)`

GetFilterOk returns a tuple with the Filter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilter

`func (o *V12AdsProviderSearchItem) SetFilter(v string)`

SetFilter sets Filter field to given value.

### HasFilter

`func (o *V12AdsProviderSearchItem) HasFilter() bool`

HasFilter returns a boolean if a field has been set.

### GetLimit

`func (o *V12AdsProviderSearchItem) GetLimit() int32`

GetLimit returns the Limit field if non-nil, zero value otherwise.

### GetLimitOk

`func (o *V12AdsProviderSearchItem) GetLimitOk() (*int32, bool)`

GetLimitOk returns a tuple with the Limit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLimit

`func (o *V12AdsProviderSearchItem) SetLimit(v int32)`

SetLimit sets Limit field to given value.

### HasLimit

`func (o *V12AdsProviderSearchItem) HasLimit() bool`

HasLimit returns a boolean if a field has been set.

### GetPassword

`func (o *V12AdsProviderSearchItem) GetPassword() string`

GetPassword returns the Password field if non-nil, zero value otherwise.

### GetPasswordOk

`func (o *V12AdsProviderSearchItem) GetPasswordOk() (*string, bool)`

GetPasswordOk returns a tuple with the Password field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPassword

`func (o *V12AdsProviderSearchItem) SetPassword(v string)`

SetPassword sets Password field to given value.

### HasPassword

`func (o *V12AdsProviderSearchItem) HasPassword() bool`

HasPassword returns a boolean if a field has been set.

### GetResume

`func (o *V12AdsProviderSearchItem) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12AdsProviderSearchItem) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12AdsProviderSearchItem) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12AdsProviderSearchItem) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetSearchGroups

`func (o *V12AdsProviderSearchItem) GetSearchGroups() bool`

GetSearchGroups returns the SearchGroups field if non-nil, zero value otherwise.

### GetSearchGroupsOk

`func (o *V12AdsProviderSearchItem) GetSearchGroupsOk() (*bool, bool)`

GetSearchGroupsOk returns a tuple with the SearchGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSearchGroups

`func (o *V12AdsProviderSearchItem) SetSearchGroups(v bool)`

SetSearchGroups sets SearchGroups field to given value.

### HasSearchGroups

`func (o *V12AdsProviderSearchItem) HasSearchGroups() bool`

HasSearchGroups returns a boolean if a field has been set.

### GetSearchUsers

`func (o *V12AdsProviderSearchItem) GetSearchUsers() bool`

GetSearchUsers returns the SearchUsers field if non-nil, zero value otherwise.

### GetSearchUsersOk

`func (o *V12AdsProviderSearchItem) GetSearchUsersOk() (*bool, bool)`

GetSearchUsersOk returns a tuple with the SearchUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSearchUsers

`func (o *V12AdsProviderSearchItem) SetSearchUsers(v bool)`

SetSearchUsers sets SearchUsers field to given value.

### HasSearchUsers

`func (o *V12AdsProviderSearchItem) HasSearchUsers() bool`

HasSearchUsers returns a boolean if a field has been set.

### GetUser

`func (o *V12AdsProviderSearchItem) GetUser() string`

GetUser returns the User field if non-nil, zero value otherwise.

### GetUserOk

`func (o *V12AdsProviderSearchItem) GetUserOk() (*string, bool)`

GetUserOk returns a tuple with the User field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUser

`func (o *V12AdsProviderSearchItem) SetUser(v string)`

SetUser sets User field to given value.

### HasUser

`func (o *V12AdsProviderSearchItem) HasUser() bool`

HasUser returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


