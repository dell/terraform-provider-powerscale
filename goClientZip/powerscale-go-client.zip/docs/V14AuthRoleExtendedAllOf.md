# V14AuthRoleExtendedAllOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | **string** | Specifies the description of the role. | 
**Id** | **string** | Specifies the ID of the role. | 
**Members** | [**[]V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) | Specifies the users or groups that have this role. | 
**Privileges** | [**[]V14AuthIdNtokenPrivilegeItem**](V14AuthIdNtokenPrivilegeItem.md) | Specifies the privileges granted by this role. | 

## Methods

### NewV14AuthRoleExtendedAllOf

`func NewV14AuthRoleExtendedAllOf(description string, id string, members []V1AuthAccessAccessItemFileGroup, privileges []V14AuthIdNtokenPrivilegeItem, ) *V14AuthRoleExtendedAllOf`

NewV14AuthRoleExtendedAllOf instantiates a new V14AuthRoleExtendedAllOf object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14AuthRoleExtendedAllOfWithDefaults

`func NewV14AuthRoleExtendedAllOfWithDefaults() *V14AuthRoleExtendedAllOf`

NewV14AuthRoleExtendedAllOfWithDefaults instantiates a new V14AuthRoleExtendedAllOf object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDescription

`func (o *V14AuthRoleExtendedAllOf) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V14AuthRoleExtendedAllOf) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V14AuthRoleExtendedAllOf) SetDescription(v string)`

SetDescription sets Description field to given value.


### GetId

`func (o *V14AuthRoleExtendedAllOf) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V14AuthRoleExtendedAllOf) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V14AuthRoleExtendedAllOf) SetId(v string)`

SetId sets Id field to given value.


### GetMembers

`func (o *V14AuthRoleExtendedAllOf) GetMembers() []V1AuthAccessAccessItemFileGroup`

GetMembers returns the Members field if non-nil, zero value otherwise.

### GetMembersOk

`func (o *V14AuthRoleExtendedAllOf) GetMembersOk() (*[]V1AuthAccessAccessItemFileGroup, bool)`

GetMembersOk returns a tuple with the Members field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMembers

`func (o *V14AuthRoleExtendedAllOf) SetMembers(v []V1AuthAccessAccessItemFileGroup)`

SetMembers sets Members field to given value.


### GetPrivileges

`func (o *V14AuthRoleExtendedAllOf) GetPrivileges() []V14AuthIdNtokenPrivilegeItem`

GetPrivileges returns the Privileges field if non-nil, zero value otherwise.

### GetPrivilegesOk

`func (o *V14AuthRoleExtendedAllOf) GetPrivilegesOk() (*[]V14AuthIdNtokenPrivilegeItem, bool)`

GetPrivilegesOk returns a tuple with the Privileges field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrivileges

`func (o *V14AuthRoleExtendedAllOf) SetPrivileges(v []V14AuthIdNtokenPrivilegeItem)`

SetPrivileges sets Privileges field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


