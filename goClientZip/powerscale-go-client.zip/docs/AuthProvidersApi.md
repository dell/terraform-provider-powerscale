# \AuthProvidersApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateAuthProvidersv12AdsProviderSearchItem**](AuthProvidersApi.md#CreateAuthProvidersv12AdsProviderSearchItem) | **Post** /platform/12/auth/providers/ads/{Id}/search | 
[**GetAuthProvidersv1AdsProviderControllers**](AuthProvidersApi.md#GetAuthProvidersv1AdsProviderControllers) | **Get** /platform/1/auth/providers/ads/{Id}/controllers | 
[**GetAuthProvidersv1AdsProviderDomains**](AuthProvidersApi.md#GetAuthProvidersv1AdsProviderDomains) | **Get** /platform/1/auth/providers/ads/{Id}/domains | 
[**GetAuthProvidersv3AdsProviderControllers**](AuthProvidersApi.md#GetAuthProvidersv3AdsProviderControllers) | **Get** /platform/3/auth/providers/ads/{Id}/controllers | 
[**GetAuthProvidersv3AdsProviderDomains**](AuthProvidersApi.md#GetAuthProvidersv3AdsProviderDomains) | **Get** /platform/3/auth/providers/ads/{Id}/domains | 
[**GetAuthProvidersv7AdsProviderControllers**](AuthProvidersApi.md#GetAuthProvidersv7AdsProviderControllers) | **Get** /platform/7/auth/providers/ads/{Id}/controllers | 
[**GetAuthProvidersv7AdsProviderDomains**](AuthProvidersApi.md#GetAuthProvidersv7AdsProviderDomains) | **Get** /platform/7/auth/providers/ads/{Id}/domains | 



## CreateAuthProvidersv12AdsProviderSearchItem

> Createv12AdsProviderSearchItemResponse CreateAuthProvidersv12AdsProviderSearchItem(ctx, id).V12AdsProviderSearchItem(v12AdsProviderSearchItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 
    v12AdsProviderSearchItem := *openapiclient.NewV12AdsProviderSearchItem() // V12AdsProviderSearchItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthProvidersApi.CreateAuthProvidersv12AdsProviderSearchItem(context.Background(), id).V12AdsProviderSearchItem(v12AdsProviderSearchItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthProvidersApi.CreateAuthProvidersv12AdsProviderSearchItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthProvidersv12AdsProviderSearchItem`: Createv12AdsProviderSearchItemResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthProvidersApi.CreateAuthProvidersv12AdsProviderSearchItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthProvidersv12AdsProviderSearchItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12AdsProviderSearchItem** | [**V12AdsProviderSearchItem**](V12AdsProviderSearchItem.md) |  | 

### Return type

[**Createv12AdsProviderSearchItemResponse**](Createv12AdsProviderSearchItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthProvidersv1AdsProviderControllers

> V1AdsProviderControllers GetAuthProvidersv1AdsProviderControllers(ctx, id).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthProvidersApi.GetAuthProvidersv1AdsProviderControllers(context.Background(), id).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthProvidersApi.GetAuthProvidersv1AdsProviderControllers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthProvidersv1AdsProviderControllers`: V1AdsProviderControllers
    fmt.Fprintf(os.Stdout, "Response from `AuthProvidersApi.GetAuthProvidersv1AdsProviderControllers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthProvidersv1AdsProviderControllersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1AdsProviderControllers**](V1AdsProviderControllers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthProvidersv1AdsProviderDomains

> V1AdsProviderDomains GetAuthProvidersv1AdsProviderDomains(ctx, id).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthProvidersApi.GetAuthProvidersv1AdsProviderDomains(context.Background(), id).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthProvidersApi.GetAuthProvidersv1AdsProviderDomains``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthProvidersv1AdsProviderDomains`: V1AdsProviderDomains
    fmt.Fprintf(os.Stdout, "Response from `AuthProvidersApi.GetAuthProvidersv1AdsProviderDomains`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthProvidersv1AdsProviderDomainsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1AdsProviderDomains**](V1AdsProviderDomains.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthProvidersv3AdsProviderControllers

> V1AdsProviderControllers GetAuthProvidersv3AdsProviderControllers(ctx, id).DcSite(dcSite).Groupnet(groupnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 
    dcSite := "dcSite_example" // string | Domain Controller site name (optional)
    groupnet := "groupnet_example" // string | Groupnet identifier (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthProvidersApi.GetAuthProvidersv3AdsProviderControllers(context.Background(), id).DcSite(dcSite).Groupnet(groupnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthProvidersApi.GetAuthProvidersv3AdsProviderControllers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthProvidersv3AdsProviderControllers`: V1AdsProviderControllers
    fmt.Fprintf(os.Stdout, "Response from `AuthProvidersApi.GetAuthProvidersv3AdsProviderControllers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthProvidersv3AdsProviderControllersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **dcSite** | **string** | Domain Controller site name | 
 **groupnet** | **string** | Groupnet identifier | 

### Return type

[**V1AdsProviderControllers**](V1AdsProviderControllers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthProvidersv3AdsProviderDomains

> V3AdsProviderDomains GetAuthProvidersv3AdsProviderDomains(ctx, id).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthProvidersApi.GetAuthProvidersv3AdsProviderDomains(context.Background(), id).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthProvidersApi.GetAuthProvidersv3AdsProviderDomains``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthProvidersv3AdsProviderDomains`: V3AdsProviderDomains
    fmt.Fprintf(os.Stdout, "Response from `AuthProvidersApi.GetAuthProvidersv3AdsProviderDomains`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthProvidersv3AdsProviderDomainsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3AdsProviderDomains**](V3AdsProviderDomains.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthProvidersv7AdsProviderControllers

> V1AdsProviderControllers GetAuthProvidersv7AdsProviderControllers(ctx, id).DcSite(dcSite).Groupnet(groupnet).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 
    dcSite := "dcSite_example" // string | Domain Controller site name (optional)
    groupnet := "groupnet_example" // string | Groupnet identifier (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthProvidersApi.GetAuthProvidersv7AdsProviderControllers(context.Background(), id).DcSite(dcSite).Groupnet(groupnet).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthProvidersApi.GetAuthProvidersv7AdsProviderControllers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthProvidersv7AdsProviderControllers`: V1AdsProviderControllers
    fmt.Fprintf(os.Stdout, "Response from `AuthProvidersApi.GetAuthProvidersv7AdsProviderControllers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthProvidersv7AdsProviderControllersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **dcSite** | **string** | Domain Controller site name | 
 **groupnet** | **string** | Groupnet identifier | 

### Return type

[**V1AdsProviderControllers**](V1AdsProviderControllers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthProvidersv7AdsProviderDomains

> V3AdsProviderDomains GetAuthProvidersv7AdsProviderDomains(ctx, id).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthProvidersApi.GetAuthProvidersv7AdsProviderDomains(context.Background(), id).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthProvidersApi.GetAuthProvidersv7AdsProviderDomains``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthProvidersv7AdsProviderDomains`: V3AdsProviderDomains
    fmt.Fprintf(os.Stdout, "Response from `AuthProvidersApi.GetAuthProvidersv7AdsProviderDomains`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthProvidersv7AdsProviderDomainsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3AdsProviderDomains**](V3AdsProviderDomains.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

