# V11EventThreshold

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Defaults** | Pointer to [**V11EventThresholdThresholds**](V11EventThresholdThresholds.md) |  | [optional] 
**Id** | Pointer to **string** | Unique event identifier. | [optional] 
**IdName** | Pointer to **string** | Name for event. | [optional] 
**ThresholdDescription** | Pointer to **string** | Verbose, human-readable description of event. | [optional] 
**Thresholds** | Pointer to [**V11EventThresholdThresholds**](V11EventThresholdThresholds.md) |  | [optional] 

## Methods

### NewV11EventThreshold

`func NewV11EventThreshold() *V11EventThreshold`

NewV11EventThreshold instantiates a new V11EventThreshold object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11EventThresholdWithDefaults

`func NewV11EventThresholdWithDefaults() *V11EventThreshold`

NewV11EventThresholdWithDefaults instantiates a new V11EventThreshold object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDefaults

`func (o *V11EventThreshold) GetDefaults() V11EventThresholdThresholds`

GetDefaults returns the Defaults field if non-nil, zero value otherwise.

### GetDefaultsOk

`func (o *V11EventThreshold) GetDefaultsOk() (*V11EventThresholdThresholds, bool)`

GetDefaultsOk returns a tuple with the Defaults field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaults

`func (o *V11EventThreshold) SetDefaults(v V11EventThresholdThresholds)`

SetDefaults sets Defaults field to given value.

### HasDefaults

`func (o *V11EventThreshold) HasDefaults() bool`

HasDefaults returns a boolean if a field has been set.

### GetId

`func (o *V11EventThreshold) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11EventThreshold) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11EventThreshold) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11EventThreshold) HasId() bool`

HasId returns a boolean if a field has been set.

### GetIdName

`func (o *V11EventThreshold) GetIdName() string`

GetIdName returns the IdName field if non-nil, zero value otherwise.

### GetIdNameOk

`func (o *V11EventThreshold) GetIdNameOk() (*string, bool)`

GetIdNameOk returns a tuple with the IdName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIdName

`func (o *V11EventThreshold) SetIdName(v string)`

SetIdName sets IdName field to given value.

### HasIdName

`func (o *V11EventThreshold) HasIdName() bool`

HasIdName returns a boolean if a field has been set.

### GetThresholdDescription

`func (o *V11EventThreshold) GetThresholdDescription() string`

GetThresholdDescription returns the ThresholdDescription field if non-nil, zero value otherwise.

### GetThresholdDescriptionOk

`func (o *V11EventThreshold) GetThresholdDescriptionOk() (*string, bool)`

GetThresholdDescriptionOk returns a tuple with the ThresholdDescription field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholdDescription

`func (o *V11EventThreshold) SetThresholdDescription(v string)`

SetThresholdDescription sets ThresholdDescription field to given value.

### HasThresholdDescription

`func (o *V11EventThreshold) HasThresholdDescription() bool`

HasThresholdDescription returns a boolean if a field has been set.

### GetThresholds

`func (o *V11EventThreshold) GetThresholds() V11EventThresholdThresholds`

GetThresholds returns the Thresholds field if non-nil, zero value otherwise.

### GetThresholdsOk

`func (o *V11EventThreshold) GetThresholdsOk() (*V11EventThresholdThresholds, bool)`

GetThresholdsOk returns a tuple with the Thresholds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholds

`func (o *V11EventThreshold) SetThresholds(v V11EventThresholdThresholds)`

SetThresholds sets Thresholds field to given value.

### HasThresholds

`func (o *V11EventThreshold) HasThresholds() bool`

HasThresholds returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


