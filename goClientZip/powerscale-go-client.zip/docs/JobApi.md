# \JobApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateJobv10JobJob**](JobApi.md#CreateJobv10JobJob) | **Post** /platform/10/job/jobs | 
[**CreateJobv1JobJob**](JobApi.md#CreateJobv1JobJob) | **Post** /platform/1/job/jobs | 
[**CreateJobv1JobPolicy**](JobApi.md#CreateJobv1JobPolicy) | **Post** /platform/1/job/policies | 
[**CreateJobv3JobJob**](JobApi.md#CreateJobv3JobJob) | **Post** /platform/3/job/jobs | 
[**CreateJobv7JobJob**](JobApi.md#CreateJobv7JobJob) | **Post** /platform/7/job/jobs | 
[**DeleteJobv1JobPolicy**](JobApi.md#DeleteJobv1JobPolicy) | **Delete** /platform/1/job/policies/{v1JobPolicyId} | 
[**GetJobv12JobJobSummary**](JobApi.md#GetJobv12JobJobSummary) | **Get** /platform/12/job/job-summary | 
[**GetJobv1JobEvents**](JobApi.md#GetJobv1JobEvents) | **Get** /platform/1/job/events | 
[**GetJobv1JobJob**](JobApi.md#GetJobv1JobJob) | **Get** /platform/1/job/jobs/{v1JobJobId} | 
[**GetJobv1JobJobSummary**](JobApi.md#GetJobv1JobJobSummary) | **Get** /platform/1/job/job-summary | 
[**GetJobv1JobPolicy**](JobApi.md#GetJobv1JobPolicy) | **Get** /platform/1/job/policies/{v1JobPolicyId} | 
[**GetJobv1JobReports**](JobApi.md#GetJobv1JobReports) | **Get** /platform/1/job/reports | 
[**GetJobv1JobStatistics**](JobApi.md#GetJobv1JobStatistics) | **Get** /platform/1/job/statistics | 
[**GetJobv1JobType**](JobApi.md#GetJobv1JobType) | **Get** /platform/1/job/types/{v1JobTypeId} | 
[**GetJobv1JobTypes**](JobApi.md#GetJobv1JobTypes) | **Get** /platform/1/job/types | 
[**GetJobv3JobEvents**](JobApi.md#GetJobv3JobEvents) | **Get** /platform/3/job/events | 
[**GetJobv3JobJob**](JobApi.md#GetJobv3JobJob) | **Get** /platform/3/job/jobs/{v3JobJobId} | 
[**GetJobv3JobRecent**](JobApi.md#GetJobv3JobRecent) | **Get** /platform/3/job/recent | 
[**GetJobv3JobReports**](JobApi.md#GetJobv3JobReports) | **Get** /platform/3/job/reports | 
[**GetJobv7JobJob**](JobApi.md#GetJobv7JobJob) | **Get** /platform/7/job/jobs/{v7JobJobId} | 
[**GetJobv7JobJobSummary**](JobApi.md#GetJobv7JobJobSummary) | **Get** /platform/7/job/job-summary | 
[**GetJobv7JobReports**](JobApi.md#GetJobv7JobReports) | **Get** /platform/7/job/reports | 
[**ListJobv10JobJobs**](JobApi.md#ListJobv10JobJobs) | **Get** /platform/10/job/jobs | 
[**ListJobv1JobJobs**](JobApi.md#ListJobv1JobJobs) | **Get** /platform/1/job/jobs | 
[**ListJobv1JobPolicies**](JobApi.md#ListJobv1JobPolicies) | **Get** /platform/1/job/policies | 
[**ListJobv3JobJobs**](JobApi.md#ListJobv3JobJobs) | **Get** /platform/3/job/jobs | 
[**ListJobv7JobJobs**](JobApi.md#ListJobv7JobJobs) | **Get** /platform/7/job/jobs | 
[**UpdateJobv1JobJob**](JobApi.md#UpdateJobv1JobJob) | **Put** /platform/1/job/jobs/{v1JobJobId} | 
[**UpdateJobv1JobPolicy**](JobApi.md#UpdateJobv1JobPolicy) | **Put** /platform/1/job/policies/{v1JobPolicyId} | 
[**UpdateJobv1JobType**](JobApi.md#UpdateJobv1JobType) | **Put** /platform/1/job/types/{v1JobTypeId} | 
[**UpdateJobv3JobJob**](JobApi.md#UpdateJobv3JobJob) | **Put** /platform/3/job/jobs/{v3JobJobId} | 
[**UpdateJobv7JobJob**](JobApi.md#UpdateJobv7JobJob) | **Put** /platform/7/job/jobs/{v7JobJobId} | 



## CreateJobv10JobJob

> Createv1JobJobResponse CreateJobv10JobJob(ctx).V10JobJob(v10JobJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10JobJob := *openapiclient.NewV10JobJob("Type_example") // V10JobJob | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.CreateJobv10JobJob(context.Background()).V10JobJob(v10JobJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.CreateJobv10JobJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateJobv10JobJob`: Createv1JobJobResponse
    fmt.Fprintf(os.Stdout, "Response from `JobApi.CreateJobv10JobJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateJobv10JobJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10JobJob** | [**V10JobJob**](V10JobJob.md) |  | 

### Return type

[**Createv1JobJobResponse**](Createv1JobJobResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateJobv1JobJob

> Createv1JobJobResponse CreateJobv1JobJob(ctx).V1JobJob(v1JobJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1JobJob := *openapiclient.NewV1JobJob("Type_example") // V1JobJob | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.CreateJobv1JobJob(context.Background()).V1JobJob(v1JobJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.CreateJobv1JobJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateJobv1JobJob`: Createv1JobJobResponse
    fmt.Fprintf(os.Stdout, "Response from `JobApi.CreateJobv1JobJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateJobv1JobJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1JobJob** | [**V1JobJob**](V1JobJob.md) |  | 

### Return type

[**Createv1JobJobResponse**](Createv1JobJobResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateJobv1JobPolicy

> CreateResponse CreateJobv1JobPolicy(ctx).V1JobPolicy(v1JobPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1JobPolicy := *openapiclient.NewV1JobPolicy("Name_example") // V1JobPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.CreateJobv1JobPolicy(context.Background()).V1JobPolicy(v1JobPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.CreateJobv1JobPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateJobv1JobPolicy`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `JobApi.CreateJobv1JobPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateJobv1JobPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1JobPolicy** | [**V1JobPolicy**](V1JobPolicy.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateJobv3JobJob

> Createv1JobJobResponse CreateJobv3JobJob(ctx).V3JobJob(v3JobJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3JobJob := *openapiclient.NewV3JobJob("Type_example") // V3JobJob | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.CreateJobv3JobJob(context.Background()).V3JobJob(v3JobJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.CreateJobv3JobJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateJobv3JobJob`: Createv1JobJobResponse
    fmt.Fprintf(os.Stdout, "Response from `JobApi.CreateJobv3JobJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateJobv3JobJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3JobJob** | [**V3JobJob**](V3JobJob.md) |  | 

### Return type

[**Createv1JobJobResponse**](Createv1JobJobResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateJobv7JobJob

> Createv1JobJobResponse CreateJobv7JobJob(ctx).V7JobJob(v7JobJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7JobJob := *openapiclient.NewV7JobJob("Type_example") // V7JobJob | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.CreateJobv7JobJob(context.Background()).V7JobJob(v7JobJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.CreateJobv7JobJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateJobv7JobJob`: Createv1JobJobResponse
    fmt.Fprintf(os.Stdout, "Response from `JobApi.CreateJobv7JobJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateJobv7JobJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7JobJob** | [**V7JobJob**](V7JobJob.md) |  | 

### Return type

[**Createv1JobJobResponse**](Createv1JobJobResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteJobv1JobPolicy

> DeleteJobv1JobPolicy(ctx, v1JobPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1JobPolicyId := "v1JobPolicyId_example" // string | Delete a job impact policy.  System policies may not be deleted.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.JobApi.DeleteJobv1JobPolicy(context.Background(), v1JobPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.DeleteJobv1JobPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1JobPolicyId** | **string** | Delete a job impact policy.  System policies may not be deleted. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteJobv1JobPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv12JobJobSummary

> V12JobJobSummary GetJobv12JobJobSummary(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv12JobJobSummary(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv12JobJobSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv12JobJobSummary`: V12JobJobSummary
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv12JobJobSummary`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv12JobJobSummaryRequest struct via the builder pattern


### Return type

[**V12JobJobSummary**](V12JobJobSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv1JobEvents

> V1JobEvents GetJobv1JobEvents(ctx).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).State(state).Limit(limit).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    begin := int32(56) // int32 | Restrict the query to events at or after the given time, in seconds since the Epoch. (optional)
    end := int32(56) // int32 | Restrict the query to events before the given time, in seconds since the Epoch. (optional)
    jobId := int32(56) // int32 | Restrict the query to the given job ID. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    jobType := "jobType_example" // string | Restrict the query to the given job type. (optional)
    state := []string{"State_example"} // []string | Restrict the query to events containing the given state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv1JobEvents(context.Background()).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).State(state).Limit(limit).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv1JobEvents``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv1JobEvents`: V1JobEvents
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv1JobEvents`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv1JobEventsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **begin** | **int32** | Restrict the query to events at or after the given time, in seconds since the Epoch. | 
 **end** | **int32** | Restrict the query to events before the given time, in seconds since the Epoch. | 
 **jobId** | **int32** | Restrict the query to the given job ID. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **jobType** | **string** | Restrict the query to the given job type. | 
 **state** | **[]string** | Restrict the query to events containing the given state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 

### Return type

[**V1JobEvents**](V1JobEvents.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv1JobJob

> V1JobJobsExtended GetJobv1JobJob(ctx, v1JobJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1JobJobId := "v1JobJobId_example" // string | View a single job instance.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv1JobJob(context.Background(), v1JobJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv1JobJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv1JobJob`: V1JobJobsExtended
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv1JobJob`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1JobJobId** | **string** | View a single job instance. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv1JobJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1JobJobsExtended**](V1JobJobsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv1JobJobSummary

> V1JobJobSummary GetJobv1JobJobSummary(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv1JobJobSummary(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv1JobJobSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv1JobJobSummary`: V1JobJobSummary
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv1JobJobSummary`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv1JobJobSummaryRequest struct via the builder pattern


### Return type

[**V1JobJobSummary**](V1JobJobSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv1JobPolicy

> V1JobPoliciesExtended GetJobv1JobPolicy(ctx, v1JobPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1JobPolicyId := "v1JobPolicyId_example" // string | View a single job impact policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv1JobPolicy(context.Background(), v1JobPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv1JobPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv1JobPolicy`: V1JobPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv1JobPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1JobPolicyId** | **string** | View a single job impact policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv1JobPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1JobPoliciesExtended**](V1JobPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv1JobReports

> V1JobReports GetJobv1JobReports(ctx).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).Limit(limit).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    begin := int32(56) // int32 | Restrict the query to reports at or after the given time, in seconds since the Epoch. (optional)
    end := int32(56) // int32 | Restrict the query to reports before the given time, in seconds since the Epoch. (optional)
    jobId := int32(56) // int32 | Restrict the query to the given job ID. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    jobType := "jobType_example" // string | Restrict the query to the given job type. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv1JobReports(context.Background()).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).Limit(limit).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv1JobReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv1JobReports`: V1JobReports
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv1JobReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv1JobReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **begin** | **int32** | Restrict the query to reports at or after the given time, in seconds since the Epoch. | 
 **end** | **int32** | Restrict the query to reports before the given time, in seconds since the Epoch. | 
 **jobId** | **int32** | Restrict the query to the given job ID. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **jobType** | **string** | Restrict the query to the given job type. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 

### Return type

[**V1JobReports**](V1JobReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv1JobStatistics

> V1JobStatistics GetJobv1JobStatistics(ctx).Devid(devid).JobId(jobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    devid := int32(56) // int32 | Restrict the query to the given node. (optional)
    jobId := int32(56) // int32 | Restrict the query to the given job ID. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv1JobStatistics(context.Background()).Devid(devid).JobId(jobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv1JobStatistics``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv1JobStatistics`: V1JobStatistics
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv1JobStatistics`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv1JobStatisticsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **devid** | **int32** | Restrict the query to the given node. | 
 **jobId** | **int32** | Restrict the query to the given job ID. | 

### Return type

[**V1JobStatistics**](V1JobStatistics.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv1JobType

> V1JobTypesExtended GetJobv1JobType(ctx, v1JobTypeId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1JobTypeId := "v1JobTypeId_example" // string | Retrieve job type information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv1JobType(context.Background(), v1JobTypeId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv1JobType``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv1JobType`: V1JobTypesExtended
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv1JobType`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1JobTypeId** | **string** | Retrieve job type information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv1JobTypeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1JobTypesExtended**](V1JobTypesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv1JobTypes

> V1JobTypes GetJobv1JobTypes(ctx).Sort(sort).ShowAll(showAll).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    showAll := true // bool | Whether to show all job types, including hidden ones.  Defaults to false. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv1JobTypes(context.Background()).Sort(sort).ShowAll(showAll).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv1JobTypes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv1JobTypes`: V1JobTypes
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv1JobTypes`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv1JobTypesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **showAll** | **bool** | Whether to show all job types, including hidden ones.  Defaults to false. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1JobTypes**](V1JobTypes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv3JobEvents

> V3JobEvents GetJobv3JobEvents(ctx).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).TimeoutMs(timeoutMs).State(state).EndedJobsOnly(endedJobsOnly).Limit(limit).Key(key).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    begin := int32(56) // int32 | Restrict the query to events at or after the given time, in seconds since the Epoch. (optional)
    end := int32(56) // int32 | Restrict the query to events before the given time, in seconds since the Epoch. (optional)
    jobId := int32(56) // int32 | Restrict the query to the given job ID. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    jobType := "jobType_example" // string | Restrict the query to the given job type. (optional)
    timeoutMs := int32(56) // int32 | Query timeout in milliseconds. The default is 10000 ms. (optional)
    state := "state_example" // string | Restrict the query to events containing the given state. This parameter cannot be used with ended_jobs_only (optional)
    endedJobsOnly := true // bool | Request all jobs that ended. This parameter cannot be used with the 'state' parameter. Ended states are 'cancelled_user', 'cancelled_system', 'failed' or 'succeeded' (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    key := "key_example" // string | Restrict the query to the given key name. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv3JobEvents(context.Background()).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).TimeoutMs(timeoutMs).State(state).EndedJobsOnly(endedJobsOnly).Limit(limit).Key(key).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv3JobEvents``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv3JobEvents`: V3JobEvents
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv3JobEvents`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv3JobEventsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **begin** | **int32** | Restrict the query to events at or after the given time, in seconds since the Epoch. | 
 **end** | **int32** | Restrict the query to events before the given time, in seconds since the Epoch. | 
 **jobId** | **int32** | Restrict the query to the given job ID. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **jobType** | **string** | Restrict the query to the given job type. | 
 **timeoutMs** | **int32** | Query timeout in milliseconds. The default is 10000 ms. | 
 **state** | **string** | Restrict the query to events containing the given state. This parameter cannot be used with ended_jobs_only | 
 **endedJobsOnly** | **bool** | Request all jobs that ended. This parameter cannot be used with the &#39;state&#39; parameter. Ended states are &#39;cancelled_user&#39;, &#39;cancelled_system&#39;, &#39;failed&#39; or &#39;succeeded&#39; | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **key** | **string** | Restrict the query to the given key name. | 

### Return type

[**V3JobEvents**](V3JobEvents.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv3JobJob

> V1JobJobsExtended GetJobv3JobJob(ctx, v3JobJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3JobJobId := "v3JobJobId_example" // string | View a single job instance.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv3JobJob(context.Background(), v3JobJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv3JobJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv3JobJob`: V1JobJobsExtended
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv3JobJob`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3JobJobId** | **string** | View a single job instance. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv3JobJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1JobJobsExtended**](V1JobJobsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv3JobRecent

> V3JobRecent GetJobv3JobRecent(ctx).TimeoutMs(timeoutMs).Limit(limit).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    timeoutMs := int32(56) // int32 | Query timeout in milliseconds. The default is 10000 ms. (optional)
    limit := int32(56) // int32 | Max number of recent jobs to return. The default is 8, the max is 100. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv3JobRecent(context.Background()).TimeoutMs(timeoutMs).Limit(limit).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv3JobRecent``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv3JobRecent`: V3JobRecent
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv3JobRecent`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv3JobRecentRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeoutMs** | **int32** | Query timeout in milliseconds. The default is 10000 ms. | 
 **limit** | **int32** | Max number of recent jobs to return. The default is 8, the max is 100. | 

### Return type

[**V3JobRecent**](V3JobRecent.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv3JobReports

> V3JobReports GetJobv3JobReports(ctx).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).TimeoutMs(timeoutMs).Limit(limit).Key(key).Verbose(verbose).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    begin := int32(56) // int32 | Restrict the query to reports at or after the given time, in seconds since the Epoch. (optional)
    end := int32(56) // int32 | Restrict the query to reports before the given time, in seconds since the Epoch. (optional)
    jobId := int32(56) // int32 | Restrict the query to the given job ID. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    jobType := "jobType_example" // string | Restrict the query to the given job type. (optional)
    timeoutMs := int32(56) // int32 | Query timeout in milliseconds. The default is 10000 ms. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    key := "key_example" // string | Restrict the query to the given report key. (optional)
    verbose := true // bool | Display more detailed information, including job engine framework statistics. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv3JobReports(context.Background()).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).TimeoutMs(timeoutMs).Limit(limit).Key(key).Verbose(verbose).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv3JobReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv3JobReports`: V3JobReports
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv3JobReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv3JobReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **begin** | **int32** | Restrict the query to reports at or after the given time, in seconds since the Epoch. | 
 **end** | **int32** | Restrict the query to reports before the given time, in seconds since the Epoch. | 
 **jobId** | **int32** | Restrict the query to the given job ID. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **jobType** | **string** | Restrict the query to the given job type. | 
 **timeoutMs** | **int32** | Query timeout in milliseconds. The default is 10000 ms. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **key** | **string** | Restrict the query to the given report key. | 
 **verbose** | **bool** | Display more detailed information, including job engine framework statistics. | 

### Return type

[**V3JobReports**](V3JobReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv7JobJob

> V7JobJobs GetJobv7JobJob(ctx, v7JobJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7JobJobId := "v7JobJobId_example" // string | View a single job instance.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv7JobJob(context.Background(), v7JobJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv7JobJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv7JobJob`: V7JobJobs
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv7JobJob`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7JobJobId** | **string** | View a single job instance. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv7JobJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7JobJobs**](V7JobJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv7JobJobSummary

> V7JobJobSummary GetJobv7JobJobSummary(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv7JobJobSummary(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv7JobJobSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv7JobJobSummary`: V7JobJobSummary
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv7JobJobSummary`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv7JobJobSummaryRequest struct via the builder pattern


### Return type

[**V7JobJobSummary**](V7JobJobSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetJobv7JobReports

> V7JobReports GetJobv7JobReports(ctx).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).TimeoutMs(timeoutMs).Limit(limit).Key(key).LastPhaseOnly(lastPhaseOnly).Verbose(verbose).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    begin := int32(56) // int32 | Restrict the query to reports at or after the given time, in seconds since the Epoch. (optional)
    end := int32(56) // int32 | Restrict the query to reports before the given time, in seconds since the Epoch. (optional)
    jobId := int32(56) // int32 | Restrict the query to the given job ID. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    jobType := "jobType_example" // string | Restrict the query to the given job type. (optional)
    timeoutMs := int32(56) // int32 | Query timeout in milliseconds. The default is 10000 ms. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    key := "key_example" // string | Restrict the query to the given report key. (optional)
    lastPhaseOnly := true // bool | if set, the query will return the last reported phase only. (optional)
    verbose := true // bool | Display more detailed information, including job engine framework statistics. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.GetJobv7JobReports(context.Background()).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).TimeoutMs(timeoutMs).Limit(limit).Key(key).LastPhaseOnly(lastPhaseOnly).Verbose(verbose).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.GetJobv7JobReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetJobv7JobReports`: V7JobReports
    fmt.Fprintf(os.Stdout, "Response from `JobApi.GetJobv7JobReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetJobv7JobReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **begin** | **int32** | Restrict the query to reports at or after the given time, in seconds since the Epoch. | 
 **end** | **int32** | Restrict the query to reports before the given time, in seconds since the Epoch. | 
 **jobId** | **int32** | Restrict the query to the given job ID. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **jobType** | **string** | Restrict the query to the given job type. | 
 **timeoutMs** | **int32** | Query timeout in milliseconds. The default is 10000 ms. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **key** | **string** | Restrict the query to the given report key. | 
 **lastPhaseOnly** | **bool** | if set, the query will return the last reported phase only. | 
 **verbose** | **bool** | Display more detailed information, including job engine framework statistics. | 

### Return type

[**V7JobReports**](V7JobReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListJobv10JobJobs

> V10JobJobs ListJobv10JobJobs(ctx).Sort(sort).Resume(resume).Batch(batch).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    batch := true // bool | If true, other arguments are ignored, and the query will return all results, unsorted, as quickly as possible. (optional)
    state := "state_example" // string | Limit the results to jobs in the specified state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.ListJobv10JobJobs(context.Background()).Sort(sort).Resume(resume).Batch(batch).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.ListJobv10JobJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListJobv10JobJobs`: V10JobJobs
    fmt.Fprintf(os.Stdout, "Response from `JobApi.ListJobv10JobJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListJobv10JobJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **batch** | **bool** | If true, other arguments are ignored, and the query will return all results, unsorted, as quickly as possible. | 
 **state** | **string** | Limit the results to jobs in the specified state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V10JobJobs**](V10JobJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListJobv1JobJobs

> V1JobJobs ListJobv1JobJobs(ctx).Sort(sort).Resume(resume).Batch(batch).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    batch := true // bool | If true, other arguments are ignored, and the query will return all results, unsorted, as quickly as possible. (optional)
    state := "state_example" // string | Limit the results to jobs in the specified state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.ListJobv1JobJobs(context.Background()).Sort(sort).Resume(resume).Batch(batch).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.ListJobv1JobJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListJobv1JobJobs`: V1JobJobs
    fmt.Fprintf(os.Stdout, "Response from `JobApi.ListJobv1JobJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListJobv1JobJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **batch** | **bool** | If true, other arguments are ignored, and the query will return all results, unsorted, as quickly as possible. | 
 **state** | **string** | Limit the results to jobs in the specified state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1JobJobs**](V1JobJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListJobv1JobPolicies

> V1JobPolicies ListJobv1JobPolicies(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.ListJobv1JobPolicies(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.ListJobv1JobPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListJobv1JobPolicies`: V1JobPolicies
    fmt.Fprintf(os.Stdout, "Response from `JobApi.ListJobv1JobPolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListJobv1JobPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1JobPolicies**](V1JobPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListJobv3JobJobs

> V1JobJobs ListJobv3JobJobs(ctx).Sort(sort).Resume(resume).Batch(batch).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    batch := true // bool | If true, other arguments are ignored, and the query will return all results, unsorted, as quickly as possible. (optional)
    state := "state_example" // string | Limit the results to jobs in the specified state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.ListJobv3JobJobs(context.Background()).Sort(sort).Resume(resume).Batch(batch).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.ListJobv3JobJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListJobv3JobJobs`: V1JobJobs
    fmt.Fprintf(os.Stdout, "Response from `JobApi.ListJobv3JobJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListJobv3JobJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **batch** | **bool** | If true, other arguments are ignored, and the query will return all results, unsorted, as quickly as possible. | 
 **state** | **string** | Limit the results to jobs in the specified state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1JobJobs**](V1JobJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListJobv7JobJobs

> V10JobJobs ListJobv7JobJobs(ctx).Sort(sort).Resume(resume).Batch(batch).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    batch := true // bool | If true, other arguments are ignored, and the query will return all results, unsorted, as quickly as possible. (optional)
    state := "state_example" // string | Limit the results to jobs in the specified state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.JobApi.ListJobv7JobJobs(context.Background()).Sort(sort).Resume(resume).Batch(batch).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.ListJobv7JobJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListJobv7JobJobs`: V10JobJobs
    fmt.Fprintf(os.Stdout, "Response from `JobApi.ListJobv7JobJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListJobv7JobJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **batch** | **bool** | If true, other arguments are ignored, and the query will return all results, unsorted, as quickly as possible. | 
 **state** | **string** | Limit the results to jobs in the specified state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V10JobJobs**](V10JobJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateJobv1JobJob

> UpdateJobv1JobJob(ctx, v1JobJobId).V1JobJob(v1JobJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1JobJobId := "v1JobJobId_example" // string | Modify a running or paused job instance.  All input fields are optional, but one or more must be supplied.
    v1JobJob := *openapiclient.NewV1JobJobExtendedExtended() // V1JobJobExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.JobApi.UpdateJobv1JobJob(context.Background(), v1JobJobId).V1JobJob(v1JobJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.UpdateJobv1JobJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1JobJobId** | **string** | Modify a running or paused job instance.  All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateJobv1JobJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1JobJob** | [**V1JobJobExtendedExtended**](V1JobJobExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateJobv1JobPolicy

> UpdateJobv1JobPolicy(ctx, v1JobPolicyId).V1JobPolicy(v1JobPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1JobPolicyId := "v1JobPolicyId_example" // string | Modify a job impact policy.
    v1JobPolicy := *openapiclient.NewV1JobPolicyExtendedExtended() // V1JobPolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.JobApi.UpdateJobv1JobPolicy(context.Background(), v1JobPolicyId).V1JobPolicy(v1JobPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.UpdateJobv1JobPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1JobPolicyId** | **string** | Modify a job impact policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateJobv1JobPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1JobPolicy** | [**V1JobPolicyExtendedExtended**](V1JobPolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateJobv1JobType

> UpdateJobv1JobType(ctx, v1JobTypeId).V1JobType(v1JobType).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1JobTypeId := "v1JobTypeId_example" // string | Modify the job type.  All input fields are optional, but one or more must be supplied.
    v1JobType := *openapiclient.NewV1JobTypeExtended() // V1JobTypeExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.JobApi.UpdateJobv1JobType(context.Background(), v1JobTypeId).V1JobType(v1JobType).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.UpdateJobv1JobType``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1JobTypeId** | **string** | Modify the job type.  All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateJobv1JobTypeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1JobType** | [**V1JobTypeExtended**](V1JobTypeExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateJobv3JobJob

> UpdateJobv3JobJob(ctx, v3JobJobId).V3JobJob(v3JobJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3JobJobId := "v3JobJobId_example" // string | Modify a running or paused job instance.  All input fields are optional, but one or more must be supplied.
    v3JobJob := *openapiclient.NewV1JobJobExtendedExtended() // V1JobJobExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.JobApi.UpdateJobv3JobJob(context.Background(), v3JobJobId).V3JobJob(v3JobJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.UpdateJobv3JobJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3JobJobId** | **string** | Modify a running or paused job instance.  All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateJobv3JobJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3JobJob** | [**V1JobJobExtendedExtended**](V1JobJobExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateJobv7JobJob

> UpdateJobv7JobJob(ctx, v7JobJobId).V7JobJob(v7JobJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7JobJobId := "v7JobJobId_example" // string | Modify a running or paused job instance.  All input fields are optional, but one or more must be supplied.
    v7JobJob := *openapiclient.NewV1JobJobExtendedExtended() // V1JobJobExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.JobApi.UpdateJobv7JobJob(context.Background(), v7JobJobId).V7JobJob(v7JobJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `JobApi.UpdateJobv7JobJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7JobJobId** | **string** | Modify a running or paused job instance.  All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateJobv7JobJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7JobJob** | [**V1JobJobExtendedExtended**](V1JobJobExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

