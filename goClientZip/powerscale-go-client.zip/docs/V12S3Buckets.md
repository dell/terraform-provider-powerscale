# V12S3Buckets

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Buckets** | [**[]V12S3Bucket**](V12S3Bucket.md) |  | 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int64** | Total number of items available. | [optional] 

## Methods

### NewV12S3Buckets

`func NewV12S3Buckets(buckets []V12S3Bucket, ) *V12S3Buckets`

NewV12S3Buckets instantiates a new V12S3Buckets object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12S3BucketsWithDefaults

`func NewV12S3BucketsWithDefaults() *V12S3Buckets`

NewV12S3BucketsWithDefaults instantiates a new V12S3Buckets object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBuckets

`func (o *V12S3Buckets) GetBuckets() []V12S3Bucket`

GetBuckets returns the Buckets field if non-nil, zero value otherwise.

### GetBucketsOk

`func (o *V12S3Buckets) GetBucketsOk() (*[]V12S3Bucket, bool)`

GetBucketsOk returns a tuple with the Buckets field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBuckets

`func (o *V12S3Buckets) SetBuckets(v []V12S3Bucket)`

SetBuckets sets Buckets field to given value.


### GetResume

`func (o *V12S3Buckets) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12S3Buckets) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12S3Buckets) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12S3Buckets) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V12S3Buckets) GetTotal() int64`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12S3Buckets) GetTotalOk() (*int64, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12S3Buckets) SetTotal(v int64)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12S3Buckets) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


