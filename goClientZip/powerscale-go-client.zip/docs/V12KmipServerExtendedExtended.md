# V12KmipServerExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CaCertPath** | Pointer to **string** | Certification Authority (CA) certificate, used for TLS Mutual Authentication with the KMIP Server. | [optional] 
**ClientCertPassword** | Pointer to **string** | Cluster identity private key password. | [optional] 
**ClientCertPath** | Pointer to **string** | Cluster identity certificate and private key used for TLS Mutual Authentication with the KMIP Server. | [optional] 
**Host** | Pointer to **string** | KMIP server hostname. | [optional] 
**MinimumTlsVersion** | Pointer to **string** | Denotes the minimum TLS version supported by the KTP. Default value is set to &#39;1.2&#39;. However other supported values are &#39;1.0&#39; and &#39;1.1&#39;. | [optional] 
**Port** | Pointer to **int32** | KMIP server port. | [optional] 

## Methods

### NewV12KmipServerExtendedExtended

`func NewV12KmipServerExtendedExtended() *V12KmipServerExtendedExtended`

NewV12KmipServerExtendedExtended instantiates a new V12KmipServerExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12KmipServerExtendedExtendedWithDefaults

`func NewV12KmipServerExtendedExtendedWithDefaults() *V12KmipServerExtendedExtended`

NewV12KmipServerExtendedExtendedWithDefaults instantiates a new V12KmipServerExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCaCertPath

`func (o *V12KmipServerExtendedExtended) GetCaCertPath() string`

GetCaCertPath returns the CaCertPath field if non-nil, zero value otherwise.

### GetCaCertPathOk

`func (o *V12KmipServerExtendedExtended) GetCaCertPathOk() (*string, bool)`

GetCaCertPathOk returns a tuple with the CaCertPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCaCertPath

`func (o *V12KmipServerExtendedExtended) SetCaCertPath(v string)`

SetCaCertPath sets CaCertPath field to given value.

### HasCaCertPath

`func (o *V12KmipServerExtendedExtended) HasCaCertPath() bool`

HasCaCertPath returns a boolean if a field has been set.

### GetClientCertPassword

`func (o *V12KmipServerExtendedExtended) GetClientCertPassword() string`

GetClientCertPassword returns the ClientCertPassword field if non-nil, zero value otherwise.

### GetClientCertPasswordOk

`func (o *V12KmipServerExtendedExtended) GetClientCertPasswordOk() (*string, bool)`

GetClientCertPasswordOk returns a tuple with the ClientCertPassword field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClientCertPassword

`func (o *V12KmipServerExtendedExtended) SetClientCertPassword(v string)`

SetClientCertPassword sets ClientCertPassword field to given value.

### HasClientCertPassword

`func (o *V12KmipServerExtendedExtended) HasClientCertPassword() bool`

HasClientCertPassword returns a boolean if a field has been set.

### GetClientCertPath

`func (o *V12KmipServerExtendedExtended) GetClientCertPath() string`

GetClientCertPath returns the ClientCertPath field if non-nil, zero value otherwise.

### GetClientCertPathOk

`func (o *V12KmipServerExtendedExtended) GetClientCertPathOk() (*string, bool)`

GetClientCertPathOk returns a tuple with the ClientCertPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClientCertPath

`func (o *V12KmipServerExtendedExtended) SetClientCertPath(v string)`

SetClientCertPath sets ClientCertPath field to given value.

### HasClientCertPath

`func (o *V12KmipServerExtendedExtended) HasClientCertPath() bool`

HasClientCertPath returns a boolean if a field has been set.

### GetHost

`func (o *V12KmipServerExtendedExtended) GetHost() string`

GetHost returns the Host field if non-nil, zero value otherwise.

### GetHostOk

`func (o *V12KmipServerExtendedExtended) GetHostOk() (*string, bool)`

GetHostOk returns a tuple with the Host field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHost

`func (o *V12KmipServerExtendedExtended) SetHost(v string)`

SetHost sets Host field to given value.

### HasHost

`func (o *V12KmipServerExtendedExtended) HasHost() bool`

HasHost returns a boolean if a field has been set.

### GetMinimumTlsVersion

`func (o *V12KmipServerExtendedExtended) GetMinimumTlsVersion() string`

GetMinimumTlsVersion returns the MinimumTlsVersion field if non-nil, zero value otherwise.

### GetMinimumTlsVersionOk

`func (o *V12KmipServerExtendedExtended) GetMinimumTlsVersionOk() (*string, bool)`

GetMinimumTlsVersionOk returns a tuple with the MinimumTlsVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinimumTlsVersion

`func (o *V12KmipServerExtendedExtended) SetMinimumTlsVersion(v string)`

SetMinimumTlsVersion sets MinimumTlsVersion field to given value.

### HasMinimumTlsVersion

`func (o *V12KmipServerExtendedExtended) HasMinimumTlsVersion() bool`

HasMinimumTlsVersion returns a boolean if a field has been set.

### GetPort

`func (o *V12KmipServerExtendedExtended) GetPort() int32`

GetPort returns the Port field if non-nil, zero value otherwise.

### GetPortOk

`func (o *V12KmipServerExtendedExtended) GetPortOk() (*int32, bool)`

GetPortOk returns a tuple with the Port field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPort

`func (o *V12KmipServerExtendedExtended) SetPort(v int32)`

SetPort sets Port field to given value.

### HasPort

`func (o *V12KmipServerExtendedExtended) HasPort() bool`

HasPort returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


