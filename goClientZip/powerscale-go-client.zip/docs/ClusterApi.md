# \ClusterApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateClusterv14ClusterAc**](ClusterApi.md#CreateClusterv14ClusterAc) | **Post** /platform/14/cluster/acs | 
[**CreateClusterv16DiagnosticsGatherStartItem**](ClusterApi.md#CreateClusterv16DiagnosticsGatherStartItem) | **Post** /platform/16/cluster/diagnostics/gather/start | 
[**CreateClusterv3ClusterAddNodeItem**](ClusterApi.md#CreateClusterv3ClusterAddNodeItem) | **Post** /platform/3/cluster/add-node | 
[**CreateClusterv3DiagnosticsGatherStartItem**](ClusterApi.md#CreateClusterv3DiagnosticsGatherStartItem) | **Post** /platform/3/cluster/diagnostics/gather/start | 
[**CreateClusterv3DiagnosticsGatherStopItem**](ClusterApi.md#CreateClusterv3DiagnosticsGatherStopItem) | **Post** /platform/3/cluster/diagnostics/gather/stop | 
[**CreateClusterv3DiagnosticsNetloggerStartItem**](ClusterApi.md#CreateClusterv3DiagnosticsNetloggerStartItem) | **Post** /platform/3/cluster/diagnostics/netlogger/start | 
[**CreateClusterv3DiagnosticsNetloggerStopItem**](ClusterApi.md#CreateClusterv3DiagnosticsNetloggerStopItem) | **Post** /platform/3/cluster/diagnostics/netlogger/stop | 
[**GetClusterv10ClusterNode**](ClusterApi.md#GetClusterv10ClusterNode) | **Get** /platform/10/cluster/nodes/{v10ClusterNodeId} | 
[**GetClusterv10ClusterNodes**](ClusterApi.md#GetClusterv10ClusterNodes) | **Get** /platform/10/cluster/nodes | 
[**GetClusterv12ClusterNode**](ClusterApi.md#GetClusterv12ClusterNode) | **Get** /platform/12/cluster/nodes/{v12ClusterNodeId} | 
[**GetClusterv12ClusterNodes**](ClusterApi.md#GetClusterv12ClusterNodes) | **Get** /platform/12/cluster/nodes | 
[**GetClusterv14ClusterNode**](ClusterApi.md#GetClusterv14ClusterNode) | **Get** /platform/14/cluster/nodes/{v14ClusterNodeId} | 
[**GetClusterv14ClusterNodes**](ClusterApi.md#GetClusterv14ClusterNodes) | **Get** /platform/14/cluster/nodes | 
[**GetClusterv14InternalNetworksSettings**](ClusterApi.md#GetClusterv14InternalNetworksSettings) | **Get** /platform/14/cluster/internal-networks/settings | 
[**GetClusterv15ClusterNode**](ClusterApi.md#GetClusterv15ClusterNode) | **Get** /platform/15/cluster/nodes/{v15ClusterNodeId} | 
[**GetClusterv15ClusterNodes**](ClusterApi.md#GetClusterv15ClusterNodes) | **Get** /platform/15/cluster/nodes | 
[**GetClusterv15ClusterServices**](ClusterApi.md#GetClusterv15ClusterServices) | **Get** /platform/15/cluster/services | 
[**GetClusterv15NodesLnnDrive**](ClusterApi.md#GetClusterv15NodesLnnDrive) | **Get** /platform/15/cluster/nodes/{Lnn}/drives/{v15NodesLnnDriveId} | 
[**GetClusterv16ClusterNode**](ClusterApi.md#GetClusterv16ClusterNode) | **Get** /platform/16/cluster/nodes/{v16ClusterNodeId} | 
[**GetClusterv16ClusterNodes**](ClusterApi.md#GetClusterv16ClusterNodes) | **Get** /platform/16/cluster/nodes | 
[**GetClusterv16DiagnosticsGatherSettings**](ClusterApi.md#GetClusterv16DiagnosticsGatherSettings) | **Get** /platform/16/cluster/diagnostics/gather/settings | 
[**GetClusterv16IceageSettings**](ClusterApi.md#GetClusterv16IceageSettings) | **Get** /platform/16/cluster/iceage/settings | 
[**GetClusterv16NodesLnnDrive**](ClusterApi.md#GetClusterv16NodesLnnDrive) | **Get** /platform/16/cluster/nodes/{Lnn}/drives/{v16NodesLnnDriveId} | 
[**GetClusterv1ClusterConfig**](ClusterApi.md#GetClusterv1ClusterConfig) | **Get** /platform/1/cluster/config | 
[**GetClusterv1ClusterEmail**](ClusterApi.md#GetClusterv1ClusterEmail) | **Get** /platform/1/cluster/email | 
[**GetClusterv1ClusterExternalIps**](ClusterApi.md#GetClusterv1ClusterExternalIps) | **Get** /platform/1/cluster/external-ips | 
[**GetClusterv1ClusterIdentity**](ClusterApi.md#GetClusterv1ClusterIdentity) | **Get** /platform/1/cluster/identity | 
[**GetClusterv1ClusterOwner**](ClusterApi.md#GetClusterv1ClusterOwner) | **Get** /platform/1/cluster/owner | 
[**GetClusterv1ClusterStatfs**](ClusterApi.md#GetClusterv1ClusterStatfs) | **Get** /platform/1/cluster/statfs | 
[**GetClusterv1ClusterTime**](ClusterApi.md#GetClusterv1ClusterTime) | **Get** /platform/1/cluster/time | 
[**GetClusterv2ClusterExternalIps**](ClusterApi.md#GetClusterv2ClusterExternalIps) | **Get** /platform/2/cluster/external-ips | 
[**GetClusterv3ClusterConfig**](ClusterApi.md#GetClusterv3ClusterConfig) | **Get** /platform/3/cluster/config | 
[**GetClusterv3ClusterIdentity**](ClusterApi.md#GetClusterv3ClusterIdentity) | **Get** /platform/3/cluster/identity | 
[**GetClusterv3ClusterNode**](ClusterApi.md#GetClusterv3ClusterNode) | **Get** /platform/3/cluster/nodes/{v3ClusterNodeId} | 
[**GetClusterv3ClusterNodes**](ClusterApi.md#GetClusterv3ClusterNodes) | **Get** /platform/3/cluster/nodes | 
[**GetClusterv3ClusterNodesAvailable**](ClusterApi.md#GetClusterv3ClusterNodesAvailable) | **Get** /platform/3/cluster/nodes-available | 
[**GetClusterv3ClusterTime**](ClusterApi.md#GetClusterv3ClusterTime) | **Get** /platform/3/cluster/time | 
[**GetClusterv3ClusterTimezone**](ClusterApi.md#GetClusterv3ClusterTimezone) | **Get** /platform/3/cluster/timezone | 
[**GetClusterv3ClusterVersion**](ClusterApi.md#GetClusterv3ClusterVersion) | **Get** /platform/3/cluster/version | 
[**GetClusterv3DiagnosticsGather**](ClusterApi.md#GetClusterv3DiagnosticsGather) | **Get** /platform/3/cluster/diagnostics/gather | 
[**GetClusterv3DiagnosticsGatherSettings**](ClusterApi.md#GetClusterv3DiagnosticsGatherSettings) | **Get** /platform/3/cluster/diagnostics/gather/settings | 
[**GetClusterv3DiagnosticsGatherStatus**](ClusterApi.md#GetClusterv3DiagnosticsGatherStatus) | **Get** /platform/3/cluster/diagnostics/gather/status | 
[**GetClusterv3DiagnosticsNetlogger**](ClusterApi.md#GetClusterv3DiagnosticsNetlogger) | **Get** /platform/3/cluster/diagnostics/netlogger | 
[**GetClusterv3DiagnosticsNetloggerSettings**](ClusterApi.md#GetClusterv3DiagnosticsNetloggerSettings) | **Get** /platform/3/cluster/diagnostics/netlogger/settings | 
[**GetClusterv3DiagnosticsNetloggerStatus**](ClusterApi.md#GetClusterv3DiagnosticsNetloggerStatus) | **Get** /platform/3/cluster/diagnostics/netlogger/status | 
[**GetClusterv3NodesLnnDrive**](ClusterApi.md#GetClusterv3NodesLnnDrive) | **Get** /platform/3/cluster/nodes/{Lnn}/drives/{v3NodesLnnDriveId} | 
[**GetClusterv3TimezoneRegion**](ClusterApi.md#GetClusterv3TimezoneRegion) | **Get** /platform/3/cluster/timezone/regions/{v3TimezoneRegionId} | 
[**GetClusterv3TimezoneSettings**](ClusterApi.md#GetClusterv3TimezoneSettings) | **Get** /platform/3/cluster/timezone/settings | 
[**GetClusterv5ClusterIdentity**](ClusterApi.md#GetClusterv5ClusterIdentity) | **Get** /platform/5/cluster/identity | 
[**GetClusterv5ClusterNode**](ClusterApi.md#GetClusterv5ClusterNode) | **Get** /platform/5/cluster/nodes/{v5ClusterNodeId} | 
[**GetClusterv5ClusterNodes**](ClusterApi.md#GetClusterv5ClusterNodes) | **Get** /platform/5/cluster/nodes | 
[**GetClusterv5NodesLnnDrive**](ClusterApi.md#GetClusterv5NodesLnnDrive) | **Get** /platform/5/cluster/nodes/{Lnn}/drives/{v5NodesLnnDriveId} | 
[**GetClusterv5NodesLnnSled**](ClusterApi.md#GetClusterv5NodesLnnSled) | **Get** /platform/5/cluster/nodes/{Lnn}/sleds/{v5NodesLnnSledId} | 
[**GetClusterv7ClusterInternalNetworks**](ClusterApi.md#GetClusterv7ClusterInternalNetworks) | **Get** /platform/7/cluster/internal-networks | 
[**GetClusterv7ClusterNode**](ClusterApi.md#GetClusterv7ClusterNode) | **Get** /platform/7/cluster/nodes/{v7ClusterNodeId} | 
[**GetClusterv7ClusterNodes**](ClusterApi.md#GetClusterv7ClusterNodes) | **Get** /platform/7/cluster/nodes | 
[**GetClusterv7NodesLnnDrive**](ClusterApi.md#GetClusterv7NodesLnnDrive) | **Get** /platform/7/cluster/nodes/{Lnn}/drives/{v7NodesLnnDriveId} | 
[**ListClusterv14ClusterAcs**](ClusterApi.md#ListClusterv14ClusterAcs) | **Get** /platform/14/cluster/acs | 
[**UpdateClusterv14InternalNetworksPreferredNetwork**](ClusterApi.md#UpdateClusterv14InternalNetworksPreferredNetwork) | **Put** /platform/14/cluster/internal-networks/preferred-network | 
[**UpdateClusterv14InternalNetworksSettings**](ClusterApi.md#UpdateClusterv14InternalNetworksSettings) | **Put** /platform/14/cluster/internal-networks/settings | 
[**UpdateClusterv16DiagnosticsGatherSettings**](ClusterApi.md#UpdateClusterv16DiagnosticsGatherSettings) | **Put** /platform/16/cluster/diagnostics/gather/settings | 
[**UpdateClusterv16IceageSettings**](ClusterApi.md#UpdateClusterv16IceageSettings) | **Put** /platform/16/cluster/iceage/settings | 
[**UpdateClusterv1ClusterEmail**](ClusterApi.md#UpdateClusterv1ClusterEmail) | **Put** /platform/1/cluster/email | 
[**UpdateClusterv1ClusterOwner**](ClusterApi.md#UpdateClusterv1ClusterOwner) | **Put** /platform/1/cluster/owner | 
[**UpdateClusterv3ClusterIdentity**](ClusterApi.md#UpdateClusterv3ClusterIdentity) | **Put** /platform/3/cluster/identity | 
[**UpdateClusterv3ClusterNode**](ClusterApi.md#UpdateClusterv3ClusterNode) | **Put** /platform/3/cluster/nodes/{v3ClusterNodeId} | 
[**UpdateClusterv3ClusterTime**](ClusterApi.md#UpdateClusterv3ClusterTime) | **Put** /platform/3/cluster/time | 
[**UpdateClusterv3ClusterTimezone**](ClusterApi.md#UpdateClusterv3ClusterTimezone) | **Put** /platform/3/cluster/timezone | 
[**UpdateClusterv3DiagnosticsGatherSettings**](ClusterApi.md#UpdateClusterv3DiagnosticsGatherSettings) | **Put** /platform/3/cluster/diagnostics/gather/settings | 
[**UpdateClusterv3DiagnosticsNetloggerSettings**](ClusterApi.md#UpdateClusterv3DiagnosticsNetloggerSettings) | **Put** /platform/3/cluster/diagnostics/netlogger/settings | 
[**UpdateClusterv3TimezoneSettings**](ClusterApi.md#UpdateClusterv3TimezoneSettings) | **Put** /platform/3/cluster/timezone/settings | 
[**UpdateClusterv5ClusterIdentity**](ClusterApi.md#UpdateClusterv5ClusterIdentity) | **Put** /platform/5/cluster/identity | 
[**UpdateClusterv5ClusterNode**](ClusterApi.md#UpdateClusterv5ClusterNode) | **Put** /platform/5/cluster/nodes/{v5ClusterNodeId} | 
[**UpdateClusterv7ClusterInternalNetworks**](ClusterApi.md#UpdateClusterv7ClusterInternalNetworks) | **Put** /platform/7/cluster/internal-networks | 
[**UpdateClusterv7ClusterNode**](ClusterApi.md#UpdateClusterv7ClusterNode) | **Put** /platform/7/cluster/nodes/{v7ClusterNodeId} | 
[**UpdateClusterv7ClusterUpdateLnns**](ClusterApi.md#UpdateClusterv7ClusterUpdateLnns) | **Put** /platform/7/cluster/update-lnns | 



## CreateClusterv14ClusterAc

> CreateResponse CreateClusterv14ClusterAc(ctx).V14ClusterAc(v14ClusterAc).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14ClusterAc := *openapiclient.NewV14ClusterAc() // V14ClusterAc | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.CreateClusterv14ClusterAc(context.Background()).V14ClusterAc(v14ClusterAc).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.CreateClusterv14ClusterAc``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterv14ClusterAc`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.CreateClusterv14ClusterAc`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterv14ClusterAcRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14ClusterAc** | [**V14ClusterAc**](V14ClusterAc.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterv16DiagnosticsGatherStartItem

> map[string]interface{} CreateClusterv16DiagnosticsGatherStartItem(ctx).V16DiagnosticsGatherStartItem(v16DiagnosticsGatherStartItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16DiagnosticsGatherStartItem := *openapiclient.NewV16DiagnosticsGatherSettingsExtended() // V16DiagnosticsGatherSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.CreateClusterv16DiagnosticsGatherStartItem(context.Background()).V16DiagnosticsGatherStartItem(v16DiagnosticsGatherStartItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.CreateClusterv16DiagnosticsGatherStartItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterv16DiagnosticsGatherStartItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.CreateClusterv16DiagnosticsGatherStartItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterv16DiagnosticsGatherStartItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16DiagnosticsGatherStartItem** | [**V16DiagnosticsGatherSettingsExtended**](V16DiagnosticsGatherSettingsExtended.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterv3ClusterAddNodeItem

> map[string]interface{} CreateClusterv3ClusterAddNodeItem(ctx).V3ClusterAddNodeItem(v3ClusterAddNodeItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterAddNodeItem := *openapiclient.NewV3ClusterAddNodeItem("SerialNumber_example") // V3ClusterAddNodeItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.CreateClusterv3ClusterAddNodeItem(context.Background()).V3ClusterAddNodeItem(v3ClusterAddNodeItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.CreateClusterv3ClusterAddNodeItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterv3ClusterAddNodeItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.CreateClusterv3ClusterAddNodeItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterv3ClusterAddNodeItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterAddNodeItem** | [**V3ClusterAddNodeItem**](V3ClusterAddNodeItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterv3DiagnosticsGatherStartItem

> map[string]interface{} CreateClusterv3DiagnosticsGatherStartItem(ctx).V3DiagnosticsGatherStartItem(v3DiagnosticsGatherStartItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3DiagnosticsGatherStartItem := *openapiclient.NewV3DiagnosticsGatherSettingsExtended() // V3DiagnosticsGatherSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.CreateClusterv3DiagnosticsGatherStartItem(context.Background()).V3DiagnosticsGatherStartItem(v3DiagnosticsGatherStartItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.CreateClusterv3DiagnosticsGatherStartItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterv3DiagnosticsGatherStartItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.CreateClusterv3DiagnosticsGatherStartItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterv3DiagnosticsGatherStartItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3DiagnosticsGatherStartItem** | [**V3DiagnosticsGatherSettingsExtended**](V3DiagnosticsGatherSettingsExtended.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterv3DiagnosticsGatherStopItem

> map[string]interface{} CreateClusterv3DiagnosticsGatherStopItem(ctx).V3DiagnosticsGatherStopItem(v3DiagnosticsGatherStopItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3DiagnosticsGatherStopItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.CreateClusterv3DiagnosticsGatherStopItem(context.Background()).V3DiagnosticsGatherStopItem(v3DiagnosticsGatherStopItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.CreateClusterv3DiagnosticsGatherStopItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterv3DiagnosticsGatherStopItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.CreateClusterv3DiagnosticsGatherStopItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterv3DiagnosticsGatherStopItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3DiagnosticsGatherStopItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterv3DiagnosticsNetloggerStartItem

> map[string]interface{} CreateClusterv3DiagnosticsNetloggerStartItem(ctx).V3DiagnosticsNetloggerStartItem(v3DiagnosticsNetloggerStartItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3DiagnosticsNetloggerStartItem := *openapiclient.NewV3DiagnosticsNetloggerSettingsSettings() // V3DiagnosticsNetloggerSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.CreateClusterv3DiagnosticsNetloggerStartItem(context.Background()).V3DiagnosticsNetloggerStartItem(v3DiagnosticsNetloggerStartItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.CreateClusterv3DiagnosticsNetloggerStartItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterv3DiagnosticsNetloggerStartItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.CreateClusterv3DiagnosticsNetloggerStartItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterv3DiagnosticsNetloggerStartItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3DiagnosticsNetloggerStartItem** | [**V3DiagnosticsNetloggerSettingsSettings**](V3DiagnosticsNetloggerSettingsSettings.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterv3DiagnosticsNetloggerStopItem

> map[string]interface{} CreateClusterv3DiagnosticsNetloggerStopItem(ctx).V3DiagnosticsNetloggerStopItem(v3DiagnosticsNetloggerStopItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3DiagnosticsNetloggerStopItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.CreateClusterv3DiagnosticsNetloggerStopItem(context.Background()).V3DiagnosticsNetloggerStopItem(v3DiagnosticsNetloggerStopItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.CreateClusterv3DiagnosticsNetloggerStopItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterv3DiagnosticsNetloggerStopItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.CreateClusterv3DiagnosticsNetloggerStopItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterv3DiagnosticsNetloggerStopItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3DiagnosticsNetloggerStopItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv10ClusterNode

> V10ClusterNodes GetClusterv10ClusterNode(ctx, v10ClusterNodeId).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ClusterNodeId := int32(56) // int32 | Retrieve node information.
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv10ClusterNode(context.Background(), v10ClusterNodeId).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv10ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv10ClusterNode`: V10ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv10ClusterNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10ClusterNodeId** | **int32** | Retrieve node information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv10ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V10ClusterNodes**](V10ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv10ClusterNodes

> V10ClusterNodes GetClusterv10ClusterNodes(ctx).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv10ClusterNodes(context.Background()).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv10ClusterNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv10ClusterNodes`: V10ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv10ClusterNodes`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv10ClusterNodesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeout** | **float32** | Request timeout | 

### Return type

[**V10ClusterNodes**](V10ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv12ClusterNode

> V12ClusterNodes GetClusterv12ClusterNode(ctx, v12ClusterNodeId).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12ClusterNodeId := int32(56) // int32 | Retrieve node information.
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv12ClusterNode(context.Background(), v12ClusterNodeId).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv12ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv12ClusterNode`: V12ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv12ClusterNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12ClusterNodeId** | **int32** | Retrieve node information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv12ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V12ClusterNodes**](V12ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv12ClusterNodes

> V12ClusterNodes GetClusterv12ClusterNodes(ctx).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv12ClusterNodes(context.Background()).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv12ClusterNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv12ClusterNodes`: V12ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv12ClusterNodes`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv12ClusterNodesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeout** | **float32** | Request timeout | 

### Return type

[**V12ClusterNodes**](V12ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv14ClusterNode

> V14ClusterNodes GetClusterv14ClusterNode(ctx, v14ClusterNodeId).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14ClusterNodeId := int32(56) // int32 | Retrieve node information.
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv14ClusterNode(context.Background(), v14ClusterNodeId).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv14ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv14ClusterNode`: V14ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv14ClusterNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v14ClusterNodeId** | **int32** | Retrieve node information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv14ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V14ClusterNodes**](V14ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv14ClusterNodes

> V14ClusterNodes GetClusterv14ClusterNodes(ctx).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv14ClusterNodes(context.Background()).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv14ClusterNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv14ClusterNodes`: V14ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv14ClusterNodes`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv14ClusterNodesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeout** | **float32** | Request timeout | 

### Return type

[**V14ClusterNodes**](V14ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv14InternalNetworksSettings

> V14InternalNetworksSettings GetClusterv14InternalNetworksSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv14InternalNetworksSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv14InternalNetworksSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv14InternalNetworksSettings`: V14InternalNetworksSettings
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv14InternalNetworksSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv14InternalNetworksSettingsRequest struct via the builder pattern


### Return type

[**V14InternalNetworksSettings**](V14InternalNetworksSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv15ClusterNode

> V15ClusterNodes GetClusterv15ClusterNode(ctx, v15ClusterNodeId).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15ClusterNodeId := int32(56) // int32 | Retrieve node information.
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv15ClusterNode(context.Background(), v15ClusterNodeId).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv15ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv15ClusterNode`: V15ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv15ClusterNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15ClusterNodeId** | **int32** | Retrieve node information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv15ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V15ClusterNodes**](V15ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv15ClusterNodes

> V15ClusterNodes GetClusterv15ClusterNodes(ctx).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv15ClusterNodes(context.Background()).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv15ClusterNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv15ClusterNodes`: V15ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv15ClusterNodes`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv15ClusterNodesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeout** | **float32** | Request timeout | 

### Return type

[**V15ClusterNodes**](V15ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv15ClusterServices

> V15ClusterServices GetClusterv15ClusterServices(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv15ClusterServices(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv15ClusterServices``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv15ClusterServices`: V15ClusterServices
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv15ClusterServices`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv15ClusterServicesRequest struct via the builder pattern


### Return type

[**V15ClusterServices**](V15ClusterServices.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv15NodesLnnDrive

> V15NodeDrives GetClusterv15NodesLnnDrive(ctx, v15NodesLnnDriveId, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15NodesLnnDriveId := "v15NodesLnnDriveId_example" // string | Retrieve drive information.
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv15NodesLnnDrive(context.Background(), v15NodesLnnDriveId, lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv15NodesLnnDrive``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv15NodesLnnDrive`: V15NodeDrives
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv15NodesLnnDrive`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15NodesLnnDriveId** | **string** | Retrieve drive information. | 
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv15NodesLnnDriveRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **timeout** | **float32** | Request timeout | 

### Return type

[**V15NodeDrives**](V15NodeDrives.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv16ClusterNode

> V16ClusterNodes GetClusterv16ClusterNode(ctx, v16ClusterNodeId).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16ClusterNodeId := int32(56) // int32 | Retrieve node information.
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv16ClusterNode(context.Background(), v16ClusterNodeId).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv16ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv16ClusterNode`: V16ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv16ClusterNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16ClusterNodeId** | **int32** | Retrieve node information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv16ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V16ClusterNodes**](V16ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv16ClusterNodes

> V16ClusterNodes GetClusterv16ClusterNodes(ctx).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv16ClusterNodes(context.Background()).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv16ClusterNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv16ClusterNodes`: V16ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv16ClusterNodes`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv16ClusterNodesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeout** | **float32** | Request timeout | 

### Return type

[**V16ClusterNodes**](V16ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv16DiagnosticsGatherSettings

> V16DiagnosticsGatherSettings GetClusterv16DiagnosticsGatherSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv16DiagnosticsGatherSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv16DiagnosticsGatherSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv16DiagnosticsGatherSettings`: V16DiagnosticsGatherSettings
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv16DiagnosticsGatherSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv16DiagnosticsGatherSettingsRequest struct via the builder pattern


### Return type

[**V16DiagnosticsGatherSettings**](V16DiagnosticsGatherSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv16IceageSettings

> V16IceageSettings GetClusterv16IceageSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv16IceageSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv16IceageSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv16IceageSettings`: V16IceageSettings
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv16IceageSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv16IceageSettingsRequest struct via the builder pattern


### Return type

[**V16IceageSettings**](V16IceageSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv16NodesLnnDrive

> V16NodeDrives GetClusterv16NodesLnnDrive(ctx, v16NodesLnnDriveId, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16NodesLnnDriveId := "v16NodesLnnDriveId_example" // string | Retrieve drive information.
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv16NodesLnnDrive(context.Background(), v16NodesLnnDriveId, lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv16NodesLnnDrive``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv16NodesLnnDrive`: V16NodeDrives
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv16NodesLnnDrive`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16NodesLnnDriveId** | **string** | Retrieve drive information. | 
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv16NodesLnnDriveRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **timeout** | **float32** | Request timeout | 

### Return type

[**V16NodeDrives**](V16NodeDrives.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv1ClusterConfig

> V1ClusterConfig GetClusterv1ClusterConfig(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv1ClusterConfig(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv1ClusterConfig``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv1ClusterConfig`: V1ClusterConfig
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv1ClusterConfig`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv1ClusterConfigRequest struct via the builder pattern


### Return type

[**V1ClusterConfig**](V1ClusterConfig.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv1ClusterEmail

> V1ClusterEmail GetClusterv1ClusterEmail(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv1ClusterEmail(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv1ClusterEmail``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv1ClusterEmail`: V1ClusterEmail
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv1ClusterEmail`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv1ClusterEmailRequest struct via the builder pattern


### Return type

[**V1ClusterEmail**](V1ClusterEmail.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv1ClusterExternalIps

> []string GetClusterv1ClusterExternalIps(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv1ClusterExternalIps(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv1ClusterExternalIps``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv1ClusterExternalIps`: []string
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv1ClusterExternalIps`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv1ClusterExternalIpsRequest struct via the builder pattern


### Return type

**[]string**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv1ClusterIdentity

> V1ClusterIdentity GetClusterv1ClusterIdentity(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv1ClusterIdentity(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv1ClusterIdentity``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv1ClusterIdentity`: V1ClusterIdentity
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv1ClusterIdentity`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv1ClusterIdentityRequest struct via the builder pattern


### Return type

[**V1ClusterIdentity**](V1ClusterIdentity.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv1ClusterOwner

> V1ClusterOwner GetClusterv1ClusterOwner(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv1ClusterOwner(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv1ClusterOwner``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv1ClusterOwner`: V1ClusterOwner
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv1ClusterOwner`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv1ClusterOwnerRequest struct via the builder pattern


### Return type

[**V1ClusterOwner**](V1ClusterOwner.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv1ClusterStatfs

> V1ClusterStatfs GetClusterv1ClusterStatfs(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv1ClusterStatfs(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv1ClusterStatfs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv1ClusterStatfs`: V1ClusterStatfs
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv1ClusterStatfs`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv1ClusterStatfsRequest struct via the builder pattern


### Return type

[**V1ClusterStatfs**](V1ClusterStatfs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv1ClusterTime

> V1ClusterTime GetClusterv1ClusterTime(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv1ClusterTime(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv1ClusterTime``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv1ClusterTime`: V1ClusterTime
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv1ClusterTime`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv1ClusterTimeRequest struct via the builder pattern


### Return type

[**V1ClusterTime**](V1ClusterTime.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv2ClusterExternalIps

> []string GetClusterv2ClusterExternalIps(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv2ClusterExternalIps(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv2ClusterExternalIps``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv2ClusterExternalIps`: []string
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv2ClusterExternalIps`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv2ClusterExternalIpsRequest struct via the builder pattern


### Return type

**[]string**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3ClusterConfig

> V3ClusterConfig GetClusterv3ClusterConfig(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3ClusterConfig(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3ClusterConfig``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3ClusterConfig`: V3ClusterConfig
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3ClusterConfig`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3ClusterConfigRequest struct via the builder pattern


### Return type

[**V3ClusterConfig**](V3ClusterConfig.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3ClusterIdentity

> V1ClusterIdentity GetClusterv3ClusterIdentity(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3ClusterIdentity(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3ClusterIdentity``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3ClusterIdentity`: V1ClusterIdentity
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3ClusterIdentity`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3ClusterIdentityRequest struct via the builder pattern


### Return type

[**V1ClusterIdentity**](V1ClusterIdentity.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3ClusterNode

> V3ClusterNodes GetClusterv3ClusterNode(ctx, v3ClusterNodeId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterNodeId := int32(56) // int32 | Retrieve node information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3ClusterNode(context.Background(), v3ClusterNodeId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3ClusterNode`: V3ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3ClusterNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ClusterNodeId** | **int32** | Retrieve node information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3ClusterNodes**](V3ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3ClusterNodes

> V3ClusterNodes GetClusterv3ClusterNodes(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3ClusterNodes(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3ClusterNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3ClusterNodes`: V3ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3ClusterNodes`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3ClusterNodesRequest struct via the builder pattern


### Return type

[**V3ClusterNodes**](V3ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3ClusterNodesAvailable

> V3ClusterNodesAvailable GetClusterv3ClusterNodesAvailable(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3ClusterNodesAvailable(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3ClusterNodesAvailable``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3ClusterNodesAvailable`: V3ClusterNodesAvailable
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3ClusterNodesAvailable`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3ClusterNodesAvailableRequest struct via the builder pattern


### Return type

[**V3ClusterNodesAvailable**](V3ClusterNodesAvailable.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3ClusterTime

> V3ClusterTime GetClusterv3ClusterTime(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3ClusterTime(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3ClusterTime``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3ClusterTime`: V3ClusterTime
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3ClusterTime`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3ClusterTimeRequest struct via the builder pattern


### Return type

[**V3ClusterTime**](V3ClusterTime.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3ClusterTimezone

> V3ClusterTimezone GetClusterv3ClusterTimezone(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3ClusterTimezone(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3ClusterTimezone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3ClusterTimezone`: V3ClusterTimezone
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3ClusterTimezone`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3ClusterTimezoneRequest struct via the builder pattern


### Return type

[**V3ClusterTimezone**](V3ClusterTimezone.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3ClusterVersion

> V3ClusterVersion GetClusterv3ClusterVersion(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3ClusterVersion(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3ClusterVersion``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3ClusterVersion`: V3ClusterVersion
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3ClusterVersion`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3ClusterVersionRequest struct via the builder pattern


### Return type

[**V3ClusterVersion**](V3ClusterVersion.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3DiagnosticsGather

> V3DiagnosticsGather GetClusterv3DiagnosticsGather(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3DiagnosticsGather(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3DiagnosticsGather``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3DiagnosticsGather`: V3DiagnosticsGather
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3DiagnosticsGather`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3DiagnosticsGatherRequest struct via the builder pattern


### Return type

[**V3DiagnosticsGather**](V3DiagnosticsGather.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3DiagnosticsGatherSettings

> V3DiagnosticsGatherSettings GetClusterv3DiagnosticsGatherSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3DiagnosticsGatherSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3DiagnosticsGatherSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3DiagnosticsGatherSettings`: V3DiagnosticsGatherSettings
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3DiagnosticsGatherSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3DiagnosticsGatherSettingsRequest struct via the builder pattern


### Return type

[**V3DiagnosticsGatherSettings**](V3DiagnosticsGatherSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3DiagnosticsGatherStatus

> V3DiagnosticsGather GetClusterv3DiagnosticsGatherStatus(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3DiagnosticsGatherStatus(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3DiagnosticsGatherStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3DiagnosticsGatherStatus`: V3DiagnosticsGather
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3DiagnosticsGatherStatus`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3DiagnosticsGatherStatusRequest struct via the builder pattern


### Return type

[**V3DiagnosticsGather**](V3DiagnosticsGather.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3DiagnosticsNetlogger

> V3DiagnosticsNetlogger GetClusterv3DiagnosticsNetlogger(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3DiagnosticsNetlogger(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3DiagnosticsNetlogger``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3DiagnosticsNetlogger`: V3DiagnosticsNetlogger
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3DiagnosticsNetlogger`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3DiagnosticsNetloggerRequest struct via the builder pattern


### Return type

[**V3DiagnosticsNetlogger**](V3DiagnosticsNetlogger.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3DiagnosticsNetloggerSettings

> V3DiagnosticsNetloggerSettings GetClusterv3DiagnosticsNetloggerSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3DiagnosticsNetloggerSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3DiagnosticsNetloggerSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3DiagnosticsNetloggerSettings`: V3DiagnosticsNetloggerSettings
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3DiagnosticsNetloggerSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3DiagnosticsNetloggerSettingsRequest struct via the builder pattern


### Return type

[**V3DiagnosticsNetloggerSettings**](V3DiagnosticsNetloggerSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3DiagnosticsNetloggerStatus

> V3DiagnosticsNetlogger GetClusterv3DiagnosticsNetloggerStatus(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3DiagnosticsNetloggerStatus(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3DiagnosticsNetloggerStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3DiagnosticsNetloggerStatus`: V3DiagnosticsNetlogger
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3DiagnosticsNetloggerStatus`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3DiagnosticsNetloggerStatusRequest struct via the builder pattern


### Return type

[**V3DiagnosticsNetlogger**](V3DiagnosticsNetlogger.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3NodesLnnDrive

> V3NodeDrives GetClusterv3NodesLnnDrive(ctx, v3NodesLnnDriveId, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NodesLnnDriveId := "v3NodesLnnDriveId_example" // string | Retrieve drive information.
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3NodesLnnDrive(context.Background(), v3NodesLnnDriveId, lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3NodesLnnDrive``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3NodesLnnDrive`: V3NodeDrives
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3NodesLnnDrive`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NodesLnnDriveId** | **string** | Retrieve drive information. | 
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3NodesLnnDriveRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V3NodeDrives**](V3NodeDrives.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3TimezoneRegion

> V3TimezoneRegions GetClusterv3TimezoneRegion(ctx, v3TimezoneRegionId).Sort(sort).Resume(resume).ShowAll(showAll).DstReset(dstReset).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3TimezoneRegionId := "v3TimezoneRegionId_example" // string | List timezone regions.
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    showAll := true // bool | Show all timezones within the region specified in the URI. (optional)
    dstReset := true // bool | This query arg is not needed in normal use cases. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3TimezoneRegion(context.Background(), v3TimezoneRegionId).Sort(sort).Resume(resume).ShowAll(showAll).DstReset(dstReset).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3TimezoneRegion``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3TimezoneRegion`: V3TimezoneRegions
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3TimezoneRegion`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3TimezoneRegionId** | **string** | List timezone regions. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3TimezoneRegionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **showAll** | **bool** | Show all timezones within the region specified in the URI. | 
 **dstReset** | **bool** | This query arg is not needed in normal use cases. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3TimezoneRegions**](V3TimezoneRegions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv3TimezoneSettings

> V3TimezoneSettings GetClusterv3TimezoneSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv3TimezoneSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv3TimezoneSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv3TimezoneSettings`: V3TimezoneSettings
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv3TimezoneSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv3TimezoneSettingsRequest struct via the builder pattern


### Return type

[**V3TimezoneSettings**](V3TimezoneSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv5ClusterIdentity

> V5ClusterIdentity GetClusterv5ClusterIdentity(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv5ClusterIdentity(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv5ClusterIdentity``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv5ClusterIdentity`: V5ClusterIdentity
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv5ClusterIdentity`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv5ClusterIdentityRequest struct via the builder pattern


### Return type

[**V5ClusterIdentity**](V5ClusterIdentity.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv5ClusterNode

> V5ClusterNodes GetClusterv5ClusterNode(ctx, v5ClusterNodeId).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5ClusterNodeId := int32(56) // int32 | Retrieve node information.
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv5ClusterNode(context.Background(), v5ClusterNodeId).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv5ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv5ClusterNode`: V5ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv5ClusterNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v5ClusterNodeId** | **int32** | Retrieve node information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv5ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V5ClusterNodes**](V5ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv5ClusterNodes

> V5ClusterNodes GetClusterv5ClusterNodes(ctx).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv5ClusterNodes(context.Background()).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv5ClusterNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv5ClusterNodes`: V5ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv5ClusterNodes`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv5ClusterNodesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeout** | **float32** | Request timeout | 

### Return type

[**V5ClusterNodes**](V5ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv5NodesLnnDrive

> V5NodeDrives GetClusterv5NodesLnnDrive(ctx, v5NodesLnnDriveId, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5NodesLnnDriveId := "v5NodesLnnDriveId_example" // string | Retrieve drive information.
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv5NodesLnnDrive(context.Background(), v5NodesLnnDriveId, lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv5NodesLnnDrive``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv5NodesLnnDrive`: V5NodeDrives
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv5NodesLnnDrive`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v5NodesLnnDriveId** | **string** | Retrieve drive information. | 
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv5NodesLnnDriveRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **timeout** | **float32** | Request timeout | 

### Return type

[**V5NodeDrives**](V5NodeDrives.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv5NodesLnnSled

> V5NodeSleds GetClusterv5NodesLnnSled(ctx, v5NodesLnnSledId, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5NodesLnnSledId := "v5NodesLnnSledId_example" // string | Get detailed information for the sled specified by <SLEDID>, or all sleds in the case where <SLEDID> is 'all', in the node specified by <LNN>.  Accepts <sledid> in either 'sled' or 'all' formats.
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv5NodesLnnSled(context.Background(), v5NodesLnnSledId, lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv5NodesLnnSled``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv5NodesLnnSled`: V5NodeSleds
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv5NodesLnnSled`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v5NodesLnnSledId** | **string** | Get detailed information for the sled specified by &lt;SLEDID&gt;, or all sleds in the case where &lt;SLEDID&gt; is &#39;all&#39;, in the node specified by &lt;LNN&gt;.  Accepts &lt;sledid&gt; in either &#39;sled&#39; or &#39;all&#39; formats. | 
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv5NodesLnnSledRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **timeout** | **float32** | Request timeout | 

### Return type

[**V5NodeSleds**](V5NodeSleds.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv7ClusterInternalNetworks

> V7ClusterInternalNetworks GetClusterv7ClusterInternalNetworks(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv7ClusterInternalNetworks(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv7ClusterInternalNetworks``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv7ClusterInternalNetworks`: V7ClusterInternalNetworks
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv7ClusterInternalNetworks`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv7ClusterInternalNetworksRequest struct via the builder pattern


### Return type

[**V7ClusterInternalNetworks**](V7ClusterInternalNetworks.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv7ClusterNode

> V7ClusterNodes GetClusterv7ClusterNode(ctx, v7ClusterNodeId).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterNodeId := int32(56) // int32 | Retrieve node information.
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv7ClusterNode(context.Background(), v7ClusterNodeId).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv7ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv7ClusterNode`: V7ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv7ClusterNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ClusterNodeId** | **int32** | Retrieve node information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv7ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V7ClusterNodes**](V7ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv7ClusterNodes

> V7ClusterNodes GetClusterv7ClusterNodes(ctx).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv7ClusterNodes(context.Background()).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv7ClusterNodes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv7ClusterNodes`: V7ClusterNodes
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv7ClusterNodes`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv7ClusterNodesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **timeout** | **float32** | Request timeout | 

### Return type

[**V7ClusterNodes**](V7ClusterNodes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterv7NodesLnnDrive

> V7NodeDrives GetClusterv7NodesLnnDrive(ctx, v7NodesLnnDriveId, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7NodesLnnDriveId := "v7NodesLnnDriveId_example" // string | Retrieve drive information.
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.GetClusterv7NodesLnnDrive(context.Background(), v7NodesLnnDriveId, lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.GetClusterv7NodesLnnDrive``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterv7NodesLnnDrive`: V7NodeDrives
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.GetClusterv7NodesLnnDrive`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7NodesLnnDriveId** | **string** | Retrieve drive information. | 
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterv7NodesLnnDriveRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **timeout** | **float32** | Request timeout | 

### Return type

[**V7NodeDrives**](V7NodeDrives.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListClusterv14ClusterAcs

> V14ClusterAcs ListClusterv14ClusterAcs(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterApi.ListClusterv14ClusterAcs(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.ListClusterv14ClusterAcs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListClusterv14ClusterAcs`: V14ClusterAcs
    fmt.Fprintf(os.Stdout, "Response from `ClusterApi.ListClusterv14ClusterAcs`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListClusterv14ClusterAcsRequest struct via the builder pattern


### Return type

[**V14ClusterAcs**](V14ClusterAcs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv14InternalNetworksPreferredNetwork

> UpdateClusterv14InternalNetworksPreferredNetwork(ctx).V14InternalNetworksPreferredNetwork(v14InternalNetworksPreferredNetwork).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14InternalNetworksPreferredNetwork := *openapiclient.NewV14InternalNetworksPreferredNetwork(int32(123), int32(123), "PreferredNetwork_example") // V14InternalNetworksPreferredNetwork | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv14InternalNetworksPreferredNetwork(context.Background()).V14InternalNetworksPreferredNetwork(v14InternalNetworksPreferredNetwork).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv14InternalNetworksPreferredNetwork``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv14InternalNetworksPreferredNetworkRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14InternalNetworksPreferredNetwork** | [**V14InternalNetworksPreferredNetwork**](V14InternalNetworksPreferredNetwork.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv14InternalNetworksSettings

> UpdateClusterv14InternalNetworksSettings(ctx).V14InternalNetworksSettings(v14InternalNetworksSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14InternalNetworksSettings := *openapiclient.NewV14InternalNetworksSettingsExtended(*openapiclient.NewV14InternalNetworksSettingsNetwork(*openapiclient.NewV14InternalNetworksSettingsNetworkBackendConfig("FabricMonitoring_example"), "Name_example")) // V14InternalNetworksSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv14InternalNetworksSettings(context.Background()).V14InternalNetworksSettings(v14InternalNetworksSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv14InternalNetworksSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv14InternalNetworksSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14InternalNetworksSettings** | [**V14InternalNetworksSettingsExtended**](V14InternalNetworksSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv16DiagnosticsGatherSettings

> UpdateClusterv16DiagnosticsGatherSettings(ctx).V16DiagnosticsGatherSettings(v16DiagnosticsGatherSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16DiagnosticsGatherSettings := *openapiclient.NewV16DiagnosticsGatherSettingsExtended() // V16DiagnosticsGatherSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv16DiagnosticsGatherSettings(context.Background()).V16DiagnosticsGatherSettings(v16DiagnosticsGatherSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv16DiagnosticsGatherSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv16DiagnosticsGatherSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16DiagnosticsGatherSettings** | [**V16DiagnosticsGatherSettingsExtended**](V16DiagnosticsGatherSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv16IceageSettings

> UpdateClusterv16IceageSettings(ctx).V16IceageSettings(v16IceageSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16IceageSettings := *openapiclient.NewV16IceageSettingsSettings() // V16IceageSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv16IceageSettings(context.Background()).V16IceageSettings(v16IceageSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv16IceageSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv16IceageSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16IceageSettings** | [**V16IceageSettingsSettings**](V16IceageSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv1ClusterEmail

> UpdateClusterv1ClusterEmail(ctx).V1ClusterEmail(v1ClusterEmail).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ClusterEmail := *openapiclient.NewV1ClusterEmailExtended() // V1ClusterEmailExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv1ClusterEmail(context.Background()).V1ClusterEmail(v1ClusterEmail).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv1ClusterEmail``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv1ClusterEmailRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1ClusterEmail** | [**V1ClusterEmailExtended**](V1ClusterEmailExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv1ClusterOwner

> UpdateClusterv1ClusterOwner(ctx).V1ClusterOwner(v1ClusterOwner).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ClusterOwner := *openapiclient.NewV1ClusterOwner() // V1ClusterOwner | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv1ClusterOwner(context.Background()).V1ClusterOwner(v1ClusterOwner).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv1ClusterOwner``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv1ClusterOwnerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1ClusterOwner** | [**V1ClusterOwner**](V1ClusterOwner.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv3ClusterIdentity

> UpdateClusterv3ClusterIdentity(ctx).V3ClusterIdentity(v3ClusterIdentity).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterIdentity := *openapiclient.NewV3ClusterIdentity() // V3ClusterIdentity | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv3ClusterIdentity(context.Background()).V3ClusterIdentity(v3ClusterIdentity).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv3ClusterIdentity``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv3ClusterIdentityRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterIdentity** | [**V3ClusterIdentity**](V3ClusterIdentity.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv3ClusterNode

> UpdateClusterv3ClusterNode(ctx, v3ClusterNodeId).V3ClusterNode(v3ClusterNode).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterNodeId := int32(56) // int32 | Modify one or more node settings.
    v3ClusterNode := *openapiclient.NewV3ClusterNodeExtended() // V3ClusterNodeExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv3ClusterNode(context.Background(), v3ClusterNodeId).V3ClusterNode(v3ClusterNode).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv3ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ClusterNodeId** | **int32** | Modify one or more node settings. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv3ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3ClusterNode** | [**V3ClusterNodeExtended**](V3ClusterNodeExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv3ClusterTime

> UpdateClusterv3ClusterTime(ctx).V3ClusterTime(v3ClusterTime).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterTime := *openapiclient.NewV3ClusterTimeExtended(int32(123)) // V3ClusterTimeExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv3ClusterTime(context.Background()).V3ClusterTime(v3ClusterTime).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv3ClusterTime``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv3ClusterTimeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterTime** | [**V3ClusterTimeExtended**](V3ClusterTimeExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv3ClusterTimezone

> UpdateClusterv3ClusterTimezone(ctx).V3ClusterTimezone(v3ClusterTimezone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ClusterTimezone := *openapiclient.NewV3ClusterTimezoneExtended() // V3ClusterTimezoneExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv3ClusterTimezone(context.Background()).V3ClusterTimezone(v3ClusterTimezone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv3ClusterTimezone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv3ClusterTimezoneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ClusterTimezone** | [**V3ClusterTimezoneExtended**](V3ClusterTimezoneExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv3DiagnosticsGatherSettings

> UpdateClusterv3DiagnosticsGatherSettings(ctx).V3DiagnosticsGatherSettings(v3DiagnosticsGatherSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3DiagnosticsGatherSettings := *openapiclient.NewV3DiagnosticsGatherSettingsExtended() // V3DiagnosticsGatherSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv3DiagnosticsGatherSettings(context.Background()).V3DiagnosticsGatherSettings(v3DiagnosticsGatherSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv3DiagnosticsGatherSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv3DiagnosticsGatherSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3DiagnosticsGatherSettings** | [**V3DiagnosticsGatherSettingsExtended**](V3DiagnosticsGatherSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv3DiagnosticsNetloggerSettings

> UpdateClusterv3DiagnosticsNetloggerSettings(ctx).V3DiagnosticsNetloggerSettings(v3DiagnosticsNetloggerSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3DiagnosticsNetloggerSettings := *openapiclient.NewV3DiagnosticsNetloggerSettingsSettings() // V3DiagnosticsNetloggerSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv3DiagnosticsNetloggerSettings(context.Background()).V3DiagnosticsNetloggerSettings(v3DiagnosticsNetloggerSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv3DiagnosticsNetloggerSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv3DiagnosticsNetloggerSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3DiagnosticsNetloggerSettings** | [**V3DiagnosticsNetloggerSettingsSettings**](V3DiagnosticsNetloggerSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv3TimezoneSettings

> UpdateClusterv3TimezoneSettings(ctx).V3TimezoneSettings(v3TimezoneSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3TimezoneSettings := *openapiclient.NewV3TimezoneRegionTimezone("Path_example") // V3TimezoneRegionTimezone | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv3TimezoneSettings(context.Background()).V3TimezoneSettings(v3TimezoneSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv3TimezoneSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv3TimezoneSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3TimezoneSettings** | [**V3TimezoneRegionTimezone**](V3TimezoneRegionTimezone.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv5ClusterIdentity

> UpdateClusterv5ClusterIdentity(ctx).V5ClusterIdentity(v5ClusterIdentity).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5ClusterIdentity := *openapiclient.NewV5ClusterIdentityExtended() // V5ClusterIdentityExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv5ClusterIdentity(context.Background()).V5ClusterIdentity(v5ClusterIdentity).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv5ClusterIdentity``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv5ClusterIdentityRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v5ClusterIdentity** | [**V5ClusterIdentityExtended**](V5ClusterIdentityExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv5ClusterNode

> UpdateClusterv5ClusterNode(ctx, v5ClusterNodeId).V5ClusterNode(v5ClusterNode).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5ClusterNodeId := int32(56) // int32 | Modify one or more node settings.
    v5ClusterNode := *openapiclient.NewV3ClusterNodeExtended() // V3ClusterNodeExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv5ClusterNode(context.Background(), v5ClusterNodeId).V5ClusterNode(v5ClusterNode).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv5ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v5ClusterNodeId** | **int32** | Modify one or more node settings. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv5ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v5ClusterNode** | [**V3ClusterNodeExtended**](V3ClusterNodeExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv7ClusterInternalNetworks

> UpdateClusterv7ClusterInternalNetworks(ctx).V7ClusterInternalNetworks(v7ClusterInternalNetworks).RebootConfirmationToken(rebootConfirmationToken).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterInternalNetworks := *openapiclient.NewV7ClusterInternalNetworksExtended() // V7ClusterInternalNetworksExtended | 
    rebootConfirmationToken := "rebootConfirmationToken_example" // string | Token returned by earlier PUT call with the same configuration. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv7ClusterInternalNetworks(context.Background()).V7ClusterInternalNetworks(v7ClusterInternalNetworks).RebootConfirmationToken(rebootConfirmationToken).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv7ClusterInternalNetworks``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv7ClusterInternalNetworksRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ClusterInternalNetworks** | [**V7ClusterInternalNetworksExtended**](V7ClusterInternalNetworksExtended.md) |  | 
 **rebootConfirmationToken** | **string** | Token returned by earlier PUT call with the same configuration. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv7ClusterNode

> UpdateClusterv7ClusterNode(ctx, v7ClusterNodeId).V7ClusterNode(v7ClusterNode).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterNodeId := int32(56) // int32 | Modify one or more node settings.
    v7ClusterNode := *openapiclient.NewV3ClusterNodeExtended() // V3ClusterNodeExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv7ClusterNode(context.Background(), v7ClusterNodeId).V7ClusterNode(v7ClusterNode).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv7ClusterNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ClusterNodeId** | **int32** | Modify one or more node settings. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv7ClusterNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7ClusterNode** | [**V3ClusterNodeExtended**](V3ClusterNodeExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterv7ClusterUpdateLnns

> UpdateClusterv7ClusterUpdateLnns(ctx).V7ClusterUpdateLnns(v7ClusterUpdateLnns).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ClusterUpdateLnns := *openapiclient.NewV7ClusterUpdateLnns() // V7ClusterUpdateLnns | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterApi.UpdateClusterv7ClusterUpdateLnns(context.Background()).V7ClusterUpdateLnns(v7ClusterUpdateLnns).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterApi.UpdateClusterv7ClusterUpdateLnns``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterv7ClusterUpdateLnnsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ClusterUpdateLnns** | [**V7ClusterUpdateLnns**](V7ClusterUpdateLnns.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

