# V10JobJobExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ControlState** | Pointer to **string** | State to which the job is transitioning; if control_state is identical to state, the job&#39;s state is stable. | [optional] 
**CreateTime** | **int32** | The time the job was queued, in seconds since the epoch. | 
**CurrentPhase** | Pointer to **int32** | The current phase of the job. | [optional] 
**Description** | Pointer to **string** | A text representation of the job. | [optional] 
**EndTime** | Pointer to **int32** | The time the job ended, in seconds since the Epoch. | [optional] 
**HumanDesc** | **string** | A helpful human-readable description of the job | 
**Id** | **int32** | The ID of the job. | 
**Impact** | **string** | The current impact of the job. | 
**Participants** | Pointer to **[]int32** | The set of devids working on the job. | [optional] 
**Paths** | Pointer to **[]string** | Paths for which the job was queued. | [optional] 
**Policy** | **string** | Current impact policy of the job. | 
**Priority** | **int32** | Current priority of the job; lower numbers preempt higher numbers. | 
**Progress** | Pointer to **string** | A text representation of the job&#39;s progress. | [optional] 
**RetriesRemaining** | **int32** | The number of retries remaining if the job fails. | 
**RunningTime** | Pointer to **int32** | The number of seconds the job has executed. | [optional] 
**StartTime** | Pointer to **int32** | The time the job started, in seconds since the Epoch. | [optional] 
**State** | **string** | Current state of the job. | 
**TotalPhases** | **int32** | The total number of phases of the job type. | 
**Type** | **string** | The job type. | 
**WaitingOn** | Pointer to **int32** | The ID of a job for which this job is waiting. | [optional] 
**WaitingReason** | Pointer to **string** | The reason the job is waiting. | [optional] 

## Methods

### NewV10JobJobExtended

`func NewV10JobJobExtended(createTime int32, humanDesc string, id int32, impact string, policy string, priority int32, retriesRemaining int32, state string, totalPhases int32, type_ string, ) *V10JobJobExtended`

NewV10JobJobExtended instantiates a new V10JobJobExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10JobJobExtendedWithDefaults

`func NewV10JobJobExtendedWithDefaults() *V10JobJobExtended`

NewV10JobJobExtendedWithDefaults instantiates a new V10JobJobExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetControlState

`func (o *V10JobJobExtended) GetControlState() string`

GetControlState returns the ControlState field if non-nil, zero value otherwise.

### GetControlStateOk

`func (o *V10JobJobExtended) GetControlStateOk() (*string, bool)`

GetControlStateOk returns a tuple with the ControlState field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetControlState

`func (o *V10JobJobExtended) SetControlState(v string)`

SetControlState sets ControlState field to given value.

### HasControlState

`func (o *V10JobJobExtended) HasControlState() bool`

HasControlState returns a boolean if a field has been set.

### GetCreateTime

`func (o *V10JobJobExtended) GetCreateTime() int32`

GetCreateTime returns the CreateTime field if non-nil, zero value otherwise.

### GetCreateTimeOk

`func (o *V10JobJobExtended) GetCreateTimeOk() (*int32, bool)`

GetCreateTimeOk returns a tuple with the CreateTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateTime

`func (o *V10JobJobExtended) SetCreateTime(v int32)`

SetCreateTime sets CreateTime field to given value.


### GetCurrentPhase

`func (o *V10JobJobExtended) GetCurrentPhase() int32`

GetCurrentPhase returns the CurrentPhase field if non-nil, zero value otherwise.

### GetCurrentPhaseOk

`func (o *V10JobJobExtended) GetCurrentPhaseOk() (*int32, bool)`

GetCurrentPhaseOk returns a tuple with the CurrentPhase field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCurrentPhase

`func (o *V10JobJobExtended) SetCurrentPhase(v int32)`

SetCurrentPhase sets CurrentPhase field to given value.

### HasCurrentPhase

`func (o *V10JobJobExtended) HasCurrentPhase() bool`

HasCurrentPhase returns a boolean if a field has been set.

### GetDescription

`func (o *V10JobJobExtended) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V10JobJobExtended) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V10JobJobExtended) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V10JobJobExtended) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetEndTime

`func (o *V10JobJobExtended) GetEndTime() int32`

GetEndTime returns the EndTime field if non-nil, zero value otherwise.

### GetEndTimeOk

`func (o *V10JobJobExtended) GetEndTimeOk() (*int32, bool)`

GetEndTimeOk returns a tuple with the EndTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEndTime

`func (o *V10JobJobExtended) SetEndTime(v int32)`

SetEndTime sets EndTime field to given value.

### HasEndTime

`func (o *V10JobJobExtended) HasEndTime() bool`

HasEndTime returns a boolean if a field has been set.

### GetHumanDesc

`func (o *V10JobJobExtended) GetHumanDesc() string`

GetHumanDesc returns the HumanDesc field if non-nil, zero value otherwise.

### GetHumanDescOk

`func (o *V10JobJobExtended) GetHumanDescOk() (*string, bool)`

GetHumanDescOk returns a tuple with the HumanDesc field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHumanDesc

`func (o *V10JobJobExtended) SetHumanDesc(v string)`

SetHumanDesc sets HumanDesc field to given value.


### GetId

`func (o *V10JobJobExtended) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10JobJobExtended) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10JobJobExtended) SetId(v int32)`

SetId sets Id field to given value.


### GetImpact

`func (o *V10JobJobExtended) GetImpact() string`

GetImpact returns the Impact field if non-nil, zero value otherwise.

### GetImpactOk

`func (o *V10JobJobExtended) GetImpactOk() (*string, bool)`

GetImpactOk returns a tuple with the Impact field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImpact

`func (o *V10JobJobExtended) SetImpact(v string)`

SetImpact sets Impact field to given value.


### GetParticipants

`func (o *V10JobJobExtended) GetParticipants() []int32`

GetParticipants returns the Participants field if non-nil, zero value otherwise.

### GetParticipantsOk

`func (o *V10JobJobExtended) GetParticipantsOk() (*[]int32, bool)`

GetParticipantsOk returns a tuple with the Participants field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParticipants

`func (o *V10JobJobExtended) SetParticipants(v []int32)`

SetParticipants sets Participants field to given value.

### HasParticipants

`func (o *V10JobJobExtended) HasParticipants() bool`

HasParticipants returns a boolean if a field has been set.

### GetPaths

`func (o *V10JobJobExtended) GetPaths() []string`

GetPaths returns the Paths field if non-nil, zero value otherwise.

### GetPathsOk

`func (o *V10JobJobExtended) GetPathsOk() (*[]string, bool)`

GetPathsOk returns a tuple with the Paths field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPaths

`func (o *V10JobJobExtended) SetPaths(v []string)`

SetPaths sets Paths field to given value.

### HasPaths

`func (o *V10JobJobExtended) HasPaths() bool`

HasPaths returns a boolean if a field has been set.

### GetPolicy

`func (o *V10JobJobExtended) GetPolicy() string`

GetPolicy returns the Policy field if non-nil, zero value otherwise.

### GetPolicyOk

`func (o *V10JobJobExtended) GetPolicyOk() (*string, bool)`

GetPolicyOk returns a tuple with the Policy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicy

`func (o *V10JobJobExtended) SetPolicy(v string)`

SetPolicy sets Policy field to given value.


### GetPriority

`func (o *V10JobJobExtended) GetPriority() int32`

GetPriority returns the Priority field if non-nil, zero value otherwise.

### GetPriorityOk

`func (o *V10JobJobExtended) GetPriorityOk() (*int32, bool)`

GetPriorityOk returns a tuple with the Priority field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPriority

`func (o *V10JobJobExtended) SetPriority(v int32)`

SetPriority sets Priority field to given value.


### GetProgress

`func (o *V10JobJobExtended) GetProgress() string`

GetProgress returns the Progress field if non-nil, zero value otherwise.

### GetProgressOk

`func (o *V10JobJobExtended) GetProgressOk() (*string, bool)`

GetProgressOk returns a tuple with the Progress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProgress

`func (o *V10JobJobExtended) SetProgress(v string)`

SetProgress sets Progress field to given value.

### HasProgress

`func (o *V10JobJobExtended) HasProgress() bool`

HasProgress returns a boolean if a field has been set.

### GetRetriesRemaining

`func (o *V10JobJobExtended) GetRetriesRemaining() int32`

GetRetriesRemaining returns the RetriesRemaining field if non-nil, zero value otherwise.

### GetRetriesRemainingOk

`func (o *V10JobJobExtended) GetRetriesRemainingOk() (*int32, bool)`

GetRetriesRemainingOk returns a tuple with the RetriesRemaining field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRetriesRemaining

`func (o *V10JobJobExtended) SetRetriesRemaining(v int32)`

SetRetriesRemaining sets RetriesRemaining field to given value.


### GetRunningTime

`func (o *V10JobJobExtended) GetRunningTime() int32`

GetRunningTime returns the RunningTime field if non-nil, zero value otherwise.

### GetRunningTimeOk

`func (o *V10JobJobExtended) GetRunningTimeOk() (*int32, bool)`

GetRunningTimeOk returns a tuple with the RunningTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRunningTime

`func (o *V10JobJobExtended) SetRunningTime(v int32)`

SetRunningTime sets RunningTime field to given value.

### HasRunningTime

`func (o *V10JobJobExtended) HasRunningTime() bool`

HasRunningTime returns a boolean if a field has been set.

### GetStartTime

`func (o *V10JobJobExtended) GetStartTime() int32`

GetStartTime returns the StartTime field if non-nil, zero value otherwise.

### GetStartTimeOk

`func (o *V10JobJobExtended) GetStartTimeOk() (*int32, bool)`

GetStartTimeOk returns a tuple with the StartTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStartTime

`func (o *V10JobJobExtended) SetStartTime(v int32)`

SetStartTime sets StartTime field to given value.

### HasStartTime

`func (o *V10JobJobExtended) HasStartTime() bool`

HasStartTime returns a boolean if a field has been set.

### GetState

`func (o *V10JobJobExtended) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *V10JobJobExtended) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *V10JobJobExtended) SetState(v string)`

SetState sets State field to given value.


### GetTotalPhases

`func (o *V10JobJobExtended) GetTotalPhases() int32`

GetTotalPhases returns the TotalPhases field if non-nil, zero value otherwise.

### GetTotalPhasesOk

`func (o *V10JobJobExtended) GetTotalPhasesOk() (*int32, bool)`

GetTotalPhasesOk returns a tuple with the TotalPhases field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotalPhases

`func (o *V10JobJobExtended) SetTotalPhases(v int32)`

SetTotalPhases sets TotalPhases field to given value.


### GetType

`func (o *V10JobJobExtended) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V10JobJobExtended) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V10JobJobExtended) SetType(v string)`

SetType sets Type field to given value.


### GetWaitingOn

`func (o *V10JobJobExtended) GetWaitingOn() int32`

GetWaitingOn returns the WaitingOn field if non-nil, zero value otherwise.

### GetWaitingOnOk

`func (o *V10JobJobExtended) GetWaitingOnOk() (*int32, bool)`

GetWaitingOnOk returns a tuple with the WaitingOn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWaitingOn

`func (o *V10JobJobExtended) SetWaitingOn(v int32)`

SetWaitingOn sets WaitingOn field to given value.

### HasWaitingOn

`func (o *V10JobJobExtended) HasWaitingOn() bool`

HasWaitingOn returns a boolean if a field has been set.

### GetWaitingReason

`func (o *V10JobJobExtended) GetWaitingReason() string`

GetWaitingReason returns the WaitingReason field if non-nil, zero value otherwise.

### GetWaitingReasonOk

`func (o *V10JobJobExtended) GetWaitingReasonOk() (*string, bool)`

GetWaitingReasonOk returns a tuple with the WaitingReason field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWaitingReason

`func (o *V10JobJobExtended) SetWaitingReason(v string)`

SetWaitingReason sets WaitingReason field to given value.

### HasWaitingReason

`func (o *V10JobJobExtended) HasWaitingReason() bool`

HasWaitingReason returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


