# V14ProvidersAdsItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllocateGids** | Pointer to **bool** | Allocates an ID for an unmapped Active Directory (ADS) group. ADS groups without GIDs can be proactively assigned a GID by the ID mapper. If the ID mapper option is disabled, GIDs are not proactively assigned, and when a primary group for a user does not include a GID, the system may allocate one.  | [optional] 
**AllocateUids** | Pointer to **bool** | Allocates a user ID for an unmapped Active Directory (ADS) user. ADS users without UIDs can be proactively assigned a UID by the ID mapper. IF the ID mapper option is disabled, UIDs are not proactively assigned, and when an identify for a user does not include a UID, the system may allocate one. | [optional] 
**AssumeDefaultDomain** | Pointer to **bool** | Enables lookup of unqualified user names in the primary domain. | [optional] 
**Authentication** | Pointer to **bool** | Enables authentication and identity management through the authentication provider. | [optional] 
**CheckOnlineInterval** | Pointer to **int32** | Specifies the time in seconds between provider online checks. | [optional] 
**ControllerTime** | Pointer to **int32** | Specifies the current time for the domain controllers. | [optional] 
**CreateHomeDirectory** | Pointer to **bool** | Automatically creates a home directory on the first login. | [optional] 
**DnsDomain** | Pointer to **string** | Specifies the DNS search domain. Set this parameter if the DNS search domain has a unique name or address. | [optional] 
**DomainOfflineAlerts** | Pointer to **bool** | Sends an alert if the domain goes offline. | [optional] 
**ExtraExpectedSpns** | Pointer to **[]string** | List of additional SPNs to expect beyond what automatic checking routines might find | [optional] 
**FindableGroups** | Pointer to **[]string** | Sets list of groups that can be resolved. | [optional] 
**FindableUsers** | Pointer to **[]string** | Sets list of users that can be resolved. | [optional] 
**Groupnet** | Pointer to **string** | Groupnet identifier. | [optional] 
**HomeDirectoryTemplate** | Pointer to **string** | Specifies the path to the home directory template. | [optional] 
**IgnoreAllTrusts** | Pointer to **bool** | If set to true, ignores all trusted domains. | [optional] 
**IgnoredTrustedDomains** | Pointer to **[]string** | Includes trusted domains when &#39;ignore_all_trusts&#39; is set to false. | [optional] 
**IncludeTrustedDomains** | Pointer to **[]string** | Includes trusted domains when &#39;ignore_all_trusts&#39; is set to true. | [optional] 
**Instance** | Pointer to **string** | Specifies Active Directory provider instance. | [optional] 
**KerberosHdfsSpn** | Pointer to **bool** | Determines if connecting through HDFS with Kerberos. | [optional] 
**KerberosNfsSpn** | Pointer to **bool** | Determines if connecting through NFS with Kerberos. | [optional] 
**LdapSignAndSeal** | Pointer to **bool** | Enables encryption and signing on LDAP requests. | [optional] 
**LoginShell** | Pointer to **string** | Specifies the login shell path. | [optional] 
**LookupDomains** | Pointer to **[]string** | Limits user and group lookups to the specified domains. | [optional] 
**LookupGroups** | Pointer to **bool** | Looks up AD groups in other providers before allocating a group ID. | [optional] 
**LookupNormalizeGroups** | Pointer to **bool** | Normalizes AD group names to lowercase before look up. | [optional] 
**LookupNormalizeUsers** | Pointer to **bool** | Normalize AD user names to lowercase before look up. | [optional] 
**LookupUsers** | Pointer to **bool** | Looks up AD users in other providers before allocating a user ID. | [optional] 
**MachineAccount** | Pointer to **string** | Specifies the machine account name when creating a SAM account with Active Directory. | [optional] 
**MachinePasswordChanges** | Pointer to **bool** | Enables periodic changes of the machine password for security. | [optional] 
**MachinePasswordLifespan** | Pointer to **int32** | Sets maximum age of a password in seconds. | [optional] 
**Name** | **string** | Specifies the Active Directory provider name. | 
**NodeDcAffinity** | Pointer to **string** | Specifies the domain controller for which the node has affinity. | [optional] 
**NodeDcAffinityTimeout** | Pointer to **int32** | Specifies the timeout for the domain controller for which the local node has affinity. | [optional] 
**NssEnumeration** | Pointer to **bool** | Enables the Active Directory provider to respond to &#39;getpwent&#39; and &#39;getgrent&#39; requests. | [optional] 
**OrganizationalUnit** | Pointer to **string** | Specifies the organizational unit. | [optional] 
**Password** | **string** | Specifies the password used during domain join. | 
**RestrictFindable** | Pointer to **bool** | Check the provider for filtered lists of findable and unfindable users and groups. | [optional] 
**RpcCallTimeout** | Pointer to **int32** | The maximum amount of time (in seconds) an RPC call to Active Directory is allowed to take. | [optional] 
**ServerRetryLimit** | Pointer to **int32** | The number of retries attempted when a call to Active Directory fails due to network error. | [optional] 
**SfuSupport** | Pointer to **string** | Specifies whether to support RFC 2307 attributes on ADS domain controllers. | [optional] 
**StoreSfuMappings** | Pointer to **bool** | Stores SFU mappings permanently in the ID mapper. | [optional] 
**UnfindableGroups** | Pointer to **[]string** | Specifies groups that cannot be resolved by the provider. | [optional] 
**UnfindableUsers** | Pointer to **[]string** | Specifies users that cannot be resolved by the provider. | [optional] 
**User** | **string** | Specifies the user name that has permission to join a machine to the given domain. | 

## Methods

### NewV14ProvidersAdsItem

`func NewV14ProvidersAdsItem(name string, password string, user string, ) *V14ProvidersAdsItem`

NewV14ProvidersAdsItem instantiates a new V14ProvidersAdsItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ProvidersAdsItemWithDefaults

`func NewV14ProvidersAdsItemWithDefaults() *V14ProvidersAdsItem`

NewV14ProvidersAdsItemWithDefaults instantiates a new V14ProvidersAdsItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllocateGids

`func (o *V14ProvidersAdsItem) GetAllocateGids() bool`

GetAllocateGids returns the AllocateGids field if non-nil, zero value otherwise.

### GetAllocateGidsOk

`func (o *V14ProvidersAdsItem) GetAllocateGidsOk() (*bool, bool)`

GetAllocateGidsOk returns a tuple with the AllocateGids field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllocateGids

`func (o *V14ProvidersAdsItem) SetAllocateGids(v bool)`

SetAllocateGids sets AllocateGids field to given value.

### HasAllocateGids

`func (o *V14ProvidersAdsItem) HasAllocateGids() bool`

HasAllocateGids returns a boolean if a field has been set.

### GetAllocateUids

`func (o *V14ProvidersAdsItem) GetAllocateUids() bool`

GetAllocateUids returns the AllocateUids field if non-nil, zero value otherwise.

### GetAllocateUidsOk

`func (o *V14ProvidersAdsItem) GetAllocateUidsOk() (*bool, bool)`

GetAllocateUidsOk returns a tuple with the AllocateUids field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllocateUids

`func (o *V14ProvidersAdsItem) SetAllocateUids(v bool)`

SetAllocateUids sets AllocateUids field to given value.

### HasAllocateUids

`func (o *V14ProvidersAdsItem) HasAllocateUids() bool`

HasAllocateUids returns a boolean if a field has been set.

### GetAssumeDefaultDomain

`func (o *V14ProvidersAdsItem) GetAssumeDefaultDomain() bool`

GetAssumeDefaultDomain returns the AssumeDefaultDomain field if non-nil, zero value otherwise.

### GetAssumeDefaultDomainOk

`func (o *V14ProvidersAdsItem) GetAssumeDefaultDomainOk() (*bool, bool)`

GetAssumeDefaultDomainOk returns a tuple with the AssumeDefaultDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAssumeDefaultDomain

`func (o *V14ProvidersAdsItem) SetAssumeDefaultDomain(v bool)`

SetAssumeDefaultDomain sets AssumeDefaultDomain field to given value.

### HasAssumeDefaultDomain

`func (o *V14ProvidersAdsItem) HasAssumeDefaultDomain() bool`

HasAssumeDefaultDomain returns a boolean if a field has been set.

### GetAuthentication

`func (o *V14ProvidersAdsItem) GetAuthentication() bool`

GetAuthentication returns the Authentication field if non-nil, zero value otherwise.

### GetAuthenticationOk

`func (o *V14ProvidersAdsItem) GetAuthenticationOk() (*bool, bool)`

GetAuthenticationOk returns a tuple with the Authentication field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuthentication

`func (o *V14ProvidersAdsItem) SetAuthentication(v bool)`

SetAuthentication sets Authentication field to given value.

### HasAuthentication

`func (o *V14ProvidersAdsItem) HasAuthentication() bool`

HasAuthentication returns a boolean if a field has been set.

### GetCheckOnlineInterval

`func (o *V14ProvidersAdsItem) GetCheckOnlineInterval() int32`

GetCheckOnlineInterval returns the CheckOnlineInterval field if non-nil, zero value otherwise.

### GetCheckOnlineIntervalOk

`func (o *V14ProvidersAdsItem) GetCheckOnlineIntervalOk() (*int32, bool)`

GetCheckOnlineIntervalOk returns a tuple with the CheckOnlineInterval field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCheckOnlineInterval

`func (o *V14ProvidersAdsItem) SetCheckOnlineInterval(v int32)`

SetCheckOnlineInterval sets CheckOnlineInterval field to given value.

### HasCheckOnlineInterval

`func (o *V14ProvidersAdsItem) HasCheckOnlineInterval() bool`

HasCheckOnlineInterval returns a boolean if a field has been set.

### GetControllerTime

`func (o *V14ProvidersAdsItem) GetControllerTime() int32`

GetControllerTime returns the ControllerTime field if non-nil, zero value otherwise.

### GetControllerTimeOk

`func (o *V14ProvidersAdsItem) GetControllerTimeOk() (*int32, bool)`

GetControllerTimeOk returns a tuple with the ControllerTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetControllerTime

`func (o *V14ProvidersAdsItem) SetControllerTime(v int32)`

SetControllerTime sets ControllerTime field to given value.

### HasControllerTime

`func (o *V14ProvidersAdsItem) HasControllerTime() bool`

HasControllerTime returns a boolean if a field has been set.

### GetCreateHomeDirectory

`func (o *V14ProvidersAdsItem) GetCreateHomeDirectory() bool`

GetCreateHomeDirectory returns the CreateHomeDirectory field if non-nil, zero value otherwise.

### GetCreateHomeDirectoryOk

`func (o *V14ProvidersAdsItem) GetCreateHomeDirectoryOk() (*bool, bool)`

GetCreateHomeDirectoryOk returns a tuple with the CreateHomeDirectory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateHomeDirectory

`func (o *V14ProvidersAdsItem) SetCreateHomeDirectory(v bool)`

SetCreateHomeDirectory sets CreateHomeDirectory field to given value.

### HasCreateHomeDirectory

`func (o *V14ProvidersAdsItem) HasCreateHomeDirectory() bool`

HasCreateHomeDirectory returns a boolean if a field has been set.

### GetDnsDomain

`func (o *V14ProvidersAdsItem) GetDnsDomain() string`

GetDnsDomain returns the DnsDomain field if non-nil, zero value otherwise.

### GetDnsDomainOk

`func (o *V14ProvidersAdsItem) GetDnsDomainOk() (*string, bool)`

GetDnsDomainOk returns a tuple with the DnsDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDnsDomain

`func (o *V14ProvidersAdsItem) SetDnsDomain(v string)`

SetDnsDomain sets DnsDomain field to given value.

### HasDnsDomain

`func (o *V14ProvidersAdsItem) HasDnsDomain() bool`

HasDnsDomain returns a boolean if a field has been set.

### GetDomainOfflineAlerts

`func (o *V14ProvidersAdsItem) GetDomainOfflineAlerts() bool`

GetDomainOfflineAlerts returns the DomainOfflineAlerts field if non-nil, zero value otherwise.

### GetDomainOfflineAlertsOk

`func (o *V14ProvidersAdsItem) GetDomainOfflineAlertsOk() (*bool, bool)`

GetDomainOfflineAlertsOk returns a tuple with the DomainOfflineAlerts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomainOfflineAlerts

`func (o *V14ProvidersAdsItem) SetDomainOfflineAlerts(v bool)`

SetDomainOfflineAlerts sets DomainOfflineAlerts field to given value.

### HasDomainOfflineAlerts

`func (o *V14ProvidersAdsItem) HasDomainOfflineAlerts() bool`

HasDomainOfflineAlerts returns a boolean if a field has been set.

### GetExtraExpectedSpns

`func (o *V14ProvidersAdsItem) GetExtraExpectedSpns() []string`

GetExtraExpectedSpns returns the ExtraExpectedSpns field if non-nil, zero value otherwise.

### GetExtraExpectedSpnsOk

`func (o *V14ProvidersAdsItem) GetExtraExpectedSpnsOk() (*[]string, bool)`

GetExtraExpectedSpnsOk returns a tuple with the ExtraExpectedSpns field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExtraExpectedSpns

`func (o *V14ProvidersAdsItem) SetExtraExpectedSpns(v []string)`

SetExtraExpectedSpns sets ExtraExpectedSpns field to given value.

### HasExtraExpectedSpns

`func (o *V14ProvidersAdsItem) HasExtraExpectedSpns() bool`

HasExtraExpectedSpns returns a boolean if a field has been set.

### GetFindableGroups

`func (o *V14ProvidersAdsItem) GetFindableGroups() []string`

GetFindableGroups returns the FindableGroups field if non-nil, zero value otherwise.

### GetFindableGroupsOk

`func (o *V14ProvidersAdsItem) GetFindableGroupsOk() (*[]string, bool)`

GetFindableGroupsOk returns a tuple with the FindableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFindableGroups

`func (o *V14ProvidersAdsItem) SetFindableGroups(v []string)`

SetFindableGroups sets FindableGroups field to given value.

### HasFindableGroups

`func (o *V14ProvidersAdsItem) HasFindableGroups() bool`

HasFindableGroups returns a boolean if a field has been set.

### GetFindableUsers

`func (o *V14ProvidersAdsItem) GetFindableUsers() []string`

GetFindableUsers returns the FindableUsers field if non-nil, zero value otherwise.

### GetFindableUsersOk

`func (o *V14ProvidersAdsItem) GetFindableUsersOk() (*[]string, bool)`

GetFindableUsersOk returns a tuple with the FindableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFindableUsers

`func (o *V14ProvidersAdsItem) SetFindableUsers(v []string)`

SetFindableUsers sets FindableUsers field to given value.

### HasFindableUsers

`func (o *V14ProvidersAdsItem) HasFindableUsers() bool`

HasFindableUsers returns a boolean if a field has been set.

### GetGroupnet

`func (o *V14ProvidersAdsItem) GetGroupnet() string`

GetGroupnet returns the Groupnet field if non-nil, zero value otherwise.

### GetGroupnetOk

`func (o *V14ProvidersAdsItem) GetGroupnetOk() (*string, bool)`

GetGroupnetOk returns a tuple with the Groupnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupnet

`func (o *V14ProvidersAdsItem) SetGroupnet(v string)`

SetGroupnet sets Groupnet field to given value.

### HasGroupnet

`func (o *V14ProvidersAdsItem) HasGroupnet() bool`

HasGroupnet returns a boolean if a field has been set.

### GetHomeDirectoryTemplate

`func (o *V14ProvidersAdsItem) GetHomeDirectoryTemplate() string`

GetHomeDirectoryTemplate returns the HomeDirectoryTemplate field if non-nil, zero value otherwise.

### GetHomeDirectoryTemplateOk

`func (o *V14ProvidersAdsItem) GetHomeDirectoryTemplateOk() (*string, bool)`

GetHomeDirectoryTemplateOk returns a tuple with the HomeDirectoryTemplate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHomeDirectoryTemplate

`func (o *V14ProvidersAdsItem) SetHomeDirectoryTemplate(v string)`

SetHomeDirectoryTemplate sets HomeDirectoryTemplate field to given value.

### HasHomeDirectoryTemplate

`func (o *V14ProvidersAdsItem) HasHomeDirectoryTemplate() bool`

HasHomeDirectoryTemplate returns a boolean if a field has been set.

### GetIgnoreAllTrusts

`func (o *V14ProvidersAdsItem) GetIgnoreAllTrusts() bool`

GetIgnoreAllTrusts returns the IgnoreAllTrusts field if non-nil, zero value otherwise.

### GetIgnoreAllTrustsOk

`func (o *V14ProvidersAdsItem) GetIgnoreAllTrustsOk() (*bool, bool)`

GetIgnoreAllTrustsOk returns a tuple with the IgnoreAllTrusts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoreAllTrusts

`func (o *V14ProvidersAdsItem) SetIgnoreAllTrusts(v bool)`

SetIgnoreAllTrusts sets IgnoreAllTrusts field to given value.

### HasIgnoreAllTrusts

`func (o *V14ProvidersAdsItem) HasIgnoreAllTrusts() bool`

HasIgnoreAllTrusts returns a boolean if a field has been set.

### GetIgnoredTrustedDomains

`func (o *V14ProvidersAdsItem) GetIgnoredTrustedDomains() []string`

GetIgnoredTrustedDomains returns the IgnoredTrustedDomains field if non-nil, zero value otherwise.

### GetIgnoredTrustedDomainsOk

`func (o *V14ProvidersAdsItem) GetIgnoredTrustedDomainsOk() (*[]string, bool)`

GetIgnoredTrustedDomainsOk returns a tuple with the IgnoredTrustedDomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoredTrustedDomains

`func (o *V14ProvidersAdsItem) SetIgnoredTrustedDomains(v []string)`

SetIgnoredTrustedDomains sets IgnoredTrustedDomains field to given value.

### HasIgnoredTrustedDomains

`func (o *V14ProvidersAdsItem) HasIgnoredTrustedDomains() bool`

HasIgnoredTrustedDomains returns a boolean if a field has been set.

### GetIncludeTrustedDomains

`func (o *V14ProvidersAdsItem) GetIncludeTrustedDomains() []string`

GetIncludeTrustedDomains returns the IncludeTrustedDomains field if non-nil, zero value otherwise.

### GetIncludeTrustedDomainsOk

`func (o *V14ProvidersAdsItem) GetIncludeTrustedDomainsOk() (*[]string, bool)`

GetIncludeTrustedDomainsOk returns a tuple with the IncludeTrustedDomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeTrustedDomains

`func (o *V14ProvidersAdsItem) SetIncludeTrustedDomains(v []string)`

SetIncludeTrustedDomains sets IncludeTrustedDomains field to given value.

### HasIncludeTrustedDomains

`func (o *V14ProvidersAdsItem) HasIncludeTrustedDomains() bool`

HasIncludeTrustedDomains returns a boolean if a field has been set.

### GetInstance

`func (o *V14ProvidersAdsItem) GetInstance() string`

GetInstance returns the Instance field if non-nil, zero value otherwise.

### GetInstanceOk

`func (o *V14ProvidersAdsItem) GetInstanceOk() (*string, bool)`

GetInstanceOk returns a tuple with the Instance field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstance

`func (o *V14ProvidersAdsItem) SetInstance(v string)`

SetInstance sets Instance field to given value.

### HasInstance

`func (o *V14ProvidersAdsItem) HasInstance() bool`

HasInstance returns a boolean if a field has been set.

### GetKerberosHdfsSpn

`func (o *V14ProvidersAdsItem) GetKerberosHdfsSpn() bool`

GetKerberosHdfsSpn returns the KerberosHdfsSpn field if non-nil, zero value otherwise.

### GetKerberosHdfsSpnOk

`func (o *V14ProvidersAdsItem) GetKerberosHdfsSpnOk() (*bool, bool)`

GetKerberosHdfsSpnOk returns a tuple with the KerberosHdfsSpn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKerberosHdfsSpn

`func (o *V14ProvidersAdsItem) SetKerberosHdfsSpn(v bool)`

SetKerberosHdfsSpn sets KerberosHdfsSpn field to given value.

### HasKerberosHdfsSpn

`func (o *V14ProvidersAdsItem) HasKerberosHdfsSpn() bool`

HasKerberosHdfsSpn returns a boolean if a field has been set.

### GetKerberosNfsSpn

`func (o *V14ProvidersAdsItem) GetKerberosNfsSpn() bool`

GetKerberosNfsSpn returns the KerberosNfsSpn field if non-nil, zero value otherwise.

### GetKerberosNfsSpnOk

`func (o *V14ProvidersAdsItem) GetKerberosNfsSpnOk() (*bool, bool)`

GetKerberosNfsSpnOk returns a tuple with the KerberosNfsSpn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKerberosNfsSpn

`func (o *V14ProvidersAdsItem) SetKerberosNfsSpn(v bool)`

SetKerberosNfsSpn sets KerberosNfsSpn field to given value.

### HasKerberosNfsSpn

`func (o *V14ProvidersAdsItem) HasKerberosNfsSpn() bool`

HasKerberosNfsSpn returns a boolean if a field has been set.

### GetLdapSignAndSeal

`func (o *V14ProvidersAdsItem) GetLdapSignAndSeal() bool`

GetLdapSignAndSeal returns the LdapSignAndSeal field if non-nil, zero value otherwise.

### GetLdapSignAndSealOk

`func (o *V14ProvidersAdsItem) GetLdapSignAndSealOk() (*bool, bool)`

GetLdapSignAndSealOk returns a tuple with the LdapSignAndSeal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLdapSignAndSeal

`func (o *V14ProvidersAdsItem) SetLdapSignAndSeal(v bool)`

SetLdapSignAndSeal sets LdapSignAndSeal field to given value.

### HasLdapSignAndSeal

`func (o *V14ProvidersAdsItem) HasLdapSignAndSeal() bool`

HasLdapSignAndSeal returns a boolean if a field has been set.

### GetLoginShell

`func (o *V14ProvidersAdsItem) GetLoginShell() string`

GetLoginShell returns the LoginShell field if non-nil, zero value otherwise.

### GetLoginShellOk

`func (o *V14ProvidersAdsItem) GetLoginShellOk() (*string, bool)`

GetLoginShellOk returns a tuple with the LoginShell field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLoginShell

`func (o *V14ProvidersAdsItem) SetLoginShell(v string)`

SetLoginShell sets LoginShell field to given value.

### HasLoginShell

`func (o *V14ProvidersAdsItem) HasLoginShell() bool`

HasLoginShell returns a boolean if a field has been set.

### GetLookupDomains

`func (o *V14ProvidersAdsItem) GetLookupDomains() []string`

GetLookupDomains returns the LookupDomains field if non-nil, zero value otherwise.

### GetLookupDomainsOk

`func (o *V14ProvidersAdsItem) GetLookupDomainsOk() (*[]string, bool)`

GetLookupDomainsOk returns a tuple with the LookupDomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupDomains

`func (o *V14ProvidersAdsItem) SetLookupDomains(v []string)`

SetLookupDomains sets LookupDomains field to given value.

### HasLookupDomains

`func (o *V14ProvidersAdsItem) HasLookupDomains() bool`

HasLookupDomains returns a boolean if a field has been set.

### GetLookupGroups

`func (o *V14ProvidersAdsItem) GetLookupGroups() bool`

GetLookupGroups returns the LookupGroups field if non-nil, zero value otherwise.

### GetLookupGroupsOk

`func (o *V14ProvidersAdsItem) GetLookupGroupsOk() (*bool, bool)`

GetLookupGroupsOk returns a tuple with the LookupGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupGroups

`func (o *V14ProvidersAdsItem) SetLookupGroups(v bool)`

SetLookupGroups sets LookupGroups field to given value.

### HasLookupGroups

`func (o *V14ProvidersAdsItem) HasLookupGroups() bool`

HasLookupGroups returns a boolean if a field has been set.

### GetLookupNormalizeGroups

`func (o *V14ProvidersAdsItem) GetLookupNormalizeGroups() bool`

GetLookupNormalizeGroups returns the LookupNormalizeGroups field if non-nil, zero value otherwise.

### GetLookupNormalizeGroupsOk

`func (o *V14ProvidersAdsItem) GetLookupNormalizeGroupsOk() (*bool, bool)`

GetLookupNormalizeGroupsOk returns a tuple with the LookupNormalizeGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupNormalizeGroups

`func (o *V14ProvidersAdsItem) SetLookupNormalizeGroups(v bool)`

SetLookupNormalizeGroups sets LookupNormalizeGroups field to given value.

### HasLookupNormalizeGroups

`func (o *V14ProvidersAdsItem) HasLookupNormalizeGroups() bool`

HasLookupNormalizeGroups returns a boolean if a field has been set.

### GetLookupNormalizeUsers

`func (o *V14ProvidersAdsItem) GetLookupNormalizeUsers() bool`

GetLookupNormalizeUsers returns the LookupNormalizeUsers field if non-nil, zero value otherwise.

### GetLookupNormalizeUsersOk

`func (o *V14ProvidersAdsItem) GetLookupNormalizeUsersOk() (*bool, bool)`

GetLookupNormalizeUsersOk returns a tuple with the LookupNormalizeUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupNormalizeUsers

`func (o *V14ProvidersAdsItem) SetLookupNormalizeUsers(v bool)`

SetLookupNormalizeUsers sets LookupNormalizeUsers field to given value.

### HasLookupNormalizeUsers

`func (o *V14ProvidersAdsItem) HasLookupNormalizeUsers() bool`

HasLookupNormalizeUsers returns a boolean if a field has been set.

### GetLookupUsers

`func (o *V14ProvidersAdsItem) GetLookupUsers() bool`

GetLookupUsers returns the LookupUsers field if non-nil, zero value otherwise.

### GetLookupUsersOk

`func (o *V14ProvidersAdsItem) GetLookupUsersOk() (*bool, bool)`

GetLookupUsersOk returns a tuple with the LookupUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupUsers

`func (o *V14ProvidersAdsItem) SetLookupUsers(v bool)`

SetLookupUsers sets LookupUsers field to given value.

### HasLookupUsers

`func (o *V14ProvidersAdsItem) HasLookupUsers() bool`

HasLookupUsers returns a boolean if a field has been set.

### GetMachineAccount

`func (o *V14ProvidersAdsItem) GetMachineAccount() string`

GetMachineAccount returns the MachineAccount field if non-nil, zero value otherwise.

### GetMachineAccountOk

`func (o *V14ProvidersAdsItem) GetMachineAccountOk() (*string, bool)`

GetMachineAccountOk returns a tuple with the MachineAccount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMachineAccount

`func (o *V14ProvidersAdsItem) SetMachineAccount(v string)`

SetMachineAccount sets MachineAccount field to given value.

### HasMachineAccount

`func (o *V14ProvidersAdsItem) HasMachineAccount() bool`

HasMachineAccount returns a boolean if a field has been set.

### GetMachinePasswordChanges

`func (o *V14ProvidersAdsItem) GetMachinePasswordChanges() bool`

GetMachinePasswordChanges returns the MachinePasswordChanges field if non-nil, zero value otherwise.

### GetMachinePasswordChangesOk

`func (o *V14ProvidersAdsItem) GetMachinePasswordChangesOk() (*bool, bool)`

GetMachinePasswordChangesOk returns a tuple with the MachinePasswordChanges field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMachinePasswordChanges

`func (o *V14ProvidersAdsItem) SetMachinePasswordChanges(v bool)`

SetMachinePasswordChanges sets MachinePasswordChanges field to given value.

### HasMachinePasswordChanges

`func (o *V14ProvidersAdsItem) HasMachinePasswordChanges() bool`

HasMachinePasswordChanges returns a boolean if a field has been set.

### GetMachinePasswordLifespan

`func (o *V14ProvidersAdsItem) GetMachinePasswordLifespan() int32`

GetMachinePasswordLifespan returns the MachinePasswordLifespan field if non-nil, zero value otherwise.

### GetMachinePasswordLifespanOk

`func (o *V14ProvidersAdsItem) GetMachinePasswordLifespanOk() (*int32, bool)`

GetMachinePasswordLifespanOk returns a tuple with the MachinePasswordLifespan field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMachinePasswordLifespan

`func (o *V14ProvidersAdsItem) SetMachinePasswordLifespan(v int32)`

SetMachinePasswordLifespan sets MachinePasswordLifespan field to given value.

### HasMachinePasswordLifespan

`func (o *V14ProvidersAdsItem) HasMachinePasswordLifespan() bool`

HasMachinePasswordLifespan returns a boolean if a field has been set.

### GetName

`func (o *V14ProvidersAdsItem) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V14ProvidersAdsItem) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V14ProvidersAdsItem) SetName(v string)`

SetName sets Name field to given value.


### GetNodeDcAffinity

`func (o *V14ProvidersAdsItem) GetNodeDcAffinity() string`

GetNodeDcAffinity returns the NodeDcAffinity field if non-nil, zero value otherwise.

### GetNodeDcAffinityOk

`func (o *V14ProvidersAdsItem) GetNodeDcAffinityOk() (*string, bool)`

GetNodeDcAffinityOk returns a tuple with the NodeDcAffinity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeDcAffinity

`func (o *V14ProvidersAdsItem) SetNodeDcAffinity(v string)`

SetNodeDcAffinity sets NodeDcAffinity field to given value.

### HasNodeDcAffinity

`func (o *V14ProvidersAdsItem) HasNodeDcAffinity() bool`

HasNodeDcAffinity returns a boolean if a field has been set.

### GetNodeDcAffinityTimeout

`func (o *V14ProvidersAdsItem) GetNodeDcAffinityTimeout() int32`

GetNodeDcAffinityTimeout returns the NodeDcAffinityTimeout field if non-nil, zero value otherwise.

### GetNodeDcAffinityTimeoutOk

`func (o *V14ProvidersAdsItem) GetNodeDcAffinityTimeoutOk() (*int32, bool)`

GetNodeDcAffinityTimeoutOk returns a tuple with the NodeDcAffinityTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeDcAffinityTimeout

`func (o *V14ProvidersAdsItem) SetNodeDcAffinityTimeout(v int32)`

SetNodeDcAffinityTimeout sets NodeDcAffinityTimeout field to given value.

### HasNodeDcAffinityTimeout

`func (o *V14ProvidersAdsItem) HasNodeDcAffinityTimeout() bool`

HasNodeDcAffinityTimeout returns a boolean if a field has been set.

### GetNssEnumeration

`func (o *V14ProvidersAdsItem) GetNssEnumeration() bool`

GetNssEnumeration returns the NssEnumeration field if non-nil, zero value otherwise.

### GetNssEnumerationOk

`func (o *V14ProvidersAdsItem) GetNssEnumerationOk() (*bool, bool)`

GetNssEnumerationOk returns a tuple with the NssEnumeration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNssEnumeration

`func (o *V14ProvidersAdsItem) SetNssEnumeration(v bool)`

SetNssEnumeration sets NssEnumeration field to given value.

### HasNssEnumeration

`func (o *V14ProvidersAdsItem) HasNssEnumeration() bool`

HasNssEnumeration returns a boolean if a field has been set.

### GetOrganizationalUnit

`func (o *V14ProvidersAdsItem) GetOrganizationalUnit() string`

GetOrganizationalUnit returns the OrganizationalUnit field if non-nil, zero value otherwise.

### GetOrganizationalUnitOk

`func (o *V14ProvidersAdsItem) GetOrganizationalUnitOk() (*string, bool)`

GetOrganizationalUnitOk returns a tuple with the OrganizationalUnit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOrganizationalUnit

`func (o *V14ProvidersAdsItem) SetOrganizationalUnit(v string)`

SetOrganizationalUnit sets OrganizationalUnit field to given value.

### HasOrganizationalUnit

`func (o *V14ProvidersAdsItem) HasOrganizationalUnit() bool`

HasOrganizationalUnit returns a boolean if a field has been set.

### GetPassword

`func (o *V14ProvidersAdsItem) GetPassword() string`

GetPassword returns the Password field if non-nil, zero value otherwise.

### GetPasswordOk

`func (o *V14ProvidersAdsItem) GetPasswordOk() (*string, bool)`

GetPasswordOk returns a tuple with the Password field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPassword

`func (o *V14ProvidersAdsItem) SetPassword(v string)`

SetPassword sets Password field to given value.


### GetRestrictFindable

`func (o *V14ProvidersAdsItem) GetRestrictFindable() bool`

GetRestrictFindable returns the RestrictFindable field if non-nil, zero value otherwise.

### GetRestrictFindableOk

`func (o *V14ProvidersAdsItem) GetRestrictFindableOk() (*bool, bool)`

GetRestrictFindableOk returns a tuple with the RestrictFindable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRestrictFindable

`func (o *V14ProvidersAdsItem) SetRestrictFindable(v bool)`

SetRestrictFindable sets RestrictFindable field to given value.

### HasRestrictFindable

`func (o *V14ProvidersAdsItem) HasRestrictFindable() bool`

HasRestrictFindable returns a boolean if a field has been set.

### GetRpcCallTimeout

`func (o *V14ProvidersAdsItem) GetRpcCallTimeout() int32`

GetRpcCallTimeout returns the RpcCallTimeout field if non-nil, zero value otherwise.

### GetRpcCallTimeoutOk

`func (o *V14ProvidersAdsItem) GetRpcCallTimeoutOk() (*int32, bool)`

GetRpcCallTimeoutOk returns a tuple with the RpcCallTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRpcCallTimeout

`func (o *V14ProvidersAdsItem) SetRpcCallTimeout(v int32)`

SetRpcCallTimeout sets RpcCallTimeout field to given value.

### HasRpcCallTimeout

`func (o *V14ProvidersAdsItem) HasRpcCallTimeout() bool`

HasRpcCallTimeout returns a boolean if a field has been set.

### GetServerRetryLimit

`func (o *V14ProvidersAdsItem) GetServerRetryLimit() int32`

GetServerRetryLimit returns the ServerRetryLimit field if non-nil, zero value otherwise.

### GetServerRetryLimitOk

`func (o *V14ProvidersAdsItem) GetServerRetryLimitOk() (*int32, bool)`

GetServerRetryLimitOk returns a tuple with the ServerRetryLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerRetryLimit

`func (o *V14ProvidersAdsItem) SetServerRetryLimit(v int32)`

SetServerRetryLimit sets ServerRetryLimit field to given value.

### HasServerRetryLimit

`func (o *V14ProvidersAdsItem) HasServerRetryLimit() bool`

HasServerRetryLimit returns a boolean if a field has been set.

### GetSfuSupport

`func (o *V14ProvidersAdsItem) GetSfuSupport() string`

GetSfuSupport returns the SfuSupport field if non-nil, zero value otherwise.

### GetSfuSupportOk

`func (o *V14ProvidersAdsItem) GetSfuSupportOk() (*string, bool)`

GetSfuSupportOk returns a tuple with the SfuSupport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSfuSupport

`func (o *V14ProvidersAdsItem) SetSfuSupport(v string)`

SetSfuSupport sets SfuSupport field to given value.

### HasSfuSupport

`func (o *V14ProvidersAdsItem) HasSfuSupport() bool`

HasSfuSupport returns a boolean if a field has been set.

### GetStoreSfuMappings

`func (o *V14ProvidersAdsItem) GetStoreSfuMappings() bool`

GetStoreSfuMappings returns the StoreSfuMappings field if non-nil, zero value otherwise.

### GetStoreSfuMappingsOk

`func (o *V14ProvidersAdsItem) GetStoreSfuMappingsOk() (*bool, bool)`

GetStoreSfuMappingsOk returns a tuple with the StoreSfuMappings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStoreSfuMappings

`func (o *V14ProvidersAdsItem) SetStoreSfuMappings(v bool)`

SetStoreSfuMappings sets StoreSfuMappings field to given value.

### HasStoreSfuMappings

`func (o *V14ProvidersAdsItem) HasStoreSfuMappings() bool`

HasStoreSfuMappings returns a boolean if a field has been set.

### GetUnfindableGroups

`func (o *V14ProvidersAdsItem) GetUnfindableGroups() []string`

GetUnfindableGroups returns the UnfindableGroups field if non-nil, zero value otherwise.

### GetUnfindableGroupsOk

`func (o *V14ProvidersAdsItem) GetUnfindableGroupsOk() (*[]string, bool)`

GetUnfindableGroupsOk returns a tuple with the UnfindableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnfindableGroups

`func (o *V14ProvidersAdsItem) SetUnfindableGroups(v []string)`

SetUnfindableGroups sets UnfindableGroups field to given value.

### HasUnfindableGroups

`func (o *V14ProvidersAdsItem) HasUnfindableGroups() bool`

HasUnfindableGroups returns a boolean if a field has been set.

### GetUnfindableUsers

`func (o *V14ProvidersAdsItem) GetUnfindableUsers() []string`

GetUnfindableUsers returns the UnfindableUsers field if non-nil, zero value otherwise.

### GetUnfindableUsersOk

`func (o *V14ProvidersAdsItem) GetUnfindableUsersOk() (*[]string, bool)`

GetUnfindableUsersOk returns a tuple with the UnfindableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnfindableUsers

`func (o *V14ProvidersAdsItem) SetUnfindableUsers(v []string)`

SetUnfindableUsers sets UnfindableUsers field to given value.

### HasUnfindableUsers

`func (o *V14ProvidersAdsItem) HasUnfindableUsers() bool`

HasUnfindableUsers returns a boolean if a field has been set.

### GetUser

`func (o *V14ProvidersAdsItem) GetUser() string`

GetUser returns the User field if non-nil, zero value otherwise.

### GetUserOk

`func (o *V14ProvidersAdsItem) GetUserOk() (*string, bool)`

GetUserOk returns a tuple with the User field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUser

`func (o *V14ProvidersAdsItem) SetUser(v string)`

SetUser sets User field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


