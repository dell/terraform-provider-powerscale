# V12DatasetsDatasetWorkloads

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Workloads** | [**[]V12DatasetWorkloadExtended**](V12DatasetWorkloadExtended.md) |  | 

## Methods

### NewV12DatasetsDatasetWorkloads

`func NewV12DatasetsDatasetWorkloads(workloads []V12DatasetWorkloadExtended, ) *V12DatasetsDatasetWorkloads`

NewV12DatasetsDatasetWorkloads instantiates a new V12DatasetsDatasetWorkloads object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12DatasetsDatasetWorkloadsWithDefaults

`func NewV12DatasetsDatasetWorkloadsWithDefaults() *V12DatasetsDatasetWorkloads`

NewV12DatasetsDatasetWorkloadsWithDefaults instantiates a new V12DatasetsDatasetWorkloads object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetWorkloads

`func (o *V12DatasetsDatasetWorkloads) GetWorkloads() []V12DatasetWorkloadExtended`

GetWorkloads returns the Workloads field if non-nil, zero value otherwise.

### GetWorkloadsOk

`func (o *V12DatasetsDatasetWorkloads) GetWorkloadsOk() (*[]V12DatasetWorkloadExtended, bool)`

GetWorkloadsOk returns a tuple with the Workloads field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWorkloads

`func (o *V12DatasetsDatasetWorkloads) SetWorkloads(v []V12DatasetWorkloadExtended)`

SetWorkloads sets Workloads field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


