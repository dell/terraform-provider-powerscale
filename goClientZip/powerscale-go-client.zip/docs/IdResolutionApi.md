# \IdResolutionApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetIdResolutionv7IdResolutionDomain**](IdResolutionApi.md#GetIdResolutionv7IdResolutionDomain) | **Get** /platform/7/id-resolution/domains/{v7IdResolutionDomainId} | 
[**GetIdResolutionv7IdResolutionDomains**](IdResolutionApi.md#GetIdResolutionv7IdResolutionDomains) | **Get** /platform/7/id-resolution/domains | 
[**GetIdResolutionv7IdResolutionLin**](IdResolutionApi.md#GetIdResolutionv7IdResolutionLin) | **Get** /platform/7/id-resolution/lins/{v7IdResolutionLinId} | 
[**GetIdResolutionv7IdResolutionLins**](IdResolutionApi.md#GetIdResolutionv7IdResolutionLins) | **Get** /platform/7/id-resolution/lins | 
[**GetIdResolutionv7IdResolutionZone**](IdResolutionApi.md#GetIdResolutionv7IdResolutionZone) | **Get** /platform/7/id-resolution/zones/{v7IdResolutionZoneId} | 
[**GetIdResolutionv7IdResolutionZones**](IdResolutionApi.md#GetIdResolutionv7IdResolutionZones) | **Get** /platform/7/id-resolution/zones | 
[**GetIdResolutionv7ZonesZidGroup**](IdResolutionApi.md#GetIdResolutionv7ZonesZidGroup) | **Get** /platform/7/id-resolution/zones/{Zid}/groups/{v7ZonesZidGroupId} | 
[**GetIdResolutionv7ZonesZidUser**](IdResolutionApi.md#GetIdResolutionv7ZonesZidUser) | **Get** /platform/7/id-resolution/zones/{Zid}/users/{v7ZonesZidUserId} | 



## GetIdResolutionv7IdResolutionDomain

> V7IdResolutionDomainsExtended GetIdResolutionv7IdResolutionDomain(ctx, v7IdResolutionDomainId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7IdResolutionDomainId := "v7IdResolutionDomainId_example" // string | List domain to path mappings.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IdResolutionApi.GetIdResolutionv7IdResolutionDomain(context.Background(), v7IdResolutionDomainId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IdResolutionApi.GetIdResolutionv7IdResolutionDomain``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIdResolutionv7IdResolutionDomain`: V7IdResolutionDomainsExtended
    fmt.Fprintf(os.Stdout, "Response from `IdResolutionApi.GetIdResolutionv7IdResolutionDomain`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7IdResolutionDomainId** | **string** | List domain to path mappings. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetIdResolutionv7IdResolutionDomainRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7IdResolutionDomainsExtended**](V7IdResolutionDomainsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIdResolutionv7IdResolutionDomains

> V7IdResolutionDomains GetIdResolutionv7IdResolutionDomains(ctx).Domains(domains).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    domains := "domains_example" // string | A comma separated list specifying the domains that will be mapped with a path. Only the domains specified in this list will be mapped. (optional)
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IdResolutionApi.GetIdResolutionv7IdResolutionDomains(context.Background()).Domains(domains).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IdResolutionApi.GetIdResolutionv7IdResolutionDomains``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIdResolutionv7IdResolutionDomains`: V7IdResolutionDomains
    fmt.Fprintf(os.Stdout, "Response from `IdResolutionApi.GetIdResolutionv7IdResolutionDomains`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetIdResolutionv7IdResolutionDomainsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domains** | **string** | A comma separated list specifying the domains that will be mapped with a path. Only the domains specified in this list will be mapped. | 
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7IdResolutionDomains**](V7IdResolutionDomains.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIdResolutionv7IdResolutionLin

> V7IdResolutionLinsExtended GetIdResolutionv7IdResolutionLin(ctx, v7IdResolutionLinId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7IdResolutionLinId := int32(56) // int32 | List lin to path mappings.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IdResolutionApi.GetIdResolutionv7IdResolutionLin(context.Background(), v7IdResolutionLinId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IdResolutionApi.GetIdResolutionv7IdResolutionLin``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIdResolutionv7IdResolutionLin`: V7IdResolutionLinsExtended
    fmt.Fprintf(os.Stdout, "Response from `IdResolutionApi.GetIdResolutionv7IdResolutionLin`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7IdResolutionLinId** | **int32** | List lin to path mappings. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetIdResolutionv7IdResolutionLinRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7IdResolutionLinsExtended**](V7IdResolutionLinsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIdResolutionv7IdResolutionLins

> V7IdResolutionLins GetIdResolutionv7IdResolutionLins(ctx).Sort(sort).Lins(lins).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    lins := "lins_example" // string | A comma separated list specifying the lins that will be mapped with a path. Only the lins specified in this list will be mapped. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IdResolutionApi.GetIdResolutionv7IdResolutionLins(context.Background()).Sort(sort).Lins(lins).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IdResolutionApi.GetIdResolutionv7IdResolutionLins``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIdResolutionv7IdResolutionLins`: V7IdResolutionLins
    fmt.Fprintf(os.Stdout, "Response from `IdResolutionApi.GetIdResolutionv7IdResolutionLins`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetIdResolutionv7IdResolutionLinsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **lins** | **string** | A comma separated list specifying the lins that will be mapped with a path. Only the lins specified in this list will be mapped. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7IdResolutionLins**](V7IdResolutionLins.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIdResolutionv7IdResolutionZone

> V7IdResolutionZonesExtended GetIdResolutionv7IdResolutionZone(ctx, v7IdResolutionZoneId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7IdResolutionZoneId := "v7IdResolutionZoneId_example" // string | List zone id to zone name mappings.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IdResolutionApi.GetIdResolutionv7IdResolutionZone(context.Background(), v7IdResolutionZoneId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IdResolutionApi.GetIdResolutionv7IdResolutionZone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIdResolutionv7IdResolutionZone`: V7IdResolutionZonesExtended
    fmt.Fprintf(os.Stdout, "Response from `IdResolutionApi.GetIdResolutionv7IdResolutionZone`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7IdResolutionZoneId** | **string** | List zone id to zone name mappings. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetIdResolutionv7IdResolutionZoneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7IdResolutionZonesExtended**](V7IdResolutionZonesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIdResolutionv7IdResolutionZones

> V7IdResolutionZones GetIdResolutionv7IdResolutionZones(ctx).Sort(sort).Limit(limit).ZoneIds(zoneIds).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    zoneIds := "zoneIds_example" // string | A comma separated list specifying the zone IDs to map with a zone name. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IdResolutionApi.GetIdResolutionv7IdResolutionZones(context.Background()).Sort(sort).Limit(limit).ZoneIds(zoneIds).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IdResolutionApi.GetIdResolutionv7IdResolutionZones``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIdResolutionv7IdResolutionZones`: V7IdResolutionZones
    fmt.Fprintf(os.Stdout, "Response from `IdResolutionApi.GetIdResolutionv7IdResolutionZones`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetIdResolutionv7IdResolutionZonesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **zoneIds** | **string** | A comma separated list specifying the zone IDs to map with a zone name. | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7IdResolutionZones**](V7IdResolutionZones.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIdResolutionv7ZonesZidGroup

> V7ZonesZidGroups GetIdResolutionv7ZonesZidGroup(ctx, v7ZonesZidGroupId, zid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ZonesZidGroupId := "v7ZonesZidGroupId_example" // string | List a mapping of gid/gsid to groupname.
    zid := "zid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IdResolutionApi.GetIdResolutionv7ZonesZidGroup(context.Background(), v7ZonesZidGroupId, zid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IdResolutionApi.GetIdResolutionv7ZonesZidGroup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIdResolutionv7ZonesZidGroup`: V7ZonesZidGroups
    fmt.Fprintf(os.Stdout, "Response from `IdResolutionApi.GetIdResolutionv7ZonesZidGroup`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ZonesZidGroupId** | **string** | List a mapping of gid/gsid to groupname. | 
**zid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetIdResolutionv7ZonesZidGroupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V7ZonesZidGroups**](V7ZonesZidGroups.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIdResolutionv7ZonesZidUser

> V7ZonesZidUsers GetIdResolutionv7ZonesZidUser(ctx, v7ZonesZidUserId, zid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ZonesZidUserId := "v7ZonesZidUserId_example" // string | List a mapping of uid/sid to username.
    zid := "zid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IdResolutionApi.GetIdResolutionv7ZonesZidUser(context.Background(), v7ZonesZidUserId, zid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IdResolutionApi.GetIdResolutionv7ZonesZidUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIdResolutionv7ZonesZidUser`: V7ZonesZidUsers
    fmt.Fprintf(os.Stdout, "Response from `IdResolutionApi.GetIdResolutionv7ZonesZidUser`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ZonesZidUserId** | **string** | List a mapping of uid/sid to username. | 
**zid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetIdResolutionv7ZonesZidUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V7ZonesZidUsers**](V7ZonesZidUsers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

