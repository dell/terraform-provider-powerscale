# \EventApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateEventv12EventChannel**](EventApi.md#CreateEventv12EventChannel) | **Post** /platform/12/event/channels/{v12EventChannelId} | 
[**CreateEventv12EventChannels**](EventApi.md#CreateEventv12EventChannels) | **Post** /platform/12/event/channels | 
[**CreateEventv15EventAlertCondition**](EventApi.md#CreateEventv15EventAlertCondition) | **Post** /platform/15/event/alert-conditions | 
[**CreateEventv3EventAlertCondition**](EventApi.md#CreateEventv3EventAlertCondition) | **Post** /platform/3/event/alert-conditions | 
[**CreateEventv3EventChannels**](EventApi.md#CreateEventv3EventChannels) | **Post** /platform/3/event/channels | 
[**CreateEventv3EventEvent**](EventApi.md#CreateEventv3EventEvent) | **Post** /platform/3/event/events | 
[**CreateEventv4EventAlertCondition**](EventApi.md#CreateEventv4EventAlertCondition) | **Post** /platform/4/event/alert-conditions | 
[**CreateEventv7EventChannels**](EventApi.md#CreateEventv7EventChannels) | **Post** /platform/7/event/channels | 
[**DeleteEventv12EventChannel**](EventApi.md#DeleteEventv12EventChannel) | **Delete** /platform/12/event/channels/{v12EventChannelId} | 
[**DeleteEventv15EventAlertCondition**](EventApi.md#DeleteEventv15EventAlertCondition) | **Delete** /platform/15/event/alert-conditions/{v15EventAlertConditionId} | 
[**DeleteEventv15EventAlertConditions**](EventApi.md#DeleteEventv15EventAlertConditions) | **Delete** /platform/15/event/alert-conditions | 
[**DeleteEventv3EventAlertCondition**](EventApi.md#DeleteEventv3EventAlertCondition) | **Delete** /platform/3/event/alert-conditions/{v3EventAlertConditionId} | 
[**DeleteEventv3EventAlertConditions**](EventApi.md#DeleteEventv3EventAlertConditions) | **Delete** /platform/3/event/alert-conditions | 
[**DeleteEventv3EventChannel**](EventApi.md#DeleteEventv3EventChannel) | **Delete** /platform/3/event/channels/{v3EventChannelId} | 
[**DeleteEventv4EventAlertCondition**](EventApi.md#DeleteEventv4EventAlertCondition) | **Delete** /platform/4/event/alert-conditions/{v4EventAlertConditionId} | 
[**DeleteEventv4EventAlertConditions**](EventApi.md#DeleteEventv4EventAlertConditions) | **Delete** /platform/4/event/alert-conditions | 
[**DeleteEventv7EventChannel**](EventApi.md#DeleteEventv7EventChannel) | **Delete** /platform/7/event/channels/{v7EventChannelId} | 
[**GetEventv11EventThreshold**](EventApi.md#GetEventv11EventThreshold) | **Get** /platform/11/event/thresholds/{v11EventThresholdId} | 
[**GetEventv11EventThresholds**](EventApi.md#GetEventv11EventThresholds) | **Get** /platform/11/event/thresholds | 
[**GetEventv12EventChannel**](EventApi.md#GetEventv12EventChannel) | **Get** /platform/12/event/channels/{v12EventChannelId} | 
[**GetEventv12EventEventgroupDefinition**](EventApi.md#GetEventv12EventEventgroupDefinition) | **Get** /platform/12/event/eventgroup-definitions/{v12EventEventgroupDefinitionId} | 
[**GetEventv12EventEventgroupDefinitions**](EventApi.md#GetEventv12EventEventgroupDefinitions) | **Get** /platform/12/event/eventgroup-definitions | 
[**GetEventv12EventEventgroupOccurrence**](EventApi.md#GetEventv12EventEventgroupOccurrence) | **Get** /platform/12/event/eventgroup-occurrences/{v12EventEventgroupOccurrenceId} | 
[**GetEventv12EventEventgroupOccurrences**](EventApi.md#GetEventv12EventEventgroupOccurrences) | **Get** /platform/12/event/eventgroup-occurrences | 
[**GetEventv12EventMaintenance**](EventApi.md#GetEventv12EventMaintenance) | **Get** /platform/12/event/maintenance | 
[**GetEventv12EventSettings**](EventApi.md#GetEventv12EventSettings) | **Get** /platform/12/event/settings | 
[**GetEventv12EventSuppress**](EventApi.md#GetEventv12EventSuppress) | **Get** /platform/12/event/suppress | 
[**GetEventv12EventSuppressById**](EventApi.md#GetEventv12EventSuppressById) | **Get** /platform/12/event/suppress/{v12EventSuppressId} | 
[**GetEventv14EventSettings**](EventApi.md#GetEventv14EventSettings) | **Get** /platform/14/event/settings | 
[**GetEventv15EventAlertCondition**](EventApi.md#GetEventv15EventAlertCondition) | **Get** /platform/15/event/alert-conditions/{v15EventAlertConditionId} | 
[**GetEventv3EventAlertCondition**](EventApi.md#GetEventv3EventAlertCondition) | **Get** /platform/3/event/alert-conditions/{v3EventAlertConditionId} | 
[**GetEventv3EventCategories**](EventApi.md#GetEventv3EventCategories) | **Get** /platform/3/event/categories | 
[**GetEventv3EventCategory**](EventApi.md#GetEventv3EventCategory) | **Get** /platform/3/event/categories/{v3EventCategoryId} | 
[**GetEventv3EventChannel**](EventApi.md#GetEventv3EventChannel) | **Get** /platform/3/event/channels/{v3EventChannelId} | 
[**GetEventv3EventEventgroupDefinition**](EventApi.md#GetEventv3EventEventgroupDefinition) | **Get** /platform/3/event/eventgroup-definitions/{v3EventEventgroupDefinitionId} | 
[**GetEventv3EventEventgroupDefinitions**](EventApi.md#GetEventv3EventEventgroupDefinitions) | **Get** /platform/3/event/eventgroup-definitions | 
[**GetEventv3EventEventgroupOccurrence**](EventApi.md#GetEventv3EventEventgroupOccurrence) | **Get** /platform/3/event/eventgroup-occurrences/{v3EventEventgroupOccurrenceId} | 
[**GetEventv3EventEventgroupOccurrences**](EventApi.md#GetEventv3EventEventgroupOccurrences) | **Get** /platform/3/event/eventgroup-occurrences | 
[**GetEventv3EventEventlist**](EventApi.md#GetEventv3EventEventlist) | **Get** /platform/3/event/eventlists/{v3EventEventlistId} | 
[**GetEventv3EventEventlists**](EventApi.md#GetEventv3EventEventlists) | **Get** /platform/3/event/eventlists | 
[**GetEventv3EventSettings**](EventApi.md#GetEventv3EventSettings) | **Get** /platform/3/event/settings | 
[**GetEventv4EventAlertCondition**](EventApi.md#GetEventv4EventAlertCondition) | **Get** /platform/4/event/alert-conditions/{v4EventAlertConditionId} | 
[**GetEventv4EventEventgroupDefinition**](EventApi.md#GetEventv4EventEventgroupDefinition) | **Get** /platform/4/event/eventgroup-definitions/{v4EventEventgroupDefinitionId} | 
[**GetEventv4EventEventgroupDefinitions**](EventApi.md#GetEventv4EventEventgroupDefinitions) | **Get** /platform/4/event/eventgroup-definitions | 
[**GetEventv7EventChannel**](EventApi.md#GetEventv7EventChannel) | **Get** /platform/7/event/channels/{v7EventChannelId} | 
[**GetEventv7EventEventlist**](EventApi.md#GetEventv7EventEventlist) | **Get** /platform/7/event/eventlists/{v7EventEventlistId} | 
[**GetEventv7EventEventlists**](EventApi.md#GetEventv7EventEventlists) | **Get** /platform/7/event/eventlists | 
[**GetEventv9EventEventgroupDefinition**](EventApi.md#GetEventv9EventEventgroupDefinition) | **Get** /platform/9/event/eventgroup-definitions/{v9EventEventgroupDefinitionId} | 
[**GetEventv9EventEventgroupDefinitions**](EventApi.md#GetEventv9EventEventgroupDefinitions) | **Get** /platform/9/event/eventgroup-definitions | 
[**ListEventv12EventChannels**](EventApi.md#ListEventv12EventChannels) | **Get** /platform/12/event/channels | 
[**ListEventv15EventAlertConditions**](EventApi.md#ListEventv15EventAlertConditions) | **Get** /platform/15/event/alert-conditions | 
[**ListEventv3EventAlertConditions**](EventApi.md#ListEventv3EventAlertConditions) | **Get** /platform/3/event/alert-conditions | 
[**ListEventv3EventChannels**](EventApi.md#ListEventv3EventChannels) | **Get** /platform/3/event/channels | 
[**ListEventv4EventAlertConditions**](EventApi.md#ListEventv4EventAlertConditions) | **Get** /platform/4/event/alert-conditions | 
[**ListEventv7EventChannels**](EventApi.md#ListEventv7EventChannels) | **Get** /platform/7/event/channels | 
[**UpdateEventv11EventThreshold**](EventApi.md#UpdateEventv11EventThreshold) | **Put** /platform/11/event/thresholds/{v11EventThresholdId} | 
[**UpdateEventv12EventChannel**](EventApi.md#UpdateEventv12EventChannel) | **Put** /platform/12/event/channels/{v12EventChannelId} | 
[**UpdateEventv12EventEventgroupOccurrence**](EventApi.md#UpdateEventv12EventEventgroupOccurrence) | **Put** /platform/12/event/eventgroup-occurrences/{v12EventEventgroupOccurrenceId} | 
[**UpdateEventv12EventEventgroupOccurrences**](EventApi.md#UpdateEventv12EventEventgroupOccurrences) | **Put** /platform/12/event/eventgroup-occurrences | 
[**UpdateEventv12EventMaintenance**](EventApi.md#UpdateEventv12EventMaintenance) | **Put** /platform/12/event/maintenance | 
[**UpdateEventv12EventSettings**](EventApi.md#UpdateEventv12EventSettings) | **Put** /platform/12/event/settings | 
[**UpdateEventv12EventSuppressById**](EventApi.md#UpdateEventv12EventSuppressById) | **Put** /platform/12/event/suppress/{v12EventSuppressId} | 
[**UpdateEventv14EventSettings**](EventApi.md#UpdateEventv14EventSettings) | **Put** /platform/14/event/settings | 
[**UpdateEventv15EventAlertCondition**](EventApi.md#UpdateEventv15EventAlertCondition) | **Put** /platform/15/event/alert-conditions/{v15EventAlertConditionId} | 
[**UpdateEventv3EventAlertCondition**](EventApi.md#UpdateEventv3EventAlertCondition) | **Put** /platform/3/event/alert-conditions/{v3EventAlertConditionId} | 
[**UpdateEventv3EventChannel**](EventApi.md#UpdateEventv3EventChannel) | **Put** /platform/3/event/channels/{v3EventChannelId} | 
[**UpdateEventv3EventEventgroupOccurrence**](EventApi.md#UpdateEventv3EventEventgroupOccurrence) | **Put** /platform/3/event/eventgroup-occurrences/{v3EventEventgroupOccurrenceId} | 
[**UpdateEventv3EventEventgroupOccurrences**](EventApi.md#UpdateEventv3EventEventgroupOccurrences) | **Put** /platform/3/event/eventgroup-occurrences | 
[**UpdateEventv3EventSettings**](EventApi.md#UpdateEventv3EventSettings) | **Put** /platform/3/event/settings | 
[**UpdateEventv4EventAlertCondition**](EventApi.md#UpdateEventv4EventAlertCondition) | **Put** /platform/4/event/alert-conditions/{v4EventAlertConditionId} | 
[**UpdateEventv7EventChannel**](EventApi.md#UpdateEventv7EventChannel) | **Put** /platform/7/event/channels/{v7EventChannelId} | 



## CreateEventv12EventChannel

> CreateEventv12EventChannel(ctx, v12EventChannelId).V12EventChannel(v12EventChannel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventChannelId := "v12EventChannelId_example" // string | Send a test message to the channel.
    v12EventChannel := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.CreateEventv12EventChannel(context.Background(), v12EventChannelId).V12EventChannel(v12EventChannel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.CreateEventv12EventChannel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12EventChannelId** | **string** | Send a test message to the channel. | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateEventv12EventChannelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12EventChannel** | **map[string]interface{}** |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateEventv12EventChannels

> CreateResponse CreateEventv12EventChannels(ctx).V12EventChannels(v12EventChannels).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventChannels := *openapiclient.NewV12EventChannels("Name_example", "Type_example") // V12EventChannels | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.CreateEventv12EventChannels(context.Background()).V12EventChannels(v12EventChannels).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.CreateEventv12EventChannels``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateEventv12EventChannels`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `EventApi.CreateEventv12EventChannels`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateEventv12EventChannelsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12EventChannels** | [**V12EventChannels**](V12EventChannels.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateEventv15EventAlertCondition

> CreateResponse CreateEventv15EventAlertCondition(ctx).V15EventAlertCondition(v15EventAlertCondition).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15EventAlertCondition := *openapiclient.NewV15EventAlertCondition([]string{"Channels_example"}, "Condition_example", "Name_example") // V15EventAlertCondition | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.CreateEventv15EventAlertCondition(context.Background()).V15EventAlertCondition(v15EventAlertCondition).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.CreateEventv15EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateEventv15EventAlertCondition`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `EventApi.CreateEventv15EventAlertCondition`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateEventv15EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15EventAlertCondition** | [**V15EventAlertCondition**](V15EventAlertCondition.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateEventv3EventAlertCondition

> CreateResponse CreateEventv3EventAlertCondition(ctx).V3EventAlertCondition(v3EventAlertCondition).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventAlertCondition := *openapiclient.NewV3EventAlertCondition([]int32{int32(123)}, "Condition_example", "Name_example") // V3EventAlertCondition | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.CreateEventv3EventAlertCondition(context.Background()).V3EventAlertCondition(v3EventAlertCondition).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.CreateEventv3EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateEventv3EventAlertCondition`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `EventApi.CreateEventv3EventAlertCondition`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateEventv3EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3EventAlertCondition** | [**V3EventAlertCondition**](V3EventAlertCondition.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateEventv3EventChannels

> CreateResponse CreateEventv3EventChannels(ctx).V3EventChannels(v3EventChannels).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventChannels := *openapiclient.NewV12EventChannels("Name_example", "Type_example") // V12EventChannels | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.CreateEventv3EventChannels(context.Background()).V3EventChannels(v3EventChannels).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.CreateEventv3EventChannels``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateEventv3EventChannels`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `EventApi.CreateEventv3EventChannels`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateEventv3EventChannelsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3EventChannels** | [**V12EventChannels**](V12EventChannels.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateEventv3EventEvent

> Createv3EventEventResponse CreateEventv3EventEvent(ctx).V3EventEvent(v3EventEvent).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventEvent := *openapiclient.NewV3EventEvent() // V3EventEvent | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.CreateEventv3EventEvent(context.Background()).V3EventEvent(v3EventEvent).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.CreateEventv3EventEvent``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateEventv3EventEvent`: Createv3EventEventResponse
    fmt.Fprintf(os.Stdout, "Response from `EventApi.CreateEventv3EventEvent`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateEventv3EventEventRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3EventEvent** | [**V3EventEvent**](V3EventEvent.md) |  | 

### Return type

[**Createv3EventEventResponse**](Createv3EventEventResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateEventv4EventAlertCondition

> CreateResponse CreateEventv4EventAlertCondition(ctx).V4EventAlertCondition(v4EventAlertCondition).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4EventAlertCondition := *openapiclient.NewV4EventAlertCondition([]string{"Channels_example"}, "Condition_example", "Name_example") // V4EventAlertCondition | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.CreateEventv4EventAlertCondition(context.Background()).V4EventAlertCondition(v4EventAlertCondition).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.CreateEventv4EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateEventv4EventAlertCondition`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `EventApi.CreateEventv4EventAlertCondition`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateEventv4EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4EventAlertCondition** | [**V4EventAlertCondition**](V4EventAlertCondition.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateEventv7EventChannels

> CreateResponse CreateEventv7EventChannels(ctx).V7EventChannels(v7EventChannels).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7EventChannels := *openapiclient.NewV12EventChannels("Name_example", "Type_example") // V12EventChannels | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.CreateEventv7EventChannels(context.Background()).V7EventChannels(v7EventChannels).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.CreateEventv7EventChannels``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateEventv7EventChannels`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `EventApi.CreateEventv7EventChannels`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateEventv7EventChannelsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7EventChannels** | [**V12EventChannels**](V12EventChannels.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventv12EventChannel

> DeleteEventv12EventChannel(ctx, v12EventChannelId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventChannelId := "v12EventChannelId_example" // string | Delete the channel.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.DeleteEventv12EventChannel(context.Background(), v12EventChannelId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.DeleteEventv12EventChannel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12EventChannelId** | **string** | Delete the channel. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventv12EventChannelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventv15EventAlertCondition

> DeleteEventv15EventAlertCondition(ctx, v15EventAlertConditionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15EventAlertConditionId := "v15EventAlertConditionId_example" // string | Delete the alert-condition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.DeleteEventv15EventAlertCondition(context.Background(), v15EventAlertConditionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.DeleteEventv15EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15EventAlertConditionId** | **string** | Delete the alert-condition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventv15EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventv15EventAlertConditions

> DeleteEventv15EventAlertConditions(ctx).Channel(channel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    channel := "channel_example" // string | Delete only conditions for this channel (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.DeleteEventv15EventAlertConditions(context.Background()).Channel(channel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.DeleteEventv15EventAlertConditions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventv15EventAlertConditionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **channel** | **string** | Delete only conditions for this channel | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventv3EventAlertCondition

> DeleteEventv3EventAlertCondition(ctx, v3EventAlertConditionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventAlertConditionId := "v3EventAlertConditionId_example" // string | Delete the alert-condition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.DeleteEventv3EventAlertCondition(context.Background(), v3EventAlertConditionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.DeleteEventv3EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventAlertConditionId** | **string** | Delete the alert-condition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventv3EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventv3EventAlertConditions

> DeleteEventv3EventAlertConditions(ctx).Channel(channel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    channel := "channel_example" // string | Delete only conditions for this channel (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.DeleteEventv3EventAlertConditions(context.Background()).Channel(channel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.DeleteEventv3EventAlertConditions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventv3EventAlertConditionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **channel** | **string** | Delete only conditions for this channel | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventv3EventChannel

> DeleteEventv3EventChannel(ctx, v3EventChannelId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventChannelId := "v3EventChannelId_example" // string | Delete the channel.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.DeleteEventv3EventChannel(context.Background(), v3EventChannelId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.DeleteEventv3EventChannel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventChannelId** | **string** | Delete the channel. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventv3EventChannelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventv4EventAlertCondition

> DeleteEventv4EventAlertCondition(ctx, v4EventAlertConditionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4EventAlertConditionId := "v4EventAlertConditionId_example" // string | Delete the alert-condition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.DeleteEventv4EventAlertCondition(context.Background(), v4EventAlertConditionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.DeleteEventv4EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4EventAlertConditionId** | **string** | Delete the alert-condition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventv4EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventv4EventAlertConditions

> DeleteEventv4EventAlertConditions(ctx).Channel(channel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    channel := "channel_example" // string | Delete only conditions for this channel (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.DeleteEventv4EventAlertConditions(context.Background()).Channel(channel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.DeleteEventv4EventAlertConditions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventv4EventAlertConditionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **channel** | **string** | Delete only conditions for this channel | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteEventv7EventChannel

> DeleteEventv7EventChannel(ctx, v7EventChannelId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7EventChannelId := "v7EventChannelId_example" // string | Delete the channel.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.DeleteEventv7EventChannel(context.Background(), v7EventChannelId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.DeleteEventv7EventChannel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7EventChannelId** | **string** | Delete the channel. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteEventv7EventChannelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv11EventThreshold

> V11EventThresholds GetEventv11EventThreshold(ctx, v11EventThresholdId).EventId(eventId).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11EventThresholdId := "v11EventThresholdId_example" // string | List all configurable event thresholds
    eventId := int32(56) // int32 | Return thresholds for the specified event id (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv11EventThreshold(context.Background(), v11EventThresholdId).EventId(eventId).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv11EventThreshold``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv11EventThreshold`: V11EventThresholds
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv11EventThreshold`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11EventThresholdId** | **string** | List all configurable event thresholds | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv11EventThresholdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **eventId** | **int32** | Return thresholds for the specified event id | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V11EventThresholds**](V11EventThresholds.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv11EventThresholds

> V11EventThresholds GetEventv11EventThresholds(ctx).EventId(eventId).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    eventId := int32(56) // int32 | Return thresholds for the specified event id (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv11EventThresholds(context.Background()).EventId(eventId).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv11EventThresholds``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv11EventThresholds`: V11EventThresholds
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv11EventThresholds`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv11EventThresholdsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **eventId** | **int32** | Return thresholds for the specified event id | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V11EventThresholds**](V11EventThresholds.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv12EventChannel

> V12EventChannelsExtendedExtended GetEventv12EventChannel(ctx, v12EventChannelId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventChannelId := "v12EventChannelId_example" // string | Retrieve the channel.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv12EventChannel(context.Background(), v12EventChannelId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv12EventChannel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv12EventChannel`: V12EventChannelsExtendedExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv12EventChannel`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12EventChannelId** | **string** | Retrieve the channel. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv12EventChannelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12EventChannelsExtendedExtended**](V12EventChannelsExtendedExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv12EventEventgroupDefinition

> V12EventEventgroupDefinitionsExtended GetEventv12EventEventgroupDefinition(ctx, v12EventEventgroupDefinitionId).AlertInfo(alertInfo).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventEventgroupDefinitionId := "v12EventEventgroupDefinitionId_example" // string | Retrieve the eventgroup definition.
    alertInfo := true // bool | Include alert rules and channels in output. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv12EventEventgroupDefinition(context.Background(), v12EventEventgroupDefinitionId).AlertInfo(alertInfo).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv12EventEventgroupDefinition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv12EventEventgroupDefinition`: V12EventEventgroupDefinitionsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv12EventEventgroupDefinition`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12EventEventgroupDefinitionId** | **string** | Retrieve the eventgroup definition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv12EventEventgroupDefinitionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **alertInfo** | **bool** | Include alert rules and channels in output. | 

### Return type

[**V12EventEventgroupDefinitionsExtended**](V12EventEventgroupDefinitionsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv12EventEventgroupDefinitions

> V12EventEventgroupDefinitions GetEventv12EventEventgroupDefinitions(ctx).Category(category).Resume(resume).Limit(limit).AlertInfo(alertInfo).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    category := int32(56) // int32 | Return eventgroups in the specified category. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    alertInfo := true // bool | Include alert rules and channels in output. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv12EventEventgroupDefinitions(context.Background()).Category(category).Resume(resume).Limit(limit).AlertInfo(alertInfo).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv12EventEventgroupDefinitions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv12EventEventgroupDefinitions`: V12EventEventgroupDefinitions
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv12EventEventgroupDefinitions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv12EventEventgroupDefinitionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | **int32** | Return eventgroups in the specified category. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **alertInfo** | **bool** | Include alert rules and channels in output. | 

### Return type

[**V12EventEventgroupDefinitions**](V12EventEventgroupDefinitions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv12EventEventgroupOccurrence

> V12EventEventgroupOccurrencesExtendedExtended GetEventv12EventEventgroupOccurrence(ctx, v12EventEventgroupOccurrenceId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventEventgroupOccurrenceId := "v12EventEventgroupOccurrenceId_example" // string | Retrieve individual eventgroup occurrence.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv12EventEventgroupOccurrence(context.Background(), v12EventEventgroupOccurrenceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv12EventEventgroupOccurrence``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv12EventEventgroupOccurrence`: V12EventEventgroupOccurrencesExtendedExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv12EventEventgroupOccurrence`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12EventEventgroupOccurrenceId** | **string** | Retrieve individual eventgroup occurrence. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv12EventEventgroupOccurrenceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12EventEventgroupOccurrencesExtendedExtended**](V12EventEventgroupOccurrencesExtendedExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv12EventEventgroupOccurrences

> V12EventEventgroupOccurrences GetEventv12EventEventgroupOccurrences(ctx).Resolved(resolved).Sort(sort).Begin(begin).End(end).Resolver(resolver).EventCount(eventCount).Severity(severity).Devid(devid).Resume(resume).Ignore(ignore).LastEventEnd(lastEventEnd).Limit(limit).PartialCauseLong(partialCauseLong).Maintenance(maintenance).PartialEventgroupId(partialEventgroupId).PartialEventType(partialEventType).Cause(cause).Dir(dir).LastEventBegin(lastEventBegin).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    resolved := true // bool | Filter by resolved eventgroups. (optional)
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    begin := int32(56) // int32 | Events that are in progress after this time. (optional)
    end := int32(56) // int32 | Events that were in progress before this time. (optional)
    resolver := "resolver_example" // string | Filter by eventgroup resolver. (optional)
    eventCount := int32(56) // int32 | Events for which event_count > this. (optional)
    severity := []string{"Severity_example"} // []string | Filter by severity. (optional)
    devid := []int32{int32(123)} // []int32 | Filter by devid. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    ignore := true // bool | Filter by ignored eventgroups. (optional)
    lastEventEnd := int32(56) // int32 | Filter eventgroups by those that have last_event before this time. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    partialCauseLong := "partialCauseLong_example" // string | Filter by partial long-cause description. (optional)
    maintenance := true // bool | Filter by eventgroups created during maintenance mode. (optional)
    partialEventgroupId := "partialEventgroupId_example" // string | Filter by partial eventgroup id. (optional)
    partialEventType := "partialEventType_example" // string | Filter eventgroups by there associated event's event-type number. (optional)
    cause := "cause_example" // string | Filter by cause. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    lastEventBegin := int32(56) // int32 | Filter eventgroups by those that have last_event after this time. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv12EventEventgroupOccurrences(context.Background()).Resolved(resolved).Sort(sort).Begin(begin).End(end).Resolver(resolver).EventCount(eventCount).Severity(severity).Devid(devid).Resume(resume).Ignore(ignore).LastEventEnd(lastEventEnd).Limit(limit).PartialCauseLong(partialCauseLong).Maintenance(maintenance).PartialEventgroupId(partialEventgroupId).PartialEventType(partialEventType).Cause(cause).Dir(dir).LastEventBegin(lastEventBegin).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv12EventEventgroupOccurrences``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv12EventEventgroupOccurrences`: V12EventEventgroupOccurrences
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv12EventEventgroupOccurrences`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv12EventEventgroupOccurrencesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resolved** | **bool** | Filter by resolved eventgroups. | 
 **sort** | **string** | The field that will be used for sorting. | 
 **begin** | **int32** | Events that are in progress after this time. | 
 **end** | **int32** | Events that were in progress before this time. | 
 **resolver** | **string** | Filter by eventgroup resolver. | 
 **eventCount** | **int32** | Events for which event_count &gt; this. | 
 **severity** | **[]string** | Filter by severity. | 
 **devid** | **[]int32** | Filter by devid. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **ignore** | **bool** | Filter by ignored eventgroups. | 
 **lastEventEnd** | **int32** | Filter eventgroups by those that have last_event before this time. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **partialCauseLong** | **string** | Filter by partial long-cause description. | 
 **maintenance** | **bool** | Filter by eventgroups created during maintenance mode. | 
 **partialEventgroupId** | **string** | Filter by partial eventgroup id. | 
 **partialEventType** | **string** | Filter eventgroups by there associated event&#39;s event-type number. | 
 **cause** | **string** | Filter by cause. | 
 **dir** | **string** | The direction of the sort. | 
 **lastEventBegin** | **int32** | Filter eventgroups by those that have last_event after this time. | 

### Return type

[**V12EventEventgroupOccurrences**](V12EventEventgroupOccurrences.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv12EventMaintenance

> V12EventMaintenance GetEventv12EventMaintenance(ctx).Resume(resume).Limit(limit).History(history).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    history := true // bool | True to list history. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv12EventMaintenance(context.Background()).Resume(resume).Limit(limit).History(history).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv12EventMaintenance``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv12EventMaintenance`: V12EventMaintenance
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv12EventMaintenance`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv12EventMaintenanceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **history** | **bool** | True to list history. | 

### Return type

[**V12EventMaintenance**](V12EventMaintenance.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv12EventSettings

> V12EventSettings GetEventv12EventSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv12EventSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv12EventSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv12EventSettings`: V12EventSettings
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv12EventSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv12EventSettingsRequest struct via the builder pattern


### Return type

[**V12EventSettings**](V12EventSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv12EventSuppress

> V12EventSuppress GetEventv12EventSuppress(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv12EventSuppress(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv12EventSuppress``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv12EventSuppress`: V12EventSuppress
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv12EventSuppress`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv12EventSuppressRequest struct via the builder pattern


### Return type

[**V12EventSuppress**](V12EventSuppress.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv12EventSuppressById

> V12EventSuppressIdParams GetEventv12EventSuppressById(ctx, v12EventSuppressId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventSuppressId := "v12EventSuppressId_example" // string | Indicate whether this event type ID is suppressed.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv12EventSuppressById(context.Background(), v12EventSuppressId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv12EventSuppressById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv12EventSuppressById`: V12EventSuppressIdParams
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv12EventSuppressById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12EventSuppressId** | **string** | Indicate whether this event type ID is suppressed. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv12EventSuppressByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12EventSuppressIdParams**](V12EventSuppressIdParams.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv14EventSettings

> V14EventSettings GetEventv14EventSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv14EventSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv14EventSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv14EventSettings`: V14EventSettings
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv14EventSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv14EventSettingsRequest struct via the builder pattern


### Return type

[**V14EventSettings**](V14EventSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv15EventAlertCondition

> V15EventAlertConditionsExtended GetEventv15EventAlertCondition(ctx, v15EventAlertConditionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15EventAlertConditionId := "v15EventAlertConditionId_example" // string | Retrieve the alert-condition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv15EventAlertCondition(context.Background(), v15EventAlertConditionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv15EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv15EventAlertCondition`: V15EventAlertConditionsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv15EventAlertCondition`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15EventAlertConditionId** | **string** | Retrieve the alert-condition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv15EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V15EventAlertConditionsExtended**](V15EventAlertConditionsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventAlertCondition

> V3EventAlertConditionsExtended GetEventv3EventAlertCondition(ctx, v3EventAlertConditionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventAlertConditionId := "v3EventAlertConditionId_example" // string | Retrieve the alert-condition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventAlertCondition(context.Background(), v3EventAlertConditionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventAlertCondition`: V3EventAlertConditionsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventAlertCondition`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventAlertConditionId** | **string** | Retrieve the alert-condition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3EventAlertConditionsExtended**](V3EventAlertConditionsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventCategories

> V3EventCategories GetEventv3EventCategories(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventCategories(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventCategories``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventCategories`: V3EventCategories
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventCategories`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventCategoriesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3EventCategories**](V3EventCategories.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventCategory

> V3EventCategoriesExtended GetEventv3EventCategory(ctx, v3EventCategoryId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventCategoryId := "v3EventCategoryId_example" // string | Retrieve the eventgroup category.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventCategory(context.Background(), v3EventCategoryId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventCategory``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventCategory`: V3EventCategoriesExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventCategory`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventCategoryId** | **string** | Retrieve the eventgroup category. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventCategoryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3EventCategoriesExtended**](V3EventCategoriesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventChannel

> V3EventChannelsExtended GetEventv3EventChannel(ctx, v3EventChannelId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventChannelId := "v3EventChannelId_example" // string | Retrieve the channel.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventChannel(context.Background(), v3EventChannelId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventChannel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventChannel`: V3EventChannelsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventChannel`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventChannelId** | **string** | Retrieve the channel. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventChannelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3EventChannelsExtended**](V3EventChannelsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventEventgroupDefinition

> V3EventEventgroupDefinitionsExtended GetEventv3EventEventgroupDefinition(ctx, v3EventEventgroupDefinitionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventEventgroupDefinitionId := "v3EventEventgroupDefinitionId_example" // string | Retrieve the eventgroup definition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventEventgroupDefinition(context.Background(), v3EventEventgroupDefinitionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventEventgroupDefinition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventEventgroupDefinition`: V3EventEventgroupDefinitionsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventEventgroupDefinition`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventEventgroupDefinitionId** | **string** | Retrieve the eventgroup definition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventEventgroupDefinitionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3EventEventgroupDefinitionsExtended**](V3EventEventgroupDefinitionsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventEventgroupDefinitions

> V3EventEventgroupDefinitions GetEventv3EventEventgroupDefinitions(ctx).Category(category).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    category := int32(56) // int32 | Return eventgroups in the specified category (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventEventgroupDefinitions(context.Background()).Category(category).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventEventgroupDefinitions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventEventgroupDefinitions`: V3EventEventgroupDefinitions
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventEventgroupDefinitions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventEventgroupDefinitionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | **int32** | Return eventgroups in the specified category | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3EventEventgroupDefinitions**](V3EventEventgroupDefinitions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventEventgroupOccurrence

> V3EventEventgroupOccurrencesExtended GetEventv3EventEventgroupOccurrence(ctx, v3EventEventgroupOccurrenceId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventEventgroupOccurrenceId := "v3EventEventgroupOccurrenceId_example" // string | Retrieve individual eventgroup occurrence.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventEventgroupOccurrence(context.Background(), v3EventEventgroupOccurrenceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventEventgroupOccurrence``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventEventgroupOccurrence`: V3EventEventgroupOccurrencesExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventEventgroupOccurrence`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventEventgroupOccurrenceId** | **string** | Retrieve individual eventgroup occurrence. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventEventgroupOccurrenceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3EventEventgroupOccurrencesExtended**](V3EventEventgroupOccurrencesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventEventgroupOccurrences

> V3EventEventgroupOccurrences GetEventv3EventEventgroupOccurrences(ctx).Resolved(resolved).Sort(sort).Begin(begin).End(end).Severity(severity).EventCount(eventCount).Devid(devid).Resume(resume).Ignore(ignore).LastEventEnd(lastEventEnd).Limit(limit).PartialCauseLong(partialCauseLong).Resolver(resolver).PartialEventgroupId(partialEventgroupId).PartialEventType(partialEventType).Cause(cause).Dir(dir).LastEventBegin(lastEventBegin).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    resolved := true // bool | Filter by resolved eventgroups. (optional)
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    begin := int32(56) // int32 | Events that are in progress after this time. (optional)
    end := int32(56) // int32 | Events that were in progress before this time. (optional)
    severity := []string{"Severity_example"} // []string | Filter by severity. (optional)
    eventCount := int32(56) // int32 | Events for which event_count > this. (optional)
    devid := []int32{int32(123)} // []int32 | Filter by devid. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    ignore := true // bool | Filter by ignored eventgroups. (optional)
    lastEventEnd := int32(56) // int32 | Filter eventgroups by those that have last_event before this time. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    partialCauseLong := "partialCauseLong_example" // string | Filter by partial long-cause description. (optional)
    resolver := "resolver_example" // string | Filter by eventgroup resolver. (optional)
    partialEventgroupId := "partialEventgroupId_example" // string | Filter by partial eventgroup id. (optional)
    partialEventType := "partialEventType_example" // string | Filter eventgroups by there associated event's event-type number. (optional)
    cause := "cause_example" // string | Filter by cause. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    lastEventBegin := int32(56) // int32 | Filter eventgroups by those that have last_event after this time. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventEventgroupOccurrences(context.Background()).Resolved(resolved).Sort(sort).Begin(begin).End(end).Severity(severity).EventCount(eventCount).Devid(devid).Resume(resume).Ignore(ignore).LastEventEnd(lastEventEnd).Limit(limit).PartialCauseLong(partialCauseLong).Resolver(resolver).PartialEventgroupId(partialEventgroupId).PartialEventType(partialEventType).Cause(cause).Dir(dir).LastEventBegin(lastEventBegin).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventEventgroupOccurrences``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventEventgroupOccurrences`: V3EventEventgroupOccurrences
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventEventgroupOccurrences`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventEventgroupOccurrencesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **resolved** | **bool** | Filter by resolved eventgroups. | 
 **sort** | **string** | The field that will be used for sorting. | 
 **begin** | **int32** | Events that are in progress after this time. | 
 **end** | **int32** | Events that were in progress before this time. | 
 **severity** | **[]string** | Filter by severity. | 
 **eventCount** | **int32** | Events for which event_count &gt; this. | 
 **devid** | **[]int32** | Filter by devid. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **ignore** | **bool** | Filter by ignored eventgroups. | 
 **lastEventEnd** | **int32** | Filter eventgroups by those that have last_event before this time. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **partialCauseLong** | **string** | Filter by partial long-cause description. | 
 **resolver** | **string** | Filter by eventgroup resolver. | 
 **partialEventgroupId** | **string** | Filter by partial eventgroup id. | 
 **partialEventType** | **string** | Filter eventgroups by there associated event&#39;s event-type number. | 
 **cause** | **string** | Filter by cause. | 
 **dir** | **string** | The direction of the sort. | 
 **lastEventBegin** | **int32** | Filter eventgroups by those that have last_event after this time. | 

### Return type

[**V3EventEventgroupOccurrences**](V3EventEventgroupOccurrences.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventEventlist

> V3EventEventlistsExtended GetEventv3EventEventlist(ctx, v3EventEventlistId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventEventlistId := "v3EventEventlistId_example" // string | Retrieve the list of events for an eventgroup occurrence.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventEventlist(context.Background(), v3EventEventlistId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventEventlist``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventEventlist`: V3EventEventlistsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventEventlist`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventEventlistId** | **string** | Retrieve the list of events for an eventgroup occurrence. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventEventlistRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3EventEventlistsExtended**](V3EventEventlistsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventEventlists

> V3EventEventlists GetEventv3EventEventlists(ctx).EventInstance(eventInstance).Limit(limit).EventgroupId(eventgroupId).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    eventInstance := "eventInstance_example" // string | Return only this event occurrence. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    eventgroupId := []int32{int32(123)} // []int32 | Filter by eventgroup id. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventEventlists(context.Background()).EventInstance(eventInstance).Limit(limit).EventgroupId(eventgroupId).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventEventlists``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventEventlists`: V3EventEventlists
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventEventlists`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventEventlistsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **eventInstance** | **string** | Return only this event occurrence. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **eventgroupId** | **[]int32** | Filter by eventgroup id. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3EventEventlists**](V3EventEventlists.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv3EventSettings

> V3EventSettings GetEventv3EventSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv3EventSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv3EventSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv3EventSettings`: V3EventSettings
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv3EventSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv3EventSettingsRequest struct via the builder pattern


### Return type

[**V3EventSettings**](V3EventSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv4EventAlertCondition

> V4EventAlertConditionsExtended GetEventv4EventAlertCondition(ctx, v4EventAlertConditionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4EventAlertConditionId := "v4EventAlertConditionId_example" // string | Retrieve the alert-condition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv4EventAlertCondition(context.Background(), v4EventAlertConditionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv4EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv4EventAlertCondition`: V4EventAlertConditionsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv4EventAlertCondition`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4EventAlertConditionId** | **string** | Retrieve the alert-condition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv4EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4EventAlertConditionsExtended**](V4EventAlertConditionsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv4EventEventgroupDefinition

> V4EventEventgroupDefinitionsExtended GetEventv4EventEventgroupDefinition(ctx, v4EventEventgroupDefinitionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4EventEventgroupDefinitionId := "v4EventEventgroupDefinitionId_example" // string | Retrieve the eventgroup definition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv4EventEventgroupDefinition(context.Background(), v4EventEventgroupDefinitionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv4EventEventgroupDefinition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv4EventEventgroupDefinition`: V4EventEventgroupDefinitionsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv4EventEventgroupDefinition`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4EventEventgroupDefinitionId** | **string** | Retrieve the eventgroup definition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv4EventEventgroupDefinitionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4EventEventgroupDefinitionsExtended**](V4EventEventgroupDefinitionsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv4EventEventgroupDefinitions

> V4EventEventgroupDefinitions GetEventv4EventEventgroupDefinitions(ctx).Category(category).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    category := int32(56) // int32 | Return eventgroups in the specified category (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv4EventEventgroupDefinitions(context.Background()).Category(category).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv4EventEventgroupDefinitions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv4EventEventgroupDefinitions`: V4EventEventgroupDefinitions
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv4EventEventgroupDefinitions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv4EventEventgroupDefinitionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | **int32** | Return eventgroups in the specified category | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V4EventEventgroupDefinitions**](V4EventEventgroupDefinitions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv7EventChannel

> V3EventChannelsExtended GetEventv7EventChannel(ctx, v7EventChannelId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7EventChannelId := "v7EventChannelId_example" // string | Retrieve the channel.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv7EventChannel(context.Background(), v7EventChannelId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv7EventChannel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv7EventChannel`: V3EventChannelsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv7EventChannel`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7EventChannelId** | **string** | Retrieve the channel. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv7EventChannelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3EventChannelsExtended**](V3EventChannelsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv7EventEventlist

> V7EventEventlistsExtended GetEventv7EventEventlist(ctx, v7EventEventlistId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7EventEventlistId := "v7EventEventlistId_example" // string | Retrieve the list of events for an eventgroup occurrence.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv7EventEventlist(context.Background(), v7EventEventlistId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv7EventEventlist``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv7EventEventlist`: V7EventEventlistsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv7EventEventlist`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7EventEventlistId** | **string** | Retrieve the list of events for an eventgroup occurrence. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv7EventEventlistRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7EventEventlistsExtended**](V7EventEventlistsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv7EventEventlists

> V7EventEventlists GetEventv7EventEventlists(ctx).EventInstance(eventInstance).Limit(limit).EventgroupId(eventgroupId).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    eventInstance := "eventInstance_example" // string | Return only this event occurrence (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    eventgroupId := []int32{int32(123)} // []int32 | Filter by eventgroup id. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv7EventEventlists(context.Background()).EventInstance(eventInstance).Limit(limit).EventgroupId(eventgroupId).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv7EventEventlists``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv7EventEventlists`: V7EventEventlists
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv7EventEventlists`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv7EventEventlistsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **eventInstance** | **string** | Return only this event occurrence | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **eventgroupId** | **[]int32** | Filter by eventgroup id. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7EventEventlists**](V7EventEventlists.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv9EventEventgroupDefinition

> V9EventEventgroupDefinitionsExtended GetEventv9EventEventgroupDefinition(ctx, v9EventEventgroupDefinitionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9EventEventgroupDefinitionId := "v9EventEventgroupDefinitionId_example" // string | Retrieve the eventgroup definition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv9EventEventgroupDefinition(context.Background(), v9EventEventgroupDefinitionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv9EventEventgroupDefinition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv9EventEventgroupDefinition`: V9EventEventgroupDefinitionsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv9EventEventgroupDefinition`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9EventEventgroupDefinitionId** | **string** | Retrieve the eventgroup definition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv9EventEventgroupDefinitionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V9EventEventgroupDefinitionsExtended**](V9EventEventgroupDefinitionsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetEventv9EventEventgroupDefinitions

> V9EventEventgroupDefinitions GetEventv9EventEventgroupDefinitions(ctx).Category(category).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    category := int32(56) // int32 | Return eventgroups in the specified category (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.GetEventv9EventEventgroupDefinitions(context.Background()).Category(category).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.GetEventv9EventEventgroupDefinitions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetEventv9EventEventgroupDefinitions`: V9EventEventgroupDefinitions
    fmt.Fprintf(os.Stdout, "Response from `EventApi.GetEventv9EventEventgroupDefinitions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetEventv9EventEventgroupDefinitionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **category** | **int32** | Return eventgroups in the specified category | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V9EventEventgroupDefinitions**](V9EventEventgroupDefinitions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListEventv12EventChannels

> V12EventChannelsExtended ListEventv12EventChannels(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.ListEventv12EventChannels(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.ListEventv12EventChannels``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListEventv12EventChannels`: V12EventChannelsExtended
    fmt.Fprintf(os.Stdout, "Response from `EventApi.ListEventv12EventChannels`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListEventv12EventChannelsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V12EventChannelsExtended**](V12EventChannelsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListEventv15EventAlertConditions

> V15EventAlertConditions ListEventv15EventAlertConditions(ctx).Channels(channels).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    channels := "channels_example" // string | Return only conditions for the specified channel: (optional)
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.ListEventv15EventAlertConditions(context.Background()).Channels(channels).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.ListEventv15EventAlertConditions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListEventv15EventAlertConditions`: V15EventAlertConditions
    fmt.Fprintf(os.Stdout, "Response from `EventApi.ListEventv15EventAlertConditions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListEventv15EventAlertConditionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **channels** | **string** | Return only conditions for the specified channel: | 
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V15EventAlertConditions**](V15EventAlertConditions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListEventv3EventAlertConditions

> V3EventAlertConditions ListEventv3EventAlertConditions(ctx).Sort(sort).ChannelIds(channelIds).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    channelIds := "channelIds_example" // string | Return only conditions for the specified channel: (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.ListEventv3EventAlertConditions(context.Background()).Sort(sort).ChannelIds(channelIds).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.ListEventv3EventAlertConditions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListEventv3EventAlertConditions`: V3EventAlertConditions
    fmt.Fprintf(os.Stdout, "Response from `EventApi.ListEventv3EventAlertConditions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListEventv3EventAlertConditionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **channelIds** | **string** | Return only conditions for the specified channel: | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3EventAlertConditions**](V3EventAlertConditions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListEventv3EventChannels

> V3EventChannels ListEventv3EventChannels(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.ListEventv3EventChannels(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.ListEventv3EventChannels``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListEventv3EventChannels`: V3EventChannels
    fmt.Fprintf(os.Stdout, "Response from `EventApi.ListEventv3EventChannels`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListEventv3EventChannelsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3EventChannels**](V3EventChannels.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListEventv4EventAlertConditions

> V4EventAlertConditions ListEventv4EventAlertConditions(ctx).Channels(channels).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    channels := "channels_example" // string | Return only conditions for the specified channel: (optional)
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.ListEventv4EventAlertConditions(context.Background()).Channels(channels).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.ListEventv4EventAlertConditions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListEventv4EventAlertConditions`: V4EventAlertConditions
    fmt.Fprintf(os.Stdout, "Response from `EventApi.ListEventv4EventAlertConditions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListEventv4EventAlertConditionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **channels** | **string** | Return only conditions for the specified channel: | 
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V4EventAlertConditions**](V4EventAlertConditions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListEventv7EventChannels

> V7EventChannels ListEventv7EventChannels(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.EventApi.ListEventv7EventChannels(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.ListEventv7EventChannels``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListEventv7EventChannels`: V7EventChannels
    fmt.Fprintf(os.Stdout, "Response from `EventApi.ListEventv7EventChannels`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListEventv7EventChannelsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7EventChannels**](V7EventChannels.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv11EventThreshold

> UpdateEventv11EventThreshold(ctx, v11EventThresholdId).V11EventThreshold(v11EventThreshold).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11EventThresholdId := "v11EventThresholdId_example" // string | Modify event thresholds.
    v11EventThreshold := *openapiclient.NewV11EventThresholdExtended() // V11EventThresholdExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv11EventThreshold(context.Background(), v11EventThresholdId).V11EventThreshold(v11EventThreshold).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv11EventThreshold``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11EventThresholdId** | **string** | Modify event thresholds. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv11EventThresholdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v11EventThreshold** | [**V11EventThresholdExtended**](V11EventThresholdExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv12EventChannel

> UpdateEventv12EventChannel(ctx, v12EventChannelId).V12EventChannel(v12EventChannel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventChannelId := "v12EventChannelId_example" // string | Modify the channel.
    v12EventChannel := *openapiclient.NewV12EventChannelExtended() // V12EventChannelExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv12EventChannel(context.Background(), v12EventChannelId).V12EventChannel(v12EventChannel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv12EventChannel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12EventChannelId** | **string** | Modify the channel. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv12EventChannelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12EventChannel** | [**V12EventChannelExtended**](V12EventChannelExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv12EventEventgroupOccurrence

> UpdateEventv12EventEventgroupOccurrence(ctx, v12EventEventgroupOccurrenceId).V12EventEventgroupOccurrence(v12EventEventgroupOccurrence).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventEventgroupOccurrenceId := "v12EventEventgroupOccurrenceId_example" // string | Modify eventgroup occurrence.
    v12EventEventgroupOccurrence := *openapiclient.NewV12EventEventgroupOccurrencesExtended() // V12EventEventgroupOccurrencesExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv12EventEventgroupOccurrence(context.Background(), v12EventEventgroupOccurrenceId).V12EventEventgroupOccurrence(v12EventEventgroupOccurrence).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv12EventEventgroupOccurrence``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12EventEventgroupOccurrenceId** | **string** | Modify eventgroup occurrence. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv12EventEventgroupOccurrenceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12EventEventgroupOccurrence** | [**V12EventEventgroupOccurrencesExtended**](V12EventEventgroupOccurrencesExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv12EventEventgroupOccurrences

> UpdateEventv12EventEventgroupOccurrences(ctx).V12EventEventgroupOccurrences(v12EventEventgroupOccurrences).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventEventgroupOccurrences := *openapiclient.NewV12EventEventgroupOccurrencesExtended() // V12EventEventgroupOccurrencesExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv12EventEventgroupOccurrences(context.Background()).V12EventEventgroupOccurrences(v12EventEventgroupOccurrences).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv12EventEventgroupOccurrences``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv12EventEventgroupOccurrencesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12EventEventgroupOccurrences** | [**V12EventEventgroupOccurrencesExtended**](V12EventEventgroupOccurrencesExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv12EventMaintenance

> UpdateEventv12EventMaintenance(ctx).V12EventMaintenance(v12EventMaintenance).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventMaintenance := *openapiclient.NewV12EventMaintenanceExtended() // V12EventMaintenanceExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv12EventMaintenance(context.Background()).V12EventMaintenance(v12EventMaintenance).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv12EventMaintenance``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv12EventMaintenanceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12EventMaintenance** | [**V12EventMaintenanceExtended**](V12EventMaintenanceExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv12EventSettings

> UpdateEventv12EventSettings(ctx).V12EventSettings(v12EventSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventSettings := *openapiclient.NewV12EventSettingsSettings() // V12EventSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv12EventSettings(context.Background()).V12EventSettings(v12EventSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv12EventSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv12EventSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12EventSettings** | [**V12EventSettingsSettings**](V12EventSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv12EventSuppressById

> UpdateEventv12EventSuppressById(ctx, v12EventSuppressId).V12EventSuppressIdParams(v12EventSuppressIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12EventSuppressId := "v12EventSuppressId_example" // string | Suppress or un-suppress this event type ID.
    v12EventSuppressIdParams := *openapiclient.NewV12EventSuppressIdParams() // V12EventSuppressIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv12EventSuppressById(context.Background(), v12EventSuppressId).V12EventSuppressIdParams(v12EventSuppressIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv12EventSuppressById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12EventSuppressId** | **string** | Suppress or un-suppress this event type ID. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv12EventSuppressByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12EventSuppressIdParams** | [**V12EventSuppressIdParams**](V12EventSuppressIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv14EventSettings

> UpdateEventv14EventSettings(ctx).V14EventSettings(v14EventSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14EventSettings := *openapiclient.NewV14EventSettingsSettings() // V14EventSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv14EventSettings(context.Background()).V14EventSettings(v14EventSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv14EventSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv14EventSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14EventSettings** | [**V14EventSettingsSettings**](V14EventSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv15EventAlertCondition

> UpdateEventv15EventAlertCondition(ctx, v15EventAlertConditionId).V15EventAlertCondition(v15EventAlertCondition).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15EventAlertConditionId := "v15EventAlertConditionId_example" // string | Modify the alert-condition
    v15EventAlertCondition := *openapiclient.NewV15EventAlertConditionExtended() // V15EventAlertConditionExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv15EventAlertCondition(context.Background(), v15EventAlertConditionId).V15EventAlertCondition(v15EventAlertCondition).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv15EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15EventAlertConditionId** | **string** | Modify the alert-condition | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv15EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v15EventAlertCondition** | [**V15EventAlertConditionExtended**](V15EventAlertConditionExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv3EventAlertCondition

> UpdateEventv3EventAlertCondition(ctx, v3EventAlertConditionId).V3EventAlertCondition(v3EventAlertCondition).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventAlertConditionId := "v3EventAlertConditionId_example" // string | Modify the alert-condition
    v3EventAlertCondition := *openapiclient.NewV3EventAlertConditionExtended() // V3EventAlertConditionExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv3EventAlertCondition(context.Background(), v3EventAlertConditionId).V3EventAlertCondition(v3EventAlertCondition).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv3EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventAlertConditionId** | **string** | Modify the alert-condition | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv3EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3EventAlertCondition** | [**V3EventAlertConditionExtended**](V3EventAlertConditionExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv3EventChannel

> UpdateEventv3EventChannel(ctx, v3EventChannelId).V3EventChannel(v3EventChannel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventChannelId := "v3EventChannelId_example" // string | Modify the channel.
    v3EventChannel := *openapiclient.NewV12EventChannelExtended() // V12EventChannelExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv3EventChannel(context.Background(), v3EventChannelId).V3EventChannel(v3EventChannel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv3EventChannel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventChannelId** | **string** | Modify the channel. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv3EventChannelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3EventChannel** | [**V12EventChannelExtended**](V12EventChannelExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv3EventEventgroupOccurrence

> UpdateEventv3EventEventgroupOccurrence(ctx, v3EventEventgroupOccurrenceId).V3EventEventgroupOccurrence(v3EventEventgroupOccurrence).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventEventgroupOccurrenceId := "v3EventEventgroupOccurrenceId_example" // string | modify eventgroup occurrence.
    v3EventEventgroupOccurrence := *openapiclient.NewV12EventEventgroupOccurrencesExtended() // V12EventEventgroupOccurrencesExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv3EventEventgroupOccurrence(context.Background(), v3EventEventgroupOccurrenceId).V3EventEventgroupOccurrence(v3EventEventgroupOccurrence).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv3EventEventgroupOccurrence``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3EventEventgroupOccurrenceId** | **string** | modify eventgroup occurrence. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv3EventEventgroupOccurrenceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3EventEventgroupOccurrence** | [**V12EventEventgroupOccurrencesExtended**](V12EventEventgroupOccurrencesExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv3EventEventgroupOccurrences

> UpdateEventv3EventEventgroupOccurrences(ctx).V3EventEventgroupOccurrences(v3EventEventgroupOccurrences).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventEventgroupOccurrences := *openapiclient.NewV12EventEventgroupOccurrencesExtended() // V12EventEventgroupOccurrencesExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv3EventEventgroupOccurrences(context.Background()).V3EventEventgroupOccurrences(v3EventEventgroupOccurrences).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv3EventEventgroupOccurrences``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv3EventEventgroupOccurrencesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3EventEventgroupOccurrences** | [**V12EventEventgroupOccurrencesExtended**](V12EventEventgroupOccurrencesExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv3EventSettings

> UpdateEventv3EventSettings(ctx).V3EventSettings(v3EventSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3EventSettings := *openapiclient.NewV3EventSettingsSettings() // V3EventSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv3EventSettings(context.Background()).V3EventSettings(v3EventSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv3EventSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv3EventSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3EventSettings** | [**V3EventSettingsSettings**](V3EventSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv4EventAlertCondition

> UpdateEventv4EventAlertCondition(ctx, v4EventAlertConditionId).V4EventAlertCondition(v4EventAlertCondition).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4EventAlertConditionId := "v4EventAlertConditionId_example" // string | Modify the alert-condition
    v4EventAlertCondition := *openapiclient.NewV4EventAlertConditionExtended() // V4EventAlertConditionExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv4EventAlertCondition(context.Background(), v4EventAlertConditionId).V4EventAlertCondition(v4EventAlertCondition).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv4EventAlertCondition``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4EventAlertConditionId** | **string** | Modify the alert-condition | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv4EventAlertConditionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v4EventAlertCondition** | [**V4EventAlertConditionExtended**](V4EventAlertConditionExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateEventv7EventChannel

> UpdateEventv7EventChannel(ctx, v7EventChannelId).V7EventChannel(v7EventChannel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7EventChannelId := "v7EventChannelId_example" // string | Modify the channel.
    v7EventChannel := *openapiclient.NewV12EventChannelExtended() // V12EventChannelExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.EventApi.UpdateEventv7EventChannel(context.Background(), v7EventChannelId).V7EventChannel(v7EventChannel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `EventApi.UpdateEventv7EventChannel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7EventChannelId** | **string** | Modify the channel. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateEventv7EventChannelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7EventChannel** | [**V12EventChannelExtended**](V12EventChannelExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

