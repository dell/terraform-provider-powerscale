# V14AuthIdNtoken

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AdditionalId** | Pointer to [**[]V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) | Specifies additional UIDs, GIDs, and SIDs. | [optional] 
**Gid** | Pointer to [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | [optional] 
**GroupSid** | Pointer to [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | [optional] 
**IfsRestricted** | Pointer to **bool** | Indicates if this user has restricted access to the /ifs file system. | [optional] 
**LocalAddress** | Pointer to **string** | Specifies the IP address of the node that is serving the request. | [optional] 
**OnDiskGroupId** | Pointer to [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | [optional] 
**OnDiskUserId** | Pointer to [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | [optional] 
**Privilege** | Pointer to [**[]V14AuthIdNtokenPrivilegeItem**](V14AuthIdNtokenPrivilegeItem.md) | Specifies the privileges granted to the currently authenticated user. | [optional] 
**Protocol** | Pointer to **int32** | Specifies the protocol that is responsible for the creation of the token. The integer values for each protocol are as follows: NFS (1), SMB (2), NLM (3), FTP (4), HTTP (5), ISCSI (7), SMB2 (8), NFS4 (9), OneFS API (10), HDFS (15), console (16), and SSH (17). | [optional] 
**RemoteAddress** | Pointer to **string** | Specifies the IP address of the client requesting information. | [optional] 
**Uid** | Pointer to [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | [optional] 
**UserSid** | Pointer to [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | [optional] 
**Zid** | Pointer to **int32** | Specifies the zone ID of the access zone that is serving the request. | [optional] 
**ZoneId** | Pointer to **string** | Specifies the name of the access zone that is serving the request. | [optional] 

## Methods

### NewV14AuthIdNtoken

`func NewV14AuthIdNtoken() *V14AuthIdNtoken`

NewV14AuthIdNtoken instantiates a new V14AuthIdNtoken object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14AuthIdNtokenWithDefaults

`func NewV14AuthIdNtokenWithDefaults() *V14AuthIdNtoken`

NewV14AuthIdNtokenWithDefaults instantiates a new V14AuthIdNtoken object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAdditionalId

`func (o *V14AuthIdNtoken) GetAdditionalId() []V1AuthAccessAccessItemFileGroup`

GetAdditionalId returns the AdditionalId field if non-nil, zero value otherwise.

### GetAdditionalIdOk

`func (o *V14AuthIdNtoken) GetAdditionalIdOk() (*[]V1AuthAccessAccessItemFileGroup, bool)`

GetAdditionalIdOk returns a tuple with the AdditionalId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAdditionalId

`func (o *V14AuthIdNtoken) SetAdditionalId(v []V1AuthAccessAccessItemFileGroup)`

SetAdditionalId sets AdditionalId field to given value.

### HasAdditionalId

`func (o *V14AuthIdNtoken) HasAdditionalId() bool`

HasAdditionalId returns a boolean if a field has been set.

### GetGid

`func (o *V14AuthIdNtoken) GetGid() V1AuthAccessAccessItemFileGroup`

GetGid returns the Gid field if non-nil, zero value otherwise.

### GetGidOk

`func (o *V14AuthIdNtoken) GetGidOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetGidOk returns a tuple with the Gid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGid

`func (o *V14AuthIdNtoken) SetGid(v V1AuthAccessAccessItemFileGroup)`

SetGid sets Gid field to given value.

### HasGid

`func (o *V14AuthIdNtoken) HasGid() bool`

HasGid returns a boolean if a field has been set.

### GetGroupSid

`func (o *V14AuthIdNtoken) GetGroupSid() V1AuthAccessAccessItemFileGroup`

GetGroupSid returns the GroupSid field if non-nil, zero value otherwise.

### GetGroupSidOk

`func (o *V14AuthIdNtoken) GetGroupSidOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetGroupSidOk returns a tuple with the GroupSid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupSid

`func (o *V14AuthIdNtoken) SetGroupSid(v V1AuthAccessAccessItemFileGroup)`

SetGroupSid sets GroupSid field to given value.

### HasGroupSid

`func (o *V14AuthIdNtoken) HasGroupSid() bool`

HasGroupSid returns a boolean if a field has been set.

### GetIfsRestricted

`func (o *V14AuthIdNtoken) GetIfsRestricted() bool`

GetIfsRestricted returns the IfsRestricted field if non-nil, zero value otherwise.

### GetIfsRestrictedOk

`func (o *V14AuthIdNtoken) GetIfsRestrictedOk() (*bool, bool)`

GetIfsRestrictedOk returns a tuple with the IfsRestricted field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIfsRestricted

`func (o *V14AuthIdNtoken) SetIfsRestricted(v bool)`

SetIfsRestricted sets IfsRestricted field to given value.

### HasIfsRestricted

`func (o *V14AuthIdNtoken) HasIfsRestricted() bool`

HasIfsRestricted returns a boolean if a field has been set.

### GetLocalAddress

`func (o *V14AuthIdNtoken) GetLocalAddress() string`

GetLocalAddress returns the LocalAddress field if non-nil, zero value otherwise.

### GetLocalAddressOk

`func (o *V14AuthIdNtoken) GetLocalAddressOk() (*string, bool)`

GetLocalAddressOk returns a tuple with the LocalAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocalAddress

`func (o *V14AuthIdNtoken) SetLocalAddress(v string)`

SetLocalAddress sets LocalAddress field to given value.

### HasLocalAddress

`func (o *V14AuthIdNtoken) HasLocalAddress() bool`

HasLocalAddress returns a boolean if a field has been set.

### GetOnDiskGroupId

`func (o *V14AuthIdNtoken) GetOnDiskGroupId() V1AuthAccessAccessItemFileGroup`

GetOnDiskGroupId returns the OnDiskGroupId field if non-nil, zero value otherwise.

### GetOnDiskGroupIdOk

`func (o *V14AuthIdNtoken) GetOnDiskGroupIdOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetOnDiskGroupIdOk returns a tuple with the OnDiskGroupId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnDiskGroupId

`func (o *V14AuthIdNtoken) SetOnDiskGroupId(v V1AuthAccessAccessItemFileGroup)`

SetOnDiskGroupId sets OnDiskGroupId field to given value.

### HasOnDiskGroupId

`func (o *V14AuthIdNtoken) HasOnDiskGroupId() bool`

HasOnDiskGroupId returns a boolean if a field has been set.

### GetOnDiskUserId

`func (o *V14AuthIdNtoken) GetOnDiskUserId() V1AuthAccessAccessItemFileGroup`

GetOnDiskUserId returns the OnDiskUserId field if non-nil, zero value otherwise.

### GetOnDiskUserIdOk

`func (o *V14AuthIdNtoken) GetOnDiskUserIdOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetOnDiskUserIdOk returns a tuple with the OnDiskUserId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnDiskUserId

`func (o *V14AuthIdNtoken) SetOnDiskUserId(v V1AuthAccessAccessItemFileGroup)`

SetOnDiskUserId sets OnDiskUserId field to given value.

### HasOnDiskUserId

`func (o *V14AuthIdNtoken) HasOnDiskUserId() bool`

HasOnDiskUserId returns a boolean if a field has been set.

### GetPrivilege

`func (o *V14AuthIdNtoken) GetPrivilege() []V14AuthIdNtokenPrivilegeItem`

GetPrivilege returns the Privilege field if non-nil, zero value otherwise.

### GetPrivilegeOk

`func (o *V14AuthIdNtoken) GetPrivilegeOk() (*[]V14AuthIdNtokenPrivilegeItem, bool)`

GetPrivilegeOk returns a tuple with the Privilege field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrivilege

`func (o *V14AuthIdNtoken) SetPrivilege(v []V14AuthIdNtokenPrivilegeItem)`

SetPrivilege sets Privilege field to given value.

### HasPrivilege

`func (o *V14AuthIdNtoken) HasPrivilege() bool`

HasPrivilege returns a boolean if a field has been set.

### GetProtocol

`func (o *V14AuthIdNtoken) GetProtocol() int32`

GetProtocol returns the Protocol field if non-nil, zero value otherwise.

### GetProtocolOk

`func (o *V14AuthIdNtoken) GetProtocolOk() (*int32, bool)`

GetProtocolOk returns a tuple with the Protocol field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProtocol

`func (o *V14AuthIdNtoken) SetProtocol(v int32)`

SetProtocol sets Protocol field to given value.

### HasProtocol

`func (o *V14AuthIdNtoken) HasProtocol() bool`

HasProtocol returns a boolean if a field has been set.

### GetRemoteAddress

`func (o *V14AuthIdNtoken) GetRemoteAddress() string`

GetRemoteAddress returns the RemoteAddress field if non-nil, zero value otherwise.

### GetRemoteAddressOk

`func (o *V14AuthIdNtoken) GetRemoteAddressOk() (*string, bool)`

GetRemoteAddressOk returns a tuple with the RemoteAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteAddress

`func (o *V14AuthIdNtoken) SetRemoteAddress(v string)`

SetRemoteAddress sets RemoteAddress field to given value.

### HasRemoteAddress

`func (o *V14AuthIdNtoken) HasRemoteAddress() bool`

HasRemoteAddress returns a boolean if a field has been set.

### GetUid

`func (o *V14AuthIdNtoken) GetUid() V1AuthAccessAccessItemFileGroup`

GetUid returns the Uid field if non-nil, zero value otherwise.

### GetUidOk

`func (o *V14AuthIdNtoken) GetUidOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetUidOk returns a tuple with the Uid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUid

`func (o *V14AuthIdNtoken) SetUid(v V1AuthAccessAccessItemFileGroup)`

SetUid sets Uid field to given value.

### HasUid

`func (o *V14AuthIdNtoken) HasUid() bool`

HasUid returns a boolean if a field has been set.

### GetUserSid

`func (o *V14AuthIdNtoken) GetUserSid() V1AuthAccessAccessItemFileGroup`

GetUserSid returns the UserSid field if non-nil, zero value otherwise.

### GetUserSidOk

`func (o *V14AuthIdNtoken) GetUserSidOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetUserSidOk returns a tuple with the UserSid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserSid

`func (o *V14AuthIdNtoken) SetUserSid(v V1AuthAccessAccessItemFileGroup)`

SetUserSid sets UserSid field to given value.

### HasUserSid

`func (o *V14AuthIdNtoken) HasUserSid() bool`

HasUserSid returns a boolean if a field has been set.

### GetZid

`func (o *V14AuthIdNtoken) GetZid() int32`

GetZid returns the Zid field if non-nil, zero value otherwise.

### GetZidOk

`func (o *V14AuthIdNtoken) GetZidOk() (*int32, bool)`

GetZidOk returns a tuple with the Zid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZid

`func (o *V14AuthIdNtoken) SetZid(v int32)`

SetZid sets Zid field to given value.

### HasZid

`func (o *V14AuthIdNtoken) HasZid() bool`

HasZid returns a boolean if a field has been set.

### GetZoneId

`func (o *V14AuthIdNtoken) GetZoneId() string`

GetZoneId returns the ZoneId field if non-nil, zero value otherwise.

### GetZoneIdOk

`func (o *V14AuthIdNtoken) GetZoneIdOk() (*string, bool)`

GetZoneIdOk returns a tuple with the ZoneId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZoneId

`func (o *V14AuthIdNtoken) SetZoneId(v string)`

SetZoneId sets ZoneId field to given value.

### HasZoneId

`func (o *V14AuthIdNtoken) HasZoneId() bool`

HasZoneId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


