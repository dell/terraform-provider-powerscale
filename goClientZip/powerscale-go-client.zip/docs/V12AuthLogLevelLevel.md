# V12AuthLogLevelLevel

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LsassLevel** | Pointer to **string** | Valid auth logging levels | [optional] 
**NetlogonLevel** | Pointer to **string** | Valid auth logging levels | [optional] 

## Methods

### NewV12AuthLogLevelLevel

`func NewV12AuthLogLevelLevel() *V12AuthLogLevelLevel`

NewV12AuthLogLevelLevel instantiates a new V12AuthLogLevelLevel object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12AuthLogLevelLevelWithDefaults

`func NewV12AuthLogLevelLevelWithDefaults() *V12AuthLogLevelLevel`

NewV12AuthLogLevelLevelWithDefaults instantiates a new V12AuthLogLevelLevel object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLsassLevel

`func (o *V12AuthLogLevelLevel) GetLsassLevel() string`

GetLsassLevel returns the LsassLevel field if non-nil, zero value otherwise.

### GetLsassLevelOk

`func (o *V12AuthLogLevelLevel) GetLsassLevelOk() (*string, bool)`

GetLsassLevelOk returns a tuple with the LsassLevel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLsassLevel

`func (o *V12AuthLogLevelLevel) SetLsassLevel(v string)`

SetLsassLevel sets LsassLevel field to given value.

### HasLsassLevel

`func (o *V12AuthLogLevelLevel) HasLsassLevel() bool`

HasLsassLevel returns a boolean if a field has been set.

### GetNetlogonLevel

`func (o *V12AuthLogLevelLevel) GetNetlogonLevel() string`

GetNetlogonLevel returns the NetlogonLevel field if non-nil, zero value otherwise.

### GetNetlogonLevelOk

`func (o *V12AuthLogLevelLevel) GetNetlogonLevelOk() (*string, bool)`

GetNetlogonLevelOk returns a tuple with the NetlogonLevel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetlogonLevel

`func (o *V12AuthLogLevelLevel) SetNetlogonLevel(v string)`

SetNetlogonLevel sets NetlogonLevel field to given value.

### HasNetlogonLevel

`func (o *V12AuthLogLevelLevel) HasNetlogonLevel() bool`

HasNetlogonLevel returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


