# \AuthApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateAuthv11ProvidersLdapItem**](AuthApi.md#CreateAuthv11ProvidersLdapItem) | **Post** /platform/11/auth/providers/ldap | 
[**CreateAuthv1AuthGroup**](AuthApi.md#CreateAuthv1AuthGroup) | **Post** /platform/1/auth/groups | 
[**CreateAuthv1AuthRole**](AuthApi.md#CreateAuthv1AuthRole) | **Post** /platform/1/auth/roles | 
[**CreateAuthv1AuthUser**](AuthApi.md#CreateAuthv1AuthUser) | **Post** /platform/1/auth/users | 
[**CreateAuthv1MappingIdentities**](AuthApi.md#CreateAuthv1MappingIdentities) | **Post** /platform/1/auth/mapping/identities | 
[**CreateAuthv1MappingIdentity**](AuthApi.md#CreateAuthv1MappingIdentity) | **Post** /platform/1/auth/mapping/identities/{v1MappingIdentityId} | 
[**CreateAuthv1ProvidersAdsItem**](AuthApi.md#CreateAuthv1ProvidersAdsItem) | **Post** /platform/1/auth/providers/ads | 
[**CreateAuthv1ProvidersFileItem**](AuthApi.md#CreateAuthv1ProvidersFileItem) | **Post** /platform/1/auth/providers/file | 
[**CreateAuthv1ProvidersKrb5Item**](AuthApi.md#CreateAuthv1ProvidersKrb5Item) | **Post** /platform/1/auth/providers/krb5 | 
[**CreateAuthv1ProvidersLdapItem**](AuthApi.md#CreateAuthv1ProvidersLdapItem) | **Post** /platform/1/auth/providers/ldap | 
[**CreateAuthv1ProvidersNisItem**](AuthApi.md#CreateAuthv1ProvidersNisItem) | **Post** /platform/1/auth/providers/nis | 
[**CreateAuthv1SettingsKrb5Domain**](AuthApi.md#CreateAuthv1SettingsKrb5Domain) | **Post** /platform/1/auth/settings/krb5/domains | 
[**CreateAuthv1SettingsKrb5Realm**](AuthApi.md#CreateAuthv1SettingsKrb5Realm) | **Post** /platform/1/auth/settings/krb5/realms | 
[**CreateAuthv3AuthRefreshItem**](AuthApi.md#CreateAuthv3AuthRefreshItem) | **Post** /platform/3/auth/refresh | 
[**CreateAuthv3ProvidersAdsItem**](AuthApi.md#CreateAuthv3ProvidersAdsItem) | **Post** /platform/3/auth/providers/ads | 
[**CreateAuthv3ProvidersKrb5Item**](AuthApi.md#CreateAuthv3ProvidersKrb5Item) | **Post** /platform/3/auth/providers/krb5 | 
[**CreateAuthv3ProvidersLdapItem**](AuthApi.md#CreateAuthv3ProvidersLdapItem) | **Post** /platform/3/auth/providers/ldap | 
[**CreateAuthv3ProvidersNisItem**](AuthApi.md#CreateAuthv3ProvidersNisItem) | **Post** /platform/3/auth/providers/nis | 
[**CreateAuthv4AuthCacheItem**](AuthApi.md#CreateAuthv4AuthCacheItem) | **Post** /platform/4/auth/cache | 
[**CreateAuthv4ProvidersLdapItem**](AuthApi.md#CreateAuthv4ProvidersLdapItem) | **Post** /platform/4/auth/providers/ldap | 
[**CreateAuthv7AuthRole**](AuthApi.md#CreateAuthv7AuthRole) | **Post** /platform/7/auth/roles | 
[**CreateAuthv7AuthUser**](AuthApi.md#CreateAuthv7AuthUser) | **Post** /platform/7/auth/users | 
[**CreateAuthv7ProvidersAdsItem**](AuthApi.md#CreateAuthv7ProvidersAdsItem) | **Post** /platform/7/auth/providers/ads | 
[**CreateAuthv7ProvidersFileItem**](AuthApi.md#CreateAuthv7ProvidersFileItem) | **Post** /platform/7/auth/providers/file | 
[**CreateAuthv7ProvidersKrb5Item**](AuthApi.md#CreateAuthv7ProvidersKrb5Item) | **Post** /platform/7/auth/providers/krb5 | 
[**CreateAuthv7ProvidersLdapItem**](AuthApi.md#CreateAuthv7ProvidersLdapItem) | **Post** /platform/7/auth/providers/ldap | 
[**CreateAuthv7ProvidersNisItem**](AuthApi.md#CreateAuthv7ProvidersNisItem) | **Post** /platform/7/auth/providers/nis | 
[**DeleteAuthv11ProvidersLdapById**](AuthApi.md#DeleteAuthv11ProvidersLdapById) | **Delete** /platform/11/auth/providers/ldap/{v11ProvidersLdapId} | 
[**DeleteAuthv1AuthGroup**](AuthApi.md#DeleteAuthv1AuthGroup) | **Delete** /platform/1/auth/groups/{v1AuthGroupId} | 
[**DeleteAuthv1AuthGroups**](AuthApi.md#DeleteAuthv1AuthGroups) | **Delete** /platform/1/auth/groups | 
[**DeleteAuthv1AuthRole**](AuthApi.md#DeleteAuthv1AuthRole) | **Delete** /platform/1/auth/roles/{v1AuthRoleId} | 
[**DeleteAuthv1AuthUser**](AuthApi.md#DeleteAuthv1AuthUser) | **Delete** /platform/1/auth/users/{v1AuthUserId} | 
[**DeleteAuthv1AuthUsers**](AuthApi.md#DeleteAuthv1AuthUsers) | **Delete** /platform/1/auth/users | 
[**DeleteAuthv1GroupsGroupMember**](AuthApi.md#DeleteAuthv1GroupsGroupMember) | **Delete** /platform/1/auth/groups/{Group}/members/{v1GroupsGroupMemberId} | 
[**DeleteAuthv1MappingIdentities**](AuthApi.md#DeleteAuthv1MappingIdentities) | **Delete** /platform/1/auth/mapping/identities | 
[**DeleteAuthv1MappingIdentity**](AuthApi.md#DeleteAuthv1MappingIdentity) | **Delete** /platform/1/auth/mapping/identities/{v1MappingIdentityId} | 
[**DeleteAuthv1ProvidersAdsById**](AuthApi.md#DeleteAuthv1ProvidersAdsById) | **Delete** /platform/1/auth/providers/ads/{v1ProvidersAdsId} | 
[**DeleteAuthv1ProvidersFileById**](AuthApi.md#DeleteAuthv1ProvidersFileById) | **Delete** /platform/1/auth/providers/file/{v1ProvidersFileId} | 
[**DeleteAuthv1ProvidersKrb5ById**](AuthApi.md#DeleteAuthv1ProvidersKrb5ById) | **Delete** /platform/1/auth/providers/krb5/{v1ProvidersKrb5Id} | 
[**DeleteAuthv1ProvidersLdapById**](AuthApi.md#DeleteAuthv1ProvidersLdapById) | **Delete** /platform/1/auth/providers/ldap/{v1ProvidersLdapId} | 
[**DeleteAuthv1ProvidersNisById**](AuthApi.md#DeleteAuthv1ProvidersNisById) | **Delete** /platform/1/auth/providers/nis/{v1ProvidersNisId} | 
[**DeleteAuthv1RolesRoleMember**](AuthApi.md#DeleteAuthv1RolesRoleMember) | **Delete** /platform/1/auth/roles/{Role}/members/{v1RolesRoleMemberId} | 
[**DeleteAuthv1RolesRolePrivilege**](AuthApi.md#DeleteAuthv1RolesRolePrivilege) | **Delete** /platform/1/auth/roles/{Role}/privileges/{v1RolesRolePrivilegeId} | 
[**DeleteAuthv1SettingsKrb5Domain**](AuthApi.md#DeleteAuthv1SettingsKrb5Domain) | **Delete** /platform/1/auth/settings/krb5/domains/{v1SettingsKrb5DomainId} | 
[**DeleteAuthv1SettingsKrb5Realm**](AuthApi.md#DeleteAuthv1SettingsKrb5Realm) | **Delete** /platform/1/auth/settings/krb5/realms/{v1SettingsKrb5RealmId} | 
[**DeleteAuthv3ProvidersAdsById**](AuthApi.md#DeleteAuthv3ProvidersAdsById) | **Delete** /platform/3/auth/providers/ads/{v3ProvidersAdsId} | 
[**DeleteAuthv3ProvidersKrb5ById**](AuthApi.md#DeleteAuthv3ProvidersKrb5ById) | **Delete** /platform/3/auth/providers/krb5/{v3ProvidersKrb5Id} | 
[**DeleteAuthv3ProvidersLdapById**](AuthApi.md#DeleteAuthv3ProvidersLdapById) | **Delete** /platform/3/auth/providers/ldap/{v3ProvidersLdapId} | 
[**DeleteAuthv3ProvidersNisById**](AuthApi.md#DeleteAuthv3ProvidersNisById) | **Delete** /platform/3/auth/providers/nis/{v3ProvidersNisId} | 
[**DeleteAuthv3UsersUserMemberOfMemberOf**](AuthApi.md#DeleteAuthv3UsersUserMemberOfMemberOf) | **Delete** /platform/3/auth/users/{User}/member-of/{v3UsersUserMemberOfMemberOf} | 
[**DeleteAuthv4ProvidersLdapById**](AuthApi.md#DeleteAuthv4ProvidersLdapById) | **Delete** /platform/4/auth/providers/ldap/{v4ProvidersLdapId} | 
[**DeleteAuthv7AuthRole**](AuthApi.md#DeleteAuthv7AuthRole) | **Delete** /platform/7/auth/roles/{v7AuthRoleId} | 
[**DeleteAuthv7AuthUser**](AuthApi.md#DeleteAuthv7AuthUser) | **Delete** /platform/7/auth/users/{v7AuthUserId} | 
[**DeleteAuthv7AuthUsers**](AuthApi.md#DeleteAuthv7AuthUsers) | **Delete** /platform/7/auth/users | 
[**DeleteAuthv7ProvidersAdsById**](AuthApi.md#DeleteAuthv7ProvidersAdsById) | **Delete** /platform/7/auth/providers/ads/{v7ProvidersAdsId} | 
[**DeleteAuthv7ProvidersFileById**](AuthApi.md#DeleteAuthv7ProvidersFileById) | **Delete** /platform/7/auth/providers/file/{v7ProvidersFileId} | 
[**DeleteAuthv7ProvidersKrb5ById**](AuthApi.md#DeleteAuthv7ProvidersKrb5ById) | **Delete** /platform/7/auth/providers/krb5/{v7ProvidersKrb5Id} | 
[**DeleteAuthv7ProvidersLdapById**](AuthApi.md#DeleteAuthv7ProvidersLdapById) | **Delete** /platform/7/auth/providers/ldap/{v7ProvidersLdapId} | 
[**DeleteAuthv7ProvidersNisById**](AuthApi.md#DeleteAuthv7ProvidersNisById) | **Delete** /platform/7/auth/providers/nis/{v7ProvidersNisId} | 
[**DeleteAuthv7RolesRoleMember**](AuthApi.md#DeleteAuthv7RolesRoleMember) | **Delete** /platform/7/auth/roles/{Role}/members/{v7RolesRoleMemberId} | 
[**DeleteAuthv7RolesRolePrivilege**](AuthApi.md#DeleteAuthv7RolesRolePrivilege) | **Delete** /platform/7/auth/roles/{Role}/privileges/{v7RolesRolePrivilegeId} | 
[**GetAuthv11ProvidersLdapById**](AuthApi.md#GetAuthv11ProvidersLdapById) | **Get** /platform/11/auth/providers/ldap/{v11ProvidersLdapId} | 
[**GetAuthv11ProvidersSummary**](AuthApi.md#GetAuthv11ProvidersSummary) | **Get** /platform/11/auth/providers/summary | 
[**GetAuthv11SettingsAcls**](AuthApi.md#GetAuthv11SettingsAcls) | **Get** /platform/11/auth/settings/acls | 
[**GetAuthv12AuthLogLevel**](AuthApi.md#GetAuthv12AuthLogLevel) | **Get** /platform/12/auth/log-level | 
[**GetAuthv1AuthAccessUser**](AuthApi.md#GetAuthv1AuthAccessUser) | **Get** /platform/1/auth/access/{v1AuthAccessUser} | 
[**GetAuthv1AuthGroup**](AuthApi.md#GetAuthv1AuthGroup) | **Get** /platform/1/auth/groups/{v1AuthGroupId} | 
[**GetAuthv1AuthId**](AuthApi.md#GetAuthv1AuthId) | **Get** /platform/1/auth/id | 
[**GetAuthv1AuthNetgroup**](AuthApi.md#GetAuthv1AuthNetgroup) | **Get** /platform/1/auth/netgroups/{v1AuthNetgroupId} | 
[**GetAuthv1AuthPrivileges**](AuthApi.md#GetAuthv1AuthPrivileges) | **Get** /platform/1/auth/privileges | 
[**GetAuthv1AuthRole**](AuthApi.md#GetAuthv1AuthRole) | **Get** /platform/1/auth/roles/{v1AuthRoleId} | 
[**GetAuthv1AuthShells**](AuthApi.md#GetAuthv1AuthShells) | **Get** /platform/1/auth/shells | 
[**GetAuthv1AuthUser**](AuthApi.md#GetAuthv1AuthUser) | **Get** /platform/1/auth/users/{v1AuthUserId} | 
[**GetAuthv1AuthWellknown**](AuthApi.md#GetAuthv1AuthWellknown) | **Get** /platform/1/auth/wellknowns/{v1AuthWellknownId} | 
[**GetAuthv1AuthWellknowns**](AuthApi.md#GetAuthv1AuthWellknowns) | **Get** /platform/1/auth/wellknowns | 
[**GetAuthv1MappingIdentity**](AuthApi.md#GetAuthv1MappingIdentity) | **Get** /platform/1/auth/mapping/identities/{v1MappingIdentityId} | 
[**GetAuthv1MappingUsersLookup**](AuthApi.md#GetAuthv1MappingUsersLookup) | **Get** /platform/1/auth/mapping/users/lookup | 
[**GetAuthv1MappingUsersRules**](AuthApi.md#GetAuthv1MappingUsersRules) | **Get** /platform/1/auth/mapping/users/rules | 
[**GetAuthv1ProvidersAdsById**](AuthApi.md#GetAuthv1ProvidersAdsById) | **Get** /platform/1/auth/providers/ads/{v1ProvidersAdsId} | 
[**GetAuthv1ProvidersAdsIdDomain**](AuthApi.md#GetAuthv1ProvidersAdsIdDomain) | **Get** /platform/1/auth/providers/ads/{Id}/domains/{v1ProvidersAdsIdDomainId} | 
[**GetAuthv1ProvidersFileById**](AuthApi.md#GetAuthv1ProvidersFileById) | **Get** /platform/1/auth/providers/file/{v1ProvidersFileId} | 
[**GetAuthv1ProvidersKrb5ById**](AuthApi.md#GetAuthv1ProvidersKrb5ById) | **Get** /platform/1/auth/providers/krb5/{v1ProvidersKrb5Id} | 
[**GetAuthv1ProvidersLdapById**](AuthApi.md#GetAuthv1ProvidersLdapById) | **Get** /platform/1/auth/providers/ldap/{v1ProvidersLdapId} | 
[**GetAuthv1ProvidersLocal**](AuthApi.md#GetAuthv1ProvidersLocal) | **Get** /platform/1/auth/providers/local | 
[**GetAuthv1ProvidersLocalById**](AuthApi.md#GetAuthv1ProvidersLocalById) | **Get** /platform/1/auth/providers/local/{v1ProvidersLocalId} | 
[**GetAuthv1ProvidersNisById**](AuthApi.md#GetAuthv1ProvidersNisById) | **Get** /platform/1/auth/providers/nis/{v1ProvidersNisId} | 
[**GetAuthv1ProvidersSummary**](AuthApi.md#GetAuthv1ProvidersSummary) | **Get** /platform/1/auth/providers/summary | 
[**GetAuthv1SettingsGlobal**](AuthApi.md#GetAuthv1SettingsGlobal) | **Get** /platform/1/auth/settings/global | 
[**GetAuthv1SettingsKrb5Defaults**](AuthApi.md#GetAuthv1SettingsKrb5Defaults) | **Get** /platform/1/auth/settings/krb5/defaults | 
[**GetAuthv1SettingsKrb5Domain**](AuthApi.md#GetAuthv1SettingsKrb5Domain) | **Get** /platform/1/auth/settings/krb5/domains/{v1SettingsKrb5DomainId} | 
[**GetAuthv1SettingsKrb5Realm**](AuthApi.md#GetAuthv1SettingsKrb5Realm) | **Get** /platform/1/auth/settings/krb5/realms/{v1SettingsKrb5RealmId} | 
[**GetAuthv1SettingsMapping**](AuthApi.md#GetAuthv1SettingsMapping) | **Get** /platform/1/auth/settings/mapping | 
[**GetAuthv3AuthLogLevel**](AuthApi.md#GetAuthv3AuthLogLevel) | **Get** /platform/3/auth/log-level | 
[**GetAuthv3MappingDump**](AuthApi.md#GetAuthv3MappingDump) | **Get** /platform/3/auth/mapping/dump | 
[**GetAuthv3ProvidersAdsById**](AuthApi.md#GetAuthv3ProvidersAdsById) | **Get** /platform/3/auth/providers/ads/{v3ProvidersAdsId} | 
[**GetAuthv3ProvidersAdsIdDomain**](AuthApi.md#GetAuthv3ProvidersAdsIdDomain) | **Get** /platform/3/auth/providers/ads/{Id}/domains/{v3ProvidersAdsIdDomainId} | 
[**GetAuthv3ProvidersKrb5ById**](AuthApi.md#GetAuthv3ProvidersKrb5ById) | **Get** /platform/3/auth/providers/krb5/{v3ProvidersKrb5Id} | 
[**GetAuthv3ProvidersLdapById**](AuthApi.md#GetAuthv3ProvidersLdapById) | **Get** /platform/3/auth/providers/ldap/{v3ProvidersLdapId} | 
[**GetAuthv3ProvidersNisById**](AuthApi.md#GetAuthv3ProvidersNisById) | **Get** /platform/3/auth/providers/nis/{v3ProvidersNisId} | 
[**GetAuthv3ProvidersSummary**](AuthApi.md#GetAuthv3ProvidersSummary) | **Get** /platform/3/auth/providers/summary | 
[**GetAuthv3SettingsAcls**](AuthApi.md#GetAuthv3SettingsAcls) | **Get** /platform/3/auth/settings/acls | 
[**GetAuthv4AuthLdapTemplate**](AuthApi.md#GetAuthv4AuthLdapTemplate) | **Get** /platform/4/auth/ldap-templates/{v4AuthLdapTemplateId} | 
[**GetAuthv4AuthLdapTemplates**](AuthApi.md#GetAuthv4AuthLdapTemplates) | **Get** /platform/4/auth/ldap-templates | 
[**GetAuthv4ProvidersLdapById**](AuthApi.md#GetAuthv4ProvidersLdapById) | **Get** /platform/4/auth/providers/ldap/{v4ProvidersLdapId} | 
[**GetAuthv7AuthErrorError**](AuthApi.md#GetAuthv7AuthErrorError) | **Get** /platform/7/auth/error/{v7AuthErrorError} | 
[**GetAuthv7AuthLdapTemplate**](AuthApi.md#GetAuthv7AuthLdapTemplate) | **Get** /platform/7/auth/ldap-templates/{v7AuthLdapTemplateId} | 
[**GetAuthv7AuthLdapTemplates**](AuthApi.md#GetAuthv7AuthLdapTemplates) | **Get** /platform/7/auth/ldap-templates | 
[**GetAuthv7AuthPrivileges**](AuthApi.md#GetAuthv7AuthPrivileges) | **Get** /platform/7/auth/privileges | 
[**GetAuthv7AuthRole**](AuthApi.md#GetAuthv7AuthRole) | **Get** /platform/7/auth/roles/{v7AuthRoleId} | 
[**GetAuthv7AuthUser**](AuthApi.md#GetAuthv7AuthUser) | **Get** /platform/7/auth/users/{v7AuthUserId} | 
[**GetAuthv7ProvidersAdsById**](AuthApi.md#GetAuthv7ProvidersAdsById) | **Get** /platform/7/auth/providers/ads/{v7ProvidersAdsId} | 
[**GetAuthv7ProvidersAdsIdDomain**](AuthApi.md#GetAuthv7ProvidersAdsIdDomain) | **Get** /platform/7/auth/providers/ads/{Id}/domains/{v7ProvidersAdsIdDomainId} | 
[**GetAuthv7ProvidersDuo**](AuthApi.md#GetAuthv7ProvidersDuo) | **Get** /platform/7/auth/providers/duo | 
[**GetAuthv7ProvidersFileById**](AuthApi.md#GetAuthv7ProvidersFileById) | **Get** /platform/7/auth/providers/file/{v7ProvidersFileId} | 
[**GetAuthv7ProvidersKrb5ById**](AuthApi.md#GetAuthv7ProvidersKrb5ById) | **Get** /platform/7/auth/providers/krb5/{v7ProvidersKrb5Id} | 
[**GetAuthv7ProvidersLdapById**](AuthApi.md#GetAuthv7ProvidersLdapById) | **Get** /platform/7/auth/providers/ldap/{v7ProvidersLdapId} | 
[**GetAuthv7ProvidersLocal**](AuthApi.md#GetAuthv7ProvidersLocal) | **Get** /platform/7/auth/providers/local | 
[**GetAuthv7ProvidersLocalById**](AuthApi.md#GetAuthv7ProvidersLocalById) | **Get** /platform/7/auth/providers/local/{v7ProvidersLocalId} | 
[**GetAuthv7ProvidersNisById**](AuthApi.md#GetAuthv7ProvidersNisById) | **Get** /platform/7/auth/providers/nis/{v7ProvidersNisId} | 
[**GetAuthv7SettingsAcls**](AuthApi.md#GetAuthv7SettingsAcls) | **Get** /platform/7/auth/settings/acls | 
[**GetAuthv9ProvidersSummary**](AuthApi.md#GetAuthv9ProvidersSummary) | **Get** /platform/9/auth/providers/summary | 
[**ListAuthv11ProvidersLdap**](AuthApi.md#ListAuthv11ProvidersLdap) | **Get** /platform/11/auth/providers/ldap | 
[**ListAuthv1AuthGroups**](AuthApi.md#ListAuthv1AuthGroups) | **Get** /platform/1/auth/groups | 
[**ListAuthv1AuthRoles**](AuthApi.md#ListAuthv1AuthRoles) | **Get** /platform/1/auth/roles | 
[**ListAuthv1AuthUsers**](AuthApi.md#ListAuthv1AuthUsers) | **Get** /platform/1/auth/users | 
[**ListAuthv1ProvidersAds**](AuthApi.md#ListAuthv1ProvidersAds) | **Get** /platform/1/auth/providers/ads | 
[**ListAuthv1ProvidersFile**](AuthApi.md#ListAuthv1ProvidersFile) | **Get** /platform/1/auth/providers/file | 
[**ListAuthv1ProvidersKrb5**](AuthApi.md#ListAuthv1ProvidersKrb5) | **Get** /platform/1/auth/providers/krb5 | 
[**ListAuthv1ProvidersLdap**](AuthApi.md#ListAuthv1ProvidersLdap) | **Get** /platform/1/auth/providers/ldap | 
[**ListAuthv1ProvidersNis**](AuthApi.md#ListAuthv1ProvidersNis) | **Get** /platform/1/auth/providers/nis | 
[**ListAuthv1SettingsKrb5Domains**](AuthApi.md#ListAuthv1SettingsKrb5Domains) | **Get** /platform/1/auth/settings/krb5/domains | 
[**ListAuthv1SettingsKrb5Realms**](AuthApi.md#ListAuthv1SettingsKrb5Realms) | **Get** /platform/1/auth/settings/krb5/realms | 
[**ListAuthv3ProvidersAds**](AuthApi.md#ListAuthv3ProvidersAds) | **Get** /platform/3/auth/providers/ads | 
[**ListAuthv3ProvidersKrb5**](AuthApi.md#ListAuthv3ProvidersKrb5) | **Get** /platform/3/auth/providers/krb5 | 
[**ListAuthv3ProvidersLdap**](AuthApi.md#ListAuthv3ProvidersLdap) | **Get** /platform/3/auth/providers/ldap | 
[**ListAuthv3ProvidersNis**](AuthApi.md#ListAuthv3ProvidersNis) | **Get** /platform/3/auth/providers/nis | 
[**ListAuthv4ProvidersLdap**](AuthApi.md#ListAuthv4ProvidersLdap) | **Get** /platform/4/auth/providers/ldap | 
[**ListAuthv7AuthRoles**](AuthApi.md#ListAuthv7AuthRoles) | **Get** /platform/7/auth/roles | 
[**ListAuthv7AuthUsers**](AuthApi.md#ListAuthv7AuthUsers) | **Get** /platform/7/auth/users | 
[**ListAuthv7ProvidersAds**](AuthApi.md#ListAuthv7ProvidersAds) | **Get** /platform/7/auth/providers/ads | 
[**ListAuthv7ProvidersFile**](AuthApi.md#ListAuthv7ProvidersFile) | **Get** /platform/7/auth/providers/file | 
[**ListAuthv7ProvidersKrb5**](AuthApi.md#ListAuthv7ProvidersKrb5) | **Get** /platform/7/auth/providers/krb5 | 
[**ListAuthv7ProvidersLdap**](AuthApi.md#ListAuthv7ProvidersLdap) | **Get** /platform/7/auth/providers/ldap | 
[**ListAuthv7ProvidersNis**](AuthApi.md#ListAuthv7ProvidersNis) | **Get** /platform/7/auth/providers/nis | 
[**UpdateAuthv11ProvidersLdapById**](AuthApi.md#UpdateAuthv11ProvidersLdapById) | **Put** /platform/11/auth/providers/ldap/{v11ProvidersLdapId} | 
[**UpdateAuthv11SettingsAcls**](AuthApi.md#UpdateAuthv11SettingsAcls) | **Put** /platform/11/auth/settings/acls | 
[**UpdateAuthv12AuthLogLevel**](AuthApi.md#UpdateAuthv12AuthLogLevel) | **Put** /platform/12/auth/log-level | 
[**UpdateAuthv1AuthGroup**](AuthApi.md#UpdateAuthv1AuthGroup) | **Put** /platform/1/auth/groups/{v1AuthGroupId} | 
[**UpdateAuthv1AuthRole**](AuthApi.md#UpdateAuthv1AuthRole) | **Put** /platform/1/auth/roles/{v1AuthRoleId} | 
[**UpdateAuthv1AuthUser**](AuthApi.md#UpdateAuthv1AuthUser) | **Put** /platform/1/auth/users/{v1AuthUserId} | 
[**UpdateAuthv1MappingUsersRules**](AuthApi.md#UpdateAuthv1MappingUsersRules) | **Put** /platform/1/auth/mapping/users/rules | 
[**UpdateAuthv1ProvidersAdsById**](AuthApi.md#UpdateAuthv1ProvidersAdsById) | **Put** /platform/1/auth/providers/ads/{v1ProvidersAdsId} | 
[**UpdateAuthv1ProvidersFileById**](AuthApi.md#UpdateAuthv1ProvidersFileById) | **Put** /platform/1/auth/providers/file/{v1ProvidersFileId} | 
[**UpdateAuthv1ProvidersKrb5ById**](AuthApi.md#UpdateAuthv1ProvidersKrb5ById) | **Put** /platform/1/auth/providers/krb5/{v1ProvidersKrb5Id} | 
[**UpdateAuthv1ProvidersLdapById**](AuthApi.md#UpdateAuthv1ProvidersLdapById) | **Put** /platform/1/auth/providers/ldap/{v1ProvidersLdapId} | 
[**UpdateAuthv1ProvidersLocalById**](AuthApi.md#UpdateAuthv1ProvidersLocalById) | **Put** /platform/1/auth/providers/local/{v1ProvidersLocalId} | 
[**UpdateAuthv1ProvidersNisById**](AuthApi.md#UpdateAuthv1ProvidersNisById) | **Put** /platform/1/auth/providers/nis/{v1ProvidersNisId} | 
[**UpdateAuthv1SettingsGlobal**](AuthApi.md#UpdateAuthv1SettingsGlobal) | **Put** /platform/1/auth/settings/global | 
[**UpdateAuthv1SettingsKrb5Defaults**](AuthApi.md#UpdateAuthv1SettingsKrb5Defaults) | **Put** /platform/1/auth/settings/krb5/defaults | 
[**UpdateAuthv1SettingsKrb5Domain**](AuthApi.md#UpdateAuthv1SettingsKrb5Domain) | **Put** /platform/1/auth/settings/krb5/domains/{v1SettingsKrb5DomainId} | 
[**UpdateAuthv1SettingsKrb5Realm**](AuthApi.md#UpdateAuthv1SettingsKrb5Realm) | **Put** /platform/1/auth/settings/krb5/realms/{v1SettingsKrb5RealmId} | 
[**UpdateAuthv1SettingsMapping**](AuthApi.md#UpdateAuthv1SettingsMapping) | **Put** /platform/1/auth/settings/mapping | 
[**UpdateAuthv3AuthLogLevel**](AuthApi.md#UpdateAuthv3AuthLogLevel) | **Put** /platform/3/auth/log-level | 
[**UpdateAuthv3MappingImport**](AuthApi.md#UpdateAuthv3MappingImport) | **Put** /platform/3/auth/mapping/import | 
[**UpdateAuthv3ProvidersAdsById**](AuthApi.md#UpdateAuthv3ProvidersAdsById) | **Put** /platform/3/auth/providers/ads/{v3ProvidersAdsId} | 
[**UpdateAuthv3ProvidersKrb5ById**](AuthApi.md#UpdateAuthv3ProvidersKrb5ById) | **Put** /platform/3/auth/providers/krb5/{v3ProvidersKrb5Id} | 
[**UpdateAuthv3ProvidersLdapById**](AuthApi.md#UpdateAuthv3ProvidersLdapById) | **Put** /platform/3/auth/providers/ldap/{v3ProvidersLdapId} | 
[**UpdateAuthv3ProvidersNisById**](AuthApi.md#UpdateAuthv3ProvidersNisById) | **Put** /platform/3/auth/providers/nis/{v3ProvidersNisId} | 
[**UpdateAuthv3SettingsAcls**](AuthApi.md#UpdateAuthv3SettingsAcls) | **Put** /platform/3/auth/settings/acls | 
[**UpdateAuthv4ProvidersLdapById**](AuthApi.md#UpdateAuthv4ProvidersLdapById) | **Put** /platform/4/auth/providers/ldap/{v4ProvidersLdapId} | 
[**UpdateAuthv7AuthRole**](AuthApi.md#UpdateAuthv7AuthRole) | **Put** /platform/7/auth/roles/{v7AuthRoleId} | 
[**UpdateAuthv7AuthUser**](AuthApi.md#UpdateAuthv7AuthUser) | **Put** /platform/7/auth/users/{v7AuthUserId} | 
[**UpdateAuthv7ProvidersAdsById**](AuthApi.md#UpdateAuthv7ProvidersAdsById) | **Put** /platform/7/auth/providers/ads/{v7ProvidersAdsId} | 
[**UpdateAuthv7ProvidersDuo**](AuthApi.md#UpdateAuthv7ProvidersDuo) | **Put** /platform/7/auth/providers/duo | 
[**UpdateAuthv7ProvidersFileById**](AuthApi.md#UpdateAuthv7ProvidersFileById) | **Put** /platform/7/auth/providers/file/{v7ProvidersFileId} | 
[**UpdateAuthv7ProvidersKrb5ById**](AuthApi.md#UpdateAuthv7ProvidersKrb5ById) | **Put** /platform/7/auth/providers/krb5/{v7ProvidersKrb5Id} | 
[**UpdateAuthv7ProvidersLdapById**](AuthApi.md#UpdateAuthv7ProvidersLdapById) | **Put** /platform/7/auth/providers/ldap/{v7ProvidersLdapId} | 
[**UpdateAuthv7ProvidersLocalById**](AuthApi.md#UpdateAuthv7ProvidersLocalById) | **Put** /platform/7/auth/providers/local/{v7ProvidersLocalId} | 
[**UpdateAuthv7ProvidersNisById**](AuthApi.md#UpdateAuthv7ProvidersNisById) | **Put** /platform/7/auth/providers/nis/{v7ProvidersNisId} | 
[**UpdateAuthv7SettingsAcls**](AuthApi.md#UpdateAuthv7SettingsAcls) | **Put** /platform/7/auth/settings/acls | 



## CreateAuthv11ProvidersLdapItem

> CreateResponse CreateAuthv11ProvidersLdapItem(ctx).V11ProvidersLdapItem(v11ProvidersLdapItem).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11ProvidersLdapItem := *openapiclient.NewV11ProvidersLdapItem("BaseDn_example", "Name_example", []string{"ServerUris_example"}) // V11ProvidersLdapItem | 
    force := true // bool | Ignore unresolvable server URIs. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv11ProvidersLdapItem(context.Background()).V11ProvidersLdapItem(v11ProvidersLdapItem).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv11ProvidersLdapItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv11ProvidersLdapItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv11ProvidersLdapItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv11ProvidersLdapItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v11ProvidersLdapItem** | [**V11ProvidersLdapItem**](V11ProvidersLdapItem.md) |  | 
 **force** | **bool** | Ignore unresolvable server URIs. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1AuthGroup

> CreateResponse CreateAuthv1AuthGroup(ctx).V1AuthGroup(v1AuthGroup).Force(force).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthGroup := *openapiclient.NewV1AuthGroup("Name_example") // V1AuthGroup | 
    force := true // bool | Skip validation checks when creating a group. (optional)
    zone := "zone_example" // string | Optional zone. (optional)
    provider := "provider_example" // string | Optional provider type. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1AuthGroup(context.Background()).V1AuthGroup(v1AuthGroup).Force(force).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1AuthGroup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1AuthGroup`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1AuthGroup`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1AuthGroupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1AuthGroup** | [**V1AuthGroup**](V1AuthGroup.md) |  | 
 **force** | **bool** | Skip validation checks when creating a group. | 
 **zone** | **string** | Optional zone. | 
 **provider** | **string** | Optional provider type. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1AuthRole

> CreateResponse CreateAuthv1AuthRole(ctx).V1AuthRole(v1AuthRole).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthRole := *openapiclient.NewV1AuthRole("Name_example") // V1AuthRole | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1AuthRole(context.Background()).V1AuthRole(v1AuthRole).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1AuthRole``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1AuthRole`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1AuthRole`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1AuthRoleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1AuthRole** | [**V1AuthRole**](V1AuthRole.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1AuthUser

> CreateResponse CreateAuthv1AuthUser(ctx).V1AuthUser(v1AuthUser).Force(force).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthUser := *openapiclient.NewV1AuthUser("Name_example") // V1AuthUser | 
    force := true // bool | Skip validation checks when creating user. (optional)
    zone := "zone_example" // string | Optional zone. (optional)
    provider := "provider_example" // string | Optional provider type. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1AuthUser(context.Background()).V1AuthUser(v1AuthUser).Force(force).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1AuthUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1AuthUser`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1AuthUser`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1AuthUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1AuthUser** | [**V1AuthUser**](V1AuthUser.md) |  | 
 **force** | **bool** | Skip validation checks when creating user. | 
 **zone** | **string** | Optional zone. | 
 **provider** | **string** | Optional provider type. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1MappingIdentities

> map[string]interface{} CreateAuthv1MappingIdentities(ctx).V1MappingIdentities(v1MappingIdentities).Var2way(var2way).Zone(zone).Replace(replace).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1MappingIdentities := *openapiclient.NewV1MappingIdentities(*openapiclient.NewV1AuthAccessAccessItemFileGroup(), []openapiclient.V1MappingIdentitiesTarget{*openapiclient.NewV1MappingIdentitiesTarget(*openapiclient.NewV1AuthAccessAccessItemFileGroup())}) // V1MappingIdentities | 
    var2way := true // bool | Create a bi-directional mapping from source to target and target to source. (optional)
    zone := "zone_example" // string | Optional zone. (optional)
    replace := true // bool | Replace existing mappings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1MappingIdentities(context.Background()).V1MappingIdentities(v1MappingIdentities).Var2way(var2way).Zone(zone).Replace(replace).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1MappingIdentities``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1MappingIdentities`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1MappingIdentities`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1MappingIdentitiesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1MappingIdentities** | [**V1MappingIdentities**](V1MappingIdentities.md) |  | 
 **var2way** | **bool** | Create a bi-directional mapping from source to target and target to source. | 
 **zone** | **string** | Optional zone. | 
 **replace** | **bool** | Replace existing mappings. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1MappingIdentity

> V1MappingIdentitiesExtended CreateAuthv1MappingIdentity(ctx, v1MappingIdentityId).V1MappingIdentity(v1MappingIdentity).Type_(type_).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1MappingIdentityId := "v1MappingIdentityId_example" // string | Manually set or modify a mapping between two personae.
    v1MappingIdentity := map[string]interface{}{ ... } // map[string]interface{} | 
    type_ := "type__example" // string | Desired mapping target to fetch/generate. (optional)
    zone := "zone_example" // string | Optional zone. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1MappingIdentity(context.Background(), v1MappingIdentityId).V1MappingIdentity(v1MappingIdentity).Type_(type_).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1MappingIdentity``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1MappingIdentity`: V1MappingIdentitiesExtended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1MappingIdentity`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1MappingIdentityId** | **string** | Manually set or modify a mapping between two personae. | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1MappingIdentityRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1MappingIdentity** | **map[string]interface{}** |  | 
 **type_** | **string** | Desired mapping target to fetch/generate. | 
 **zone** | **string** | Optional zone. | 

### Return type

[**V1MappingIdentitiesExtended**](V1MappingIdentitiesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1ProvidersAdsItem

> CreateResponse CreateAuthv1ProvidersAdsItem(ctx).V1ProvidersAdsItem(v1ProvidersAdsItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersAdsItem := *openapiclient.NewV1ProvidersAdsItem("Name_example", "Password_example", "User_example") // V1ProvidersAdsItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1ProvidersAdsItem(context.Background()).V1ProvidersAdsItem(v1ProvidersAdsItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1ProvidersAdsItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1ProvidersAdsItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1ProvidersAdsItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1ProvidersAdsItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1ProvidersAdsItem** | [**V1ProvidersAdsItem**](V1ProvidersAdsItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1ProvidersFileItem

> CreateResponse CreateAuthv1ProvidersFileItem(ctx).V1ProvidersFileItem(v1ProvidersFileItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersFileItem := *openapiclient.NewV1ProvidersFileItem("GroupFile_example", "Name_example", "PasswordFile_example") // V1ProvidersFileItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1ProvidersFileItem(context.Background()).V1ProvidersFileItem(v1ProvidersFileItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1ProvidersFileItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1ProvidersFileItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1ProvidersFileItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1ProvidersFileItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1ProvidersFileItem** | [**V1ProvidersFileItem**](V1ProvidersFileItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1ProvidersKrb5Item

> CreateResponse CreateAuthv1ProvidersKrb5Item(ctx).V1ProvidersKrb5Item(v1ProvidersKrb5Item).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersKrb5Item := *openapiclient.NewV1ProvidersKrb5Item("Realm_example") // V1ProvidersKrb5Item | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1ProvidersKrb5Item(context.Background()).V1ProvidersKrb5Item(v1ProvidersKrb5Item).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1ProvidersKrb5Item``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1ProvidersKrb5Item`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1ProvidersKrb5Item`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1ProvidersKrb5ItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1ProvidersKrb5Item** | [**V1ProvidersKrb5Item**](V1ProvidersKrb5Item.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1ProvidersLdapItem

> CreateResponse CreateAuthv1ProvidersLdapItem(ctx).V1ProvidersLdapItem(v1ProvidersLdapItem).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersLdapItem := *openapiclient.NewV1ProvidersLdapItem("BaseDn_example", "Name_example", []string{"ServerUris_example"}) // V1ProvidersLdapItem | 
    force := true // bool | Ignore unresolvable server URIs. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1ProvidersLdapItem(context.Background()).V1ProvidersLdapItem(v1ProvidersLdapItem).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1ProvidersLdapItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1ProvidersLdapItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1ProvidersLdapItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1ProvidersLdapItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1ProvidersLdapItem** | [**V1ProvidersLdapItem**](V1ProvidersLdapItem.md) |  | 
 **force** | **bool** | Ignore unresolvable server URIs. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1ProvidersNisItem

> CreateResponse CreateAuthv1ProvidersNisItem(ctx).V1ProvidersNisItem(v1ProvidersNisItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersNisItem := *openapiclient.NewV1ProvidersNisItem("Name_example", "NisDomain_example", []string{"Servers_example"}) // V1ProvidersNisItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1ProvidersNisItem(context.Background()).V1ProvidersNisItem(v1ProvidersNisItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1ProvidersNisItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1ProvidersNisItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1ProvidersNisItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1ProvidersNisItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1ProvidersNisItem** | [**V1ProvidersNisItem**](V1ProvidersNisItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1SettingsKrb5Domain

> CreateResponse CreateAuthv1SettingsKrb5Domain(ctx).V1SettingsKrb5Domain(v1SettingsKrb5Domain).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsKrb5Domain := *openapiclient.NewV1SettingsKrb5Domain("Domain_example", "Realm_example") // V1SettingsKrb5Domain | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1SettingsKrb5Domain(context.Background()).V1SettingsKrb5Domain(v1SettingsKrb5Domain).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1SettingsKrb5Domain``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1SettingsKrb5Domain`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1SettingsKrb5Domain`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1SettingsKrb5DomainRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SettingsKrb5Domain** | [**V1SettingsKrb5Domain**](V1SettingsKrb5Domain.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv1SettingsKrb5Realm

> CreateResponse CreateAuthv1SettingsKrb5Realm(ctx).V1SettingsKrb5Realm(v1SettingsKrb5Realm).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsKrb5Realm := *openapiclient.NewV1SettingsKrb5Realm("Realm_example") // V1SettingsKrb5Realm | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv1SettingsKrb5Realm(context.Background()).V1SettingsKrb5Realm(v1SettingsKrb5Realm).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv1SettingsKrb5Realm``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv1SettingsKrb5Realm`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv1SettingsKrb5Realm`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv1SettingsKrb5RealmRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SettingsKrb5Realm** | [**V1SettingsKrb5Realm**](V1SettingsKrb5Realm.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv3AuthRefreshItem

> map[string]interface{} CreateAuthv3AuthRefreshItem(ctx).V3AuthRefreshItem(v3AuthRefreshItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AuthRefreshItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv3AuthRefreshItem(context.Background()).V3AuthRefreshItem(v3AuthRefreshItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv3AuthRefreshItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv3AuthRefreshItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv3AuthRefreshItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv3AuthRefreshItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3AuthRefreshItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv3ProvidersAdsItem

> CreateResponse CreateAuthv3ProvidersAdsItem(ctx).V3ProvidersAdsItem(v3ProvidersAdsItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersAdsItem := *openapiclient.NewV3ProvidersAdsItem("Name_example", "Password_example", "User_example") // V3ProvidersAdsItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv3ProvidersAdsItem(context.Background()).V3ProvidersAdsItem(v3ProvidersAdsItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv3ProvidersAdsItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv3ProvidersAdsItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv3ProvidersAdsItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv3ProvidersAdsItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ProvidersAdsItem** | [**V3ProvidersAdsItem**](V3ProvidersAdsItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv3ProvidersKrb5Item

> CreateResponse CreateAuthv3ProvidersKrb5Item(ctx).V3ProvidersKrb5Item(v3ProvidersKrb5Item).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersKrb5Item := *openapiclient.NewV3ProvidersKrb5Item("Realm_example") // V3ProvidersKrb5Item | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv3ProvidersKrb5Item(context.Background()).V3ProvidersKrb5Item(v3ProvidersKrb5Item).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv3ProvidersKrb5Item``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv3ProvidersKrb5Item`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv3ProvidersKrb5Item`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv3ProvidersKrb5ItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ProvidersKrb5Item** | [**V3ProvidersKrb5Item**](V3ProvidersKrb5Item.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv3ProvidersLdapItem

> CreateResponse CreateAuthv3ProvidersLdapItem(ctx).V3ProvidersLdapItem(v3ProvidersLdapItem).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersLdapItem := *openapiclient.NewV3ProvidersLdapItem("BaseDn_example", "Name_example", []string{"ServerUris_example"}) // V3ProvidersLdapItem | 
    force := true // bool | Ignore unresolvable server URIs. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv3ProvidersLdapItem(context.Background()).V3ProvidersLdapItem(v3ProvidersLdapItem).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv3ProvidersLdapItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv3ProvidersLdapItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv3ProvidersLdapItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv3ProvidersLdapItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ProvidersLdapItem** | [**V3ProvidersLdapItem**](V3ProvidersLdapItem.md) |  | 
 **force** | **bool** | Ignore unresolvable server URIs. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv3ProvidersNisItem

> CreateResponse CreateAuthv3ProvidersNisItem(ctx).V3ProvidersNisItem(v3ProvidersNisItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersNisItem := *openapiclient.NewV3ProvidersNisItem("Name_example", "NisDomain_example", []string{"Servers_example"}) // V3ProvidersNisItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv3ProvidersNisItem(context.Background()).V3ProvidersNisItem(v3ProvidersNisItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv3ProvidersNisItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv3ProvidersNisItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv3ProvidersNisItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv3ProvidersNisItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3ProvidersNisItem** | [**V3ProvidersNisItem**](V3ProvidersNisItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv4AuthCacheItem

> map[string]interface{} CreateAuthv4AuthCacheItem(ctx).V4AuthCacheItem(v4AuthCacheItem).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4AuthCacheItem := *openapiclient.NewV4AuthCacheItem() // V4AuthCacheItem | 
    zone := "zone_example" // string | Specifies access zone from which to flush objects. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv4AuthCacheItem(context.Background()).V4AuthCacheItem(v4AuthCacheItem).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv4AuthCacheItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv4AuthCacheItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv4AuthCacheItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv4AuthCacheItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4AuthCacheItem** | [**V4AuthCacheItem**](V4AuthCacheItem.md) |  | 
 **zone** | **string** | Specifies access zone from which to flush objects. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv4ProvidersLdapItem

> CreateResponse CreateAuthv4ProvidersLdapItem(ctx).V4ProvidersLdapItem(v4ProvidersLdapItem).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4ProvidersLdapItem := *openapiclient.NewV4ProvidersLdapItem("BaseDn_example", "Name_example", []string{"ServerUris_example"}) // V4ProvidersLdapItem | 
    force := true // bool | Ignore unresolvable server URIs. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv4ProvidersLdapItem(context.Background()).V4ProvidersLdapItem(v4ProvidersLdapItem).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv4ProvidersLdapItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv4ProvidersLdapItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv4ProvidersLdapItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv4ProvidersLdapItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4ProvidersLdapItem** | [**V4ProvidersLdapItem**](V4ProvidersLdapItem.md) |  | 
 **force** | **bool** | Ignore unresolvable server URIs. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv7AuthRole

> CreateResponse CreateAuthv7AuthRole(ctx).V7AuthRole(v7AuthRole).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuthRole := *openapiclient.NewV1AuthRole("Name_example") // V1AuthRole | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv7AuthRole(context.Background()).V7AuthRole(v7AuthRole).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv7AuthRole``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv7AuthRole`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv7AuthRole`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv7AuthRoleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7AuthRole** | [**V1AuthRole**](V1AuthRole.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv7AuthUser

> CreateResponse CreateAuthv7AuthUser(ctx).V7AuthUser(v7AuthUser).Force(force).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuthUser := *openapiclient.NewV1AuthUser("Name_example") // V1AuthUser | 
    force := true // bool | Skip validation checks when creating user. (optional)
    zone := "zone_example" // string | Optional zone. (optional)
    provider := "provider_example" // string | Optional provider type. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv7AuthUser(context.Background()).V7AuthUser(v7AuthUser).Force(force).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv7AuthUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv7AuthUser`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv7AuthUser`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv7AuthUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7AuthUser** | [**V1AuthUser**](V1AuthUser.md) |  | 
 **force** | **bool** | Skip validation checks when creating user. | 
 **zone** | **string** | Optional zone. | 
 **provider** | **string** | Optional provider type. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv7ProvidersAdsItem

> CreateResponse CreateAuthv7ProvidersAdsItem(ctx).V7ProvidersAdsItem(v7ProvidersAdsItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersAdsItem := *openapiclient.NewV7ProvidersAdsItem("Name_example", "Password_example", "User_example") // V7ProvidersAdsItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv7ProvidersAdsItem(context.Background()).V7ProvidersAdsItem(v7ProvidersAdsItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv7ProvidersAdsItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv7ProvidersAdsItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv7ProvidersAdsItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv7ProvidersAdsItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ProvidersAdsItem** | [**V7ProvidersAdsItem**](V7ProvidersAdsItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv7ProvidersFileItem

> CreateResponse CreateAuthv7ProvidersFileItem(ctx).V7ProvidersFileItem(v7ProvidersFileItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersFileItem := *openapiclient.NewV1ProvidersFileItem("GroupFile_example", "Name_example", "PasswordFile_example") // V1ProvidersFileItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv7ProvidersFileItem(context.Background()).V7ProvidersFileItem(v7ProvidersFileItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv7ProvidersFileItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv7ProvidersFileItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv7ProvidersFileItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv7ProvidersFileItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ProvidersFileItem** | [**V1ProvidersFileItem**](V1ProvidersFileItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv7ProvidersKrb5Item

> CreateResponse CreateAuthv7ProvidersKrb5Item(ctx).V7ProvidersKrb5Item(v7ProvidersKrb5Item).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersKrb5Item := *openapiclient.NewV3ProvidersKrb5Item("Realm_example") // V3ProvidersKrb5Item | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv7ProvidersKrb5Item(context.Background()).V7ProvidersKrb5Item(v7ProvidersKrb5Item).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv7ProvidersKrb5Item``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv7ProvidersKrb5Item`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv7ProvidersKrb5Item`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv7ProvidersKrb5ItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ProvidersKrb5Item** | [**V3ProvidersKrb5Item**](V3ProvidersKrb5Item.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv7ProvidersLdapItem

> CreateResponse CreateAuthv7ProvidersLdapItem(ctx).V7ProvidersLdapItem(v7ProvidersLdapItem).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersLdapItem := *openapiclient.NewV7ProvidersLdapItem("BaseDn_example", "Name_example", []string{"ServerUris_example"}) // V7ProvidersLdapItem | 
    force := true // bool | Ignore unresolvable server URIs. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv7ProvidersLdapItem(context.Background()).V7ProvidersLdapItem(v7ProvidersLdapItem).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv7ProvidersLdapItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv7ProvidersLdapItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv7ProvidersLdapItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv7ProvidersLdapItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ProvidersLdapItem** | [**V7ProvidersLdapItem**](V7ProvidersLdapItem.md) |  | 
 **force** | **bool** | Ignore unresolvable server URIs. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthv7ProvidersNisItem

> CreateResponse CreateAuthv7ProvidersNisItem(ctx).V7ProvidersNisItem(v7ProvidersNisItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersNisItem := *openapiclient.NewV3ProvidersNisItem("Name_example", "NisDomain_example", []string{"Servers_example"}) // V3ProvidersNisItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.CreateAuthv7ProvidersNisItem(context.Background()).V7ProvidersNisItem(v7ProvidersNisItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.CreateAuthv7ProvidersNisItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthv7ProvidersNisItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.CreateAuthv7ProvidersNisItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthv7ProvidersNisItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ProvidersNisItem** | [**V3ProvidersNisItem**](V3ProvidersNisItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv11ProvidersLdapById

> DeleteAuthv11ProvidersLdapById(ctx, v11ProvidersLdapId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11ProvidersLdapId := "v11ProvidersLdapId_example" // string | Delete the LDAP provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv11ProvidersLdapById(context.Background(), v11ProvidersLdapId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv11ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11ProvidersLdapId** | **string** | Delete the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv11ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1AuthGroup

> DeleteAuthv1AuthGroup(ctx, v1AuthGroupId).Cached(cached).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthGroupId := "v1AuthGroupId_example" // string | Delete the group.
    cached := true // bool | If true, flush the group from the cache. (optional)
    zone := "zone_example" // string | Filter groups by zone. (optional)
    provider := "provider_example" // string | Filter groups by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1AuthGroup(context.Background(), v1AuthGroupId).Cached(cached).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1AuthGroup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthGroupId** | **string** | Delete the group. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1AuthGroupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **cached** | **bool** | If true, flush the group from the cache. | 
 **zone** | **string** | Filter groups by zone. | 
 **provider** | **string** | Filter groups by provider. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1AuthGroups

> DeleteAuthv1AuthGroups(ctx).Cached(cached).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    cached := true // bool | If true, only flush cached objects. (optional)
    zone := "zone_example" // string | Filter groups by zone. (optional)
    provider := "provider_example" // string | Filter groups by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1AuthGroups(context.Background()).Cached(cached).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1AuthGroups``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1AuthGroupsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cached** | **bool** | If true, only flush cached objects. | 
 **zone** | **string** | Filter groups by zone. | 
 **provider** | **string** | Filter groups by provider. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1AuthRole

> DeleteAuthv1AuthRole(ctx, v1AuthRoleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthRoleId := "v1AuthRoleId_example" // string | Delete the role.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1AuthRole(context.Background(), v1AuthRoleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1AuthRole``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthRoleId** | **string** | Delete the role. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1AuthRoleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1AuthUser

> DeleteAuthv1AuthUser(ctx, v1AuthUserId).Cached(cached).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthUserId := "v1AuthUserId_example" // string | Delete the user.
    cached := true // bool | If true, flush the user from the cache. (optional)
    zone := "zone_example" // string | Filter users by zone. (optional)
    provider := "provider_example" // string | Filter users by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1AuthUser(context.Background(), v1AuthUserId).Cached(cached).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1AuthUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthUserId** | **string** | Delete the user. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1AuthUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **cached** | **bool** | If true, flush the user from the cache. | 
 **zone** | **string** | Filter users by zone. | 
 **provider** | **string** | Filter users by provider. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1AuthUsers

> DeleteAuthv1AuthUsers(ctx).Cached(cached).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    cached := true // bool | If true, only flush cached objects. (optional)
    zone := "zone_example" // string | Filter users by zone. (optional)
    provider := "provider_example" // string | Filter users by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1AuthUsers(context.Background()).Cached(cached).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1AuthUsers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1AuthUsersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cached** | **bool** | If true, only flush cached objects. | 
 **zone** | **string** | Filter users by zone. | 
 **provider** | **string** | Filter users by provider. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1GroupsGroupMember

> DeleteAuthv1GroupsGroupMember(ctx, v1GroupsGroupMemberId, group).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1GroupsGroupMemberId := "v1GroupsGroupMemberId_example" // string | Remove the member from the group.
    group := "group_example" // string | 
    zone := "zone_example" // string | Filter group members by zone. (optional)
    provider := "provider_example" // string | Filter group members by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1GroupsGroupMember(context.Background(), v1GroupsGroupMemberId, group).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1GroupsGroupMember``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1GroupsGroupMemberId** | **string** | Remove the member from the group. | 
**group** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1GroupsGroupMemberRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **zone** | **string** | Filter group members by zone. | 
 **provider** | **string** | Filter group members by provider. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1MappingIdentities

> DeleteAuthv1MappingIdentities(ctx).Filter(filter).Zone(zone).Remove(remove).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    filter := "filter_example" // string | Filter to apply when deleting identity mappings. (optional)
    zone := "zone_example" // string | Optional zone. (optional)
    remove := true // bool | Delete mapping instead of flush mapping cache. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1MappingIdentities(context.Background()).Filter(filter).Zone(zone).Remove(remove).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1MappingIdentities``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1MappingIdentitiesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **filter** | **string** | Filter to apply when deleting identity mappings. | 
 **zone** | **string** | Optional zone. | 
 **remove** | **bool** | Delete mapping instead of flush mapping cache. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1MappingIdentity

> DeleteAuthv1MappingIdentity(ctx, v1MappingIdentityId).Zone(zone).Var2way(var2way).Target(target).Remove(remove).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1MappingIdentityId := "v1MappingIdentityId_example" // string | Flush the entire idmap cache.
    zone := "zone_example" // string | Optional zone. (optional)
    var2way := true // bool | Delete the bi-directional mapping from source to target and target to source. (optional)
    target := "target_example" // string | Target identity persona. (optional)
    remove := true // bool | Delete mapping instead of flush mapping from cache. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1MappingIdentity(context.Background(), v1MappingIdentityId).Zone(zone).Var2way(var2way).Target(target).Remove(remove).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1MappingIdentity``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1MappingIdentityId** | **string** | Flush the entire idmap cache. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1MappingIdentityRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Optional zone. | 
 **var2way** | **bool** | Delete the bi-directional mapping from source to target and target to source. | 
 **target** | **string** | Target identity persona. | 
 **remove** | **bool** | Delete mapping instead of flush mapping from cache. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1ProvidersAdsById

> DeleteAuthv1ProvidersAdsById(ctx, v1ProvidersAdsId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersAdsId := "v1ProvidersAdsId_example" // string | Delete the ADS provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1ProvidersAdsById(context.Background(), v1ProvidersAdsId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1ProvidersAdsById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersAdsId** | **string** | Delete the ADS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1ProvidersAdsByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1ProvidersFileById

> DeleteAuthv1ProvidersFileById(ctx, v1ProvidersFileId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersFileId := "v1ProvidersFileId_example" // string | Delete the file provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1ProvidersFileById(context.Background(), v1ProvidersFileId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1ProvidersFileById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersFileId** | **string** | Delete the file provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1ProvidersFileByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1ProvidersKrb5ById

> DeleteAuthv1ProvidersKrb5ById(ctx, v1ProvidersKrb5Id).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersKrb5Id := "v1ProvidersKrb5Id_example" // string | Delete the KRB5 provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1ProvidersKrb5ById(context.Background(), v1ProvidersKrb5Id).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1ProvidersKrb5ById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersKrb5Id** | **string** | Delete the KRB5 provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1ProvidersKrb5ByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1ProvidersLdapById

> DeleteAuthv1ProvidersLdapById(ctx, v1ProvidersLdapId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersLdapId := "v1ProvidersLdapId_example" // string | Delete the LDAP provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1ProvidersLdapById(context.Background(), v1ProvidersLdapId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersLdapId** | **string** | Delete the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1ProvidersNisById

> DeleteAuthv1ProvidersNisById(ctx, v1ProvidersNisId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersNisId := "v1ProvidersNisId_example" // string | Delete the NIS provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1ProvidersNisById(context.Background(), v1ProvidersNisId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1ProvidersNisById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersNisId** | **string** | Delete the NIS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1ProvidersNisByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1RolesRoleMember

> DeleteAuthv1RolesRoleMember(ctx, v1RolesRoleMemberId, role).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1RolesRoleMemberId := "v1RolesRoleMemberId_example" // string | Remove a member from the role.
    role := "role_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1RolesRoleMember(context.Background(), v1RolesRoleMemberId, role).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1RolesRoleMember``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1RolesRoleMemberId** | **string** | Remove a member from the role. | 
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1RolesRoleMemberRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1RolesRolePrivilege

> DeleteAuthv1RolesRolePrivilege(ctx, v1RolesRolePrivilegeId, role).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1RolesRolePrivilegeId := "v1RolesRolePrivilegeId_example" // string | Remove a privilege from a role.
    role := "role_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1RolesRolePrivilege(context.Background(), v1RolesRolePrivilegeId, role).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1RolesRolePrivilege``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1RolesRolePrivilegeId** | **string** | Remove a privilege from a role. | 
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1RolesRolePrivilegeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1SettingsKrb5Domain

> DeleteAuthv1SettingsKrb5Domain(ctx, v1SettingsKrb5DomainId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsKrb5DomainId := "v1SettingsKrb5DomainId_example" // string | Remove a krb5 domain.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1SettingsKrb5Domain(context.Background(), v1SettingsKrb5DomainId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1SettingsKrb5Domain``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsKrb5DomainId** | **string** | Remove a krb5 domain. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1SettingsKrb5DomainRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv1SettingsKrb5Realm

> DeleteAuthv1SettingsKrb5Realm(ctx, v1SettingsKrb5RealmId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsKrb5RealmId := "v1SettingsKrb5RealmId_example" // string | Remove a realm.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv1SettingsKrb5Realm(context.Background(), v1SettingsKrb5RealmId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv1SettingsKrb5Realm``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsKrb5RealmId** | **string** | Remove a realm. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv1SettingsKrb5RealmRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv3ProvidersAdsById

> DeleteAuthv3ProvidersAdsById(ctx, v3ProvidersAdsId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersAdsId := "v3ProvidersAdsId_example" // string | Delete the ADS provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv3ProvidersAdsById(context.Background(), v3ProvidersAdsId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv3ProvidersAdsById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersAdsId** | **string** | Delete the ADS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv3ProvidersAdsByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv3ProvidersKrb5ById

> DeleteAuthv3ProvidersKrb5ById(ctx, v3ProvidersKrb5Id).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersKrb5Id := "v3ProvidersKrb5Id_example" // string | Delete the KRB5 provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv3ProvidersKrb5ById(context.Background(), v3ProvidersKrb5Id).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv3ProvidersKrb5ById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersKrb5Id** | **string** | Delete the KRB5 provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv3ProvidersKrb5ByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv3ProvidersLdapById

> DeleteAuthv3ProvidersLdapById(ctx, v3ProvidersLdapId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersLdapId := "v3ProvidersLdapId_example" // string | Delete the LDAP provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv3ProvidersLdapById(context.Background(), v3ProvidersLdapId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv3ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersLdapId** | **string** | Delete the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv3ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv3ProvidersNisById

> DeleteAuthv3ProvidersNisById(ctx, v3ProvidersNisId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersNisId := "v3ProvidersNisId_example" // string | Delete the NIS provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv3ProvidersNisById(context.Background(), v3ProvidersNisId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv3ProvidersNisById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersNisId** | **string** | Delete the NIS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv3ProvidersNisByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv3UsersUserMemberOfMemberOf

> DeleteAuthv3UsersUserMemberOfMemberOf(ctx, v3UsersUserMemberOfMemberOf, user).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3UsersUserMemberOfMemberOf := "v3UsersUserMemberOfMemberOf_example" // string | Remove the user from the group.
    user := "user_example" // string | 
    zone := "zone_example" // string | Filter groups by zone. (optional)
    provider := "provider_example" // string | Filter groups by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv3UsersUserMemberOfMemberOf(context.Background(), v3UsersUserMemberOfMemberOf, user).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv3UsersUserMemberOfMemberOf``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3UsersUserMemberOfMemberOf** | **string** | Remove the user from the group. | 
**user** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv3UsersUserMemberOfMemberOfRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **zone** | **string** | Filter groups by zone. | 
 **provider** | **string** | Filter groups by provider. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv4ProvidersLdapById

> DeleteAuthv4ProvidersLdapById(ctx, v4ProvidersLdapId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4ProvidersLdapId := "v4ProvidersLdapId_example" // string | Delete the LDAP provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv4ProvidersLdapById(context.Background(), v4ProvidersLdapId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv4ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4ProvidersLdapId** | **string** | Delete the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv4ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv7AuthRole

> DeleteAuthv7AuthRole(ctx, v7AuthRoleId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuthRoleId := "v7AuthRoleId_example" // string | Delete the role.
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv7AuthRole(context.Background(), v7AuthRoleId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv7AuthRole``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7AuthRoleId** | **string** | Delete the role. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv7AuthRoleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv7AuthUser

> DeleteAuthv7AuthUser(ctx, v7AuthUserId).Cached(cached).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuthUserId := "v7AuthUserId_example" // string | Delete the user.
    cached := true // bool | If true, flush the user from the cache. (optional)
    zone := "zone_example" // string | Filter users by zone. (optional)
    provider := "provider_example" // string | Filter users by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv7AuthUser(context.Background(), v7AuthUserId).Cached(cached).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv7AuthUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7AuthUserId** | **string** | Delete the user. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv7AuthUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **cached** | **bool** | If true, flush the user from the cache. | 
 **zone** | **string** | Filter users by zone. | 
 **provider** | **string** | Filter users by provider. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv7AuthUsers

> DeleteAuthv7AuthUsers(ctx).Cached(cached).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    cached := true // bool | If true, only flush cached objects. (optional)
    zone := "zone_example" // string | Filter users by zone. (optional)
    provider := "provider_example" // string | Filter users by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv7AuthUsers(context.Background()).Cached(cached).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv7AuthUsers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv7AuthUsersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **cached** | **bool** | If true, only flush cached objects. | 
 **zone** | **string** | Filter users by zone. | 
 **provider** | **string** | Filter users by provider. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv7ProvidersAdsById

> DeleteAuthv7ProvidersAdsById(ctx, v7ProvidersAdsId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersAdsId := "v7ProvidersAdsId_example" // string | Delete the ADS provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv7ProvidersAdsById(context.Background(), v7ProvidersAdsId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv7ProvidersAdsById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersAdsId** | **string** | Delete the ADS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv7ProvidersAdsByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv7ProvidersFileById

> DeleteAuthv7ProvidersFileById(ctx, v7ProvidersFileId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersFileId := "v7ProvidersFileId_example" // string | Delete the file provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv7ProvidersFileById(context.Background(), v7ProvidersFileId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv7ProvidersFileById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersFileId** | **string** | Delete the file provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv7ProvidersFileByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv7ProvidersKrb5ById

> DeleteAuthv7ProvidersKrb5ById(ctx, v7ProvidersKrb5Id).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersKrb5Id := "v7ProvidersKrb5Id_example" // string | Delete the KRB5 provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv7ProvidersKrb5ById(context.Background(), v7ProvidersKrb5Id).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv7ProvidersKrb5ById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersKrb5Id** | **string** | Delete the KRB5 provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv7ProvidersKrb5ByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv7ProvidersLdapById

> DeleteAuthv7ProvidersLdapById(ctx, v7ProvidersLdapId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersLdapId := "v7ProvidersLdapId_example" // string | Delete the LDAP provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv7ProvidersLdapById(context.Background(), v7ProvidersLdapId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv7ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersLdapId** | **string** | Delete the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv7ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv7ProvidersNisById

> DeleteAuthv7ProvidersNisById(ctx, v7ProvidersNisId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersNisId := "v7ProvidersNisId_example" // string | Delete the NIS provider.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv7ProvidersNisById(context.Background(), v7ProvidersNisId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv7ProvidersNisById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersNisId** | **string** | Delete the NIS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv7ProvidersNisByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv7RolesRoleMember

> DeleteAuthv7RolesRoleMember(ctx, v7RolesRoleMemberId, role).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7RolesRoleMemberId := "v7RolesRoleMemberId_example" // string | Remove a member from the role.
    role := "role_example" // string | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv7RolesRoleMember(context.Background(), v7RolesRoleMemberId, role).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv7RolesRoleMember``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7RolesRoleMemberId** | **string** | Remove a member from the role. | 
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv7RolesRoleMemberRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuthv7RolesRolePrivilege

> DeleteAuthv7RolesRolePrivilege(ctx, v7RolesRolePrivilegeId, role).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7RolesRolePrivilegeId := "v7RolesRolePrivilegeId_example" // string | Remove a privilege from a role.
    role := "role_example" // string | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.DeleteAuthv7RolesRolePrivilege(context.Background(), v7RolesRolePrivilegeId, role).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.DeleteAuthv7RolesRolePrivilege``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7RolesRolePrivilegeId** | **string** | Remove a privilege from a role. | 
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuthv7RolesRolePrivilegeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv11ProvidersLdapById

> V11ProvidersLdap GetAuthv11ProvidersLdapById(ctx, v11ProvidersLdapId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11ProvidersLdapId := "v11ProvidersLdapId_example" // string | Retrieve the LDAP provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv11ProvidersLdapById(context.Background(), v11ProvidersLdapId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv11ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv11ProvidersLdapById`: V11ProvidersLdap
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv11ProvidersLdapById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11ProvidersLdapId** | **string** | Retrieve the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv11ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V11ProvidersLdap**](V11ProvidersLdap.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv11ProvidersSummary

> V11ProvidersSummary GetAuthv11ProvidersSummary(ctx).Groupnet(groupnet).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | Filter providers by groupnet. (optional)
    zone := "zone_example" // string | Filter providers by zone. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv11ProvidersSummary(context.Background()).Groupnet(groupnet).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv11ProvidersSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv11ProvidersSummary`: V11ProvidersSummary
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv11ProvidersSummary`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv11ProvidersSummaryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupnet** | **string** | Filter providers by groupnet. | 
 **zone** | **string** | Filter providers by zone. | 

### Return type

[**V11ProvidersSummary**](V11ProvidersSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv11SettingsAcls

> V11SettingsAcls GetAuthv11SettingsAcls(ctx).Preset(preset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    preset := "preset_example" // string | If specified the preset configuration values for all applicable ACL policies are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv11SettingsAcls(context.Background()).Preset(preset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv11SettingsAcls``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv11SettingsAcls`: V11SettingsAcls
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv11SettingsAcls`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv11SettingsAclsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **preset** | **string** | If specified the preset configuration values for all applicable ACL policies are returned. | 

### Return type

[**V11SettingsAcls**](V11SettingsAcls.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv12AuthLogLevel

> V12AuthLogLevel GetAuthv12AuthLogLevel(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv12AuthLogLevel(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv12AuthLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv12AuthLogLevel`: V12AuthLogLevel
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv12AuthLogLevel`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv12AuthLogLevelRequest struct via the builder pattern


### Return type

[**V12AuthLogLevel**](V12AuthLogLevel.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1AuthAccessUser

> V1AuthAccess GetAuthv1AuthAccessUser(ctx, v1AuthAccessUser).Path(path).Share(share).Zone(zone).Numeric(numeric).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthAccessUser := "v1AuthAccessUser_example" // string | Determine user's access rights to a file
    path := "path_example" // string | Path to the file. Must be within /ifs. (optional)
    share := "share_example" // string | SMB share name (optional)
    zone := "zone_example" // string | Access zone the user is in. (optional)
    numeric := true // bool | Show the user's numeric identifier. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1AuthAccessUser(context.Background(), v1AuthAccessUser).Path(path).Share(share).Zone(zone).Numeric(numeric).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1AuthAccessUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1AuthAccessUser`: V1AuthAccess
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1AuthAccessUser`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthAccessUser** | **string** | Determine user&#39;s access rights to a file | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1AuthAccessUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **path** | **string** | Path to the file. Must be within /ifs. | 
 **share** | **string** | SMB share name | 
 **zone** | **string** | Access zone the user is in. | 
 **numeric** | **bool** | Show the user&#39;s numeric identifier. | 

### Return type

[**V1AuthAccess**](V1AuthAccess.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1AuthGroup

> V1AuthGroupsExtended GetAuthv1AuthGroup(ctx, v1AuthGroupId).Cached(cached).ResolveNames(resolveNames).QueryMemberOf(queryMemberOf).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthGroupId := "v1AuthGroupId_example" // string | Retrieve the group information.
    cached := true // bool | If true, only return cached objects. (optional)
    resolveNames := true // bool | Resolve names of personas. (optional)
    queryMemberOf := true // bool | Enumerate all groups that a group is a member of. (optional)
    zone := "zone_example" // string | Filter groups by zone. (optional)
    provider := "provider_example" // string | Filter groups by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1AuthGroup(context.Background(), v1AuthGroupId).Cached(cached).ResolveNames(resolveNames).QueryMemberOf(queryMemberOf).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1AuthGroup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1AuthGroup`: V1AuthGroupsExtended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1AuthGroup`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthGroupId** | **string** | Retrieve the group information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1AuthGroupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **cached** | **bool** | If true, only return cached objects. | 
 **resolveNames** | **bool** | Resolve names of personas. | 
 **queryMemberOf** | **bool** | Enumerate all groups that a group is a member of. | 
 **zone** | **string** | Filter groups by zone. | 
 **provider** | **string** | Filter groups by provider. | 

### Return type

[**V1AuthGroupsExtended**](V1AuthGroupsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1AuthId

> V1AuthId GetAuthv1AuthId(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1AuthId(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1AuthId``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1AuthId`: V1AuthId
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1AuthId`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1AuthIdRequest struct via the builder pattern


### Return type

[**V1AuthId**](V1AuthId.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1AuthNetgroup

> V1AuthNetgroups GetAuthv1AuthNetgroup(ctx, v1AuthNetgroupId).IgnoreErrors(ignoreErrors).Recursive(recursive).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthNetgroupId := "v1AuthNetgroupId_example" // string | Retrieve the user information.
    ignoreErrors := true // bool | Ignore netgroup errors. (optional)
    recursive := true // bool | Perform recursive search. (optional)
    zone := "zone_example" // string | Filter users by zone. (optional)
    provider := "provider_example" // string | Filter users by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1AuthNetgroup(context.Background(), v1AuthNetgroupId).IgnoreErrors(ignoreErrors).Recursive(recursive).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1AuthNetgroup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1AuthNetgroup`: V1AuthNetgroups
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1AuthNetgroup`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthNetgroupId** | **string** | Retrieve the user information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1AuthNetgroupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **ignoreErrors** | **bool** | Ignore netgroup errors. | 
 **recursive** | **bool** | Perform recursive search. | 
 **zone** | **string** | Filter users by zone. | 
 **provider** | **string** | Filter users by provider. | 

### Return type

[**V1AuthNetgroups**](V1AuthNetgroups.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1AuthPrivileges

> V1AuthPrivileges GetAuthv1AuthPrivileges(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1AuthPrivileges(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1AuthPrivileges``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1AuthPrivileges`: V1AuthPrivileges
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1AuthPrivileges`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1AuthPrivilegesRequest struct via the builder pattern


### Return type

[**V1AuthPrivileges**](V1AuthPrivileges.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1AuthRole

> V1AuthRolesExtended GetAuthv1AuthRole(ctx, v1AuthRoleId).ResolveNames(resolveNames).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthRoleId := "v1AuthRoleId_example" // string | Retrieve the role information.
    resolveNames := true // bool | Resolve names of personas. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1AuthRole(context.Background(), v1AuthRoleId).ResolveNames(resolveNames).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1AuthRole``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1AuthRole`: V1AuthRolesExtended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1AuthRole`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthRoleId** | **string** | Retrieve the role information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1AuthRoleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **resolveNames** | **bool** | Resolve names of personas. | 

### Return type

[**V1AuthRolesExtended**](V1AuthRolesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1AuthShells

> V1AuthShells GetAuthv1AuthShells(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1AuthShells(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1AuthShells``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1AuthShells`: V1AuthShells
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1AuthShells`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1AuthShellsRequest struct via the builder pattern


### Return type

[**V1AuthShells**](V1AuthShells.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1AuthUser

> V1AuthUsersExtended GetAuthv1AuthUser(ctx, v1AuthUserId).Cached(cached).ResolveNames(resolveNames).QueryMemberOf(queryMemberOf).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthUserId := "v1AuthUserId_example" // string | Retrieve the user information.
    cached := true // bool | If true, only return cached objects. (optional)
    resolveNames := true // bool | Resolve names of personas. (optional)
    queryMemberOf := true // bool | Enumerate all users that a group is a member of. (optional)
    zone := "zone_example" // string | Filter users by zone. (optional)
    provider := "provider_example" // string | Filter users by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1AuthUser(context.Background(), v1AuthUserId).Cached(cached).ResolveNames(resolveNames).QueryMemberOf(queryMemberOf).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1AuthUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1AuthUser`: V1AuthUsersExtended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1AuthUser`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthUserId** | **string** | Retrieve the user information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1AuthUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **cached** | **bool** | If true, only return cached objects. | 
 **resolveNames** | **bool** | Resolve names of personas. | 
 **queryMemberOf** | **bool** | Enumerate all users that a group is a member of. | 
 **zone** | **string** | Filter users by zone. | 
 **provider** | **string** | Filter users by provider. | 

### Return type

[**V1AuthUsersExtended**](V1AuthUsersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1AuthWellknown

> V1AuthWellknowns GetAuthv1AuthWellknown(ctx, v1AuthWellknownId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthWellknownId := "v1AuthWellknownId_example" // string | Retrieve the wellknown persona.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1AuthWellknown(context.Background(), v1AuthWellknownId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1AuthWellknown``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1AuthWellknown`: V1AuthWellknowns
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1AuthWellknown`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthWellknownId** | **string** | Retrieve the wellknown persona. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1AuthWellknownRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1AuthWellknowns**](V1AuthWellknowns.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1AuthWellknowns

> V1AuthWellknowns GetAuthv1AuthWellknowns(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1AuthWellknowns(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1AuthWellknowns``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1AuthWellknowns`: V1AuthWellknowns
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1AuthWellknowns`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1AuthWellknownsRequest struct via the builder pattern


### Return type

[**V1AuthWellknowns**](V1AuthWellknowns.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1MappingIdentity

> V1MappingIdentitiesExtended GetAuthv1MappingIdentity(ctx, v1MappingIdentityId).Nocreate(nocreate).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1MappingIdentityId := "v1MappingIdentityId_example" // string | Retrieve all identity mappings (uid, gid, sid, and on-disk) for the supplied source persona.
    nocreate := true // bool | Idmap should attempt to create missing identity mappings. (optional)
    zone := "zone_example" // string | Optional zone. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1MappingIdentity(context.Background(), v1MappingIdentityId).Nocreate(nocreate).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1MappingIdentity``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1MappingIdentity`: V1MappingIdentitiesExtended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1MappingIdentity`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1MappingIdentityId** | **string** | Retrieve all identity mappings (uid, gid, sid, and on-disk) for the supplied source persona. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1MappingIdentityRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **nocreate** | **bool** | Idmap should attempt to create missing identity mappings. | 
 **zone** | **string** | Optional zone. | 

### Return type

[**V1MappingIdentitiesExtended**](V1MappingIdentitiesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1MappingUsersLookup

> V1MappingUsersLookup GetAuthv1MappingUsersLookup(ctx).PrimaryGid(primaryGid).Uid(uid).Zone(zone).Gid(gid).User(user).KerberosPrincipal(kerberosPrincipal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    primaryGid := int32(56) // int32 | The user's primary group ID. (optional)
    uid := int32(56) // int32 | The user ID. (optional)
    zone := "zone_example" // string | The zone the user belongs to. (optional)
    gid := []int32{int32(123)} // []int32 | The IDs of the groups that the user belongs to. (optional)
    user := "user_example" // string | The user name. (optional)
    kerberosPrincipal := "kerberosPrincipal_example" // string | The Kerberos principal name, of the form user@realm. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1MappingUsersLookup(context.Background()).PrimaryGid(primaryGid).Uid(uid).Zone(zone).Gid(gid).User(user).KerberosPrincipal(kerberosPrincipal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1MappingUsersLookup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1MappingUsersLookup`: V1MappingUsersLookup
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1MappingUsersLookup`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1MappingUsersLookupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **primaryGid** | **int32** | The user&#39;s primary group ID. | 
 **uid** | **int32** | The user ID. | 
 **zone** | **string** | The zone the user belongs to. | 
 **gid** | **[]int32** | The IDs of the groups that the user belongs to. | 
 **user** | **string** | The user name. | 
 **kerberosPrincipal** | **string** | The Kerberos principal name, of the form user@realm. | 

### Return type

[**V1MappingUsersLookup**](V1MappingUsersLookup.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1MappingUsersRules

> V1MappingUsersRules GetAuthv1MappingUsersRules(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | The zone to which the user mapping applies. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1MappingUsersRules(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1MappingUsersRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1MappingUsersRules`: V1MappingUsersRules
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1MappingUsersRules`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1MappingUsersRulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | The zone to which the user mapping applies. | 

### Return type

[**V1MappingUsersRules**](V1MappingUsersRules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1ProvidersAdsById

> V1ProvidersAdsExtended GetAuthv1ProvidersAdsById(ctx, v1ProvidersAdsId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersAdsId := "v1ProvidersAdsId_example" // string | Retrieve the ADS provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1ProvidersAdsById(context.Background(), v1ProvidersAdsId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1ProvidersAdsById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1ProvidersAdsById`: V1ProvidersAdsExtended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1ProvidersAdsById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersAdsId** | **string** | Retrieve the ADS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1ProvidersAdsByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersAdsExtended**](V1ProvidersAdsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1ProvidersAdsIdDomain

> V1AdsProviderDomains GetAuthv1ProvidersAdsIdDomain(ctx, v1ProvidersAdsIdDomainId, id).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersAdsIdDomainId := "v1ProvidersAdsIdDomainId_example" // string | Retrieve the ADS domain information.
    id := "id_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1ProvidersAdsIdDomain(context.Background(), v1ProvidersAdsIdDomainId, id).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1ProvidersAdsIdDomain``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1ProvidersAdsIdDomain`: V1AdsProviderDomains
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1ProvidersAdsIdDomain`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersAdsIdDomainId** | **string** | Retrieve the ADS domain information. | 
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1ProvidersAdsIdDomainRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V1AdsProviderDomains**](V1AdsProviderDomains.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1ProvidersFileById

> V1ProvidersFile GetAuthv1ProvidersFileById(ctx, v1ProvidersFileId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersFileId := "v1ProvidersFileId_example" // string | Retrieve the file provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1ProvidersFileById(context.Background(), v1ProvidersFileId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1ProvidersFileById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1ProvidersFileById`: V1ProvidersFile
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1ProvidersFileById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersFileId** | **string** | Retrieve the file provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1ProvidersFileByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersFile**](V1ProvidersFile.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1ProvidersKrb5ById

> V1ProvidersKrb5Extended GetAuthv1ProvidersKrb5ById(ctx, v1ProvidersKrb5Id).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersKrb5Id := "v1ProvidersKrb5Id_example" // string | Retrieve the KRB5 provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1ProvidersKrb5ById(context.Background(), v1ProvidersKrb5Id).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1ProvidersKrb5ById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1ProvidersKrb5ById`: V1ProvidersKrb5Extended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1ProvidersKrb5ById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersKrb5Id** | **string** | Retrieve the KRB5 provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1ProvidersKrb5ByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersKrb5Extended**](V1ProvidersKrb5Extended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1ProvidersLdapById

> V1ProvidersLdap GetAuthv1ProvidersLdapById(ctx, v1ProvidersLdapId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersLdapId := "v1ProvidersLdapId_example" // string | Retrieve the LDAP provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1ProvidersLdapById(context.Background(), v1ProvidersLdapId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1ProvidersLdapById`: V1ProvidersLdap
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1ProvidersLdapById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersLdapId** | **string** | Retrieve the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersLdap**](V1ProvidersLdap.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1ProvidersLocal

> V1ProvidersLocal GetAuthv1ProvidersLocal(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1ProvidersLocal(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1ProvidersLocal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1ProvidersLocal`: V1ProvidersLocal
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1ProvidersLocal`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1ProvidersLocalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersLocal**](V1ProvidersLocal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1ProvidersLocalById

> V1ProvidersLocal GetAuthv1ProvidersLocalById(ctx, v1ProvidersLocalId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersLocalId := "v1ProvidersLocalId_example" // string | Retrieve the local provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1ProvidersLocalById(context.Background(), v1ProvidersLocalId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1ProvidersLocalById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1ProvidersLocalById`: V1ProvidersLocal
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1ProvidersLocalById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersLocalId** | **string** | Retrieve the local provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1ProvidersLocalByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersLocal**](V1ProvidersLocal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1ProvidersNisById

> V1ProvidersNis GetAuthv1ProvidersNisById(ctx, v1ProvidersNisId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersNisId := "v1ProvidersNisId_example" // string | Retrieve the NIS provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1ProvidersNisById(context.Background(), v1ProvidersNisId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1ProvidersNisById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1ProvidersNisById`: V1ProvidersNis
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1ProvidersNisById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersNisId** | **string** | Retrieve the NIS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1ProvidersNisByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersNis**](V1ProvidersNis.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1ProvidersSummary

> V1ProvidersSummary GetAuthv1ProvidersSummary(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Filter providers by zone. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1ProvidersSummary(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1ProvidersSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1ProvidersSummary`: V1ProvidersSummary
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1ProvidersSummary`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1ProvidersSummaryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Filter providers by zone. | 

### Return type

[**V1ProvidersSummary**](V1ProvidersSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1SettingsGlobal

> V1SettingsGlobal GetAuthv1SettingsGlobal(ctx).Scope(scope).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    zone := "zone_example" // string | Zone which contains any per-zone settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1SettingsGlobal(context.Background()).Scope(scope).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1SettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1SettingsGlobal`: V1SettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1SettingsGlobal`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1SettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **zone** | **string** | Zone which contains any per-zone settings. | 

### Return type

[**V1SettingsGlobal**](V1SettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1SettingsKrb5Defaults

> V1SettingsKrb5Defaults GetAuthv1SettingsKrb5Defaults(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1SettingsKrb5Defaults(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1SettingsKrb5Defaults``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1SettingsKrb5Defaults`: V1SettingsKrb5Defaults
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1SettingsKrb5Defaults`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1SettingsKrb5DefaultsRequest struct via the builder pattern


### Return type

[**V1SettingsKrb5Defaults**](V1SettingsKrb5Defaults.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1SettingsKrb5Domain

> V1SettingsKrb5Domains GetAuthv1SettingsKrb5Domain(ctx, v1SettingsKrb5DomainId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsKrb5DomainId := "v1SettingsKrb5DomainId_example" // string | View the krb5 domain settings.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1SettingsKrb5Domain(context.Background(), v1SettingsKrb5DomainId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1SettingsKrb5Domain``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1SettingsKrb5Domain`: V1SettingsKrb5Domains
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1SettingsKrb5Domain`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsKrb5DomainId** | **string** | View the krb5 domain settings. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1SettingsKrb5DomainRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1SettingsKrb5Domains**](V1SettingsKrb5Domains.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1SettingsKrb5Realm

> V1SettingsKrb5Realms GetAuthv1SettingsKrb5Realm(ctx, v1SettingsKrb5RealmId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsKrb5RealmId := "v1SettingsKrb5RealmId_example" // string | Retrieve the krb5 settings for realms.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1SettingsKrb5Realm(context.Background(), v1SettingsKrb5RealmId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1SettingsKrb5Realm``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1SettingsKrb5Realm`: V1SettingsKrb5Realms
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1SettingsKrb5Realm`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsKrb5RealmId** | **string** | Retrieve the krb5 settings for realms. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1SettingsKrb5RealmRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1SettingsKrb5Realms**](V1SettingsKrb5Realms.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv1SettingsMapping

> V1SettingsMapping GetAuthv1SettingsMapping(ctx).Scope(scope).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    zone := "zone_example" // string | Access zone which contains mapping settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv1SettingsMapping(context.Background()).Scope(scope).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv1SettingsMapping``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv1SettingsMapping`: V1SettingsMapping
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv1SettingsMapping`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv1SettingsMappingRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **zone** | **string** | Access zone which contains mapping settings. | 

### Return type

[**V1SettingsMapping**](V1SettingsMapping.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv3AuthLogLevel

> V3AuthLogLevel GetAuthv3AuthLogLevel(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv3AuthLogLevel(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv3AuthLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv3AuthLogLevel`: V3AuthLogLevel
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv3AuthLogLevel`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv3AuthLogLevelRequest struct via the builder pattern


### Return type

[**V3AuthLogLevel**](V3AuthLogLevel.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv3MappingDump

> V3MappingDump GetAuthv3MappingDump(ctx).Nocreate(nocreate).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    nocreate := true // bool | Idmap should attempt to create missing identity mappings. (optional)
    zone := "zone_example" // string | Optional zone. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv3MappingDump(context.Background()).Nocreate(nocreate).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv3MappingDump``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv3MappingDump`: V3MappingDump
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv3MappingDump`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv3MappingDumpRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **nocreate** | **bool** | Idmap should attempt to create missing identity mappings. | 
 **zone** | **string** | Optional zone. | 

### Return type

[**V3MappingDump**](V3MappingDump.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv3ProvidersAdsById

> V3ProvidersAdsExtended GetAuthv3ProvidersAdsById(ctx, v3ProvidersAdsId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersAdsId := "v3ProvidersAdsId_example" // string | Retrieve the ADS provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv3ProvidersAdsById(context.Background(), v3ProvidersAdsId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv3ProvidersAdsById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv3ProvidersAdsById`: V3ProvidersAdsExtended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv3ProvidersAdsById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersAdsId** | **string** | Retrieve the ADS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv3ProvidersAdsByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3ProvidersAdsExtended**](V3ProvidersAdsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv3ProvidersAdsIdDomain

> V3AdsProviderDomains GetAuthv3ProvidersAdsIdDomain(ctx, v3ProvidersAdsIdDomainId, id).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersAdsIdDomainId := "v3ProvidersAdsIdDomainId_example" // string | Retrieve the ADS domain information.
    id := "id_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv3ProvidersAdsIdDomain(context.Background(), v3ProvidersAdsIdDomainId, id).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv3ProvidersAdsIdDomain``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv3ProvidersAdsIdDomain`: V3AdsProviderDomains
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv3ProvidersAdsIdDomain`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersAdsIdDomainId** | **string** | Retrieve the ADS domain information. | 
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv3ProvidersAdsIdDomainRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V3AdsProviderDomains**](V3AdsProviderDomains.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv3ProvidersKrb5ById

> V3ProvidersKrb5Extended GetAuthv3ProvidersKrb5ById(ctx, v3ProvidersKrb5Id).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersKrb5Id := "v3ProvidersKrb5Id_example" // string | Retrieve the KRB5 provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv3ProvidersKrb5ById(context.Background(), v3ProvidersKrb5Id).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv3ProvidersKrb5ById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv3ProvidersKrb5ById`: V3ProvidersKrb5Extended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv3ProvidersKrb5ById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersKrb5Id** | **string** | Retrieve the KRB5 provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv3ProvidersKrb5ByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3ProvidersKrb5Extended**](V3ProvidersKrb5Extended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv3ProvidersLdapById

> V3ProvidersLdap GetAuthv3ProvidersLdapById(ctx, v3ProvidersLdapId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersLdapId := "v3ProvidersLdapId_example" // string | Retrieve the LDAP provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv3ProvidersLdapById(context.Background(), v3ProvidersLdapId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv3ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv3ProvidersLdapById`: V3ProvidersLdap
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv3ProvidersLdapById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersLdapId** | **string** | Retrieve the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv3ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3ProvidersLdap**](V3ProvidersLdap.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv3ProvidersNisById

> V3ProvidersNis GetAuthv3ProvidersNisById(ctx, v3ProvidersNisId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersNisId := "v3ProvidersNisId_example" // string | Retrieve the NIS provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv3ProvidersNisById(context.Background(), v3ProvidersNisId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv3ProvidersNisById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv3ProvidersNisById`: V3ProvidersNis
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv3ProvidersNisById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersNisId** | **string** | Retrieve the NIS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv3ProvidersNisByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3ProvidersNis**](V3ProvidersNis.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv3ProvidersSummary

> V3ProvidersSummary GetAuthv3ProvidersSummary(ctx).Groupnet(groupnet).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | Filter providers by groupnet. (optional)
    zone := "zone_example" // string | Filter providers by zone. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv3ProvidersSummary(context.Background()).Groupnet(groupnet).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv3ProvidersSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv3ProvidersSummary`: V3ProvidersSummary
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv3ProvidersSummary`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv3ProvidersSummaryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupnet** | **string** | Filter providers by groupnet. | 
 **zone** | **string** | Filter providers by zone. | 

### Return type

[**V3ProvidersSummary**](V3ProvidersSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv3SettingsAcls

> V3SettingsAcls GetAuthv3SettingsAcls(ctx).Preset(preset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    preset := "preset_example" // string | If specified the preset configuration values for all applicable ACL policies are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv3SettingsAcls(context.Background()).Preset(preset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv3SettingsAcls``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv3SettingsAcls`: V3SettingsAcls
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv3SettingsAcls`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv3SettingsAclsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **preset** | **string** | If specified the preset configuration values for all applicable ACL policies are returned. | 

### Return type

[**V3SettingsAcls**](V3SettingsAcls.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv4AuthLdapTemplate

> V4AuthLdapTemplates GetAuthv4AuthLdapTemplate(ctx, v4AuthLdapTemplateId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4AuthLdapTemplateId := "v4AuthLdapTemplateId_example" // string | Retrieve the LDAP provider template.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv4AuthLdapTemplate(context.Background(), v4AuthLdapTemplateId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv4AuthLdapTemplate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv4AuthLdapTemplate`: V4AuthLdapTemplates
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv4AuthLdapTemplate`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4AuthLdapTemplateId** | **string** | Retrieve the LDAP provider template. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv4AuthLdapTemplateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4AuthLdapTemplates**](V4AuthLdapTemplates.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv4AuthLdapTemplates

> V4AuthLdapTemplates GetAuthv4AuthLdapTemplates(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv4AuthLdapTemplates(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv4AuthLdapTemplates``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv4AuthLdapTemplates`: V4AuthLdapTemplates
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv4AuthLdapTemplates`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv4AuthLdapTemplatesRequest struct via the builder pattern


### Return type

[**V4AuthLdapTemplates**](V4AuthLdapTemplates.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv4ProvidersLdapById

> V4ProvidersLdap GetAuthv4ProvidersLdapById(ctx, v4ProvidersLdapId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4ProvidersLdapId := "v4ProvidersLdapId_example" // string | Retrieve the LDAP provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv4ProvidersLdapById(context.Background(), v4ProvidersLdapId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv4ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv4ProvidersLdapById`: V4ProvidersLdap
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv4ProvidersLdapById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4ProvidersLdapId** | **string** | Retrieve the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv4ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V4ProvidersLdap**](V4ProvidersLdap.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7AuthErrorError

> V7AuthError GetAuthv7AuthErrorError(ctx, v7AuthErrorError).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuthErrorError := "v7AuthErrorError_example" // string | Get descriptions for auth error codes

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7AuthErrorError(context.Background(), v7AuthErrorError).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7AuthErrorError``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7AuthErrorError`: V7AuthError
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7AuthErrorError`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7AuthErrorError** | **string** | Get descriptions for auth error codes | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7AuthErrorErrorRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7AuthError**](V7AuthError.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7AuthLdapTemplate

> V7AuthLdapTemplates GetAuthv7AuthLdapTemplate(ctx, v7AuthLdapTemplateId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuthLdapTemplateId := "v7AuthLdapTemplateId_example" // string | Retrieve the LDAP provider template.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7AuthLdapTemplate(context.Background(), v7AuthLdapTemplateId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7AuthLdapTemplate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7AuthLdapTemplate`: V7AuthLdapTemplates
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7AuthLdapTemplate`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7AuthLdapTemplateId** | **string** | Retrieve the LDAP provider template. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7AuthLdapTemplateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7AuthLdapTemplates**](V7AuthLdapTemplates.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7AuthLdapTemplates

> V7AuthLdapTemplates GetAuthv7AuthLdapTemplates(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7AuthLdapTemplates(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7AuthLdapTemplates``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7AuthLdapTemplates`: V7AuthLdapTemplates
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7AuthLdapTemplates`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7AuthLdapTemplatesRequest struct via the builder pattern


### Return type

[**V7AuthLdapTemplates**](V7AuthLdapTemplates.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7AuthPrivileges

> V1AuthPrivileges GetAuthv7AuthPrivileges(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7AuthPrivileges(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7AuthPrivileges``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7AuthPrivileges`: V1AuthPrivileges
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7AuthPrivileges`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7AuthPrivilegesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V1AuthPrivileges**](V1AuthPrivileges.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7AuthRole

> V1AuthRolesExtended GetAuthv7AuthRole(ctx, v7AuthRoleId).ResolveNames(resolveNames).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuthRoleId := "v7AuthRoleId_example" // string | Retrieve the role information.
    resolveNames := true // bool | Resolve names of personas. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7AuthRole(context.Background(), v7AuthRoleId).ResolveNames(resolveNames).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7AuthRole``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7AuthRole`: V1AuthRolesExtended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7AuthRole`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7AuthRoleId** | **string** | Retrieve the role information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7AuthRoleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **resolveNames** | **bool** | Resolve names of personas. | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V1AuthRolesExtended**](V1AuthRolesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7AuthUser

> V7AuthUsersExtended GetAuthv7AuthUser(ctx, v7AuthUserId).Cached(cached).ResolveNames(resolveNames).QueryMemberOf(queryMemberOf).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuthUserId := "v7AuthUserId_example" // string | Retrieve the user information.
    cached := true // bool | If true, only return cached objects. (optional)
    resolveNames := true // bool | Resolve names of personas. (optional)
    queryMemberOf := true // bool | Enumerate all users that a group is a member of. (optional)
    zone := "zone_example" // string | Filter users by zone. (optional)
    provider := "provider_example" // string | Filter users by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7AuthUser(context.Background(), v7AuthUserId).Cached(cached).ResolveNames(resolveNames).QueryMemberOf(queryMemberOf).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7AuthUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7AuthUser`: V7AuthUsersExtended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7AuthUser`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7AuthUserId** | **string** | Retrieve the user information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7AuthUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **cached** | **bool** | If true, only return cached objects. | 
 **resolveNames** | **bool** | Resolve names of personas. | 
 **queryMemberOf** | **bool** | Enumerate all users that a group is a member of. | 
 **zone** | **string** | Filter users by zone. | 
 **provider** | **string** | Filter users by provider. | 

### Return type

[**V7AuthUsersExtended**](V7AuthUsersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7ProvidersAdsById

> V7ProvidersAdsExtended GetAuthv7ProvidersAdsById(ctx, v7ProvidersAdsId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersAdsId := "v7ProvidersAdsId_example" // string | Retrieve the ADS provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7ProvidersAdsById(context.Background(), v7ProvidersAdsId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7ProvidersAdsById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7ProvidersAdsById`: V7ProvidersAdsExtended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7ProvidersAdsById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersAdsId** | **string** | Retrieve the ADS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7ProvidersAdsByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersAdsExtended**](V7ProvidersAdsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7ProvidersAdsIdDomain

> V3AdsProviderDomains GetAuthv7ProvidersAdsIdDomain(ctx, v7ProvidersAdsIdDomainId, id).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersAdsIdDomainId := "v7ProvidersAdsIdDomainId_example" // string | Retrieve the ADS domain information.
    id := "id_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7ProvidersAdsIdDomain(context.Background(), v7ProvidersAdsIdDomainId, id).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7ProvidersAdsIdDomain``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7ProvidersAdsIdDomain`: V3AdsProviderDomains
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7ProvidersAdsIdDomain`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersAdsIdDomainId** | **string** | Retrieve the ADS domain information. | 
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7ProvidersAdsIdDomainRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V3AdsProviderDomains**](V3AdsProviderDomains.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7ProvidersDuo

> V7ProvidersDuo GetAuthv7ProvidersDuo(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7ProvidersDuo(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7ProvidersDuo``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7ProvidersDuo`: V7ProvidersDuo
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7ProvidersDuo`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7ProvidersDuoRequest struct via the builder pattern


### Return type

[**V7ProvidersDuo**](V7ProvidersDuo.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7ProvidersFileById

> V7ProvidersFile GetAuthv7ProvidersFileById(ctx, v7ProvidersFileId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersFileId := "v7ProvidersFileId_example" // string | Retrieve the file provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7ProvidersFileById(context.Background(), v7ProvidersFileId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7ProvidersFileById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7ProvidersFileById`: V7ProvidersFile
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7ProvidersFileById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersFileId** | **string** | Retrieve the file provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7ProvidersFileByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersFile**](V7ProvidersFile.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7ProvidersKrb5ById

> V7ProvidersKrb5Extended GetAuthv7ProvidersKrb5ById(ctx, v7ProvidersKrb5Id).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersKrb5Id := "v7ProvidersKrb5Id_example" // string | Retrieve the KRB5 provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7ProvidersKrb5ById(context.Background(), v7ProvidersKrb5Id).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7ProvidersKrb5ById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7ProvidersKrb5ById`: V7ProvidersKrb5Extended
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7ProvidersKrb5ById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersKrb5Id** | **string** | Retrieve the KRB5 provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7ProvidersKrb5ByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersKrb5Extended**](V7ProvidersKrb5Extended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7ProvidersLdapById

> V7ProvidersLdap GetAuthv7ProvidersLdapById(ctx, v7ProvidersLdapId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersLdapId := "v7ProvidersLdapId_example" // string | Retrieve the LDAP provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7ProvidersLdapById(context.Background(), v7ProvidersLdapId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7ProvidersLdapById`: V7ProvidersLdap
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7ProvidersLdapById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersLdapId** | **string** | Retrieve the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersLdap**](V7ProvidersLdap.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7ProvidersLocal

> V7ProvidersLocal GetAuthv7ProvidersLocal(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7ProvidersLocal(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7ProvidersLocal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7ProvidersLocal`: V7ProvidersLocal
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7ProvidersLocal`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7ProvidersLocalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersLocal**](V7ProvidersLocal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7ProvidersLocalById

> V7ProvidersLocal GetAuthv7ProvidersLocalById(ctx, v7ProvidersLocalId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersLocalId := "v7ProvidersLocalId_example" // string | Retrieve the local provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7ProvidersLocalById(context.Background(), v7ProvidersLocalId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7ProvidersLocalById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7ProvidersLocalById`: V7ProvidersLocal
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7ProvidersLocalById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersLocalId** | **string** | Retrieve the local provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7ProvidersLocalByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersLocal**](V7ProvidersLocal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7ProvidersNisById

> V7ProvidersNis GetAuthv7ProvidersNisById(ctx, v7ProvidersNisId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersNisId := "v7ProvidersNisId_example" // string | Retrieve the NIS provider.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7ProvidersNisById(context.Background(), v7ProvidersNisId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7ProvidersNisById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7ProvidersNisById`: V7ProvidersNis
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7ProvidersNisById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersNisId** | **string** | Retrieve the NIS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7ProvidersNisByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersNis**](V7ProvidersNis.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv7SettingsAcls

> V7SettingsAcls GetAuthv7SettingsAcls(ctx).Preset(preset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    preset := "preset_example" // string | If specified the preset configuration values for all applicable ACL policies are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv7SettingsAcls(context.Background()).Preset(preset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv7SettingsAcls``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv7SettingsAcls`: V7SettingsAcls
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv7SettingsAcls`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv7SettingsAclsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **preset** | **string** | If specified the preset configuration values for all applicable ACL policies are returned. | 

### Return type

[**V7SettingsAcls**](V7SettingsAcls.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuthv9ProvidersSummary

> V11ProvidersSummary GetAuthv9ProvidersSummary(ctx).Groupnet(groupnet).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | Filter providers by groupnet. (optional)
    zone := "zone_example" // string | Filter providers by zone. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.GetAuthv9ProvidersSummary(context.Background()).Groupnet(groupnet).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.GetAuthv9ProvidersSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuthv9ProvidersSummary`: V11ProvidersSummary
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.GetAuthv9ProvidersSummary`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuthv9ProvidersSummaryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **groupnet** | **string** | Filter providers by groupnet. | 
 **zone** | **string** | Filter providers by zone. | 

### Return type

[**V11ProvidersSummary**](V11ProvidersSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv11ProvidersLdap

> V11ProvidersLdap ListAuthv11ProvidersLdap(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv11ProvidersLdap(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv11ProvidersLdap``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv11ProvidersLdap`: V11ProvidersLdap
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv11ProvidersLdap`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv11ProvidersLdapRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V11ProvidersLdap**](V11ProvidersLdap.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv1AuthGroups

> V1AuthGroups ListAuthv1AuthGroups(ctx).Domain(domain).Zone(zone).Resume(resume).Cached(cached).ResolveNames(resolveNames).Filter(filter).Limit(limit).Provider(provider).QueryMemberOf(queryMemberOf).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    domain := "domain_example" // string | Filter groups by domain. (optional)
    zone := "zone_example" // string | Filter groups by zone. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    cached := true // bool | If true, only return cached objects. (optional)
    resolveNames := true // bool | Resolve names of personas. (optional)
    filter := "filter_example" // string | Filter groups by name prefix. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    provider := "provider_example" // string | Filter groups by provider. (optional)
    queryMemberOf := true // bool | Enumerate all groups that a group is a member of. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv1AuthGroups(context.Background()).Domain(domain).Zone(zone).Resume(resume).Cached(cached).ResolveNames(resolveNames).Filter(filter).Limit(limit).Provider(provider).QueryMemberOf(queryMemberOf).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv1AuthGroups``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv1AuthGroups`: V1AuthGroups
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv1AuthGroups`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv1AuthGroupsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **string** | Filter groups by domain. | 
 **zone** | **string** | Filter groups by zone. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **cached** | **bool** | If true, only return cached objects. | 
 **resolveNames** | **bool** | Resolve names of personas. | 
 **filter** | **string** | Filter groups by name prefix. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **provider** | **string** | Filter groups by provider. | 
 **queryMemberOf** | **bool** | Enumerate all groups that a group is a member of. | 

### Return type

[**V1AuthGroups**](V1AuthGroups.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv1AuthRoles

> V1AuthRoles ListAuthv1AuthRoles(ctx).Sort(sort).ResolveNames(resolveNames).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resolveNames := true // bool | Filter users by zone. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv1AuthRoles(context.Background()).Sort(sort).ResolveNames(resolveNames).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv1AuthRoles``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv1AuthRoles`: V1AuthRoles
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv1AuthRoles`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv1AuthRolesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **resolveNames** | **bool** | Filter users by zone. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1AuthRoles**](V1AuthRoles.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv1AuthUsers

> V1AuthUsers ListAuthv1AuthUsers(ctx).Domain(domain).Zone(zone).Resume(resume).Cached(cached).ResolveNames(resolveNames).Filter(filter).Limit(limit).Provider(provider).QueryMemberOf(queryMemberOf).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    domain := "domain_example" // string | Filter users by domain. (optional)
    zone := "zone_example" // string | Filter users by zone. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    cached := true // bool | If true, only return cached objects. (optional)
    resolveNames := true // bool | Resolve names of personas. (optional)
    filter := "filter_example" // string | Filter users by name prefix. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    provider := "provider_example" // string | Filter users by provider. (optional)
    queryMemberOf := true // bool | Enumerate all users that a group is a member of. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv1AuthUsers(context.Background()).Domain(domain).Zone(zone).Resume(resume).Cached(cached).ResolveNames(resolveNames).Filter(filter).Limit(limit).Provider(provider).QueryMemberOf(queryMemberOf).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv1AuthUsers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv1AuthUsers`: V1AuthUsers
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv1AuthUsers`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv1AuthUsersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **string** | Filter users by domain. | 
 **zone** | **string** | Filter users by zone. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **cached** | **bool** | If true, only return cached objects. | 
 **resolveNames** | **bool** | Resolve names of personas. | 
 **filter** | **string** | Filter users by name prefix. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **provider** | **string** | Filter users by provider. | 
 **queryMemberOf** | **bool** | Enumerate all users that a group is a member of. | 

### Return type

[**V1AuthUsers**](V1AuthUsers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv1ProvidersAds

> V1ProvidersAds ListAuthv1ProvidersAds(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv1ProvidersAds(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv1ProvidersAds``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv1ProvidersAds`: V1ProvidersAds
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv1ProvidersAds`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv1ProvidersAdsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersAds**](V1ProvidersAds.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv1ProvidersFile

> V1ProvidersFile ListAuthv1ProvidersFile(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv1ProvidersFile(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv1ProvidersFile``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv1ProvidersFile`: V1ProvidersFile
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv1ProvidersFile`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv1ProvidersFileRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersFile**](V1ProvidersFile.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv1ProvidersKrb5

> V1ProvidersKrb5 ListAuthv1ProvidersKrb5(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv1ProvidersKrb5(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv1ProvidersKrb5``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv1ProvidersKrb5`: V1ProvidersKrb5
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv1ProvidersKrb5`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv1ProvidersKrb5Request struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersKrb5**](V1ProvidersKrb5.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv1ProvidersLdap

> V1ProvidersLdap ListAuthv1ProvidersLdap(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv1ProvidersLdap(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv1ProvidersLdap``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv1ProvidersLdap`: V1ProvidersLdap
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv1ProvidersLdap`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv1ProvidersLdapRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersLdap**](V1ProvidersLdap.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv1ProvidersNis

> V1ProvidersNis ListAuthv1ProvidersNis(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv1ProvidersNis(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv1ProvidersNis``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv1ProvidersNis`: V1ProvidersNis
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv1ProvidersNis`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv1ProvidersNisRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1ProvidersNis**](V1ProvidersNis.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv1SettingsKrb5Domains

> V1SettingsKrb5Domains ListAuthv1SettingsKrb5Domains(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv1SettingsKrb5Domains(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv1SettingsKrb5Domains``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv1SettingsKrb5Domains`: V1SettingsKrb5Domains
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv1SettingsKrb5Domains`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv1SettingsKrb5DomainsRequest struct via the builder pattern


### Return type

[**V1SettingsKrb5Domains**](V1SettingsKrb5Domains.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv1SettingsKrb5Realms

> V1SettingsKrb5Realms ListAuthv1SettingsKrb5Realms(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv1SettingsKrb5Realms(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv1SettingsKrb5Realms``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv1SettingsKrb5Realms`: V1SettingsKrb5Realms
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv1SettingsKrb5Realms`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv1SettingsKrb5RealmsRequest struct via the builder pattern


### Return type

[**V1SettingsKrb5Realms**](V1SettingsKrb5Realms.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv3ProvidersAds

> V3ProvidersAds ListAuthv3ProvidersAds(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv3ProvidersAds(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv3ProvidersAds``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv3ProvidersAds`: V3ProvidersAds
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv3ProvidersAds`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv3ProvidersAdsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3ProvidersAds**](V3ProvidersAds.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv3ProvidersKrb5

> V3ProvidersKrb5 ListAuthv3ProvidersKrb5(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv3ProvidersKrb5(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv3ProvidersKrb5``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv3ProvidersKrb5`: V3ProvidersKrb5
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv3ProvidersKrb5`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv3ProvidersKrb5Request struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3ProvidersKrb5**](V3ProvidersKrb5.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv3ProvidersLdap

> V3ProvidersLdap ListAuthv3ProvidersLdap(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv3ProvidersLdap(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv3ProvidersLdap``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv3ProvidersLdap`: V3ProvidersLdap
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv3ProvidersLdap`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv3ProvidersLdapRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3ProvidersLdap**](V3ProvidersLdap.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv3ProvidersNis

> V3ProvidersNis ListAuthv3ProvidersNis(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv3ProvidersNis(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv3ProvidersNis``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv3ProvidersNis`: V3ProvidersNis
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv3ProvidersNis`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv3ProvidersNisRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3ProvidersNis**](V3ProvidersNis.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv4ProvidersLdap

> V4ProvidersLdap ListAuthv4ProvidersLdap(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv4ProvidersLdap(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv4ProvidersLdap``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv4ProvidersLdap`: V4ProvidersLdap
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv4ProvidersLdap`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv4ProvidersLdapRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V4ProvidersLdap**](V4ProvidersLdap.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv7AuthRoles

> V1AuthRoles ListAuthv7AuthRoles(ctx).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    resolveNames := true // bool | Resolve names of personas. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv7AuthRoles(context.Background()).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv7AuthRoles``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv7AuthRoles`: V1AuthRoles
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv7AuthRoles`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv7AuthRolesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **zone** | **string** | Specifies which access zone to use. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **resolveNames** | **bool** | Resolve names of personas. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1AuthRoles**](V1AuthRoles.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv7AuthUsers

> V7AuthUsers ListAuthv7AuthUsers(ctx).Domain(domain).Zone(zone).Resume(resume).Cached(cached).ResolveNames(resolveNames).Filter(filter).Limit(limit).Provider(provider).QueryMemberOf(queryMemberOf).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    domain := "domain_example" // string | Filter users by domain. (optional)
    zone := "zone_example" // string | Filter users by zone. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    cached := true // bool | If true, only return cached objects. (optional)
    resolveNames := true // bool | Resolve names of personas. (optional)
    filter := "filter_example" // string | Filter users by name prefix. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    provider := "provider_example" // string | Filter users by provider. (optional)
    queryMemberOf := true // bool | Enumerate all users that a group is a member of. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv7AuthUsers(context.Background()).Domain(domain).Zone(zone).Resume(resume).Cached(cached).ResolveNames(resolveNames).Filter(filter).Limit(limit).Provider(provider).QueryMemberOf(queryMemberOf).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv7AuthUsers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv7AuthUsers`: V7AuthUsers
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv7AuthUsers`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv7AuthUsersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **domain** | **string** | Filter users by domain. | 
 **zone** | **string** | Filter users by zone. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **cached** | **bool** | If true, only return cached objects. | 
 **resolveNames** | **bool** | Resolve names of personas. | 
 **filter** | **string** | Filter users by name prefix. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **provider** | **string** | Filter users by provider. | 
 **queryMemberOf** | **bool** | Enumerate all users that a group is a member of. | 

### Return type

[**V7AuthUsers**](V7AuthUsers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv7ProvidersAds

> V7ProvidersAds ListAuthv7ProvidersAds(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv7ProvidersAds(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv7ProvidersAds``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv7ProvidersAds`: V7ProvidersAds
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv7ProvidersAds`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv7ProvidersAdsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersAds**](V7ProvidersAds.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv7ProvidersFile

> V7ProvidersFile ListAuthv7ProvidersFile(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv7ProvidersFile(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv7ProvidersFile``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv7ProvidersFile`: V7ProvidersFile
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv7ProvidersFile`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv7ProvidersFileRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersFile**](V7ProvidersFile.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv7ProvidersKrb5

> V7ProvidersKrb5 ListAuthv7ProvidersKrb5(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv7ProvidersKrb5(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv7ProvidersKrb5``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv7ProvidersKrb5`: V7ProvidersKrb5
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv7ProvidersKrb5`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv7ProvidersKrb5Request struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersKrb5**](V7ProvidersKrb5.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv7ProvidersLdap

> V7ProvidersLdap ListAuthv7ProvidersLdap(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv7ProvidersLdap(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv7ProvidersLdap``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv7ProvidersLdap`: V7ProvidersLdap
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv7ProvidersLdap`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv7ProvidersLdapRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersLdap**](V7ProvidersLdap.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthv7ProvidersNis

> V7ProvidersNis ListAuthv7ProvidersNis(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthApi.ListAuthv7ProvidersNis(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.ListAuthv7ProvidersNis``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthv7ProvidersNis`: V7ProvidersNis
    fmt.Fprintf(os.Stdout, "Response from `AuthApi.ListAuthv7ProvidersNis`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAuthv7ProvidersNisRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V7ProvidersNis**](V7ProvidersNis.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv11ProvidersLdapById

> UpdateAuthv11ProvidersLdapById(ctx, v11ProvidersLdapId).V11ProvidersLdapIdParams(v11ProvidersLdapIdParams).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11ProvidersLdapId := "v11ProvidersLdapId_example" // string | Modify the LDAP provider.
    v11ProvidersLdapIdParams := *openapiclient.NewV11ProvidersLdapIdParams() // V11ProvidersLdapIdParams | 
    force := true // bool | Ignore unresolvable server URIs. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv11ProvidersLdapById(context.Background(), v11ProvidersLdapId).V11ProvidersLdapIdParams(v11ProvidersLdapIdParams).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv11ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11ProvidersLdapId** | **string** | Modify the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv11ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v11ProvidersLdapIdParams** | [**V11ProvidersLdapIdParams**](V11ProvidersLdapIdParams.md) |  | 
 **force** | **bool** | Ignore unresolvable server URIs. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv11SettingsAcls

> UpdateAuthv11SettingsAcls(ctx).V11SettingsAcls(v11SettingsAcls).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11SettingsAcls := *openapiclient.NewV11SettingsAclsAclPolicySettings() // V11SettingsAclsAclPolicySettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv11SettingsAcls(context.Background()).V11SettingsAcls(v11SettingsAcls).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv11SettingsAcls``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv11SettingsAclsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v11SettingsAcls** | [**V11SettingsAclsAclPolicySettings**](V11SettingsAclsAclPolicySettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv12AuthLogLevel

> UpdateAuthv12AuthLogLevel(ctx).V12AuthLogLevel(v12AuthLogLevel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12AuthLogLevel := *openapiclient.NewV12AuthLogLevelExtended() // V12AuthLogLevelExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv12AuthLogLevel(context.Background()).V12AuthLogLevel(v12AuthLogLevel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv12AuthLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv12AuthLogLevelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12AuthLogLevel** | [**V12AuthLogLevelExtended**](V12AuthLogLevelExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1AuthGroup

> UpdateAuthv1AuthGroup(ctx, v1AuthGroupId).V1AuthGroup(v1AuthGroup).Force(force).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthGroupId := "v1AuthGroupId_example" // string | Modify the group.
    v1AuthGroup := *openapiclient.NewV1AuthGroupExtendedExtended() // V1AuthGroupExtendedExtended | 
    force := true // bool | Changes to the group ID can result in loss of access to the file system. To mitigate this risk of lost access, the force option is required for group ID changes. (optional)
    zone := "zone_example" // string | Optional zone. (optional)
    provider := "provider_example" // string | Optional provider type. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1AuthGroup(context.Background(), v1AuthGroupId).V1AuthGroup(v1AuthGroup).Force(force).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1AuthGroup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthGroupId** | **string** | Modify the group. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1AuthGroupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1AuthGroup** | [**V1AuthGroupExtendedExtended**](V1AuthGroupExtendedExtended.md) |  | 
 **force** | **bool** | Changes to the group ID can result in loss of access to the file system. To mitigate this risk of lost access, the force option is required for group ID changes. | 
 **zone** | **string** | Optional zone. | 
 **provider** | **string** | Optional provider type. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1AuthRole

> UpdateAuthv1AuthRole(ctx, v1AuthRoleId).V1AuthRole(v1AuthRole).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthRoleId := "v1AuthRoleId_example" // string | Modify the role.
    v1AuthRole := *openapiclient.NewV1AuthRoleExtendedExtended() // V1AuthRoleExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1AuthRole(context.Background(), v1AuthRoleId).V1AuthRole(v1AuthRole).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1AuthRole``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthRoleId** | **string** | Modify the role. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1AuthRoleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1AuthRole** | [**V1AuthRoleExtendedExtended**](V1AuthRoleExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1AuthUser

> UpdateAuthv1AuthUser(ctx, v1AuthUserId).V1AuthUser(v1AuthUser).Force(force).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuthUserId := "v1AuthUserId_example" // string | Modify the user.
    v1AuthUser := *openapiclient.NewV1AuthUserExtended() // V1AuthUserExtended | 
    force := true // bool | Changes to the user ID can result in loss of access to the file system. To mitigate this risk of lost access, the force option is required for user ID changes. (optional)
    zone := "zone_example" // string | Optional zone. (optional)
    provider := "provider_example" // string | Optional provider type. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1AuthUser(context.Background(), v1AuthUserId).V1AuthUser(v1AuthUser).Force(force).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1AuthUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuthUserId** | **string** | Modify the user. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1AuthUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1AuthUser** | [**V1AuthUserExtended**](V1AuthUserExtended.md) |  | 
 **force** | **bool** | Changes to the user ID can result in loss of access to the file system. To mitigate this risk of lost access, the force option is required for user ID changes. | 
 **zone** | **string** | Optional zone. | 
 **provider** | **string** | Optional provider type. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1MappingUsersRules

> UpdateAuthv1MappingUsersRules(ctx).V1MappingUsersRules(v1MappingUsersRules).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1MappingUsersRules := *openapiclient.NewV1MappingUsersRulesRules() // V1MappingUsersRulesRules | 
    zone := "zone_example" // string | The zone to which the user mapping applies. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1MappingUsersRules(context.Background()).V1MappingUsersRules(v1MappingUsersRules).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1MappingUsersRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1MappingUsersRulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1MappingUsersRules** | [**V1MappingUsersRulesRules**](V1MappingUsersRulesRules.md) |  | 
 **zone** | **string** | The zone to which the user mapping applies. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1ProvidersAdsById

> UpdateAuthv1ProvidersAdsById(ctx, v1ProvidersAdsId).V1ProvidersAdsIdParams(v1ProvidersAdsIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersAdsId := "v1ProvidersAdsId_example" // string | Modify the ADS provider.
    v1ProvidersAdsIdParams := *openapiclient.NewV1ProvidersAdsIdParams() // V1ProvidersAdsIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1ProvidersAdsById(context.Background(), v1ProvidersAdsId).V1ProvidersAdsIdParams(v1ProvidersAdsIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1ProvidersAdsById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersAdsId** | **string** | Modify the ADS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1ProvidersAdsByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1ProvidersAdsIdParams** | [**V1ProvidersAdsIdParams**](V1ProvidersAdsIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1ProvidersFileById

> UpdateAuthv1ProvidersFileById(ctx, v1ProvidersFileId).V1ProvidersFileIdParams(v1ProvidersFileIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersFileId := "v1ProvidersFileId_example" // string | Modify the file provider.
    v1ProvidersFileIdParams := *openapiclient.NewV1ProvidersFileIdParams() // V1ProvidersFileIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1ProvidersFileById(context.Background(), v1ProvidersFileId).V1ProvidersFileIdParams(v1ProvidersFileIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1ProvidersFileById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersFileId** | **string** | Modify the file provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1ProvidersFileByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1ProvidersFileIdParams** | [**V1ProvidersFileIdParams**](V1ProvidersFileIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1ProvidersKrb5ById

> UpdateAuthv1ProvidersKrb5ById(ctx, v1ProvidersKrb5Id).V1ProvidersKrb5IdParams(v1ProvidersKrb5IdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersKrb5Id := "v1ProvidersKrb5Id_example" // string | Modify the KRB5 provider.
    v1ProvidersKrb5IdParams := *openapiclient.NewV1ProvidersKrb5IdParams() // V1ProvidersKrb5IdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1ProvidersKrb5ById(context.Background(), v1ProvidersKrb5Id).V1ProvidersKrb5IdParams(v1ProvidersKrb5IdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1ProvidersKrb5ById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersKrb5Id** | **string** | Modify the KRB5 provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1ProvidersKrb5ByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1ProvidersKrb5IdParams** | [**V1ProvidersKrb5IdParams**](V1ProvidersKrb5IdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1ProvidersLdapById

> UpdateAuthv1ProvidersLdapById(ctx, v1ProvidersLdapId).V1ProvidersLdapIdParams(v1ProvidersLdapIdParams).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersLdapId := "v1ProvidersLdapId_example" // string | Modify the LDAP provider.
    v1ProvidersLdapIdParams := *openapiclient.NewV1ProvidersLdapIdParams() // V1ProvidersLdapIdParams | 
    force := true // bool | Ignore unresolvable server URIs. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1ProvidersLdapById(context.Background(), v1ProvidersLdapId).V1ProvidersLdapIdParams(v1ProvidersLdapIdParams).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersLdapId** | **string** | Modify the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1ProvidersLdapIdParams** | [**V1ProvidersLdapIdParams**](V1ProvidersLdapIdParams.md) |  | 
 **force** | **bool** | Ignore unresolvable server URIs. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1ProvidersLocalById

> UpdateAuthv1ProvidersLocalById(ctx, v1ProvidersLocalId).V1ProvidersLocalIdParams(v1ProvidersLocalIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersLocalId := "v1ProvidersLocalId_example" // string | Modify the local provider.
    v1ProvidersLocalIdParams := *openapiclient.NewV1ProvidersLocalIdParams() // V1ProvidersLocalIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1ProvidersLocalById(context.Background(), v1ProvidersLocalId).V1ProvidersLocalIdParams(v1ProvidersLocalIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1ProvidersLocalById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersLocalId** | **string** | Modify the local provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1ProvidersLocalByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1ProvidersLocalIdParams** | [**V1ProvidersLocalIdParams**](V1ProvidersLocalIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1ProvidersNisById

> UpdateAuthv1ProvidersNisById(ctx, v1ProvidersNisId).V1ProvidersNisIdParams(v1ProvidersNisIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ProvidersNisId := "v1ProvidersNisId_example" // string | Modify the NIS provider.
    v1ProvidersNisIdParams := *openapiclient.NewV1ProvidersNisIdParams() // V1ProvidersNisIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1ProvidersNisById(context.Background(), v1ProvidersNisId).V1ProvidersNisIdParams(v1ProvidersNisIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1ProvidersNisById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ProvidersNisId** | **string** | Modify the NIS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1ProvidersNisByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1ProvidersNisIdParams** | [**V1ProvidersNisIdParams**](V1ProvidersNisIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1SettingsGlobal

> UpdateAuthv1SettingsGlobal(ctx).V1SettingsGlobal(v1SettingsGlobal).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsGlobal := *openapiclient.NewV1SettingsGlobalGlobalSettings() // V1SettingsGlobalGlobalSettings | 
    zone := "zone_example" // string | Zone which contains any per-zone settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1SettingsGlobal(context.Background()).V1SettingsGlobal(v1SettingsGlobal).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1SettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1SettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SettingsGlobal** | [**V1SettingsGlobalGlobalSettings**](V1SettingsGlobalGlobalSettings.md) |  | 
 **zone** | **string** | Zone which contains any per-zone settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1SettingsKrb5Defaults

> UpdateAuthv1SettingsKrb5Defaults(ctx).V1SettingsKrb5Defaults(v1SettingsKrb5Defaults).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsKrb5Defaults := *openapiclient.NewV1SettingsKrb5DefaultsKrb5Settings() // V1SettingsKrb5DefaultsKrb5Settings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1SettingsKrb5Defaults(context.Background()).V1SettingsKrb5Defaults(v1SettingsKrb5Defaults).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1SettingsKrb5Defaults``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1SettingsKrb5DefaultsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SettingsKrb5Defaults** | [**V1SettingsKrb5DefaultsKrb5Settings**](V1SettingsKrb5DefaultsKrb5Settings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1SettingsKrb5Domain

> UpdateAuthv1SettingsKrb5Domain(ctx, v1SettingsKrb5DomainId).V1SettingsKrb5Domain(v1SettingsKrb5Domain).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsKrb5DomainId := "v1SettingsKrb5DomainId_example" // string | Modify the krb5 domain settings.
    v1SettingsKrb5Domain := *openapiclient.NewV1SettingsKrb5DomainExtended() // V1SettingsKrb5DomainExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1SettingsKrb5Domain(context.Background(), v1SettingsKrb5DomainId).V1SettingsKrb5Domain(v1SettingsKrb5Domain).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1SettingsKrb5Domain``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsKrb5DomainId** | **string** | Modify the krb5 domain settings. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1SettingsKrb5DomainRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SettingsKrb5Domain** | [**V1SettingsKrb5DomainExtended**](V1SettingsKrb5DomainExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1SettingsKrb5Realm

> UpdateAuthv1SettingsKrb5Realm(ctx, v1SettingsKrb5RealmId).V1SettingsKrb5Realm(v1SettingsKrb5Realm).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsKrb5RealmId := "v1SettingsKrb5RealmId_example" // string | Modify the krb5 realm settings.
    v1SettingsKrb5Realm := *openapiclient.NewV1SettingsKrb5RealmExtended() // V1SettingsKrb5RealmExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1SettingsKrb5Realm(context.Background(), v1SettingsKrb5RealmId).V1SettingsKrb5Realm(v1SettingsKrb5Realm).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1SettingsKrb5Realm``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsKrb5RealmId** | **string** | Modify the krb5 realm settings. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1SettingsKrb5RealmRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SettingsKrb5Realm** | [**V1SettingsKrb5RealmExtended**](V1SettingsKrb5RealmExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv1SettingsMapping

> UpdateAuthv1SettingsMapping(ctx).V1SettingsMapping(v1SettingsMapping).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsMapping := *openapiclient.NewV1SettingsMappingMappingSettings() // V1SettingsMappingMappingSettings | 
    zone := "zone_example" // string | Access zone which contains mapping settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv1SettingsMapping(context.Background()).V1SettingsMapping(v1SettingsMapping).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv1SettingsMapping``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv1SettingsMappingRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SettingsMapping** | [**V1SettingsMappingMappingSettings**](V1SettingsMappingMappingSettings.md) |  | 
 **zone** | **string** | Access zone which contains mapping settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv3AuthLogLevel

> UpdateAuthv3AuthLogLevel(ctx).V3AuthLogLevel(v3AuthLogLevel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AuthLogLevel := *openapiclient.NewV3AuthLogLevelExtended() // V3AuthLogLevelExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv3AuthLogLevel(context.Background()).V3AuthLogLevel(v3AuthLogLevel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv3AuthLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv3AuthLogLevelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3AuthLogLevel** | [**V3AuthLogLevelExtended**](V3AuthLogLevelExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv3MappingImport

> UpdateAuthv3MappingImport(ctx).V3MappingImport(v3MappingImport).Zone(zone).Replace(replace).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3MappingImport := *openapiclient.NewV3MappingDump() // V3MappingDump | 
    zone := "zone_example" // string | Optional zone. (optional)
    replace := true // bool | Specify whether existing mappings should be replaced. The default behavior is to leave existing mappings intact and return an error. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv3MappingImport(context.Background()).V3MappingImport(v3MappingImport).Zone(zone).Replace(replace).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv3MappingImport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv3MappingImportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3MappingImport** | [**V3MappingDump**](V3MappingDump.md) |  | 
 **zone** | **string** | Optional zone. | 
 **replace** | **bool** | Specify whether existing mappings should be replaced. The default behavior is to leave existing mappings intact and return an error. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv3ProvidersAdsById

> UpdateAuthv3ProvidersAdsById(ctx, v3ProvidersAdsId).V3ProvidersAdsIdParams(v3ProvidersAdsIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersAdsId := "v3ProvidersAdsId_example" // string | Modify the ADS provider.
    v3ProvidersAdsIdParams := *openapiclient.NewV3ProvidersAdsIdParams() // V3ProvidersAdsIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv3ProvidersAdsById(context.Background(), v3ProvidersAdsId).V3ProvidersAdsIdParams(v3ProvidersAdsIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv3ProvidersAdsById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersAdsId** | **string** | Modify the ADS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv3ProvidersAdsByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3ProvidersAdsIdParams** | [**V3ProvidersAdsIdParams**](V3ProvidersAdsIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv3ProvidersKrb5ById

> UpdateAuthv3ProvidersKrb5ById(ctx, v3ProvidersKrb5Id).V3ProvidersKrb5IdParams(v3ProvidersKrb5IdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersKrb5Id := "v3ProvidersKrb5Id_example" // string | Modify the KRB5 provider.
    v3ProvidersKrb5IdParams := *openapiclient.NewV1ProvidersKrb5IdParams() // V1ProvidersKrb5IdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv3ProvidersKrb5ById(context.Background(), v3ProvidersKrb5Id).V3ProvidersKrb5IdParams(v3ProvidersKrb5IdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv3ProvidersKrb5ById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersKrb5Id** | **string** | Modify the KRB5 provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv3ProvidersKrb5ByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3ProvidersKrb5IdParams** | [**V1ProvidersKrb5IdParams**](V1ProvidersKrb5IdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv3ProvidersLdapById

> UpdateAuthv3ProvidersLdapById(ctx, v3ProvidersLdapId).V3ProvidersLdapIdParams(v3ProvidersLdapIdParams).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersLdapId := "v3ProvidersLdapId_example" // string | Modify the LDAP provider.
    v3ProvidersLdapIdParams := *openapiclient.NewV3ProvidersLdapIdParams() // V3ProvidersLdapIdParams | 
    force := true // bool | Ignore unresolvable server URIs. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv3ProvidersLdapById(context.Background(), v3ProvidersLdapId).V3ProvidersLdapIdParams(v3ProvidersLdapIdParams).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv3ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersLdapId** | **string** | Modify the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv3ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3ProvidersLdapIdParams** | [**V3ProvidersLdapIdParams**](V3ProvidersLdapIdParams.md) |  | 
 **force** | **bool** | Ignore unresolvable server URIs. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv3ProvidersNisById

> UpdateAuthv3ProvidersNisById(ctx, v3ProvidersNisId).V3ProvidersNisIdParams(v3ProvidersNisIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ProvidersNisId := "v3ProvidersNisId_example" // string | Modify the NIS provider.
    v3ProvidersNisIdParams := *openapiclient.NewV1ProvidersNisIdParams() // V1ProvidersNisIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv3ProvidersNisById(context.Background(), v3ProvidersNisId).V3ProvidersNisIdParams(v3ProvidersNisIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv3ProvidersNisById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ProvidersNisId** | **string** | Modify the NIS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv3ProvidersNisByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3ProvidersNisIdParams** | [**V1ProvidersNisIdParams**](V1ProvidersNisIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv3SettingsAcls

> UpdateAuthv3SettingsAcls(ctx).V3SettingsAcls(v3SettingsAcls).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SettingsAcls := *openapiclient.NewV3SettingsAclsAclPolicySettings() // V3SettingsAclsAclPolicySettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv3SettingsAcls(context.Background()).V3SettingsAcls(v3SettingsAcls).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv3SettingsAcls``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv3SettingsAclsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SettingsAcls** | [**V3SettingsAclsAclPolicySettings**](V3SettingsAclsAclPolicySettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv4ProvidersLdapById

> UpdateAuthv4ProvidersLdapById(ctx, v4ProvidersLdapId).V4ProvidersLdapIdParams(v4ProvidersLdapIdParams).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4ProvidersLdapId := "v4ProvidersLdapId_example" // string | Modify the LDAP provider.
    v4ProvidersLdapIdParams := *openapiclient.NewV4ProvidersLdapIdParams() // V4ProvidersLdapIdParams | 
    force := true // bool | Ignore unresolvable server URIs. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv4ProvidersLdapById(context.Background(), v4ProvidersLdapId).V4ProvidersLdapIdParams(v4ProvidersLdapIdParams).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv4ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4ProvidersLdapId** | **string** | Modify the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv4ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v4ProvidersLdapIdParams** | [**V4ProvidersLdapIdParams**](V4ProvidersLdapIdParams.md) |  | 
 **force** | **bool** | Ignore unresolvable server URIs. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv7AuthRole

> UpdateAuthv7AuthRole(ctx, v7AuthRoleId).V7AuthRole(v7AuthRole).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuthRoleId := "v7AuthRoleId_example" // string | Modify the role.
    v7AuthRole := *openapiclient.NewV1AuthRoleExtendedExtended() // V1AuthRoleExtendedExtended | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv7AuthRole(context.Background(), v7AuthRoleId).V7AuthRole(v7AuthRole).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv7AuthRole``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7AuthRoleId** | **string** | Modify the role. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv7AuthRoleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7AuthRole** | [**V1AuthRoleExtendedExtended**](V1AuthRoleExtendedExtended.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv7AuthUser

> UpdateAuthv7AuthUser(ctx, v7AuthUserId).V7AuthUser(v7AuthUser).Force(force).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuthUserId := "v7AuthUserId_example" // string | Modify the user.
    v7AuthUser := *openapiclient.NewV1AuthUserExtended() // V1AuthUserExtended | 
    force := true // bool | Changes to the user ID can result in loss of access to the file system. To mitigate this risk of lost access, the force option is required for user ID changes. (optional)
    zone := "zone_example" // string | Optional zone. (optional)
    provider := "provider_example" // string | Optional provider type. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv7AuthUser(context.Background(), v7AuthUserId).V7AuthUser(v7AuthUser).Force(force).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv7AuthUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7AuthUserId** | **string** | Modify the user. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv7AuthUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7AuthUser** | [**V1AuthUserExtended**](V1AuthUserExtended.md) |  | 
 **force** | **bool** | Changes to the user ID can result in loss of access to the file system. To mitigate this risk of lost access, the force option is required for user ID changes. | 
 **zone** | **string** | Optional zone. | 
 **provider** | **string** | Optional provider type. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv7ProvidersAdsById

> UpdateAuthv7ProvidersAdsById(ctx, v7ProvidersAdsId).V7ProvidersAdsIdParams(v7ProvidersAdsIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersAdsId := "v7ProvidersAdsId_example" // string | Modify the ADS provider.
    v7ProvidersAdsIdParams := *openapiclient.NewV7ProvidersAdsIdParams() // V7ProvidersAdsIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv7ProvidersAdsById(context.Background(), v7ProvidersAdsId).V7ProvidersAdsIdParams(v7ProvidersAdsIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv7ProvidersAdsById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersAdsId** | **string** | Modify the ADS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv7ProvidersAdsByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7ProvidersAdsIdParams** | [**V7ProvidersAdsIdParams**](V7ProvidersAdsIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv7ProvidersDuo

> UpdateAuthv7ProvidersDuo(ctx).V7ProvidersDuo(v7ProvidersDuo).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersDuo := *openapiclient.NewV7ProvidersDuoExtended() // V7ProvidersDuoExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv7ProvidersDuo(context.Background()).V7ProvidersDuo(v7ProvidersDuo).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv7ProvidersDuo``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv7ProvidersDuoRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7ProvidersDuo** | [**V7ProvidersDuoExtended**](V7ProvidersDuoExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv7ProvidersFileById

> UpdateAuthv7ProvidersFileById(ctx, v7ProvidersFileId).V7ProvidersFileIdParams(v7ProvidersFileIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersFileId := "v7ProvidersFileId_example" // string | Modify the file provider.
    v7ProvidersFileIdParams := *openapiclient.NewV1ProvidersFileIdParams() // V1ProvidersFileIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv7ProvidersFileById(context.Background(), v7ProvidersFileId).V7ProvidersFileIdParams(v7ProvidersFileIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv7ProvidersFileById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersFileId** | **string** | Modify the file provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv7ProvidersFileByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7ProvidersFileIdParams** | [**V1ProvidersFileIdParams**](V1ProvidersFileIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv7ProvidersKrb5ById

> UpdateAuthv7ProvidersKrb5ById(ctx, v7ProvidersKrb5Id).V7ProvidersKrb5IdParams(v7ProvidersKrb5IdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersKrb5Id := "v7ProvidersKrb5Id_example" // string | Modify the KRB5 provider.
    v7ProvidersKrb5IdParams := *openapiclient.NewV1ProvidersKrb5IdParams() // V1ProvidersKrb5IdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv7ProvidersKrb5ById(context.Background(), v7ProvidersKrb5Id).V7ProvidersKrb5IdParams(v7ProvidersKrb5IdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv7ProvidersKrb5ById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersKrb5Id** | **string** | Modify the KRB5 provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv7ProvidersKrb5ByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7ProvidersKrb5IdParams** | [**V1ProvidersKrb5IdParams**](V1ProvidersKrb5IdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv7ProvidersLdapById

> UpdateAuthv7ProvidersLdapById(ctx, v7ProvidersLdapId).V7ProvidersLdapIdParams(v7ProvidersLdapIdParams).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersLdapId := "v7ProvidersLdapId_example" // string | Modify the LDAP provider.
    v7ProvidersLdapIdParams := *openapiclient.NewV7ProvidersLdapIdParams() // V7ProvidersLdapIdParams | 
    force := true // bool | Ignore unresolvable server URIs. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv7ProvidersLdapById(context.Background(), v7ProvidersLdapId).V7ProvidersLdapIdParams(v7ProvidersLdapIdParams).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv7ProvidersLdapById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersLdapId** | **string** | Modify the LDAP provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv7ProvidersLdapByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7ProvidersLdapIdParams** | [**V7ProvidersLdapIdParams**](V7ProvidersLdapIdParams.md) |  | 
 **force** | **bool** | Ignore unresolvable server URIs. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv7ProvidersLocalById

> UpdateAuthv7ProvidersLocalById(ctx, v7ProvidersLocalId).V7ProvidersLocalIdParams(v7ProvidersLocalIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersLocalId := "v7ProvidersLocalId_example" // string | Modify the local provider.
    v7ProvidersLocalIdParams := *openapiclient.NewV1ProvidersLocalIdParams() // V1ProvidersLocalIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv7ProvidersLocalById(context.Background(), v7ProvidersLocalId).V7ProvidersLocalIdParams(v7ProvidersLocalIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv7ProvidersLocalById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersLocalId** | **string** | Modify the local provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv7ProvidersLocalByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7ProvidersLocalIdParams** | [**V1ProvidersLocalIdParams**](V1ProvidersLocalIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv7ProvidersNisById

> UpdateAuthv7ProvidersNisById(ctx, v7ProvidersNisId).V7ProvidersNisIdParams(v7ProvidersNisIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7ProvidersNisId := "v7ProvidersNisId_example" // string | Modify the NIS provider.
    v7ProvidersNisIdParams := *openapiclient.NewV1ProvidersNisIdParams() // V1ProvidersNisIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv7ProvidersNisById(context.Background(), v7ProvidersNisId).V7ProvidersNisIdParams(v7ProvidersNisIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv7ProvidersNisById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7ProvidersNisId** | **string** | Modify the NIS provider. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv7ProvidersNisByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7ProvidersNisIdParams** | [**V1ProvidersNisIdParams**](V1ProvidersNisIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthv7SettingsAcls

> UpdateAuthv7SettingsAcls(ctx).V7SettingsAcls(v7SettingsAcls).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SettingsAcls := *openapiclient.NewV7SettingsAclsAclPolicySettings() // V7SettingsAclsAclPolicySettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthApi.UpdateAuthv7SettingsAcls(context.Background()).V7SettingsAcls(v7SettingsAcls).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthApi.UpdateAuthv7SettingsAcls``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthv7SettingsAclsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SettingsAcls** | [**V7SettingsAclsAclPolicySettings**](V7SettingsAclsAclPolicySettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

