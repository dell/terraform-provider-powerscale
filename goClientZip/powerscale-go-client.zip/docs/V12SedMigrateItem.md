# V12SedMigrateItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Retry** | Pointer to **bool** | Set to true to retry KMIP migration in the previous direction for errored nodes. e.g. if error occured after migrate with &#39;to_server&#x3D;true&#39;, using &#39;sed/migrate&#39; handler with &#39;retry&#x3D;true&#39; will retry migration to server. Similarly, if previous migration was &#39;to_server&#x3D;false&#39;, retry will try to restore back to local. Also note that, whenever a &#39;retry&#39; arg is provided to the handler, regardless of true or false, &#39;to_server&#39; arg will be ignored. i.e. if using the handler with (&#39;retry&#39;:true(or false), &#39;to_server&#39;: true), the &#39;to_server&#39; arg will be ignored and have no effects. | [optional] 
**ToServer** | Pointer to **bool** | Set to true to indicate migrating all keys to server. Set to false to indicate retoring all keys back to local. | [optional] 

## Methods

### NewV12SedMigrateItem

`func NewV12SedMigrateItem() *V12SedMigrateItem`

NewV12SedMigrateItem instantiates a new V12SedMigrateItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SedMigrateItemWithDefaults

`func NewV12SedMigrateItemWithDefaults() *V12SedMigrateItem`

NewV12SedMigrateItemWithDefaults instantiates a new V12SedMigrateItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRetry

`func (o *V12SedMigrateItem) GetRetry() bool`

GetRetry returns the Retry field if non-nil, zero value otherwise.

### GetRetryOk

`func (o *V12SedMigrateItem) GetRetryOk() (*bool, bool)`

GetRetryOk returns a tuple with the Retry field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRetry

`func (o *V12SedMigrateItem) SetRetry(v bool)`

SetRetry sets Retry field to given value.

### HasRetry

`func (o *V12SedMigrateItem) HasRetry() bool`

HasRetry returns a boolean if a field has been set.

### GetToServer

`func (o *V12SedMigrateItem) GetToServer() bool`

GetToServer returns the ToServer field if non-nil, zero value otherwise.

### GetToServerOk

`func (o *V12SedMigrateItem) GetToServerOk() (*bool, bool)`

GetToServerOk returns a tuple with the ToServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetToServer

`func (o *V12SedMigrateItem) SetToServer(v bool)`

SetToServer sets ToServer field to given value.

### HasToServer

`func (o *V12SedMigrateItem) HasToServer() bool`

HasToServer returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


