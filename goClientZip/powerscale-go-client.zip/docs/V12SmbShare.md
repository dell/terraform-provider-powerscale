# V12SmbShare

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessBasedEnumeration** | Pointer to **bool** | Only enumerate files and folders the requesting user has access to. | [optional] 
**AccessBasedEnumerationRootOnly** | Pointer to **bool** | Access-based enumeration on only the root directory of the share. | [optional] 
**AllowDeleteReadonly** | Pointer to **bool** | Allow deletion of read-only files in the share. | [optional] 
**AllowExecuteAlways** | Pointer to **bool** | Allows users to execute files they have read rights for. | [optional] 
**AllowVariableExpansion** | Pointer to **bool** | Allow automatic expansion of variables for home directories. | [optional] 
**AutoCreateDirectory** | Pointer to **bool** | Automatically create home directories. | [optional] 
**Browsable** | Pointer to **bool** | Share is visible in net view and the browse list. | [optional] 
**CaTimeout** | Pointer to **int32** | Persistent open timeout for the share. | [optional] 
**CaWriteIntegrity** | Pointer to **string** | Specify the level of write-integrity on continuously available shares. | [optional] 
**ChangeNotify** | Pointer to **string** | Level of change notification alerts on the share. | [optional] 
**ContinuouslyAvailable** | Pointer to **bool** | Specify if persistent opens are allowed on the share. | [optional] 
**CreatePath** | Pointer to **bool** | Create path if does not exist. | [optional] 
**CreatePermissions** | Pointer to **string** | Create permissions for new files and directories in share. | [optional] 
**CscPolicy** | Pointer to **string** | Client-side caching policy for the shares. | [optional] 
**Description** | Pointer to **string** | Description for this SMB share. | [optional] 
**DirectoryCreateMask** | Pointer to **int32** | Directory create mask bits. | [optional] 
**DirectoryCreateMode** | Pointer to **int32** | Directory create mode bits. | [optional] 
**FileCreateMask** | Pointer to **int32** | File create mask bits. | [optional] 
**FileCreateMode** | Pointer to **int32** | File create mode bits. | [optional] 
**FileFilterExtensions** | Pointer to **[]string** | Specifies the list of file extensions. | [optional] 
**FileFilterType** | Pointer to **string** | Specifies if filter list is for deny or allow. Default is deny. | [optional] 
**FileFilteringEnabled** | Pointer to **bool** | Enables file filtering on this zone. | [optional] 
**HideDotFiles** | Pointer to **bool** | Hide files and directories that begin with a period &#39;.&#39;. | [optional] 
**HostAcl** | Pointer to **[]string** | An ACL expressing which hosts are allowed access. A deny clause must be the final entry. | [optional] 
**ImpersonateGuest** | Pointer to **string** | Specify the condition in which user access is done as the guest account. | [optional] 
**ImpersonateUser** | Pointer to **string** | User account to be used as guest account. | [optional] 
**InheritablePathAcl** | Pointer to **bool** | Set the inheritable ACL on the share path. | [optional] 
**MangleByteStart** | Pointer to **int32** | Specifies the wchar_t starting point for automatic byte mangling. | [optional] 
**MangleMap** | Pointer to **[]string** | Character mangle map. | [optional] 
**Name** | **string** | Share name. | 
**NtfsAclSupport** | Pointer to **bool** | Support NTFS ACLs on files and directories. | [optional] 
**Oplocks** | Pointer to **bool** | Support oplocks. | [optional] 
**Path** | **string** | Path of share within /ifs. | 
**Permissions** | Pointer to [**[]V1SmbSharePermission**](V1SmbSharePermission.md) | Specifies an ordered list of permission modifications. | [optional] 
**RunAsRoot** | Pointer to [**[]V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) | Allow account to run as root. | [optional] 
**Smb3EncryptionEnabled** | Pointer to **bool** | Enables SMB3 encryption for the share. | [optional] 
**SparseFile** | Pointer to **bool** | Enables sparse file. | [optional] 
**StrictCaLockout** | Pointer to **bool** | Specifies if persistent opens would do strict lockout on the share. | [optional] 
**StrictFlush** | Pointer to **bool** | Handle SMB flush operations. | [optional] 
**StrictLocking** | Pointer to **bool** | Specifies whether byte range locks contend against SMB I/O. | [optional] 
**Zone** | Pointer to **string** | Name of the access zone to which to move this SMB share. | [optional] 

## Methods

### NewV12SmbShare

`func NewV12SmbShare(name string, path string, ) *V12SmbShare`

NewV12SmbShare instantiates a new V12SmbShare object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SmbShareWithDefaults

`func NewV12SmbShareWithDefaults() *V12SmbShare`

NewV12SmbShareWithDefaults instantiates a new V12SmbShare object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAccessBasedEnumeration

`func (o *V12SmbShare) GetAccessBasedEnumeration() bool`

GetAccessBasedEnumeration returns the AccessBasedEnumeration field if non-nil, zero value otherwise.

### GetAccessBasedEnumerationOk

`func (o *V12SmbShare) GetAccessBasedEnumerationOk() (*bool, bool)`

GetAccessBasedEnumerationOk returns a tuple with the AccessBasedEnumeration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessBasedEnumeration

`func (o *V12SmbShare) SetAccessBasedEnumeration(v bool)`

SetAccessBasedEnumeration sets AccessBasedEnumeration field to given value.

### HasAccessBasedEnumeration

`func (o *V12SmbShare) HasAccessBasedEnumeration() bool`

HasAccessBasedEnumeration returns a boolean if a field has been set.

### GetAccessBasedEnumerationRootOnly

`func (o *V12SmbShare) GetAccessBasedEnumerationRootOnly() bool`

GetAccessBasedEnumerationRootOnly returns the AccessBasedEnumerationRootOnly field if non-nil, zero value otherwise.

### GetAccessBasedEnumerationRootOnlyOk

`func (o *V12SmbShare) GetAccessBasedEnumerationRootOnlyOk() (*bool, bool)`

GetAccessBasedEnumerationRootOnlyOk returns a tuple with the AccessBasedEnumerationRootOnly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessBasedEnumerationRootOnly

`func (o *V12SmbShare) SetAccessBasedEnumerationRootOnly(v bool)`

SetAccessBasedEnumerationRootOnly sets AccessBasedEnumerationRootOnly field to given value.

### HasAccessBasedEnumerationRootOnly

`func (o *V12SmbShare) HasAccessBasedEnumerationRootOnly() bool`

HasAccessBasedEnumerationRootOnly returns a boolean if a field has been set.

### GetAllowDeleteReadonly

`func (o *V12SmbShare) GetAllowDeleteReadonly() bool`

GetAllowDeleteReadonly returns the AllowDeleteReadonly field if non-nil, zero value otherwise.

### GetAllowDeleteReadonlyOk

`func (o *V12SmbShare) GetAllowDeleteReadonlyOk() (*bool, bool)`

GetAllowDeleteReadonlyOk returns a tuple with the AllowDeleteReadonly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowDeleteReadonly

`func (o *V12SmbShare) SetAllowDeleteReadonly(v bool)`

SetAllowDeleteReadonly sets AllowDeleteReadonly field to given value.

### HasAllowDeleteReadonly

`func (o *V12SmbShare) HasAllowDeleteReadonly() bool`

HasAllowDeleteReadonly returns a boolean if a field has been set.

### GetAllowExecuteAlways

`func (o *V12SmbShare) GetAllowExecuteAlways() bool`

GetAllowExecuteAlways returns the AllowExecuteAlways field if non-nil, zero value otherwise.

### GetAllowExecuteAlwaysOk

`func (o *V12SmbShare) GetAllowExecuteAlwaysOk() (*bool, bool)`

GetAllowExecuteAlwaysOk returns a tuple with the AllowExecuteAlways field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowExecuteAlways

`func (o *V12SmbShare) SetAllowExecuteAlways(v bool)`

SetAllowExecuteAlways sets AllowExecuteAlways field to given value.

### HasAllowExecuteAlways

`func (o *V12SmbShare) HasAllowExecuteAlways() bool`

HasAllowExecuteAlways returns a boolean if a field has been set.

### GetAllowVariableExpansion

`func (o *V12SmbShare) GetAllowVariableExpansion() bool`

GetAllowVariableExpansion returns the AllowVariableExpansion field if non-nil, zero value otherwise.

### GetAllowVariableExpansionOk

`func (o *V12SmbShare) GetAllowVariableExpansionOk() (*bool, bool)`

GetAllowVariableExpansionOk returns a tuple with the AllowVariableExpansion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowVariableExpansion

`func (o *V12SmbShare) SetAllowVariableExpansion(v bool)`

SetAllowVariableExpansion sets AllowVariableExpansion field to given value.

### HasAllowVariableExpansion

`func (o *V12SmbShare) HasAllowVariableExpansion() bool`

HasAllowVariableExpansion returns a boolean if a field has been set.

### GetAutoCreateDirectory

`func (o *V12SmbShare) GetAutoCreateDirectory() bool`

GetAutoCreateDirectory returns the AutoCreateDirectory field if non-nil, zero value otherwise.

### GetAutoCreateDirectoryOk

`func (o *V12SmbShare) GetAutoCreateDirectoryOk() (*bool, bool)`

GetAutoCreateDirectoryOk returns a tuple with the AutoCreateDirectory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutoCreateDirectory

`func (o *V12SmbShare) SetAutoCreateDirectory(v bool)`

SetAutoCreateDirectory sets AutoCreateDirectory field to given value.

### HasAutoCreateDirectory

`func (o *V12SmbShare) HasAutoCreateDirectory() bool`

HasAutoCreateDirectory returns a boolean if a field has been set.

### GetBrowsable

`func (o *V12SmbShare) GetBrowsable() bool`

GetBrowsable returns the Browsable field if non-nil, zero value otherwise.

### GetBrowsableOk

`func (o *V12SmbShare) GetBrowsableOk() (*bool, bool)`

GetBrowsableOk returns a tuple with the Browsable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBrowsable

`func (o *V12SmbShare) SetBrowsable(v bool)`

SetBrowsable sets Browsable field to given value.

### HasBrowsable

`func (o *V12SmbShare) HasBrowsable() bool`

HasBrowsable returns a boolean if a field has been set.

### GetCaTimeout

`func (o *V12SmbShare) GetCaTimeout() int32`

GetCaTimeout returns the CaTimeout field if non-nil, zero value otherwise.

### GetCaTimeoutOk

`func (o *V12SmbShare) GetCaTimeoutOk() (*int32, bool)`

GetCaTimeoutOk returns a tuple with the CaTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCaTimeout

`func (o *V12SmbShare) SetCaTimeout(v int32)`

SetCaTimeout sets CaTimeout field to given value.

### HasCaTimeout

`func (o *V12SmbShare) HasCaTimeout() bool`

HasCaTimeout returns a boolean if a field has been set.

### GetCaWriteIntegrity

`func (o *V12SmbShare) GetCaWriteIntegrity() string`

GetCaWriteIntegrity returns the CaWriteIntegrity field if non-nil, zero value otherwise.

### GetCaWriteIntegrityOk

`func (o *V12SmbShare) GetCaWriteIntegrityOk() (*string, bool)`

GetCaWriteIntegrityOk returns a tuple with the CaWriteIntegrity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCaWriteIntegrity

`func (o *V12SmbShare) SetCaWriteIntegrity(v string)`

SetCaWriteIntegrity sets CaWriteIntegrity field to given value.

### HasCaWriteIntegrity

`func (o *V12SmbShare) HasCaWriteIntegrity() bool`

HasCaWriteIntegrity returns a boolean if a field has been set.

### GetChangeNotify

`func (o *V12SmbShare) GetChangeNotify() string`

GetChangeNotify returns the ChangeNotify field if non-nil, zero value otherwise.

### GetChangeNotifyOk

`func (o *V12SmbShare) GetChangeNotifyOk() (*string, bool)`

GetChangeNotifyOk returns a tuple with the ChangeNotify field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChangeNotify

`func (o *V12SmbShare) SetChangeNotify(v string)`

SetChangeNotify sets ChangeNotify field to given value.

### HasChangeNotify

`func (o *V12SmbShare) HasChangeNotify() bool`

HasChangeNotify returns a boolean if a field has been set.

### GetContinuouslyAvailable

`func (o *V12SmbShare) GetContinuouslyAvailable() bool`

GetContinuouslyAvailable returns the ContinuouslyAvailable field if non-nil, zero value otherwise.

### GetContinuouslyAvailableOk

`func (o *V12SmbShare) GetContinuouslyAvailableOk() (*bool, bool)`

GetContinuouslyAvailableOk returns a tuple with the ContinuouslyAvailable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetContinuouslyAvailable

`func (o *V12SmbShare) SetContinuouslyAvailable(v bool)`

SetContinuouslyAvailable sets ContinuouslyAvailable field to given value.

### HasContinuouslyAvailable

`func (o *V12SmbShare) HasContinuouslyAvailable() bool`

HasContinuouslyAvailable returns a boolean if a field has been set.

### GetCreatePath

`func (o *V12SmbShare) GetCreatePath() bool`

GetCreatePath returns the CreatePath field if non-nil, zero value otherwise.

### GetCreatePathOk

`func (o *V12SmbShare) GetCreatePathOk() (*bool, bool)`

GetCreatePathOk returns a tuple with the CreatePath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreatePath

`func (o *V12SmbShare) SetCreatePath(v bool)`

SetCreatePath sets CreatePath field to given value.

### HasCreatePath

`func (o *V12SmbShare) HasCreatePath() bool`

HasCreatePath returns a boolean if a field has been set.

### GetCreatePermissions

`func (o *V12SmbShare) GetCreatePermissions() string`

GetCreatePermissions returns the CreatePermissions field if non-nil, zero value otherwise.

### GetCreatePermissionsOk

`func (o *V12SmbShare) GetCreatePermissionsOk() (*string, bool)`

GetCreatePermissionsOk returns a tuple with the CreatePermissions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreatePermissions

`func (o *V12SmbShare) SetCreatePermissions(v string)`

SetCreatePermissions sets CreatePermissions field to given value.

### HasCreatePermissions

`func (o *V12SmbShare) HasCreatePermissions() bool`

HasCreatePermissions returns a boolean if a field has been set.

### GetCscPolicy

`func (o *V12SmbShare) GetCscPolicy() string`

GetCscPolicy returns the CscPolicy field if non-nil, zero value otherwise.

### GetCscPolicyOk

`func (o *V12SmbShare) GetCscPolicyOk() (*string, bool)`

GetCscPolicyOk returns a tuple with the CscPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCscPolicy

`func (o *V12SmbShare) SetCscPolicy(v string)`

SetCscPolicy sets CscPolicy field to given value.

### HasCscPolicy

`func (o *V12SmbShare) HasCscPolicy() bool`

HasCscPolicy returns a boolean if a field has been set.

### GetDescription

`func (o *V12SmbShare) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V12SmbShare) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V12SmbShare) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V12SmbShare) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDirectoryCreateMask

`func (o *V12SmbShare) GetDirectoryCreateMask() int32`

GetDirectoryCreateMask returns the DirectoryCreateMask field if non-nil, zero value otherwise.

### GetDirectoryCreateMaskOk

`func (o *V12SmbShare) GetDirectoryCreateMaskOk() (*int32, bool)`

GetDirectoryCreateMaskOk returns a tuple with the DirectoryCreateMask field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectoryCreateMask

`func (o *V12SmbShare) SetDirectoryCreateMask(v int32)`

SetDirectoryCreateMask sets DirectoryCreateMask field to given value.

### HasDirectoryCreateMask

`func (o *V12SmbShare) HasDirectoryCreateMask() bool`

HasDirectoryCreateMask returns a boolean if a field has been set.

### GetDirectoryCreateMode

`func (o *V12SmbShare) GetDirectoryCreateMode() int32`

GetDirectoryCreateMode returns the DirectoryCreateMode field if non-nil, zero value otherwise.

### GetDirectoryCreateModeOk

`func (o *V12SmbShare) GetDirectoryCreateModeOk() (*int32, bool)`

GetDirectoryCreateModeOk returns a tuple with the DirectoryCreateMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDirectoryCreateMode

`func (o *V12SmbShare) SetDirectoryCreateMode(v int32)`

SetDirectoryCreateMode sets DirectoryCreateMode field to given value.

### HasDirectoryCreateMode

`func (o *V12SmbShare) HasDirectoryCreateMode() bool`

HasDirectoryCreateMode returns a boolean if a field has been set.

### GetFileCreateMask

`func (o *V12SmbShare) GetFileCreateMask() int32`

GetFileCreateMask returns the FileCreateMask field if non-nil, zero value otherwise.

### GetFileCreateMaskOk

`func (o *V12SmbShare) GetFileCreateMaskOk() (*int32, bool)`

GetFileCreateMaskOk returns a tuple with the FileCreateMask field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileCreateMask

`func (o *V12SmbShare) SetFileCreateMask(v int32)`

SetFileCreateMask sets FileCreateMask field to given value.

### HasFileCreateMask

`func (o *V12SmbShare) HasFileCreateMask() bool`

HasFileCreateMask returns a boolean if a field has been set.

### GetFileCreateMode

`func (o *V12SmbShare) GetFileCreateMode() int32`

GetFileCreateMode returns the FileCreateMode field if non-nil, zero value otherwise.

### GetFileCreateModeOk

`func (o *V12SmbShare) GetFileCreateModeOk() (*int32, bool)`

GetFileCreateModeOk returns a tuple with the FileCreateMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileCreateMode

`func (o *V12SmbShare) SetFileCreateMode(v int32)`

SetFileCreateMode sets FileCreateMode field to given value.

### HasFileCreateMode

`func (o *V12SmbShare) HasFileCreateMode() bool`

HasFileCreateMode returns a boolean if a field has been set.

### GetFileFilterExtensions

`func (o *V12SmbShare) GetFileFilterExtensions() []string`

GetFileFilterExtensions returns the FileFilterExtensions field if non-nil, zero value otherwise.

### GetFileFilterExtensionsOk

`func (o *V12SmbShare) GetFileFilterExtensionsOk() (*[]string, bool)`

GetFileFilterExtensionsOk returns a tuple with the FileFilterExtensions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileFilterExtensions

`func (o *V12SmbShare) SetFileFilterExtensions(v []string)`

SetFileFilterExtensions sets FileFilterExtensions field to given value.

### HasFileFilterExtensions

`func (o *V12SmbShare) HasFileFilterExtensions() bool`

HasFileFilterExtensions returns a boolean if a field has been set.

### GetFileFilterType

`func (o *V12SmbShare) GetFileFilterType() string`

GetFileFilterType returns the FileFilterType field if non-nil, zero value otherwise.

### GetFileFilterTypeOk

`func (o *V12SmbShare) GetFileFilterTypeOk() (*string, bool)`

GetFileFilterTypeOk returns a tuple with the FileFilterType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileFilterType

`func (o *V12SmbShare) SetFileFilterType(v string)`

SetFileFilterType sets FileFilterType field to given value.

### HasFileFilterType

`func (o *V12SmbShare) HasFileFilterType() bool`

HasFileFilterType returns a boolean if a field has been set.

### GetFileFilteringEnabled

`func (o *V12SmbShare) GetFileFilteringEnabled() bool`

GetFileFilteringEnabled returns the FileFilteringEnabled field if non-nil, zero value otherwise.

### GetFileFilteringEnabledOk

`func (o *V12SmbShare) GetFileFilteringEnabledOk() (*bool, bool)`

GetFileFilteringEnabledOk returns a tuple with the FileFilteringEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileFilteringEnabled

`func (o *V12SmbShare) SetFileFilteringEnabled(v bool)`

SetFileFilteringEnabled sets FileFilteringEnabled field to given value.

### HasFileFilteringEnabled

`func (o *V12SmbShare) HasFileFilteringEnabled() bool`

HasFileFilteringEnabled returns a boolean if a field has been set.

### GetHideDotFiles

`func (o *V12SmbShare) GetHideDotFiles() bool`

GetHideDotFiles returns the HideDotFiles field if non-nil, zero value otherwise.

### GetHideDotFilesOk

`func (o *V12SmbShare) GetHideDotFilesOk() (*bool, bool)`

GetHideDotFilesOk returns a tuple with the HideDotFiles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHideDotFiles

`func (o *V12SmbShare) SetHideDotFiles(v bool)`

SetHideDotFiles sets HideDotFiles field to given value.

### HasHideDotFiles

`func (o *V12SmbShare) HasHideDotFiles() bool`

HasHideDotFiles returns a boolean if a field has been set.

### GetHostAcl

`func (o *V12SmbShare) GetHostAcl() []string`

GetHostAcl returns the HostAcl field if non-nil, zero value otherwise.

### GetHostAclOk

`func (o *V12SmbShare) GetHostAclOk() (*[]string, bool)`

GetHostAclOk returns a tuple with the HostAcl field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostAcl

`func (o *V12SmbShare) SetHostAcl(v []string)`

SetHostAcl sets HostAcl field to given value.

### HasHostAcl

`func (o *V12SmbShare) HasHostAcl() bool`

HasHostAcl returns a boolean if a field has been set.

### GetImpersonateGuest

`func (o *V12SmbShare) GetImpersonateGuest() string`

GetImpersonateGuest returns the ImpersonateGuest field if non-nil, zero value otherwise.

### GetImpersonateGuestOk

`func (o *V12SmbShare) GetImpersonateGuestOk() (*string, bool)`

GetImpersonateGuestOk returns a tuple with the ImpersonateGuest field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImpersonateGuest

`func (o *V12SmbShare) SetImpersonateGuest(v string)`

SetImpersonateGuest sets ImpersonateGuest field to given value.

### HasImpersonateGuest

`func (o *V12SmbShare) HasImpersonateGuest() bool`

HasImpersonateGuest returns a boolean if a field has been set.

### GetImpersonateUser

`func (o *V12SmbShare) GetImpersonateUser() string`

GetImpersonateUser returns the ImpersonateUser field if non-nil, zero value otherwise.

### GetImpersonateUserOk

`func (o *V12SmbShare) GetImpersonateUserOk() (*string, bool)`

GetImpersonateUserOk returns a tuple with the ImpersonateUser field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImpersonateUser

`func (o *V12SmbShare) SetImpersonateUser(v string)`

SetImpersonateUser sets ImpersonateUser field to given value.

### HasImpersonateUser

`func (o *V12SmbShare) HasImpersonateUser() bool`

HasImpersonateUser returns a boolean if a field has been set.

### GetInheritablePathAcl

`func (o *V12SmbShare) GetInheritablePathAcl() bool`

GetInheritablePathAcl returns the InheritablePathAcl field if non-nil, zero value otherwise.

### GetInheritablePathAclOk

`func (o *V12SmbShare) GetInheritablePathAclOk() (*bool, bool)`

GetInheritablePathAclOk returns a tuple with the InheritablePathAcl field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInheritablePathAcl

`func (o *V12SmbShare) SetInheritablePathAcl(v bool)`

SetInheritablePathAcl sets InheritablePathAcl field to given value.

### HasInheritablePathAcl

`func (o *V12SmbShare) HasInheritablePathAcl() bool`

HasInheritablePathAcl returns a boolean if a field has been set.

### GetMangleByteStart

`func (o *V12SmbShare) GetMangleByteStart() int32`

GetMangleByteStart returns the MangleByteStart field if non-nil, zero value otherwise.

### GetMangleByteStartOk

`func (o *V12SmbShare) GetMangleByteStartOk() (*int32, bool)`

GetMangleByteStartOk returns a tuple with the MangleByteStart field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMangleByteStart

`func (o *V12SmbShare) SetMangleByteStart(v int32)`

SetMangleByteStart sets MangleByteStart field to given value.

### HasMangleByteStart

`func (o *V12SmbShare) HasMangleByteStart() bool`

HasMangleByteStart returns a boolean if a field has been set.

### GetMangleMap

`func (o *V12SmbShare) GetMangleMap() []string`

GetMangleMap returns the MangleMap field if non-nil, zero value otherwise.

### GetMangleMapOk

`func (o *V12SmbShare) GetMangleMapOk() (*[]string, bool)`

GetMangleMapOk returns a tuple with the MangleMap field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMangleMap

`func (o *V12SmbShare) SetMangleMap(v []string)`

SetMangleMap sets MangleMap field to given value.

### HasMangleMap

`func (o *V12SmbShare) HasMangleMap() bool`

HasMangleMap returns a boolean if a field has been set.

### GetName

`func (o *V12SmbShare) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12SmbShare) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12SmbShare) SetName(v string)`

SetName sets Name field to given value.


### GetNtfsAclSupport

`func (o *V12SmbShare) GetNtfsAclSupport() bool`

GetNtfsAclSupport returns the NtfsAclSupport field if non-nil, zero value otherwise.

### GetNtfsAclSupportOk

`func (o *V12SmbShare) GetNtfsAclSupportOk() (*bool, bool)`

GetNtfsAclSupportOk returns a tuple with the NtfsAclSupport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNtfsAclSupport

`func (o *V12SmbShare) SetNtfsAclSupport(v bool)`

SetNtfsAclSupport sets NtfsAclSupport field to given value.

### HasNtfsAclSupport

`func (o *V12SmbShare) HasNtfsAclSupport() bool`

HasNtfsAclSupport returns a boolean if a field has been set.

### GetOplocks

`func (o *V12SmbShare) GetOplocks() bool`

GetOplocks returns the Oplocks field if non-nil, zero value otherwise.

### GetOplocksOk

`func (o *V12SmbShare) GetOplocksOk() (*bool, bool)`

GetOplocksOk returns a tuple with the Oplocks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOplocks

`func (o *V12SmbShare) SetOplocks(v bool)`

SetOplocks sets Oplocks field to given value.

### HasOplocks

`func (o *V12SmbShare) HasOplocks() bool`

HasOplocks returns a boolean if a field has been set.

### GetPath

`func (o *V12SmbShare) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V12SmbShare) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V12SmbShare) SetPath(v string)`

SetPath sets Path field to given value.


### GetPermissions

`func (o *V12SmbShare) GetPermissions() []V1SmbSharePermission`

GetPermissions returns the Permissions field if non-nil, zero value otherwise.

### GetPermissionsOk

`func (o *V12SmbShare) GetPermissionsOk() (*[]V1SmbSharePermission, bool)`

GetPermissionsOk returns a tuple with the Permissions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPermissions

`func (o *V12SmbShare) SetPermissions(v []V1SmbSharePermission)`

SetPermissions sets Permissions field to given value.

### HasPermissions

`func (o *V12SmbShare) HasPermissions() bool`

HasPermissions returns a boolean if a field has been set.

### GetRunAsRoot

`func (o *V12SmbShare) GetRunAsRoot() []V1AuthAccessAccessItemFileGroup`

GetRunAsRoot returns the RunAsRoot field if non-nil, zero value otherwise.

### GetRunAsRootOk

`func (o *V12SmbShare) GetRunAsRootOk() (*[]V1AuthAccessAccessItemFileGroup, bool)`

GetRunAsRootOk returns a tuple with the RunAsRoot field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRunAsRoot

`func (o *V12SmbShare) SetRunAsRoot(v []V1AuthAccessAccessItemFileGroup)`

SetRunAsRoot sets RunAsRoot field to given value.

### HasRunAsRoot

`func (o *V12SmbShare) HasRunAsRoot() bool`

HasRunAsRoot returns a boolean if a field has been set.

### GetSmb3EncryptionEnabled

`func (o *V12SmbShare) GetSmb3EncryptionEnabled() bool`

GetSmb3EncryptionEnabled returns the Smb3EncryptionEnabled field if non-nil, zero value otherwise.

### GetSmb3EncryptionEnabledOk

`func (o *V12SmbShare) GetSmb3EncryptionEnabledOk() (*bool, bool)`

GetSmb3EncryptionEnabledOk returns a tuple with the Smb3EncryptionEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmb3EncryptionEnabled

`func (o *V12SmbShare) SetSmb3EncryptionEnabled(v bool)`

SetSmb3EncryptionEnabled sets Smb3EncryptionEnabled field to given value.

### HasSmb3EncryptionEnabled

`func (o *V12SmbShare) HasSmb3EncryptionEnabled() bool`

HasSmb3EncryptionEnabled returns a boolean if a field has been set.

### GetSparseFile

`func (o *V12SmbShare) GetSparseFile() bool`

GetSparseFile returns the SparseFile field if non-nil, zero value otherwise.

### GetSparseFileOk

`func (o *V12SmbShare) GetSparseFileOk() (*bool, bool)`

GetSparseFileOk returns a tuple with the SparseFile field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSparseFile

`func (o *V12SmbShare) SetSparseFile(v bool)`

SetSparseFile sets SparseFile field to given value.

### HasSparseFile

`func (o *V12SmbShare) HasSparseFile() bool`

HasSparseFile returns a boolean if a field has been set.

### GetStrictCaLockout

`func (o *V12SmbShare) GetStrictCaLockout() bool`

GetStrictCaLockout returns the StrictCaLockout field if non-nil, zero value otherwise.

### GetStrictCaLockoutOk

`func (o *V12SmbShare) GetStrictCaLockoutOk() (*bool, bool)`

GetStrictCaLockoutOk returns a tuple with the StrictCaLockout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStrictCaLockout

`func (o *V12SmbShare) SetStrictCaLockout(v bool)`

SetStrictCaLockout sets StrictCaLockout field to given value.

### HasStrictCaLockout

`func (o *V12SmbShare) HasStrictCaLockout() bool`

HasStrictCaLockout returns a boolean if a field has been set.

### GetStrictFlush

`func (o *V12SmbShare) GetStrictFlush() bool`

GetStrictFlush returns the StrictFlush field if non-nil, zero value otherwise.

### GetStrictFlushOk

`func (o *V12SmbShare) GetStrictFlushOk() (*bool, bool)`

GetStrictFlushOk returns a tuple with the StrictFlush field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStrictFlush

`func (o *V12SmbShare) SetStrictFlush(v bool)`

SetStrictFlush sets StrictFlush field to given value.

### HasStrictFlush

`func (o *V12SmbShare) HasStrictFlush() bool`

HasStrictFlush returns a boolean if a field has been set.

### GetStrictLocking

`func (o *V12SmbShare) GetStrictLocking() bool`

GetStrictLocking returns the StrictLocking field if non-nil, zero value otherwise.

### GetStrictLockingOk

`func (o *V12SmbShare) GetStrictLockingOk() (*bool, bool)`

GetStrictLockingOk returns a tuple with the StrictLocking field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStrictLocking

`func (o *V12SmbShare) SetStrictLocking(v bool)`

SetStrictLocking sets StrictLocking field to given value.

### HasStrictLocking

`func (o *V12SmbShare) HasStrictLocking() bool`

HasStrictLocking returns a boolean if a field has been set.

### GetZone

`func (o *V12SmbShare) GetZone() string`

GetZone returns the Zone field if non-nil, zero value otherwise.

### GetZoneOk

`func (o *V12SmbShare) GetZoneOk() (*string, bool)`

GetZoneOk returns a tuple with the Zone field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZone

`func (o *V12SmbShare) SetZone(v string)`

SetZone sets Zone field to given value.

### HasZone

`func (o *V12SmbShare) HasZone() bool`

HasZone returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


