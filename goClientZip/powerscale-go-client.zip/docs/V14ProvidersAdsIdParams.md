# V14ProvidersAdsIdParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllocateGids** | Pointer to **bool** | Allocates an ID for an unmapped Active Directory (ADS) group. ADS groups without GIDs can be proactively assigned a GID by the ID mapper. If the ID mapper option is disabled, GIDs are not proactively assigned, and when a primary group for a user does not include a GID, the system may allocate one.  | [optional] 
**AllocateUids** | Pointer to **bool** | Allocates a user ID for an unmapped Active Directory (ADS) user. ADS users without UIDs can be proactively assigned a UID by the ID mapper. IF the ID mapper option is disabled, UIDs are not proactively assigned, and when an identify for a user does not include a UID, the system may allocate one. | [optional] 
**AssumeDefaultDomain** | Pointer to **bool** | Enables lookup of unqualified user names in the primary domain. | [optional] 
**Authentication** | Pointer to **bool** | Enables authentication and identity management through the authentication provider. | [optional] 
**CheckOnlineInterval** | Pointer to **int32** | Specifies the time in seconds between provider online checks. | [optional] 
**ControllerTime** | Pointer to **int32** | Specifies the current time for the domain controllers. | [optional] 
**CreateHomeDirectory** | Pointer to **bool** | Automatically creates a home directory on the first login. | [optional] 
**DomainController** | Pointer to **string** | Specifies the domain controller to which the authentication service should send requests | [optional] 
**DomainOfflineAlerts** | Pointer to **bool** | Sends an alert if the domain goes offline. | [optional] 
**ExtraExpectedSpns** | Pointer to **[]string** | List of additional SPNs to expect beyond what automatic checking routines might find | [optional] 
**FindableGroups** | Pointer to **[]string** | Sets list of groups that can be resolved. | [optional] 
**FindableUsers** | Pointer to **[]string** | Sets list of users that can be resolved. | [optional] 
**HomeDirectoryTemplate** | Pointer to **string** | Specifies the path to the home directory template. | [optional] 
**IgnoreAllTrusts** | Pointer to **bool** | If set to true, ignores all trusted domains. | [optional] 
**IgnoredTrustedDomains** | Pointer to **[]string** | Includes trusted domains when &#39;ignore_all_trusts&#39; is set to false. | [optional] 
**IncludeTrustedDomains** | Pointer to **[]string** | Includes trusted domains when &#39;ignore_all_trusts&#39; is set to true. | [optional] 
**LdapSignAndSeal** | Pointer to **bool** | Enables encryption and signing on LDAP requests. | [optional] 
**LoginShell** | Pointer to **string** | Specifies the login shell path. | [optional] 
**LookupDomains** | Pointer to **[]string** | Limits user and group lookups to the specified domains. | [optional] 
**LookupGroups** | Pointer to **bool** | Looks up AD groups in other providers before allocating a group ID. | [optional] 
**LookupNormalizeGroups** | Pointer to **bool** | Normalizes AD group names to lowercase before look up. | [optional] 
**LookupNormalizeUsers** | Pointer to **bool** | Normalize AD user names to lowercase before look up. | [optional] 
**LookupUsers** | Pointer to **bool** | Looks up AD users in other providers before allocating a user ID. | [optional] 
**MachinePasswordChanges** | Pointer to **bool** | Enables periodic changes of the machine password for security. | [optional] 
**MachinePasswordLifespan** | Pointer to **int32** | Sets maximum age of a password in seconds. | [optional] 
**NodeDcAffinity** | Pointer to **string** | Specifies the domain controller for which the node has affinity. | [optional] 
**NodeDcAffinityTimeout** | Pointer to **int32** | Specifies the timeout for the domain controller for which the local node has affinity. | [optional] 
**NssEnumeration** | Pointer to **bool** | Enables the Active Directory provider to respond to &#39;getpwent&#39; and &#39;getgrent&#39; requests. | [optional] 
**Password** | Pointer to **string** | Specifies the password used during domain join. | [optional] 
**ResetSchannel** | Pointer to **bool** | Resets the secure channel to the primary domain. | [optional] 
**RestrictFindable** | Pointer to **bool** | Check the provider for filtered lists of findable and unfindable users and groups. | [optional] 
**RpcCallTimeout** | Pointer to **int32** | The maximum amount of time (in seconds) an RPC call to Active Directory is allowed to take. | [optional] 
**ServerRetryLimit** | Pointer to **int32** | The number of retries attempted when a call to Active Directory fails due to network error. | [optional] 
**SfuSupport** | Pointer to **string** | Specifies whether to support RFC 2307 attributes on ADS domain controllers. | [optional] 
**Spns** | Pointer to **[]string** | Currently configured SPNs. | [optional] 
**StoreSfuMappings** | Pointer to **bool** | Stores SFU mappings permanently in the ID mapper. | [optional] 
**UnfindableGroups** | Pointer to **[]string** | Specifies groups that cannot be resolved by the provider. | [optional] 
**UnfindableUsers** | Pointer to **[]string** | Specifies users that cannot be resolved by the provider. | [optional] 
**User** | Pointer to **string** | Specifies the user name that has permission to join a machine to the given domain. | [optional] 

## Methods

### NewV14ProvidersAdsIdParams

`func NewV14ProvidersAdsIdParams() *V14ProvidersAdsIdParams`

NewV14ProvidersAdsIdParams instantiates a new V14ProvidersAdsIdParams object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ProvidersAdsIdParamsWithDefaults

`func NewV14ProvidersAdsIdParamsWithDefaults() *V14ProvidersAdsIdParams`

NewV14ProvidersAdsIdParamsWithDefaults instantiates a new V14ProvidersAdsIdParams object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllocateGids

`func (o *V14ProvidersAdsIdParams) GetAllocateGids() bool`

GetAllocateGids returns the AllocateGids field if non-nil, zero value otherwise.

### GetAllocateGidsOk

`func (o *V14ProvidersAdsIdParams) GetAllocateGidsOk() (*bool, bool)`

GetAllocateGidsOk returns a tuple with the AllocateGids field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllocateGids

`func (o *V14ProvidersAdsIdParams) SetAllocateGids(v bool)`

SetAllocateGids sets AllocateGids field to given value.

### HasAllocateGids

`func (o *V14ProvidersAdsIdParams) HasAllocateGids() bool`

HasAllocateGids returns a boolean if a field has been set.

### GetAllocateUids

`func (o *V14ProvidersAdsIdParams) GetAllocateUids() bool`

GetAllocateUids returns the AllocateUids field if non-nil, zero value otherwise.

### GetAllocateUidsOk

`func (o *V14ProvidersAdsIdParams) GetAllocateUidsOk() (*bool, bool)`

GetAllocateUidsOk returns a tuple with the AllocateUids field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllocateUids

`func (o *V14ProvidersAdsIdParams) SetAllocateUids(v bool)`

SetAllocateUids sets AllocateUids field to given value.

### HasAllocateUids

`func (o *V14ProvidersAdsIdParams) HasAllocateUids() bool`

HasAllocateUids returns a boolean if a field has been set.

### GetAssumeDefaultDomain

`func (o *V14ProvidersAdsIdParams) GetAssumeDefaultDomain() bool`

GetAssumeDefaultDomain returns the AssumeDefaultDomain field if non-nil, zero value otherwise.

### GetAssumeDefaultDomainOk

`func (o *V14ProvidersAdsIdParams) GetAssumeDefaultDomainOk() (*bool, bool)`

GetAssumeDefaultDomainOk returns a tuple with the AssumeDefaultDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAssumeDefaultDomain

`func (o *V14ProvidersAdsIdParams) SetAssumeDefaultDomain(v bool)`

SetAssumeDefaultDomain sets AssumeDefaultDomain field to given value.

### HasAssumeDefaultDomain

`func (o *V14ProvidersAdsIdParams) HasAssumeDefaultDomain() bool`

HasAssumeDefaultDomain returns a boolean if a field has been set.

### GetAuthentication

`func (o *V14ProvidersAdsIdParams) GetAuthentication() bool`

GetAuthentication returns the Authentication field if non-nil, zero value otherwise.

### GetAuthenticationOk

`func (o *V14ProvidersAdsIdParams) GetAuthenticationOk() (*bool, bool)`

GetAuthenticationOk returns a tuple with the Authentication field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuthentication

`func (o *V14ProvidersAdsIdParams) SetAuthentication(v bool)`

SetAuthentication sets Authentication field to given value.

### HasAuthentication

`func (o *V14ProvidersAdsIdParams) HasAuthentication() bool`

HasAuthentication returns a boolean if a field has been set.

### GetCheckOnlineInterval

`func (o *V14ProvidersAdsIdParams) GetCheckOnlineInterval() int32`

GetCheckOnlineInterval returns the CheckOnlineInterval field if non-nil, zero value otherwise.

### GetCheckOnlineIntervalOk

`func (o *V14ProvidersAdsIdParams) GetCheckOnlineIntervalOk() (*int32, bool)`

GetCheckOnlineIntervalOk returns a tuple with the CheckOnlineInterval field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCheckOnlineInterval

`func (o *V14ProvidersAdsIdParams) SetCheckOnlineInterval(v int32)`

SetCheckOnlineInterval sets CheckOnlineInterval field to given value.

### HasCheckOnlineInterval

`func (o *V14ProvidersAdsIdParams) HasCheckOnlineInterval() bool`

HasCheckOnlineInterval returns a boolean if a field has been set.

### GetControllerTime

`func (o *V14ProvidersAdsIdParams) GetControllerTime() int32`

GetControllerTime returns the ControllerTime field if non-nil, zero value otherwise.

### GetControllerTimeOk

`func (o *V14ProvidersAdsIdParams) GetControllerTimeOk() (*int32, bool)`

GetControllerTimeOk returns a tuple with the ControllerTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetControllerTime

`func (o *V14ProvidersAdsIdParams) SetControllerTime(v int32)`

SetControllerTime sets ControllerTime field to given value.

### HasControllerTime

`func (o *V14ProvidersAdsIdParams) HasControllerTime() bool`

HasControllerTime returns a boolean if a field has been set.

### GetCreateHomeDirectory

`func (o *V14ProvidersAdsIdParams) GetCreateHomeDirectory() bool`

GetCreateHomeDirectory returns the CreateHomeDirectory field if non-nil, zero value otherwise.

### GetCreateHomeDirectoryOk

`func (o *V14ProvidersAdsIdParams) GetCreateHomeDirectoryOk() (*bool, bool)`

GetCreateHomeDirectoryOk returns a tuple with the CreateHomeDirectory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateHomeDirectory

`func (o *V14ProvidersAdsIdParams) SetCreateHomeDirectory(v bool)`

SetCreateHomeDirectory sets CreateHomeDirectory field to given value.

### HasCreateHomeDirectory

`func (o *V14ProvidersAdsIdParams) HasCreateHomeDirectory() bool`

HasCreateHomeDirectory returns a boolean if a field has been set.

### GetDomainController

`func (o *V14ProvidersAdsIdParams) GetDomainController() string`

GetDomainController returns the DomainController field if non-nil, zero value otherwise.

### GetDomainControllerOk

`func (o *V14ProvidersAdsIdParams) GetDomainControllerOk() (*string, bool)`

GetDomainControllerOk returns a tuple with the DomainController field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomainController

`func (o *V14ProvidersAdsIdParams) SetDomainController(v string)`

SetDomainController sets DomainController field to given value.

### HasDomainController

`func (o *V14ProvidersAdsIdParams) HasDomainController() bool`

HasDomainController returns a boolean if a field has been set.

### GetDomainOfflineAlerts

`func (o *V14ProvidersAdsIdParams) GetDomainOfflineAlerts() bool`

GetDomainOfflineAlerts returns the DomainOfflineAlerts field if non-nil, zero value otherwise.

### GetDomainOfflineAlertsOk

`func (o *V14ProvidersAdsIdParams) GetDomainOfflineAlertsOk() (*bool, bool)`

GetDomainOfflineAlertsOk returns a tuple with the DomainOfflineAlerts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomainOfflineAlerts

`func (o *V14ProvidersAdsIdParams) SetDomainOfflineAlerts(v bool)`

SetDomainOfflineAlerts sets DomainOfflineAlerts field to given value.

### HasDomainOfflineAlerts

`func (o *V14ProvidersAdsIdParams) HasDomainOfflineAlerts() bool`

HasDomainOfflineAlerts returns a boolean if a field has been set.

### GetExtraExpectedSpns

`func (o *V14ProvidersAdsIdParams) GetExtraExpectedSpns() []string`

GetExtraExpectedSpns returns the ExtraExpectedSpns field if non-nil, zero value otherwise.

### GetExtraExpectedSpnsOk

`func (o *V14ProvidersAdsIdParams) GetExtraExpectedSpnsOk() (*[]string, bool)`

GetExtraExpectedSpnsOk returns a tuple with the ExtraExpectedSpns field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExtraExpectedSpns

`func (o *V14ProvidersAdsIdParams) SetExtraExpectedSpns(v []string)`

SetExtraExpectedSpns sets ExtraExpectedSpns field to given value.

### HasExtraExpectedSpns

`func (o *V14ProvidersAdsIdParams) HasExtraExpectedSpns() bool`

HasExtraExpectedSpns returns a boolean if a field has been set.

### GetFindableGroups

`func (o *V14ProvidersAdsIdParams) GetFindableGroups() []string`

GetFindableGroups returns the FindableGroups field if non-nil, zero value otherwise.

### GetFindableGroupsOk

`func (o *V14ProvidersAdsIdParams) GetFindableGroupsOk() (*[]string, bool)`

GetFindableGroupsOk returns a tuple with the FindableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFindableGroups

`func (o *V14ProvidersAdsIdParams) SetFindableGroups(v []string)`

SetFindableGroups sets FindableGroups field to given value.

### HasFindableGroups

`func (o *V14ProvidersAdsIdParams) HasFindableGroups() bool`

HasFindableGroups returns a boolean if a field has been set.

### GetFindableUsers

`func (o *V14ProvidersAdsIdParams) GetFindableUsers() []string`

GetFindableUsers returns the FindableUsers field if non-nil, zero value otherwise.

### GetFindableUsersOk

`func (o *V14ProvidersAdsIdParams) GetFindableUsersOk() (*[]string, bool)`

GetFindableUsersOk returns a tuple with the FindableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFindableUsers

`func (o *V14ProvidersAdsIdParams) SetFindableUsers(v []string)`

SetFindableUsers sets FindableUsers field to given value.

### HasFindableUsers

`func (o *V14ProvidersAdsIdParams) HasFindableUsers() bool`

HasFindableUsers returns a boolean if a field has been set.

### GetHomeDirectoryTemplate

`func (o *V14ProvidersAdsIdParams) GetHomeDirectoryTemplate() string`

GetHomeDirectoryTemplate returns the HomeDirectoryTemplate field if non-nil, zero value otherwise.

### GetHomeDirectoryTemplateOk

`func (o *V14ProvidersAdsIdParams) GetHomeDirectoryTemplateOk() (*string, bool)`

GetHomeDirectoryTemplateOk returns a tuple with the HomeDirectoryTemplate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHomeDirectoryTemplate

`func (o *V14ProvidersAdsIdParams) SetHomeDirectoryTemplate(v string)`

SetHomeDirectoryTemplate sets HomeDirectoryTemplate field to given value.

### HasHomeDirectoryTemplate

`func (o *V14ProvidersAdsIdParams) HasHomeDirectoryTemplate() bool`

HasHomeDirectoryTemplate returns a boolean if a field has been set.

### GetIgnoreAllTrusts

`func (o *V14ProvidersAdsIdParams) GetIgnoreAllTrusts() bool`

GetIgnoreAllTrusts returns the IgnoreAllTrusts field if non-nil, zero value otherwise.

### GetIgnoreAllTrustsOk

`func (o *V14ProvidersAdsIdParams) GetIgnoreAllTrustsOk() (*bool, bool)`

GetIgnoreAllTrustsOk returns a tuple with the IgnoreAllTrusts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoreAllTrusts

`func (o *V14ProvidersAdsIdParams) SetIgnoreAllTrusts(v bool)`

SetIgnoreAllTrusts sets IgnoreAllTrusts field to given value.

### HasIgnoreAllTrusts

`func (o *V14ProvidersAdsIdParams) HasIgnoreAllTrusts() bool`

HasIgnoreAllTrusts returns a boolean if a field has been set.

### GetIgnoredTrustedDomains

`func (o *V14ProvidersAdsIdParams) GetIgnoredTrustedDomains() []string`

GetIgnoredTrustedDomains returns the IgnoredTrustedDomains field if non-nil, zero value otherwise.

### GetIgnoredTrustedDomainsOk

`func (o *V14ProvidersAdsIdParams) GetIgnoredTrustedDomainsOk() (*[]string, bool)`

GetIgnoredTrustedDomainsOk returns a tuple with the IgnoredTrustedDomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoredTrustedDomains

`func (o *V14ProvidersAdsIdParams) SetIgnoredTrustedDomains(v []string)`

SetIgnoredTrustedDomains sets IgnoredTrustedDomains field to given value.

### HasIgnoredTrustedDomains

`func (o *V14ProvidersAdsIdParams) HasIgnoredTrustedDomains() bool`

HasIgnoredTrustedDomains returns a boolean if a field has been set.

### GetIncludeTrustedDomains

`func (o *V14ProvidersAdsIdParams) GetIncludeTrustedDomains() []string`

GetIncludeTrustedDomains returns the IncludeTrustedDomains field if non-nil, zero value otherwise.

### GetIncludeTrustedDomainsOk

`func (o *V14ProvidersAdsIdParams) GetIncludeTrustedDomainsOk() (*[]string, bool)`

GetIncludeTrustedDomainsOk returns a tuple with the IncludeTrustedDomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeTrustedDomains

`func (o *V14ProvidersAdsIdParams) SetIncludeTrustedDomains(v []string)`

SetIncludeTrustedDomains sets IncludeTrustedDomains field to given value.

### HasIncludeTrustedDomains

`func (o *V14ProvidersAdsIdParams) HasIncludeTrustedDomains() bool`

HasIncludeTrustedDomains returns a boolean if a field has been set.

### GetLdapSignAndSeal

`func (o *V14ProvidersAdsIdParams) GetLdapSignAndSeal() bool`

GetLdapSignAndSeal returns the LdapSignAndSeal field if non-nil, zero value otherwise.

### GetLdapSignAndSealOk

`func (o *V14ProvidersAdsIdParams) GetLdapSignAndSealOk() (*bool, bool)`

GetLdapSignAndSealOk returns a tuple with the LdapSignAndSeal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLdapSignAndSeal

`func (o *V14ProvidersAdsIdParams) SetLdapSignAndSeal(v bool)`

SetLdapSignAndSeal sets LdapSignAndSeal field to given value.

### HasLdapSignAndSeal

`func (o *V14ProvidersAdsIdParams) HasLdapSignAndSeal() bool`

HasLdapSignAndSeal returns a boolean if a field has been set.

### GetLoginShell

`func (o *V14ProvidersAdsIdParams) GetLoginShell() string`

GetLoginShell returns the LoginShell field if non-nil, zero value otherwise.

### GetLoginShellOk

`func (o *V14ProvidersAdsIdParams) GetLoginShellOk() (*string, bool)`

GetLoginShellOk returns a tuple with the LoginShell field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLoginShell

`func (o *V14ProvidersAdsIdParams) SetLoginShell(v string)`

SetLoginShell sets LoginShell field to given value.

### HasLoginShell

`func (o *V14ProvidersAdsIdParams) HasLoginShell() bool`

HasLoginShell returns a boolean if a field has been set.

### GetLookupDomains

`func (o *V14ProvidersAdsIdParams) GetLookupDomains() []string`

GetLookupDomains returns the LookupDomains field if non-nil, zero value otherwise.

### GetLookupDomainsOk

`func (o *V14ProvidersAdsIdParams) GetLookupDomainsOk() (*[]string, bool)`

GetLookupDomainsOk returns a tuple with the LookupDomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupDomains

`func (o *V14ProvidersAdsIdParams) SetLookupDomains(v []string)`

SetLookupDomains sets LookupDomains field to given value.

### HasLookupDomains

`func (o *V14ProvidersAdsIdParams) HasLookupDomains() bool`

HasLookupDomains returns a boolean if a field has been set.

### GetLookupGroups

`func (o *V14ProvidersAdsIdParams) GetLookupGroups() bool`

GetLookupGroups returns the LookupGroups field if non-nil, zero value otherwise.

### GetLookupGroupsOk

`func (o *V14ProvidersAdsIdParams) GetLookupGroupsOk() (*bool, bool)`

GetLookupGroupsOk returns a tuple with the LookupGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupGroups

`func (o *V14ProvidersAdsIdParams) SetLookupGroups(v bool)`

SetLookupGroups sets LookupGroups field to given value.

### HasLookupGroups

`func (o *V14ProvidersAdsIdParams) HasLookupGroups() bool`

HasLookupGroups returns a boolean if a field has been set.

### GetLookupNormalizeGroups

`func (o *V14ProvidersAdsIdParams) GetLookupNormalizeGroups() bool`

GetLookupNormalizeGroups returns the LookupNormalizeGroups field if non-nil, zero value otherwise.

### GetLookupNormalizeGroupsOk

`func (o *V14ProvidersAdsIdParams) GetLookupNormalizeGroupsOk() (*bool, bool)`

GetLookupNormalizeGroupsOk returns a tuple with the LookupNormalizeGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupNormalizeGroups

`func (o *V14ProvidersAdsIdParams) SetLookupNormalizeGroups(v bool)`

SetLookupNormalizeGroups sets LookupNormalizeGroups field to given value.

### HasLookupNormalizeGroups

`func (o *V14ProvidersAdsIdParams) HasLookupNormalizeGroups() bool`

HasLookupNormalizeGroups returns a boolean if a field has been set.

### GetLookupNormalizeUsers

`func (o *V14ProvidersAdsIdParams) GetLookupNormalizeUsers() bool`

GetLookupNormalizeUsers returns the LookupNormalizeUsers field if non-nil, zero value otherwise.

### GetLookupNormalizeUsersOk

`func (o *V14ProvidersAdsIdParams) GetLookupNormalizeUsersOk() (*bool, bool)`

GetLookupNormalizeUsersOk returns a tuple with the LookupNormalizeUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupNormalizeUsers

`func (o *V14ProvidersAdsIdParams) SetLookupNormalizeUsers(v bool)`

SetLookupNormalizeUsers sets LookupNormalizeUsers field to given value.

### HasLookupNormalizeUsers

`func (o *V14ProvidersAdsIdParams) HasLookupNormalizeUsers() bool`

HasLookupNormalizeUsers returns a boolean if a field has been set.

### GetLookupUsers

`func (o *V14ProvidersAdsIdParams) GetLookupUsers() bool`

GetLookupUsers returns the LookupUsers field if non-nil, zero value otherwise.

### GetLookupUsersOk

`func (o *V14ProvidersAdsIdParams) GetLookupUsersOk() (*bool, bool)`

GetLookupUsersOk returns a tuple with the LookupUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupUsers

`func (o *V14ProvidersAdsIdParams) SetLookupUsers(v bool)`

SetLookupUsers sets LookupUsers field to given value.

### HasLookupUsers

`func (o *V14ProvidersAdsIdParams) HasLookupUsers() bool`

HasLookupUsers returns a boolean if a field has been set.

### GetMachinePasswordChanges

`func (o *V14ProvidersAdsIdParams) GetMachinePasswordChanges() bool`

GetMachinePasswordChanges returns the MachinePasswordChanges field if non-nil, zero value otherwise.

### GetMachinePasswordChangesOk

`func (o *V14ProvidersAdsIdParams) GetMachinePasswordChangesOk() (*bool, bool)`

GetMachinePasswordChangesOk returns a tuple with the MachinePasswordChanges field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMachinePasswordChanges

`func (o *V14ProvidersAdsIdParams) SetMachinePasswordChanges(v bool)`

SetMachinePasswordChanges sets MachinePasswordChanges field to given value.

### HasMachinePasswordChanges

`func (o *V14ProvidersAdsIdParams) HasMachinePasswordChanges() bool`

HasMachinePasswordChanges returns a boolean if a field has been set.

### GetMachinePasswordLifespan

`func (o *V14ProvidersAdsIdParams) GetMachinePasswordLifespan() int32`

GetMachinePasswordLifespan returns the MachinePasswordLifespan field if non-nil, zero value otherwise.

### GetMachinePasswordLifespanOk

`func (o *V14ProvidersAdsIdParams) GetMachinePasswordLifespanOk() (*int32, bool)`

GetMachinePasswordLifespanOk returns a tuple with the MachinePasswordLifespan field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMachinePasswordLifespan

`func (o *V14ProvidersAdsIdParams) SetMachinePasswordLifespan(v int32)`

SetMachinePasswordLifespan sets MachinePasswordLifespan field to given value.

### HasMachinePasswordLifespan

`func (o *V14ProvidersAdsIdParams) HasMachinePasswordLifespan() bool`

HasMachinePasswordLifespan returns a boolean if a field has been set.

### GetNodeDcAffinity

`func (o *V14ProvidersAdsIdParams) GetNodeDcAffinity() string`

GetNodeDcAffinity returns the NodeDcAffinity field if non-nil, zero value otherwise.

### GetNodeDcAffinityOk

`func (o *V14ProvidersAdsIdParams) GetNodeDcAffinityOk() (*string, bool)`

GetNodeDcAffinityOk returns a tuple with the NodeDcAffinity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeDcAffinity

`func (o *V14ProvidersAdsIdParams) SetNodeDcAffinity(v string)`

SetNodeDcAffinity sets NodeDcAffinity field to given value.

### HasNodeDcAffinity

`func (o *V14ProvidersAdsIdParams) HasNodeDcAffinity() bool`

HasNodeDcAffinity returns a boolean if a field has been set.

### GetNodeDcAffinityTimeout

`func (o *V14ProvidersAdsIdParams) GetNodeDcAffinityTimeout() int32`

GetNodeDcAffinityTimeout returns the NodeDcAffinityTimeout field if non-nil, zero value otherwise.

### GetNodeDcAffinityTimeoutOk

`func (o *V14ProvidersAdsIdParams) GetNodeDcAffinityTimeoutOk() (*int32, bool)`

GetNodeDcAffinityTimeoutOk returns a tuple with the NodeDcAffinityTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeDcAffinityTimeout

`func (o *V14ProvidersAdsIdParams) SetNodeDcAffinityTimeout(v int32)`

SetNodeDcAffinityTimeout sets NodeDcAffinityTimeout field to given value.

### HasNodeDcAffinityTimeout

`func (o *V14ProvidersAdsIdParams) HasNodeDcAffinityTimeout() bool`

HasNodeDcAffinityTimeout returns a boolean if a field has been set.

### GetNssEnumeration

`func (o *V14ProvidersAdsIdParams) GetNssEnumeration() bool`

GetNssEnumeration returns the NssEnumeration field if non-nil, zero value otherwise.

### GetNssEnumerationOk

`func (o *V14ProvidersAdsIdParams) GetNssEnumerationOk() (*bool, bool)`

GetNssEnumerationOk returns a tuple with the NssEnumeration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNssEnumeration

`func (o *V14ProvidersAdsIdParams) SetNssEnumeration(v bool)`

SetNssEnumeration sets NssEnumeration field to given value.

### HasNssEnumeration

`func (o *V14ProvidersAdsIdParams) HasNssEnumeration() bool`

HasNssEnumeration returns a boolean if a field has been set.

### GetPassword

`func (o *V14ProvidersAdsIdParams) GetPassword() string`

GetPassword returns the Password field if non-nil, zero value otherwise.

### GetPasswordOk

`func (o *V14ProvidersAdsIdParams) GetPasswordOk() (*string, bool)`

GetPasswordOk returns a tuple with the Password field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPassword

`func (o *V14ProvidersAdsIdParams) SetPassword(v string)`

SetPassword sets Password field to given value.

### HasPassword

`func (o *V14ProvidersAdsIdParams) HasPassword() bool`

HasPassword returns a boolean if a field has been set.

### GetResetSchannel

`func (o *V14ProvidersAdsIdParams) GetResetSchannel() bool`

GetResetSchannel returns the ResetSchannel field if non-nil, zero value otherwise.

### GetResetSchannelOk

`func (o *V14ProvidersAdsIdParams) GetResetSchannelOk() (*bool, bool)`

GetResetSchannelOk returns a tuple with the ResetSchannel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResetSchannel

`func (o *V14ProvidersAdsIdParams) SetResetSchannel(v bool)`

SetResetSchannel sets ResetSchannel field to given value.

### HasResetSchannel

`func (o *V14ProvidersAdsIdParams) HasResetSchannel() bool`

HasResetSchannel returns a boolean if a field has been set.

### GetRestrictFindable

`func (o *V14ProvidersAdsIdParams) GetRestrictFindable() bool`

GetRestrictFindable returns the RestrictFindable field if non-nil, zero value otherwise.

### GetRestrictFindableOk

`func (o *V14ProvidersAdsIdParams) GetRestrictFindableOk() (*bool, bool)`

GetRestrictFindableOk returns a tuple with the RestrictFindable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRestrictFindable

`func (o *V14ProvidersAdsIdParams) SetRestrictFindable(v bool)`

SetRestrictFindable sets RestrictFindable field to given value.

### HasRestrictFindable

`func (o *V14ProvidersAdsIdParams) HasRestrictFindable() bool`

HasRestrictFindable returns a boolean if a field has been set.

### GetRpcCallTimeout

`func (o *V14ProvidersAdsIdParams) GetRpcCallTimeout() int32`

GetRpcCallTimeout returns the RpcCallTimeout field if non-nil, zero value otherwise.

### GetRpcCallTimeoutOk

`func (o *V14ProvidersAdsIdParams) GetRpcCallTimeoutOk() (*int32, bool)`

GetRpcCallTimeoutOk returns a tuple with the RpcCallTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRpcCallTimeout

`func (o *V14ProvidersAdsIdParams) SetRpcCallTimeout(v int32)`

SetRpcCallTimeout sets RpcCallTimeout field to given value.

### HasRpcCallTimeout

`func (o *V14ProvidersAdsIdParams) HasRpcCallTimeout() bool`

HasRpcCallTimeout returns a boolean if a field has been set.

### GetServerRetryLimit

`func (o *V14ProvidersAdsIdParams) GetServerRetryLimit() int32`

GetServerRetryLimit returns the ServerRetryLimit field if non-nil, zero value otherwise.

### GetServerRetryLimitOk

`func (o *V14ProvidersAdsIdParams) GetServerRetryLimitOk() (*int32, bool)`

GetServerRetryLimitOk returns a tuple with the ServerRetryLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerRetryLimit

`func (o *V14ProvidersAdsIdParams) SetServerRetryLimit(v int32)`

SetServerRetryLimit sets ServerRetryLimit field to given value.

### HasServerRetryLimit

`func (o *V14ProvidersAdsIdParams) HasServerRetryLimit() bool`

HasServerRetryLimit returns a boolean if a field has been set.

### GetSfuSupport

`func (o *V14ProvidersAdsIdParams) GetSfuSupport() string`

GetSfuSupport returns the SfuSupport field if non-nil, zero value otherwise.

### GetSfuSupportOk

`func (o *V14ProvidersAdsIdParams) GetSfuSupportOk() (*string, bool)`

GetSfuSupportOk returns a tuple with the SfuSupport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSfuSupport

`func (o *V14ProvidersAdsIdParams) SetSfuSupport(v string)`

SetSfuSupport sets SfuSupport field to given value.

### HasSfuSupport

`func (o *V14ProvidersAdsIdParams) HasSfuSupport() bool`

HasSfuSupport returns a boolean if a field has been set.

### GetSpns

`func (o *V14ProvidersAdsIdParams) GetSpns() []string`

GetSpns returns the Spns field if non-nil, zero value otherwise.

### GetSpnsOk

`func (o *V14ProvidersAdsIdParams) GetSpnsOk() (*[]string, bool)`

GetSpnsOk returns a tuple with the Spns field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpns

`func (o *V14ProvidersAdsIdParams) SetSpns(v []string)`

SetSpns sets Spns field to given value.

### HasSpns

`func (o *V14ProvidersAdsIdParams) HasSpns() bool`

HasSpns returns a boolean if a field has been set.

### GetStoreSfuMappings

`func (o *V14ProvidersAdsIdParams) GetStoreSfuMappings() bool`

GetStoreSfuMappings returns the StoreSfuMappings field if non-nil, zero value otherwise.

### GetStoreSfuMappingsOk

`func (o *V14ProvidersAdsIdParams) GetStoreSfuMappingsOk() (*bool, bool)`

GetStoreSfuMappingsOk returns a tuple with the StoreSfuMappings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStoreSfuMappings

`func (o *V14ProvidersAdsIdParams) SetStoreSfuMappings(v bool)`

SetStoreSfuMappings sets StoreSfuMappings field to given value.

### HasStoreSfuMappings

`func (o *V14ProvidersAdsIdParams) HasStoreSfuMappings() bool`

HasStoreSfuMappings returns a boolean if a field has been set.

### GetUnfindableGroups

`func (o *V14ProvidersAdsIdParams) GetUnfindableGroups() []string`

GetUnfindableGroups returns the UnfindableGroups field if non-nil, zero value otherwise.

### GetUnfindableGroupsOk

`func (o *V14ProvidersAdsIdParams) GetUnfindableGroupsOk() (*[]string, bool)`

GetUnfindableGroupsOk returns a tuple with the UnfindableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnfindableGroups

`func (o *V14ProvidersAdsIdParams) SetUnfindableGroups(v []string)`

SetUnfindableGroups sets UnfindableGroups field to given value.

### HasUnfindableGroups

`func (o *V14ProvidersAdsIdParams) HasUnfindableGroups() bool`

HasUnfindableGroups returns a boolean if a field has been set.

### GetUnfindableUsers

`func (o *V14ProvidersAdsIdParams) GetUnfindableUsers() []string`

GetUnfindableUsers returns the UnfindableUsers field if non-nil, zero value otherwise.

### GetUnfindableUsersOk

`func (o *V14ProvidersAdsIdParams) GetUnfindableUsersOk() (*[]string, bool)`

GetUnfindableUsersOk returns a tuple with the UnfindableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnfindableUsers

`func (o *V14ProvidersAdsIdParams) SetUnfindableUsers(v []string)`

SetUnfindableUsers sets UnfindableUsers field to given value.

### HasUnfindableUsers

`func (o *V14ProvidersAdsIdParams) HasUnfindableUsers() bool`

HasUnfindableUsers returns a boolean if a field has been set.

### GetUser

`func (o *V14ProvidersAdsIdParams) GetUser() string`

GetUser returns the User field if non-nil, zero value otherwise.

### GetUserOk

`func (o *V14ProvidersAdsIdParams) GetUserOk() (*string, bool)`

GetUserOk returns a tuple with the User field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUser

`func (o *V14ProvidersAdsIdParams) SetUser(v string)`

SetUser sets User field to given value.

### HasUser

`func (o *V14ProvidersAdsIdParams) HasUser() bool`

HasUser returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


