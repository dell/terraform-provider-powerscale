# V14RolePrivileges

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Privileges** | Pointer to [**[]V14AuthIdNtokenPrivilegeItem**](V14AuthIdNtokenPrivilegeItem.md) |  | [optional] 

## Methods

### NewV14RolePrivileges

`func NewV14RolePrivileges() *V14RolePrivileges`

NewV14RolePrivileges instantiates a new V14RolePrivileges object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14RolePrivilegesWithDefaults

`func NewV14RolePrivilegesWithDefaults() *V14RolePrivileges`

NewV14RolePrivilegesWithDefaults instantiates a new V14RolePrivileges object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPrivileges

`func (o *V14RolePrivileges) GetPrivileges() []V14AuthIdNtokenPrivilegeItem`

GetPrivileges returns the Privileges field if non-nil, zero value otherwise.

### GetPrivilegesOk

`func (o *V14RolePrivileges) GetPrivilegesOk() (*[]V14AuthIdNtokenPrivilegeItem, bool)`

GetPrivilegesOk returns a tuple with the Privileges field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrivileges

`func (o *V14RolePrivileges) SetPrivileges(v []V14AuthIdNtokenPrivilegeItem)`

SetPrivileges sets Privileges field to given value.

### HasPrivileges

`func (o *V14RolePrivileges) HasPrivileges() bool`

HasPrivileges returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


