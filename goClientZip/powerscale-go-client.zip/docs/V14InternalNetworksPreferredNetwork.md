# V14InternalNetworksPreferredNetwork

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HighLnn** | **int32** | Low-numbered LNN of node pair | 
**LowLnn** | **int32** | Low-numbered LNN of node pair | 
**PreferredNetwork** | **string** | Backend network fabric primary network int-a and secondary network int-b | 

## Methods

### NewV14InternalNetworksPreferredNetwork

`func NewV14InternalNetworksPreferredNetwork(highLnn int32, lowLnn int32, preferredNetwork string, ) *V14InternalNetworksPreferredNetwork`

NewV14InternalNetworksPreferredNetwork instantiates a new V14InternalNetworksPreferredNetwork object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14InternalNetworksPreferredNetworkWithDefaults

`func NewV14InternalNetworksPreferredNetworkWithDefaults() *V14InternalNetworksPreferredNetwork`

NewV14InternalNetworksPreferredNetworkWithDefaults instantiates a new V14InternalNetworksPreferredNetwork object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHighLnn

`func (o *V14InternalNetworksPreferredNetwork) GetHighLnn() int32`

GetHighLnn returns the HighLnn field if non-nil, zero value otherwise.

### GetHighLnnOk

`func (o *V14InternalNetworksPreferredNetwork) GetHighLnnOk() (*int32, bool)`

GetHighLnnOk returns a tuple with the HighLnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHighLnn

`func (o *V14InternalNetworksPreferredNetwork) SetHighLnn(v int32)`

SetHighLnn sets HighLnn field to given value.


### GetLowLnn

`func (o *V14InternalNetworksPreferredNetwork) GetLowLnn() int32`

GetLowLnn returns the LowLnn field if non-nil, zero value otherwise.

### GetLowLnnOk

`func (o *V14InternalNetworksPreferredNetwork) GetLowLnnOk() (*int32, bool)`

GetLowLnnOk returns a tuple with the LowLnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLowLnn

`func (o *V14InternalNetworksPreferredNetwork) SetLowLnn(v int32)`

SetLowLnn sets LowLnn field to given value.


### GetPreferredNetwork

`func (o *V14InternalNetworksPreferredNetwork) GetPreferredNetwork() string`

GetPreferredNetwork returns the PreferredNetwork field if non-nil, zero value otherwise.

### GetPreferredNetworkOk

`func (o *V14InternalNetworksPreferredNetwork) GetPreferredNetworkOk() (*string, bool)`

GetPreferredNetworkOk returns a tuple with the PreferredNetwork field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPreferredNetwork

`func (o *V14InternalNetworksPreferredNetwork) SetPreferredNetwork(v string)`

SetPreferredNetwork sets PreferredNetwork field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


