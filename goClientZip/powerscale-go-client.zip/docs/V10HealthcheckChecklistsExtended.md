# V10HealthcheckChecklistsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Checklists** | Pointer to [**[]V10HealthcheckChecklist**](V10HealthcheckChecklist.md) |  | [optional] 

## Methods

### NewV10HealthcheckChecklistsExtended

`func NewV10HealthcheckChecklistsExtended() *V10HealthcheckChecklistsExtended`

NewV10HealthcheckChecklistsExtended instantiates a new V10HealthcheckChecklistsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckChecklistsExtendedWithDefaults

`func NewV10HealthcheckChecklistsExtendedWithDefaults() *V10HealthcheckChecklistsExtended`

NewV10HealthcheckChecklistsExtendedWithDefaults instantiates a new V10HealthcheckChecklistsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChecklists

`func (o *V10HealthcheckChecklistsExtended) GetChecklists() []V10HealthcheckChecklist`

GetChecklists returns the Checklists field if non-nil, zero value otherwise.

### GetChecklistsOk

`func (o *V10HealthcheckChecklistsExtended) GetChecklistsOk() (*[]V10HealthcheckChecklist, bool)`

GetChecklistsOk returns a tuple with the Checklists field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChecklists

`func (o *V10HealthcheckChecklistsExtended) SetChecklists(v []V10HealthcheckChecklist)`

SetChecklists sets Checklists field to given value.

### HasChecklists

`func (o *V10HealthcheckChecklistsExtended) HasChecklists() bool`

HasChecklists returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


