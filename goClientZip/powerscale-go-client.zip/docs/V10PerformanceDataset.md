# V10PerformanceDataset

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filters** | Pointer to **[]string** | Filtered metrics for configuring this dataset. | [optional] 
**Metrics** | **[]string** | Performance metrics defining the dataset. | 
**Name** | Pointer to **string** | The name of the performance dataset. If a name is not specified then a default name is assigned. The default name will be an underscore separated list of the performance metrics and filters used to configure the dataset. | [optional] 

## Methods

### NewV10PerformanceDataset

`func NewV10PerformanceDataset(metrics []string, ) *V10PerformanceDataset`

NewV10PerformanceDataset instantiates a new V10PerformanceDataset object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10PerformanceDatasetWithDefaults

`func NewV10PerformanceDatasetWithDefaults() *V10PerformanceDataset`

NewV10PerformanceDatasetWithDefaults instantiates a new V10PerformanceDataset object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFilters

`func (o *V10PerformanceDataset) GetFilters() []string`

GetFilters returns the Filters field if non-nil, zero value otherwise.

### GetFiltersOk

`func (o *V10PerformanceDataset) GetFiltersOk() (*[]string, bool)`

GetFiltersOk returns a tuple with the Filters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilters

`func (o *V10PerformanceDataset) SetFilters(v []string)`

SetFilters sets Filters field to given value.

### HasFilters

`func (o *V10PerformanceDataset) HasFilters() bool`

HasFilters returns a boolean if a field has been set.

### GetMetrics

`func (o *V10PerformanceDataset) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *V10PerformanceDataset) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *V10PerformanceDataset) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.


### GetName

`func (o *V10PerformanceDataset) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10PerformanceDataset) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10PerformanceDataset) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V10PerformanceDataset) HasName() bool`

HasName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


