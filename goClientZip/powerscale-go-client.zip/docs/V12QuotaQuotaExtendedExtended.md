# V12QuotaQuotaExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Container** | Pointer to **bool** | If true, SMB shares using the quota directory see the quota thresholds as share size. | [optional] 
**Enforced** | Pointer to **bool** | True if the quota provides enforcement, otherwise an accounting quota. | [optional] 
**Force** | Pointer to **bool** | Force creation of quotas on the root of /ifs or percent based quotas. | [optional] 
**IgnoreLimitChecks** | Pointer to **bool** | If true, skip child quota&#39;s threshold comparison with parent quota path. | [optional] 
**Linked** | Pointer to **bool** | If false and the quota is linked, attempt to unlink. | [optional] 
**Thresholds** | Pointer to [**V12QuotaQuotaThresholds**](V12QuotaQuotaThresholds.md) |  | [optional] 
**ThresholdsIncludeOverhead** | Pointer to **bool** | This option is deprecated. Use the option &#39;thresholds_on&#39; to select the usage on which thresholds to apply. | [optional] 
**ThresholdsOn** | Pointer to **string** | Thresholds apply on quota accounting metric. | [optional] [default to "fslogicalsize"]

## Methods

### NewV12QuotaQuotaExtendedExtended

`func NewV12QuotaQuotaExtendedExtended() *V12QuotaQuotaExtendedExtended`

NewV12QuotaQuotaExtendedExtended instantiates a new V12QuotaQuotaExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12QuotaQuotaExtendedExtendedWithDefaults

`func NewV12QuotaQuotaExtendedExtendedWithDefaults() *V12QuotaQuotaExtendedExtended`

NewV12QuotaQuotaExtendedExtendedWithDefaults instantiates a new V12QuotaQuotaExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetContainer

`func (o *V12QuotaQuotaExtendedExtended) GetContainer() bool`

GetContainer returns the Container field if non-nil, zero value otherwise.

### GetContainerOk

`func (o *V12QuotaQuotaExtendedExtended) GetContainerOk() (*bool, bool)`

GetContainerOk returns a tuple with the Container field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetContainer

`func (o *V12QuotaQuotaExtendedExtended) SetContainer(v bool)`

SetContainer sets Container field to given value.

### HasContainer

`func (o *V12QuotaQuotaExtendedExtended) HasContainer() bool`

HasContainer returns a boolean if a field has been set.

### GetEnforced

`func (o *V12QuotaQuotaExtendedExtended) GetEnforced() bool`

GetEnforced returns the Enforced field if non-nil, zero value otherwise.

### GetEnforcedOk

`func (o *V12QuotaQuotaExtendedExtended) GetEnforcedOk() (*bool, bool)`

GetEnforcedOk returns a tuple with the Enforced field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnforced

`func (o *V12QuotaQuotaExtendedExtended) SetEnforced(v bool)`

SetEnforced sets Enforced field to given value.

### HasEnforced

`func (o *V12QuotaQuotaExtendedExtended) HasEnforced() bool`

HasEnforced returns a boolean if a field has been set.

### GetForce

`func (o *V12QuotaQuotaExtendedExtended) GetForce() bool`

GetForce returns the Force field if non-nil, zero value otherwise.

### GetForceOk

`func (o *V12QuotaQuotaExtendedExtended) GetForceOk() (*bool, bool)`

GetForceOk returns a tuple with the Force field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForce

`func (o *V12QuotaQuotaExtendedExtended) SetForce(v bool)`

SetForce sets Force field to given value.

### HasForce

`func (o *V12QuotaQuotaExtendedExtended) HasForce() bool`

HasForce returns a boolean if a field has been set.

### GetIgnoreLimitChecks

`func (o *V12QuotaQuotaExtendedExtended) GetIgnoreLimitChecks() bool`

GetIgnoreLimitChecks returns the IgnoreLimitChecks field if non-nil, zero value otherwise.

### GetIgnoreLimitChecksOk

`func (o *V12QuotaQuotaExtendedExtended) GetIgnoreLimitChecksOk() (*bool, bool)`

GetIgnoreLimitChecksOk returns a tuple with the IgnoreLimitChecks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoreLimitChecks

`func (o *V12QuotaQuotaExtendedExtended) SetIgnoreLimitChecks(v bool)`

SetIgnoreLimitChecks sets IgnoreLimitChecks field to given value.

### HasIgnoreLimitChecks

`func (o *V12QuotaQuotaExtendedExtended) HasIgnoreLimitChecks() bool`

HasIgnoreLimitChecks returns a boolean if a field has been set.

### GetLinked

`func (o *V12QuotaQuotaExtendedExtended) GetLinked() bool`

GetLinked returns the Linked field if non-nil, zero value otherwise.

### GetLinkedOk

`func (o *V12QuotaQuotaExtendedExtended) GetLinkedOk() (*bool, bool)`

GetLinkedOk returns a tuple with the Linked field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLinked

`func (o *V12QuotaQuotaExtendedExtended) SetLinked(v bool)`

SetLinked sets Linked field to given value.

### HasLinked

`func (o *V12QuotaQuotaExtendedExtended) HasLinked() bool`

HasLinked returns a boolean if a field has been set.

### GetThresholds

`func (o *V12QuotaQuotaExtendedExtended) GetThresholds() V12QuotaQuotaThresholds`

GetThresholds returns the Thresholds field if non-nil, zero value otherwise.

### GetThresholdsOk

`func (o *V12QuotaQuotaExtendedExtended) GetThresholdsOk() (*V12QuotaQuotaThresholds, bool)`

GetThresholdsOk returns a tuple with the Thresholds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholds

`func (o *V12QuotaQuotaExtendedExtended) SetThresholds(v V12QuotaQuotaThresholds)`

SetThresholds sets Thresholds field to given value.

### HasThresholds

`func (o *V12QuotaQuotaExtendedExtended) HasThresholds() bool`

HasThresholds returns a boolean if a field has been set.

### GetThresholdsIncludeOverhead

`func (o *V12QuotaQuotaExtendedExtended) GetThresholdsIncludeOverhead() bool`

GetThresholdsIncludeOverhead returns the ThresholdsIncludeOverhead field if non-nil, zero value otherwise.

### GetThresholdsIncludeOverheadOk

`func (o *V12QuotaQuotaExtendedExtended) GetThresholdsIncludeOverheadOk() (*bool, bool)`

GetThresholdsIncludeOverheadOk returns a tuple with the ThresholdsIncludeOverhead field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholdsIncludeOverhead

`func (o *V12QuotaQuotaExtendedExtended) SetThresholdsIncludeOverhead(v bool)`

SetThresholdsIncludeOverhead sets ThresholdsIncludeOverhead field to given value.

### HasThresholdsIncludeOverhead

`func (o *V12QuotaQuotaExtendedExtended) HasThresholdsIncludeOverhead() bool`

HasThresholdsIncludeOverhead returns a boolean if a field has been set.

### GetThresholdsOn

`func (o *V12QuotaQuotaExtendedExtended) GetThresholdsOn() string`

GetThresholdsOn returns the ThresholdsOn field if non-nil, zero value otherwise.

### GetThresholdsOnOk

`func (o *V12QuotaQuotaExtendedExtended) GetThresholdsOnOk() (*string, bool)`

GetThresholdsOnOk returns a tuple with the ThresholdsOn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholdsOn

`func (o *V12QuotaQuotaExtendedExtended) SetThresholdsOn(v string)`

SetThresholdsOn sets ThresholdsOn field to given value.

### HasThresholdsOn

`func (o *V12QuotaQuotaExtendedExtended) HasThresholdsOn() bool`

HasThresholdsOn returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


