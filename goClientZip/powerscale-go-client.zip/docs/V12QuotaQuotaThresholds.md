# V12QuotaQuotaThresholds

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Advisory** | Pointer to **int32** | Usage bytes at which notifications will be sent but writes will not be denied. | [optional] 
**Hard** | Pointer to **int32** | Usage bytes at which further writes will be denied. | [optional] 
**PercentAdvisory** | Pointer to **float32** | Advisory threshold as percent of hard threshold. | [optional] 
**PercentSoft** | Pointer to **float32** | Soft threshold as percent of hard threshold. | [optional] 
**Soft** | Pointer to **int32** | Usage bytes at which notifications will be sent and soft grace time will be started. | [optional] 
**SoftGrace** | Pointer to **int32** | Time in seconds after which the soft threshold has been hit before writes will be denied. | [optional] 

## Methods

### NewV12QuotaQuotaThresholds

`func NewV12QuotaQuotaThresholds() *V12QuotaQuotaThresholds`

NewV12QuotaQuotaThresholds instantiates a new V12QuotaQuotaThresholds object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12QuotaQuotaThresholdsWithDefaults

`func NewV12QuotaQuotaThresholdsWithDefaults() *V12QuotaQuotaThresholds`

NewV12QuotaQuotaThresholdsWithDefaults instantiates a new V12QuotaQuotaThresholds object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAdvisory

`func (o *V12QuotaQuotaThresholds) GetAdvisory() int32`

GetAdvisory returns the Advisory field if non-nil, zero value otherwise.

### GetAdvisoryOk

`func (o *V12QuotaQuotaThresholds) GetAdvisoryOk() (*int32, bool)`

GetAdvisoryOk returns a tuple with the Advisory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAdvisory

`func (o *V12QuotaQuotaThresholds) SetAdvisory(v int32)`

SetAdvisory sets Advisory field to given value.

### HasAdvisory

`func (o *V12QuotaQuotaThresholds) HasAdvisory() bool`

HasAdvisory returns a boolean if a field has been set.

### GetHard

`func (o *V12QuotaQuotaThresholds) GetHard() int32`

GetHard returns the Hard field if non-nil, zero value otherwise.

### GetHardOk

`func (o *V12QuotaQuotaThresholds) GetHardOk() (*int32, bool)`

GetHardOk returns a tuple with the Hard field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHard

`func (o *V12QuotaQuotaThresholds) SetHard(v int32)`

SetHard sets Hard field to given value.

### HasHard

`func (o *V12QuotaQuotaThresholds) HasHard() bool`

HasHard returns a boolean if a field has been set.

### GetPercentAdvisory

`func (o *V12QuotaQuotaThresholds) GetPercentAdvisory() float32`

GetPercentAdvisory returns the PercentAdvisory field if non-nil, zero value otherwise.

### GetPercentAdvisoryOk

`func (o *V12QuotaQuotaThresholds) GetPercentAdvisoryOk() (*float32, bool)`

GetPercentAdvisoryOk returns a tuple with the PercentAdvisory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentAdvisory

`func (o *V12QuotaQuotaThresholds) SetPercentAdvisory(v float32)`

SetPercentAdvisory sets PercentAdvisory field to given value.

### HasPercentAdvisory

`func (o *V12QuotaQuotaThresholds) HasPercentAdvisory() bool`

HasPercentAdvisory returns a boolean if a field has been set.

### GetPercentSoft

`func (o *V12QuotaQuotaThresholds) GetPercentSoft() float32`

GetPercentSoft returns the PercentSoft field if non-nil, zero value otherwise.

### GetPercentSoftOk

`func (o *V12QuotaQuotaThresholds) GetPercentSoftOk() (*float32, bool)`

GetPercentSoftOk returns a tuple with the PercentSoft field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentSoft

`func (o *V12QuotaQuotaThresholds) SetPercentSoft(v float32)`

SetPercentSoft sets PercentSoft field to given value.

### HasPercentSoft

`func (o *V12QuotaQuotaThresholds) HasPercentSoft() bool`

HasPercentSoft returns a boolean if a field has been set.

### GetSoft

`func (o *V12QuotaQuotaThresholds) GetSoft() int32`

GetSoft returns the Soft field if non-nil, zero value otherwise.

### GetSoftOk

`func (o *V12QuotaQuotaThresholds) GetSoftOk() (*int32, bool)`

GetSoftOk returns a tuple with the Soft field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSoft

`func (o *V12QuotaQuotaThresholds) SetSoft(v int32)`

SetSoft sets Soft field to given value.

### HasSoft

`func (o *V12QuotaQuotaThresholds) HasSoft() bool`

HasSoft returns a boolean if a field has been set.

### GetSoftGrace

`func (o *V12QuotaQuotaThresholds) GetSoftGrace() int32`

GetSoftGrace returns the SoftGrace field if non-nil, zero value otherwise.

### GetSoftGraceOk

`func (o *V12QuotaQuotaThresholds) GetSoftGraceOk() (*int32, bool)`

GetSoftGraceOk returns a tuple with the SoftGrace field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSoftGrace

`func (o *V12QuotaQuotaThresholds) SetSoftGrace(v int32)`

SetSoftGrace sets SoftGrace field to given value.

### HasSoftGrace

`func (o *V12QuotaQuotaThresholds) HasSoftGrace() bool`

HasSoftGrace returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


