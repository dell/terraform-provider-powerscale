# V12ClusterNodeError

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FailedUpgradeAction** | Pointer to **string** | Last upgrade step which failed on node. | [optional] 
**Log** | Pointer to **string** | Upgrade error log. | [optional] 

## Methods

### NewV12ClusterNodeError

`func NewV12ClusterNodeError() *V12ClusterNodeError`

NewV12ClusterNodeError instantiates a new V12ClusterNodeError object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterNodeErrorWithDefaults

`func NewV12ClusterNodeErrorWithDefaults() *V12ClusterNodeError`

NewV12ClusterNodeErrorWithDefaults instantiates a new V12ClusterNodeError object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFailedUpgradeAction

`func (o *V12ClusterNodeError) GetFailedUpgradeAction() string`

GetFailedUpgradeAction returns the FailedUpgradeAction field if non-nil, zero value otherwise.

### GetFailedUpgradeActionOk

`func (o *V12ClusterNodeError) GetFailedUpgradeActionOk() (*string, bool)`

GetFailedUpgradeActionOk returns a tuple with the FailedUpgradeAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFailedUpgradeAction

`func (o *V12ClusterNodeError) SetFailedUpgradeAction(v string)`

SetFailedUpgradeAction sets FailedUpgradeAction field to given value.

### HasFailedUpgradeAction

`func (o *V12ClusterNodeError) HasFailedUpgradeAction() bool`

HasFailedUpgradeAction returns a boolean if a field has been set.

### GetLog

`func (o *V12ClusterNodeError) GetLog() string`

GetLog returns the Log field if non-nil, zero value otherwise.

### GetLogOk

`func (o *V12ClusterNodeError) GetLogOk() (*string, bool)`

GetLogOk returns a tuple with the Log field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLog

`func (o *V12ClusterNodeError) SetLog(v string)`

SetLog sets Log field to given value.

### HasLog

`func (o *V12ClusterNodeError) HasLog() bool`

HasLog returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


