# V12KmipServersExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Servers** | Pointer to [**[]V12KmipServerExtendedExtendedExtended**](V12KmipServerExtendedExtendedExtended.md) |  | [optional] 

## Methods

### NewV12KmipServersExtended

`func NewV12KmipServersExtended() *V12KmipServersExtended`

NewV12KmipServersExtended instantiates a new V12KmipServersExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12KmipServersExtendedWithDefaults

`func NewV12KmipServersExtendedWithDefaults() *V12KmipServersExtended`

NewV12KmipServersExtendedWithDefaults instantiates a new V12KmipServersExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetServers

`func (o *V12KmipServersExtended) GetServers() []V12KmipServerExtendedExtendedExtended`

GetServers returns the Servers field if non-nil, zero value otherwise.

### GetServersOk

`func (o *V12KmipServersExtended) GetServersOk() (*[]V12KmipServerExtendedExtendedExtended, bool)`

GetServersOk returns a tuple with the Servers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServers

`func (o *V12KmipServersExtended) SetServers(v []V12KmipServerExtendedExtendedExtended)`

SetServers sets Servers field to given value.

### HasServers

`func (o *V12KmipServersExtended) HasServers() bool`

HasServers returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


