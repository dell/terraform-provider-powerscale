# V12SubnetsSubnetPools

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Pools** | Pointer to [**[]V12SubnetsSubnetPoolsPool**](V12SubnetsSubnetPoolsPool.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV12SubnetsSubnetPools

`func NewV12SubnetsSubnetPools() *V12SubnetsSubnetPools`

NewV12SubnetsSubnetPools instantiates a new V12SubnetsSubnetPools object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SubnetsSubnetPoolsWithDefaults

`func NewV12SubnetsSubnetPoolsWithDefaults() *V12SubnetsSubnetPools`

NewV12SubnetsSubnetPoolsWithDefaults instantiates a new V12SubnetsSubnetPools object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPools

`func (o *V12SubnetsSubnetPools) GetPools() []V12SubnetsSubnetPoolsPool`

GetPools returns the Pools field if non-nil, zero value otherwise.

### GetPoolsOk

`func (o *V12SubnetsSubnetPools) GetPoolsOk() (*[]V12SubnetsSubnetPoolsPool, bool)`

GetPoolsOk returns a tuple with the Pools field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPools

`func (o *V12SubnetsSubnetPools) SetPools(v []V12SubnetsSubnetPoolsPool)`

SetPools sets Pools field to given value.

### HasPools

`func (o *V12SubnetsSubnetPools) HasPools() bool`

HasPools returns a boolean if a field has been set.

### GetResume

`func (o *V12SubnetsSubnetPools) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12SubnetsSubnetPools) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12SubnetsSubnetPools) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12SubnetsSubnetPools) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V12SubnetsSubnetPools) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12SubnetsSubnetPools) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12SubnetsSubnetPools) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12SubnetsSubnetPools) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


