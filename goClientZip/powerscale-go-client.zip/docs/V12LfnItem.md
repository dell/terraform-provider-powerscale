# V12LfnItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaxBytes** | Pointer to **int32** | Specifies the maximum number of bytes the UTF-8 encoded filename can have. This may be more than the character limit as a single character could require up to 4 bytes to be encoded. | [optional] 
**MaxChars** | Pointer to **int32** | Specifies the maximum number of characters a filename can have. Each character will require between 1 and 4 bytes to encode. | [optional] 
**Path** | **string** | Specifies the root path that the file name length properties apply to. Files in this directory and all sub-directories will inherit these settings unless overriden. | 
**Policy** | Pointer to **string** | Specifies the name length policy for bytes and chars. | [optional] 

## Methods

### NewV12LfnItem

`func NewV12LfnItem(path string, ) *V12LfnItem`

NewV12LfnItem instantiates a new V12LfnItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12LfnItemWithDefaults

`func NewV12LfnItemWithDefaults() *V12LfnItem`

NewV12LfnItemWithDefaults instantiates a new V12LfnItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMaxBytes

`func (o *V12LfnItem) GetMaxBytes() int32`

GetMaxBytes returns the MaxBytes field if non-nil, zero value otherwise.

### GetMaxBytesOk

`func (o *V12LfnItem) GetMaxBytesOk() (*int32, bool)`

GetMaxBytesOk returns a tuple with the MaxBytes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxBytes

`func (o *V12LfnItem) SetMaxBytes(v int32)`

SetMaxBytes sets MaxBytes field to given value.

### HasMaxBytes

`func (o *V12LfnItem) HasMaxBytes() bool`

HasMaxBytes returns a boolean if a field has been set.

### GetMaxChars

`func (o *V12LfnItem) GetMaxChars() int32`

GetMaxChars returns the MaxChars field if non-nil, zero value otherwise.

### GetMaxCharsOk

`func (o *V12LfnItem) GetMaxCharsOk() (*int32, bool)`

GetMaxCharsOk returns a tuple with the MaxChars field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxChars

`func (o *V12LfnItem) SetMaxChars(v int32)`

SetMaxChars sets MaxChars field to given value.

### HasMaxChars

`func (o *V12LfnItem) HasMaxChars() bool`

HasMaxChars returns a boolean if a field has been set.

### GetPath

`func (o *V12LfnItem) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V12LfnItem) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V12LfnItem) SetPath(v string)`

SetPath sets Path field to given value.


### GetPolicy

`func (o *V12LfnItem) GetPolicy() string`

GetPolicy returns the Policy field if non-nil, zero value otherwise.

### GetPolicyOk

`func (o *V12LfnItem) GetPolicyOk() (*string, bool)`

GetPolicyOk returns a tuple with the Policy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicy

`func (o *V12LfnItem) SetPolicy(v string)`

SetPolicy sets Policy field to given value.

### HasPolicy

`func (o *V12LfnItem) HasPolicy() bool`

HasPolicy returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


