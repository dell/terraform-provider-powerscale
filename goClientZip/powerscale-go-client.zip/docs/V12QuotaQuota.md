# V12QuotaQuota

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Container** | Pointer to **bool** | If true, SMB shares using the quota directory see the quota thresholds as share size. | [optional] 
**Enforced** | Pointer to **bool** | True if the quota provides enforcement, otherwise an accounting quota. | [optional] 
**Force** | Pointer to **bool** | Force creation of quotas on the root of /ifs or percent based quotas. | [optional] 
**IgnoreLimitChecks** | Pointer to **bool** | If true, skip child quota&#39;s threshold comparison with parent quota path. | [optional] 
**IncludeSnapshots** | **bool** | If true, quota governs snapshot data as well as head data. | 
**Path** | **string** | The /ifs path governed. | 
**Persona** | Pointer to [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | [optional] 
**Thresholds** | Pointer to [**V12QuotaQuotaThresholds**](V12QuotaQuotaThresholds.md) |  | [optional] 
**ThresholdsIncludeOverhead** | Pointer to **bool** | This option is deprecated. Use the option &#39;thresholds_on&#39; to select the usage on which thresholds to apply. | [optional] 
**ThresholdsOn** | Pointer to **string** | Thresholds apply on quota accounting metric. | [optional] [default to "fslogicalsize"]
**Type** | **string** | The type of quota. | 

## Methods

### NewV12QuotaQuota

`func NewV12QuotaQuota(includeSnapshots bool, path string, type_ string, ) *V12QuotaQuota`

NewV12QuotaQuota instantiates a new V12QuotaQuota object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12QuotaQuotaWithDefaults

`func NewV12QuotaQuotaWithDefaults() *V12QuotaQuota`

NewV12QuotaQuotaWithDefaults instantiates a new V12QuotaQuota object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetContainer

`func (o *V12QuotaQuota) GetContainer() bool`

GetContainer returns the Container field if non-nil, zero value otherwise.

### GetContainerOk

`func (o *V12QuotaQuota) GetContainerOk() (*bool, bool)`

GetContainerOk returns a tuple with the Container field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetContainer

`func (o *V12QuotaQuota) SetContainer(v bool)`

SetContainer sets Container field to given value.

### HasContainer

`func (o *V12QuotaQuota) HasContainer() bool`

HasContainer returns a boolean if a field has been set.

### GetEnforced

`func (o *V12QuotaQuota) GetEnforced() bool`

GetEnforced returns the Enforced field if non-nil, zero value otherwise.

### GetEnforcedOk

`func (o *V12QuotaQuota) GetEnforcedOk() (*bool, bool)`

GetEnforcedOk returns a tuple with the Enforced field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnforced

`func (o *V12QuotaQuota) SetEnforced(v bool)`

SetEnforced sets Enforced field to given value.

### HasEnforced

`func (o *V12QuotaQuota) HasEnforced() bool`

HasEnforced returns a boolean if a field has been set.

### GetForce

`func (o *V12QuotaQuota) GetForce() bool`

GetForce returns the Force field if non-nil, zero value otherwise.

### GetForceOk

`func (o *V12QuotaQuota) GetForceOk() (*bool, bool)`

GetForceOk returns a tuple with the Force field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForce

`func (o *V12QuotaQuota) SetForce(v bool)`

SetForce sets Force field to given value.

### HasForce

`func (o *V12QuotaQuota) HasForce() bool`

HasForce returns a boolean if a field has been set.

### GetIgnoreLimitChecks

`func (o *V12QuotaQuota) GetIgnoreLimitChecks() bool`

GetIgnoreLimitChecks returns the IgnoreLimitChecks field if non-nil, zero value otherwise.

### GetIgnoreLimitChecksOk

`func (o *V12QuotaQuota) GetIgnoreLimitChecksOk() (*bool, bool)`

GetIgnoreLimitChecksOk returns a tuple with the IgnoreLimitChecks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoreLimitChecks

`func (o *V12QuotaQuota) SetIgnoreLimitChecks(v bool)`

SetIgnoreLimitChecks sets IgnoreLimitChecks field to given value.

### HasIgnoreLimitChecks

`func (o *V12QuotaQuota) HasIgnoreLimitChecks() bool`

HasIgnoreLimitChecks returns a boolean if a field has been set.

### GetIncludeSnapshots

`func (o *V12QuotaQuota) GetIncludeSnapshots() bool`

GetIncludeSnapshots returns the IncludeSnapshots field if non-nil, zero value otherwise.

### GetIncludeSnapshotsOk

`func (o *V12QuotaQuota) GetIncludeSnapshotsOk() (*bool, bool)`

GetIncludeSnapshotsOk returns a tuple with the IncludeSnapshots field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeSnapshots

`func (o *V12QuotaQuota) SetIncludeSnapshots(v bool)`

SetIncludeSnapshots sets IncludeSnapshots field to given value.


### GetPath

`func (o *V12QuotaQuota) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V12QuotaQuota) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V12QuotaQuota) SetPath(v string)`

SetPath sets Path field to given value.


### GetPersona

`func (o *V12QuotaQuota) GetPersona() V1AuthAccessAccessItemFileGroup`

GetPersona returns the Persona field if non-nil, zero value otherwise.

### GetPersonaOk

`func (o *V12QuotaQuota) GetPersonaOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetPersonaOk returns a tuple with the Persona field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPersona

`func (o *V12QuotaQuota) SetPersona(v V1AuthAccessAccessItemFileGroup)`

SetPersona sets Persona field to given value.

### HasPersona

`func (o *V12QuotaQuota) HasPersona() bool`

HasPersona returns a boolean if a field has been set.

### GetThresholds

`func (o *V12QuotaQuota) GetThresholds() V12QuotaQuotaThresholds`

GetThresholds returns the Thresholds field if non-nil, zero value otherwise.

### GetThresholdsOk

`func (o *V12QuotaQuota) GetThresholdsOk() (*V12QuotaQuotaThresholds, bool)`

GetThresholdsOk returns a tuple with the Thresholds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholds

`func (o *V12QuotaQuota) SetThresholds(v V12QuotaQuotaThresholds)`

SetThresholds sets Thresholds field to given value.

### HasThresholds

`func (o *V12QuotaQuota) HasThresholds() bool`

HasThresholds returns a boolean if a field has been set.

### GetThresholdsIncludeOverhead

`func (o *V12QuotaQuota) GetThresholdsIncludeOverhead() bool`

GetThresholdsIncludeOverhead returns the ThresholdsIncludeOverhead field if non-nil, zero value otherwise.

### GetThresholdsIncludeOverheadOk

`func (o *V12QuotaQuota) GetThresholdsIncludeOverheadOk() (*bool, bool)`

GetThresholdsIncludeOverheadOk returns a tuple with the ThresholdsIncludeOverhead field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholdsIncludeOverhead

`func (o *V12QuotaQuota) SetThresholdsIncludeOverhead(v bool)`

SetThresholdsIncludeOverhead sets ThresholdsIncludeOverhead field to given value.

### HasThresholdsIncludeOverhead

`func (o *V12QuotaQuota) HasThresholdsIncludeOverhead() bool`

HasThresholdsIncludeOverhead returns a boolean if a field has been set.

### GetThresholdsOn

`func (o *V12QuotaQuota) GetThresholdsOn() string`

GetThresholdsOn returns the ThresholdsOn field if non-nil, zero value otherwise.

### GetThresholdsOnOk

`func (o *V12QuotaQuota) GetThresholdsOnOk() (*string, bool)`

GetThresholdsOnOk returns a tuple with the ThresholdsOn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholdsOn

`func (o *V12QuotaQuota) SetThresholdsOn(v string)`

SetThresholdsOn sets ThresholdsOn field to given value.

### HasThresholdsOn

`func (o *V12QuotaQuota) HasThresholdsOn() bool`

HasThresholdsOn returns a boolean if a field has been set.

### GetType

`func (o *V12QuotaQuota) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V12QuotaQuota) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V12QuotaQuota) SetType(v string)`

SetType sets Type field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


