# V11NfsExports

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Exports** | Pointer to [**[]V11NfsExportExtended**](V11NfsExportExtended.md) |  | [optional] 

## Methods

### NewV11NfsExports

`func NewV11NfsExports() *V11NfsExports`

NewV11NfsExports instantiates a new V11NfsExports object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11NfsExportsWithDefaults

`func NewV11NfsExportsWithDefaults() *V11NfsExports`

NewV11NfsExportsWithDefaults instantiates a new V11NfsExports object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExports

`func (o *V11NfsExports) GetExports() []V11NfsExportExtended`

GetExports returns the Exports field if non-nil, zero value otherwise.

### GetExportsOk

`func (o *V11NfsExports) GetExportsOk() (*[]V11NfsExportExtended, bool)`

GetExportsOk returns a tuple with the Exports field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExports

`func (o *V11NfsExports) SetExports(v []V11NfsExportExtended)`

SetExports sets Exports field to given value.

### HasExports

`func (o *V11NfsExports) HasExports() bool`

HasExports returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


