# V10S3SettingsGlobalSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HttpPort** | Pointer to **int32** | The port on which to listen for HTTP S3 requests. | [optional] 
**HttpsOnly** | Pointer to **bool** | Indicates whether S3 service will accept only HTTPS request, or both HTTPS and HTTP. | [optional] 
**HttpsPort** | Pointer to **int32** | The port on which to listen for HTTPS S3 requests. | [optional] 
**Service** | Pointer to **bool** | True if the S3 service is enabled.  When set to false, the S3 service is disabled. | [optional] 

## Methods

### NewV10S3SettingsGlobalSettings

`func NewV10S3SettingsGlobalSettings() *V10S3SettingsGlobalSettings`

NewV10S3SettingsGlobalSettings instantiates a new V10S3SettingsGlobalSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10S3SettingsGlobalSettingsWithDefaults

`func NewV10S3SettingsGlobalSettingsWithDefaults() *V10S3SettingsGlobalSettings`

NewV10S3SettingsGlobalSettingsWithDefaults instantiates a new V10S3SettingsGlobalSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHttpPort

`func (o *V10S3SettingsGlobalSettings) GetHttpPort() int32`

GetHttpPort returns the HttpPort field if non-nil, zero value otherwise.

### GetHttpPortOk

`func (o *V10S3SettingsGlobalSettings) GetHttpPortOk() (*int32, bool)`

GetHttpPortOk returns a tuple with the HttpPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHttpPort

`func (o *V10S3SettingsGlobalSettings) SetHttpPort(v int32)`

SetHttpPort sets HttpPort field to given value.

### HasHttpPort

`func (o *V10S3SettingsGlobalSettings) HasHttpPort() bool`

HasHttpPort returns a boolean if a field has been set.

### GetHttpsOnly

`func (o *V10S3SettingsGlobalSettings) GetHttpsOnly() bool`

GetHttpsOnly returns the HttpsOnly field if non-nil, zero value otherwise.

### GetHttpsOnlyOk

`func (o *V10S3SettingsGlobalSettings) GetHttpsOnlyOk() (*bool, bool)`

GetHttpsOnlyOk returns a tuple with the HttpsOnly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHttpsOnly

`func (o *V10S3SettingsGlobalSettings) SetHttpsOnly(v bool)`

SetHttpsOnly sets HttpsOnly field to given value.

### HasHttpsOnly

`func (o *V10S3SettingsGlobalSettings) HasHttpsOnly() bool`

HasHttpsOnly returns a boolean if a field has been set.

### GetHttpsPort

`func (o *V10S3SettingsGlobalSettings) GetHttpsPort() int32`

GetHttpsPort returns the HttpsPort field if non-nil, zero value otherwise.

### GetHttpsPortOk

`func (o *V10S3SettingsGlobalSettings) GetHttpsPortOk() (*int32, bool)`

GetHttpsPortOk returns a tuple with the HttpsPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHttpsPort

`func (o *V10S3SettingsGlobalSettings) SetHttpsPort(v int32)`

SetHttpsPort sets HttpsPort field to given value.

### HasHttpsPort

`func (o *V10S3SettingsGlobalSettings) HasHttpsPort() bool`

HasHttpsPort returns a boolean if a field has been set.

### GetService

`func (o *V10S3SettingsGlobalSettings) GetService() bool`

GetService returns the Service field if non-nil, zero value otherwise.

### GetServiceOk

`func (o *V10S3SettingsGlobalSettings) GetServiceOk() (*bool, bool)`

GetServiceOk returns a tuple with the Service field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetService

`func (o *V10S3SettingsGlobalSettings) SetService(v bool)`

SetService sets Service field to given value.

### HasService

`func (o *V10S3SettingsGlobalSettings) HasService() bool`

HasService returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


