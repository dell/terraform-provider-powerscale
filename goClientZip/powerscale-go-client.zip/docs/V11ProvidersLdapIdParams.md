# V11ProvidersLdapIdParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlternateSecurityIdentitiesAttribute** | Pointer to **string** | Specifies the attribute name used when searching for alternate security identities. | [optional] 
**Authentication** | Pointer to **bool** | If true, enables authentication and identity management through the authentication provider. | [optional] 
**BalanceServers** | Pointer to **bool** | If true, connects the provider to a random server. | [optional] 
**BaseDn** | Pointer to **string** | Specifies the root of the tree in which to search identities. | [optional] 
**BindDn** | Pointer to **string** | Specifies the distinguished name for binding to the LDAP server. | [optional] 
**BindMechanism** | Pointer to **string** | Specifies which bind mechanism to use when connecting to an LDAP server. The only supported option is the &#39;simple&#39; value. | [optional] 
**BindPassword** | Pointer to **string** | Specifies the password for the distinguished name for binding to the LDAP server. | [optional] 
**BindTimeout** | Pointer to **int64** | Specifies the timeout in seconds when binding to an LDAP server. | [optional] 
**CertificateAuthorityFile** | Pointer to **string** | Specifies the path to the root certificates file. | [optional] 
**CheckOnlineInterval** | Pointer to **int64** | Specifies the time in seconds between provider online checks. | [optional] 
**CnAttribute** | Pointer to **string** | Specifies the canonical name. | [optional] 
**CreateHomeDirectory** | Pointer to **bool** | Automatically create the home directory on the first login. | [optional] 
**CryptPasswordAttribute** | Pointer to **string** | Specifies the hashed password value. | [optional] 
**EmailAttribute** | Pointer to **string** | Specifies the LDAP Email attribute. | [optional] 
**Enabled** | Pointer to **bool** | If true, enables the LDAP provider. | [optional] 
**EnumerateGroups** | Pointer to **bool** | If true, allows the provider to enumerate groups. | [optional] 
**EnumerateUsers** | Pointer to **bool** | If true, allows the provider to enumerate users. | [optional] 
**FindableGroups** | Pointer to **[]string** | Specifies the list of groups that can be resolved. | [optional] 
**FindableUsers** | Pointer to **[]string** | Specifies the list of users that can be resolved. | [optional] 
**GecosAttribute** | Pointer to **string** | Specifies the LDAP GECOS attribute. | [optional] 
**GidAttribute** | Pointer to **string** | Specifies the LDAP GID attribute. | [optional] 
**GroupBaseDn** | Pointer to **string** | Specifies the distinguished name of the entry where LDAP searches for groups are started. | [optional] 
**GroupDomain** | Pointer to **string** | Specifies the domain for this provider through which groups are qualified. | [optional] 
**GroupFilter** | Pointer to **string** | Specifies the LDAP filter for group objects. | [optional] 
**GroupMembersAttribute** | Pointer to **string** | Specifies the LDAP Group Members attribute. | [optional] 
**GroupSearchScope** | Pointer to **string** | Specifies the depth from the base DN to perform LDAP searches. | [optional] 
**HomeDirectoryTemplate** | Pointer to **string** | Specifies the path to the home directory template. | [optional] 
**HomedirAttribute** | Pointer to **string** | Specifies the LDAP Homedir attribute. | [optional] 
**IgnoreTlsErrors** | Pointer to **bool** | If true, continues over secure connections even if identity checks fail. | [optional] 
**ListableGroups** | Pointer to **[]string** | Specifies the groups that can be viewed in the provider. | [optional] 
**ListableUsers** | Pointer to **[]string** | Specifies the users that can be viewed in the provider. | [optional] 
**LoginShell** | Pointer to **string** | Specifies the login shell path. | [optional] 
**MemberLookupMethod** | Pointer to **string** | Sets the method by which group member lookups are performed. Use caution when changing this option directly. | [optional] 
**MemberOfAttribute** | Pointer to **string** | Specifies the LDAP Query Member Of attribute, which performs reverse membership queries. | [optional] 
**Name** | Pointer to **string** | Specifies the name of the LDAP provider. | [optional] 
**NameAttribute** | Pointer to **string** | Specifies the LDAP UID attribute, which is used as the login name. | [optional] 
**NetgroupBaseDn** | Pointer to **string** | Specifies the distinguished name of the entry where LDAP searches for netgroups are started. | [optional] 
**NetgroupFilter** | Pointer to **string** | Specifies the LDAP filter for netgroup objects. | [optional] 
**NetgroupMembersAttribute** | Pointer to **string** | Specifies the LDAP Netgroup Members attribute. | [optional] 
**NetgroupSearchScope** | Pointer to **string** | Specifies the depth from the base DN to perform LDAP searches. | [optional] 
**NetgroupTripleAttribute** | Pointer to **string** | Specifies the LDAP Netgroup Triple attribute. | [optional] 
**NormalizeGroups** | Pointer to **bool** | Normalizes group names to lowercase before look up. | [optional] 
**NormalizeUsers** | Pointer to **bool** | Normalizes user names to lowercase before look up. | [optional] 
**NtPasswordAttribute** | Pointer to **string** | Specifies the LDAP NT Password attribute. | [optional] 
**NtlmSupport** | Pointer to **string** | Specifies which NTLM versions to support for users with NTLM-compatible credentials. | [optional] 
**ProviderDomain** | Pointer to **string** | Specifies the provider domain. | [optional] 
**RequireSecureConnection** | Pointer to **bool** | Determines whether to continue over a non-TLS connection. | [optional] 
**RestrictFindable** | Pointer to **bool** | If true, checks the provider for filtered lists of findable and unfindable users and groups. | [optional] 
**RestrictListable** | Pointer to **bool** | If true, checks the provider for filtered lists of listable and unlistable users and groups. | [optional] 
**SearchScope** | Pointer to **string** | Specifies the default depth from the base DN to perform LDAP searches. | [optional] 
**SearchTimeout** | Pointer to **int64** | Specifies the search timeout period in seconds. | [optional] 
**ServerUris** | Pointer to **[]string** | Specifies the server URIs. | [optional] 
**ShadowExpireAttribute** | Pointer to **string** | Sets the attribute name that indicates the absolute date to expire the account. | [optional] 
**ShadowFlagAttribute** | Pointer to **string** | Sets the attribute name that indicates the section of the shadow map that is used to store the flag value. | [optional] 
**ShadowInactiveAttribute** | Pointer to **string** | Sets the attribute name that indicates the number of days of inactivity that is allowed for the user. | [optional] 
**ShadowLastChangeAttribute** | Pointer to **string** | Sets the attribute name that indicates the last change of the shadow information. | [optional] 
**ShadowMaxAttribute** | Pointer to **string** | Sets the attribute name that indicates the maximum number of days a password can be valid. | [optional] 
**ShadowMinAttribute** | Pointer to **string** | Sets the attribute name that indicates the minimum number of days between shadow changes. | [optional] 
**ShadowUserFilter** | Pointer to **string** | Sets LDAP filter for shadow user objects. | [optional] 
**ShadowWarningAttribute** | Pointer to **string** | Sets the attribute name that indicates the number of days before the password expires to warn the user. | [optional] 
**ShellAttribute** | Pointer to **string** | Specifies the LDAP Shell attribute. | [optional] 
**SshPublicKeyAttribute** | Pointer to **string** | Sets the attribute name that indicates the SSH Public Key for the user. | [optional] 
**Template** | Pointer to **string** | Specifies template to be used to create the LDAP provider. The list of templates can be found at /auth/ldap-templates.  Any fields directly defined in your request will override the template values. | [optional] 
**TlsProtocolMin** | Pointer to **string** | Specifies the minimum TLS protocol version. | [optional] 
**UidAttribute** | Pointer to **string** | Specifies the LDAP UID Number attribute. | [optional] 
**UnfindableGroups** | Pointer to **[]string** | Specifies the groups that cannot be resolved by the provider. | [optional] 
**UnfindableUsers** | Pointer to **[]string** | Specifies users that cannot be resolved by the provider. | [optional] 
**UniqueGroupMembersAttribute** | Pointer to **string** | Sets the LDAP Unique Group Members attribute. | [optional] 
**UnlistableGroups** | Pointer to **[]string** | Specifies a group that cannot be listed by the provider. | [optional] 
**UnlistableUsers** | Pointer to **[]string** | Specifies a user that cannot be listed by the provider. | [optional] 
**UserBaseDn** | Pointer to **string** | Specifies the distinguished name of the entry at which to start LDAP searches for users. | [optional] 
**UserDomain** | Pointer to **string** | Specifies the domain for this provider through which users are qualified. | [optional] 
**UserFilter** | Pointer to **string** | Specifies the LDAP filter for user objects. | [optional] 
**UserSearchScope** | Pointer to **string** | Specifies the depth from the base DN to perform LDAP searches. | [optional] 

## Methods

### NewV11ProvidersLdapIdParams

`func NewV11ProvidersLdapIdParams() *V11ProvidersLdapIdParams`

NewV11ProvidersLdapIdParams instantiates a new V11ProvidersLdapIdParams object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ProvidersLdapIdParamsWithDefaults

`func NewV11ProvidersLdapIdParamsWithDefaults() *V11ProvidersLdapIdParams`

NewV11ProvidersLdapIdParamsWithDefaults instantiates a new V11ProvidersLdapIdParams object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlternateSecurityIdentitiesAttribute

`func (o *V11ProvidersLdapIdParams) GetAlternateSecurityIdentitiesAttribute() string`

GetAlternateSecurityIdentitiesAttribute returns the AlternateSecurityIdentitiesAttribute field if non-nil, zero value otherwise.

### GetAlternateSecurityIdentitiesAttributeOk

`func (o *V11ProvidersLdapIdParams) GetAlternateSecurityIdentitiesAttributeOk() (*string, bool)`

GetAlternateSecurityIdentitiesAttributeOk returns a tuple with the AlternateSecurityIdentitiesAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlternateSecurityIdentitiesAttribute

`func (o *V11ProvidersLdapIdParams) SetAlternateSecurityIdentitiesAttribute(v string)`

SetAlternateSecurityIdentitiesAttribute sets AlternateSecurityIdentitiesAttribute field to given value.

### HasAlternateSecurityIdentitiesAttribute

`func (o *V11ProvidersLdapIdParams) HasAlternateSecurityIdentitiesAttribute() bool`

HasAlternateSecurityIdentitiesAttribute returns a boolean if a field has been set.

### GetAuthentication

`func (o *V11ProvidersLdapIdParams) GetAuthentication() bool`

GetAuthentication returns the Authentication field if non-nil, zero value otherwise.

### GetAuthenticationOk

`func (o *V11ProvidersLdapIdParams) GetAuthenticationOk() (*bool, bool)`

GetAuthenticationOk returns a tuple with the Authentication field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuthentication

`func (o *V11ProvidersLdapIdParams) SetAuthentication(v bool)`

SetAuthentication sets Authentication field to given value.

### HasAuthentication

`func (o *V11ProvidersLdapIdParams) HasAuthentication() bool`

HasAuthentication returns a boolean if a field has been set.

### GetBalanceServers

`func (o *V11ProvidersLdapIdParams) GetBalanceServers() bool`

GetBalanceServers returns the BalanceServers field if non-nil, zero value otherwise.

### GetBalanceServersOk

`func (o *V11ProvidersLdapIdParams) GetBalanceServersOk() (*bool, bool)`

GetBalanceServersOk returns a tuple with the BalanceServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBalanceServers

`func (o *V11ProvidersLdapIdParams) SetBalanceServers(v bool)`

SetBalanceServers sets BalanceServers field to given value.

### HasBalanceServers

`func (o *V11ProvidersLdapIdParams) HasBalanceServers() bool`

HasBalanceServers returns a boolean if a field has been set.

### GetBaseDn

`func (o *V11ProvidersLdapIdParams) GetBaseDn() string`

GetBaseDn returns the BaseDn field if non-nil, zero value otherwise.

### GetBaseDnOk

`func (o *V11ProvidersLdapIdParams) GetBaseDnOk() (*string, bool)`

GetBaseDnOk returns a tuple with the BaseDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBaseDn

`func (o *V11ProvidersLdapIdParams) SetBaseDn(v string)`

SetBaseDn sets BaseDn field to given value.

### HasBaseDn

`func (o *V11ProvidersLdapIdParams) HasBaseDn() bool`

HasBaseDn returns a boolean if a field has been set.

### GetBindDn

`func (o *V11ProvidersLdapIdParams) GetBindDn() string`

GetBindDn returns the BindDn field if non-nil, zero value otherwise.

### GetBindDnOk

`func (o *V11ProvidersLdapIdParams) GetBindDnOk() (*string, bool)`

GetBindDnOk returns a tuple with the BindDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBindDn

`func (o *V11ProvidersLdapIdParams) SetBindDn(v string)`

SetBindDn sets BindDn field to given value.

### HasBindDn

`func (o *V11ProvidersLdapIdParams) HasBindDn() bool`

HasBindDn returns a boolean if a field has been set.

### GetBindMechanism

`func (o *V11ProvidersLdapIdParams) GetBindMechanism() string`

GetBindMechanism returns the BindMechanism field if non-nil, zero value otherwise.

### GetBindMechanismOk

`func (o *V11ProvidersLdapIdParams) GetBindMechanismOk() (*string, bool)`

GetBindMechanismOk returns a tuple with the BindMechanism field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBindMechanism

`func (o *V11ProvidersLdapIdParams) SetBindMechanism(v string)`

SetBindMechanism sets BindMechanism field to given value.

### HasBindMechanism

`func (o *V11ProvidersLdapIdParams) HasBindMechanism() bool`

HasBindMechanism returns a boolean if a field has been set.

### GetBindPassword

`func (o *V11ProvidersLdapIdParams) GetBindPassword() string`

GetBindPassword returns the BindPassword field if non-nil, zero value otherwise.

### GetBindPasswordOk

`func (o *V11ProvidersLdapIdParams) GetBindPasswordOk() (*string, bool)`

GetBindPasswordOk returns a tuple with the BindPassword field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBindPassword

`func (o *V11ProvidersLdapIdParams) SetBindPassword(v string)`

SetBindPassword sets BindPassword field to given value.

### HasBindPassword

`func (o *V11ProvidersLdapIdParams) HasBindPassword() bool`

HasBindPassword returns a boolean if a field has been set.

### GetBindTimeout

`func (o *V11ProvidersLdapIdParams) GetBindTimeout() int64`

GetBindTimeout returns the BindTimeout field if non-nil, zero value otherwise.

### GetBindTimeoutOk

`func (o *V11ProvidersLdapIdParams) GetBindTimeoutOk() (*int64, bool)`

GetBindTimeoutOk returns a tuple with the BindTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBindTimeout

`func (o *V11ProvidersLdapIdParams) SetBindTimeout(v int64)`

SetBindTimeout sets BindTimeout field to given value.

### HasBindTimeout

`func (o *V11ProvidersLdapIdParams) HasBindTimeout() bool`

HasBindTimeout returns a boolean if a field has been set.

### GetCertificateAuthorityFile

`func (o *V11ProvidersLdapIdParams) GetCertificateAuthorityFile() string`

GetCertificateAuthorityFile returns the CertificateAuthorityFile field if non-nil, zero value otherwise.

### GetCertificateAuthorityFileOk

`func (o *V11ProvidersLdapIdParams) GetCertificateAuthorityFileOk() (*string, bool)`

GetCertificateAuthorityFileOk returns a tuple with the CertificateAuthorityFile field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCertificateAuthorityFile

`func (o *V11ProvidersLdapIdParams) SetCertificateAuthorityFile(v string)`

SetCertificateAuthorityFile sets CertificateAuthorityFile field to given value.

### HasCertificateAuthorityFile

`func (o *V11ProvidersLdapIdParams) HasCertificateAuthorityFile() bool`

HasCertificateAuthorityFile returns a boolean if a field has been set.

### GetCheckOnlineInterval

`func (o *V11ProvidersLdapIdParams) GetCheckOnlineInterval() int64`

GetCheckOnlineInterval returns the CheckOnlineInterval field if non-nil, zero value otherwise.

### GetCheckOnlineIntervalOk

`func (o *V11ProvidersLdapIdParams) GetCheckOnlineIntervalOk() (*int64, bool)`

GetCheckOnlineIntervalOk returns a tuple with the CheckOnlineInterval field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCheckOnlineInterval

`func (o *V11ProvidersLdapIdParams) SetCheckOnlineInterval(v int64)`

SetCheckOnlineInterval sets CheckOnlineInterval field to given value.

### HasCheckOnlineInterval

`func (o *V11ProvidersLdapIdParams) HasCheckOnlineInterval() bool`

HasCheckOnlineInterval returns a boolean if a field has been set.

### GetCnAttribute

`func (o *V11ProvidersLdapIdParams) GetCnAttribute() string`

GetCnAttribute returns the CnAttribute field if non-nil, zero value otherwise.

### GetCnAttributeOk

`func (o *V11ProvidersLdapIdParams) GetCnAttributeOk() (*string, bool)`

GetCnAttributeOk returns a tuple with the CnAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCnAttribute

`func (o *V11ProvidersLdapIdParams) SetCnAttribute(v string)`

SetCnAttribute sets CnAttribute field to given value.

### HasCnAttribute

`func (o *V11ProvidersLdapIdParams) HasCnAttribute() bool`

HasCnAttribute returns a boolean if a field has been set.

### GetCreateHomeDirectory

`func (o *V11ProvidersLdapIdParams) GetCreateHomeDirectory() bool`

GetCreateHomeDirectory returns the CreateHomeDirectory field if non-nil, zero value otherwise.

### GetCreateHomeDirectoryOk

`func (o *V11ProvidersLdapIdParams) GetCreateHomeDirectoryOk() (*bool, bool)`

GetCreateHomeDirectoryOk returns a tuple with the CreateHomeDirectory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateHomeDirectory

`func (o *V11ProvidersLdapIdParams) SetCreateHomeDirectory(v bool)`

SetCreateHomeDirectory sets CreateHomeDirectory field to given value.

### HasCreateHomeDirectory

`func (o *V11ProvidersLdapIdParams) HasCreateHomeDirectory() bool`

HasCreateHomeDirectory returns a boolean if a field has been set.

### GetCryptPasswordAttribute

`func (o *V11ProvidersLdapIdParams) GetCryptPasswordAttribute() string`

GetCryptPasswordAttribute returns the CryptPasswordAttribute field if non-nil, zero value otherwise.

### GetCryptPasswordAttributeOk

`func (o *V11ProvidersLdapIdParams) GetCryptPasswordAttributeOk() (*string, bool)`

GetCryptPasswordAttributeOk returns a tuple with the CryptPasswordAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCryptPasswordAttribute

`func (o *V11ProvidersLdapIdParams) SetCryptPasswordAttribute(v string)`

SetCryptPasswordAttribute sets CryptPasswordAttribute field to given value.

### HasCryptPasswordAttribute

`func (o *V11ProvidersLdapIdParams) HasCryptPasswordAttribute() bool`

HasCryptPasswordAttribute returns a boolean if a field has been set.

### GetEmailAttribute

`func (o *V11ProvidersLdapIdParams) GetEmailAttribute() string`

GetEmailAttribute returns the EmailAttribute field if non-nil, zero value otherwise.

### GetEmailAttributeOk

`func (o *V11ProvidersLdapIdParams) GetEmailAttributeOk() (*string, bool)`

GetEmailAttributeOk returns a tuple with the EmailAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmailAttribute

`func (o *V11ProvidersLdapIdParams) SetEmailAttribute(v string)`

SetEmailAttribute sets EmailAttribute field to given value.

### HasEmailAttribute

`func (o *V11ProvidersLdapIdParams) HasEmailAttribute() bool`

HasEmailAttribute returns a boolean if a field has been set.

### GetEnabled

`func (o *V11ProvidersLdapIdParams) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V11ProvidersLdapIdParams) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V11ProvidersLdapIdParams) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V11ProvidersLdapIdParams) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetEnumerateGroups

`func (o *V11ProvidersLdapIdParams) GetEnumerateGroups() bool`

GetEnumerateGroups returns the EnumerateGroups field if non-nil, zero value otherwise.

### GetEnumerateGroupsOk

`func (o *V11ProvidersLdapIdParams) GetEnumerateGroupsOk() (*bool, bool)`

GetEnumerateGroupsOk returns a tuple with the EnumerateGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnumerateGroups

`func (o *V11ProvidersLdapIdParams) SetEnumerateGroups(v bool)`

SetEnumerateGroups sets EnumerateGroups field to given value.

### HasEnumerateGroups

`func (o *V11ProvidersLdapIdParams) HasEnumerateGroups() bool`

HasEnumerateGroups returns a boolean if a field has been set.

### GetEnumerateUsers

`func (o *V11ProvidersLdapIdParams) GetEnumerateUsers() bool`

GetEnumerateUsers returns the EnumerateUsers field if non-nil, zero value otherwise.

### GetEnumerateUsersOk

`func (o *V11ProvidersLdapIdParams) GetEnumerateUsersOk() (*bool, bool)`

GetEnumerateUsersOk returns a tuple with the EnumerateUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnumerateUsers

`func (o *V11ProvidersLdapIdParams) SetEnumerateUsers(v bool)`

SetEnumerateUsers sets EnumerateUsers field to given value.

### HasEnumerateUsers

`func (o *V11ProvidersLdapIdParams) HasEnumerateUsers() bool`

HasEnumerateUsers returns a boolean if a field has been set.

### GetFindableGroups

`func (o *V11ProvidersLdapIdParams) GetFindableGroups() []string`

GetFindableGroups returns the FindableGroups field if non-nil, zero value otherwise.

### GetFindableGroupsOk

`func (o *V11ProvidersLdapIdParams) GetFindableGroupsOk() (*[]string, bool)`

GetFindableGroupsOk returns a tuple with the FindableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFindableGroups

`func (o *V11ProvidersLdapIdParams) SetFindableGroups(v []string)`

SetFindableGroups sets FindableGroups field to given value.

### HasFindableGroups

`func (o *V11ProvidersLdapIdParams) HasFindableGroups() bool`

HasFindableGroups returns a boolean if a field has been set.

### GetFindableUsers

`func (o *V11ProvidersLdapIdParams) GetFindableUsers() []string`

GetFindableUsers returns the FindableUsers field if non-nil, zero value otherwise.

### GetFindableUsersOk

`func (o *V11ProvidersLdapIdParams) GetFindableUsersOk() (*[]string, bool)`

GetFindableUsersOk returns a tuple with the FindableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFindableUsers

`func (o *V11ProvidersLdapIdParams) SetFindableUsers(v []string)`

SetFindableUsers sets FindableUsers field to given value.

### HasFindableUsers

`func (o *V11ProvidersLdapIdParams) HasFindableUsers() bool`

HasFindableUsers returns a boolean if a field has been set.

### GetGecosAttribute

`func (o *V11ProvidersLdapIdParams) GetGecosAttribute() string`

GetGecosAttribute returns the GecosAttribute field if non-nil, zero value otherwise.

### GetGecosAttributeOk

`func (o *V11ProvidersLdapIdParams) GetGecosAttributeOk() (*string, bool)`

GetGecosAttributeOk returns a tuple with the GecosAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGecosAttribute

`func (o *V11ProvidersLdapIdParams) SetGecosAttribute(v string)`

SetGecosAttribute sets GecosAttribute field to given value.

### HasGecosAttribute

`func (o *V11ProvidersLdapIdParams) HasGecosAttribute() bool`

HasGecosAttribute returns a boolean if a field has been set.

### GetGidAttribute

`func (o *V11ProvidersLdapIdParams) GetGidAttribute() string`

GetGidAttribute returns the GidAttribute field if non-nil, zero value otherwise.

### GetGidAttributeOk

`func (o *V11ProvidersLdapIdParams) GetGidAttributeOk() (*string, bool)`

GetGidAttributeOk returns a tuple with the GidAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGidAttribute

`func (o *V11ProvidersLdapIdParams) SetGidAttribute(v string)`

SetGidAttribute sets GidAttribute field to given value.

### HasGidAttribute

`func (o *V11ProvidersLdapIdParams) HasGidAttribute() bool`

HasGidAttribute returns a boolean if a field has been set.

### GetGroupBaseDn

`func (o *V11ProvidersLdapIdParams) GetGroupBaseDn() string`

GetGroupBaseDn returns the GroupBaseDn field if non-nil, zero value otherwise.

### GetGroupBaseDnOk

`func (o *V11ProvidersLdapIdParams) GetGroupBaseDnOk() (*string, bool)`

GetGroupBaseDnOk returns a tuple with the GroupBaseDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupBaseDn

`func (o *V11ProvidersLdapIdParams) SetGroupBaseDn(v string)`

SetGroupBaseDn sets GroupBaseDn field to given value.

### HasGroupBaseDn

`func (o *V11ProvidersLdapIdParams) HasGroupBaseDn() bool`

HasGroupBaseDn returns a boolean if a field has been set.

### GetGroupDomain

`func (o *V11ProvidersLdapIdParams) GetGroupDomain() string`

GetGroupDomain returns the GroupDomain field if non-nil, zero value otherwise.

### GetGroupDomainOk

`func (o *V11ProvidersLdapIdParams) GetGroupDomainOk() (*string, bool)`

GetGroupDomainOk returns a tuple with the GroupDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupDomain

`func (o *V11ProvidersLdapIdParams) SetGroupDomain(v string)`

SetGroupDomain sets GroupDomain field to given value.

### HasGroupDomain

`func (o *V11ProvidersLdapIdParams) HasGroupDomain() bool`

HasGroupDomain returns a boolean if a field has been set.

### GetGroupFilter

`func (o *V11ProvidersLdapIdParams) GetGroupFilter() string`

GetGroupFilter returns the GroupFilter field if non-nil, zero value otherwise.

### GetGroupFilterOk

`func (o *V11ProvidersLdapIdParams) GetGroupFilterOk() (*string, bool)`

GetGroupFilterOk returns a tuple with the GroupFilter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupFilter

`func (o *V11ProvidersLdapIdParams) SetGroupFilter(v string)`

SetGroupFilter sets GroupFilter field to given value.

### HasGroupFilter

`func (o *V11ProvidersLdapIdParams) HasGroupFilter() bool`

HasGroupFilter returns a boolean if a field has been set.

### GetGroupMembersAttribute

`func (o *V11ProvidersLdapIdParams) GetGroupMembersAttribute() string`

GetGroupMembersAttribute returns the GroupMembersAttribute field if non-nil, zero value otherwise.

### GetGroupMembersAttributeOk

`func (o *V11ProvidersLdapIdParams) GetGroupMembersAttributeOk() (*string, bool)`

GetGroupMembersAttributeOk returns a tuple with the GroupMembersAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupMembersAttribute

`func (o *V11ProvidersLdapIdParams) SetGroupMembersAttribute(v string)`

SetGroupMembersAttribute sets GroupMembersAttribute field to given value.

### HasGroupMembersAttribute

`func (o *V11ProvidersLdapIdParams) HasGroupMembersAttribute() bool`

HasGroupMembersAttribute returns a boolean if a field has been set.

### GetGroupSearchScope

`func (o *V11ProvidersLdapIdParams) GetGroupSearchScope() string`

GetGroupSearchScope returns the GroupSearchScope field if non-nil, zero value otherwise.

### GetGroupSearchScopeOk

`func (o *V11ProvidersLdapIdParams) GetGroupSearchScopeOk() (*string, bool)`

GetGroupSearchScopeOk returns a tuple with the GroupSearchScope field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupSearchScope

`func (o *V11ProvidersLdapIdParams) SetGroupSearchScope(v string)`

SetGroupSearchScope sets GroupSearchScope field to given value.

### HasGroupSearchScope

`func (o *V11ProvidersLdapIdParams) HasGroupSearchScope() bool`

HasGroupSearchScope returns a boolean if a field has been set.

### GetHomeDirectoryTemplate

`func (o *V11ProvidersLdapIdParams) GetHomeDirectoryTemplate() string`

GetHomeDirectoryTemplate returns the HomeDirectoryTemplate field if non-nil, zero value otherwise.

### GetHomeDirectoryTemplateOk

`func (o *V11ProvidersLdapIdParams) GetHomeDirectoryTemplateOk() (*string, bool)`

GetHomeDirectoryTemplateOk returns a tuple with the HomeDirectoryTemplate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHomeDirectoryTemplate

`func (o *V11ProvidersLdapIdParams) SetHomeDirectoryTemplate(v string)`

SetHomeDirectoryTemplate sets HomeDirectoryTemplate field to given value.

### HasHomeDirectoryTemplate

`func (o *V11ProvidersLdapIdParams) HasHomeDirectoryTemplate() bool`

HasHomeDirectoryTemplate returns a boolean if a field has been set.

### GetHomedirAttribute

`func (o *V11ProvidersLdapIdParams) GetHomedirAttribute() string`

GetHomedirAttribute returns the HomedirAttribute field if non-nil, zero value otherwise.

### GetHomedirAttributeOk

`func (o *V11ProvidersLdapIdParams) GetHomedirAttributeOk() (*string, bool)`

GetHomedirAttributeOk returns a tuple with the HomedirAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHomedirAttribute

`func (o *V11ProvidersLdapIdParams) SetHomedirAttribute(v string)`

SetHomedirAttribute sets HomedirAttribute field to given value.

### HasHomedirAttribute

`func (o *V11ProvidersLdapIdParams) HasHomedirAttribute() bool`

HasHomedirAttribute returns a boolean if a field has been set.

### GetIgnoreTlsErrors

`func (o *V11ProvidersLdapIdParams) GetIgnoreTlsErrors() bool`

GetIgnoreTlsErrors returns the IgnoreTlsErrors field if non-nil, zero value otherwise.

### GetIgnoreTlsErrorsOk

`func (o *V11ProvidersLdapIdParams) GetIgnoreTlsErrorsOk() (*bool, bool)`

GetIgnoreTlsErrorsOk returns a tuple with the IgnoreTlsErrors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoreTlsErrors

`func (o *V11ProvidersLdapIdParams) SetIgnoreTlsErrors(v bool)`

SetIgnoreTlsErrors sets IgnoreTlsErrors field to given value.

### HasIgnoreTlsErrors

`func (o *V11ProvidersLdapIdParams) HasIgnoreTlsErrors() bool`

HasIgnoreTlsErrors returns a boolean if a field has been set.

### GetListableGroups

`func (o *V11ProvidersLdapIdParams) GetListableGroups() []string`

GetListableGroups returns the ListableGroups field if non-nil, zero value otherwise.

### GetListableGroupsOk

`func (o *V11ProvidersLdapIdParams) GetListableGroupsOk() (*[]string, bool)`

GetListableGroupsOk returns a tuple with the ListableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetListableGroups

`func (o *V11ProvidersLdapIdParams) SetListableGroups(v []string)`

SetListableGroups sets ListableGroups field to given value.

### HasListableGroups

`func (o *V11ProvidersLdapIdParams) HasListableGroups() bool`

HasListableGroups returns a boolean if a field has been set.

### GetListableUsers

`func (o *V11ProvidersLdapIdParams) GetListableUsers() []string`

GetListableUsers returns the ListableUsers field if non-nil, zero value otherwise.

### GetListableUsersOk

`func (o *V11ProvidersLdapIdParams) GetListableUsersOk() (*[]string, bool)`

GetListableUsersOk returns a tuple with the ListableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetListableUsers

`func (o *V11ProvidersLdapIdParams) SetListableUsers(v []string)`

SetListableUsers sets ListableUsers field to given value.

### HasListableUsers

`func (o *V11ProvidersLdapIdParams) HasListableUsers() bool`

HasListableUsers returns a boolean if a field has been set.

### GetLoginShell

`func (o *V11ProvidersLdapIdParams) GetLoginShell() string`

GetLoginShell returns the LoginShell field if non-nil, zero value otherwise.

### GetLoginShellOk

`func (o *V11ProvidersLdapIdParams) GetLoginShellOk() (*string, bool)`

GetLoginShellOk returns a tuple with the LoginShell field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLoginShell

`func (o *V11ProvidersLdapIdParams) SetLoginShell(v string)`

SetLoginShell sets LoginShell field to given value.

### HasLoginShell

`func (o *V11ProvidersLdapIdParams) HasLoginShell() bool`

HasLoginShell returns a boolean if a field has been set.

### GetMemberLookupMethod

`func (o *V11ProvidersLdapIdParams) GetMemberLookupMethod() string`

GetMemberLookupMethod returns the MemberLookupMethod field if non-nil, zero value otherwise.

### GetMemberLookupMethodOk

`func (o *V11ProvidersLdapIdParams) GetMemberLookupMethodOk() (*string, bool)`

GetMemberLookupMethodOk returns a tuple with the MemberLookupMethod field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMemberLookupMethod

`func (o *V11ProvidersLdapIdParams) SetMemberLookupMethod(v string)`

SetMemberLookupMethod sets MemberLookupMethod field to given value.

### HasMemberLookupMethod

`func (o *V11ProvidersLdapIdParams) HasMemberLookupMethod() bool`

HasMemberLookupMethod returns a boolean if a field has been set.

### GetMemberOfAttribute

`func (o *V11ProvidersLdapIdParams) GetMemberOfAttribute() string`

GetMemberOfAttribute returns the MemberOfAttribute field if non-nil, zero value otherwise.

### GetMemberOfAttributeOk

`func (o *V11ProvidersLdapIdParams) GetMemberOfAttributeOk() (*string, bool)`

GetMemberOfAttributeOk returns a tuple with the MemberOfAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMemberOfAttribute

`func (o *V11ProvidersLdapIdParams) SetMemberOfAttribute(v string)`

SetMemberOfAttribute sets MemberOfAttribute field to given value.

### HasMemberOfAttribute

`func (o *V11ProvidersLdapIdParams) HasMemberOfAttribute() bool`

HasMemberOfAttribute returns a boolean if a field has been set.

### GetName

`func (o *V11ProvidersLdapIdParams) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V11ProvidersLdapIdParams) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V11ProvidersLdapIdParams) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V11ProvidersLdapIdParams) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNameAttribute

`func (o *V11ProvidersLdapIdParams) GetNameAttribute() string`

GetNameAttribute returns the NameAttribute field if non-nil, zero value otherwise.

### GetNameAttributeOk

`func (o *V11ProvidersLdapIdParams) GetNameAttributeOk() (*string, bool)`

GetNameAttributeOk returns a tuple with the NameAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNameAttribute

`func (o *V11ProvidersLdapIdParams) SetNameAttribute(v string)`

SetNameAttribute sets NameAttribute field to given value.

### HasNameAttribute

`func (o *V11ProvidersLdapIdParams) HasNameAttribute() bool`

HasNameAttribute returns a boolean if a field has been set.

### GetNetgroupBaseDn

`func (o *V11ProvidersLdapIdParams) GetNetgroupBaseDn() string`

GetNetgroupBaseDn returns the NetgroupBaseDn field if non-nil, zero value otherwise.

### GetNetgroupBaseDnOk

`func (o *V11ProvidersLdapIdParams) GetNetgroupBaseDnOk() (*string, bool)`

GetNetgroupBaseDnOk returns a tuple with the NetgroupBaseDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetgroupBaseDn

`func (o *V11ProvidersLdapIdParams) SetNetgroupBaseDn(v string)`

SetNetgroupBaseDn sets NetgroupBaseDn field to given value.

### HasNetgroupBaseDn

`func (o *V11ProvidersLdapIdParams) HasNetgroupBaseDn() bool`

HasNetgroupBaseDn returns a boolean if a field has been set.

### GetNetgroupFilter

`func (o *V11ProvidersLdapIdParams) GetNetgroupFilter() string`

GetNetgroupFilter returns the NetgroupFilter field if non-nil, zero value otherwise.

### GetNetgroupFilterOk

`func (o *V11ProvidersLdapIdParams) GetNetgroupFilterOk() (*string, bool)`

GetNetgroupFilterOk returns a tuple with the NetgroupFilter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetgroupFilter

`func (o *V11ProvidersLdapIdParams) SetNetgroupFilter(v string)`

SetNetgroupFilter sets NetgroupFilter field to given value.

### HasNetgroupFilter

`func (o *V11ProvidersLdapIdParams) HasNetgroupFilter() bool`

HasNetgroupFilter returns a boolean if a field has been set.

### GetNetgroupMembersAttribute

`func (o *V11ProvidersLdapIdParams) GetNetgroupMembersAttribute() string`

GetNetgroupMembersAttribute returns the NetgroupMembersAttribute field if non-nil, zero value otherwise.

### GetNetgroupMembersAttributeOk

`func (o *V11ProvidersLdapIdParams) GetNetgroupMembersAttributeOk() (*string, bool)`

GetNetgroupMembersAttributeOk returns a tuple with the NetgroupMembersAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetgroupMembersAttribute

`func (o *V11ProvidersLdapIdParams) SetNetgroupMembersAttribute(v string)`

SetNetgroupMembersAttribute sets NetgroupMembersAttribute field to given value.

### HasNetgroupMembersAttribute

`func (o *V11ProvidersLdapIdParams) HasNetgroupMembersAttribute() bool`

HasNetgroupMembersAttribute returns a boolean if a field has been set.

### GetNetgroupSearchScope

`func (o *V11ProvidersLdapIdParams) GetNetgroupSearchScope() string`

GetNetgroupSearchScope returns the NetgroupSearchScope field if non-nil, zero value otherwise.

### GetNetgroupSearchScopeOk

`func (o *V11ProvidersLdapIdParams) GetNetgroupSearchScopeOk() (*string, bool)`

GetNetgroupSearchScopeOk returns a tuple with the NetgroupSearchScope field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetgroupSearchScope

`func (o *V11ProvidersLdapIdParams) SetNetgroupSearchScope(v string)`

SetNetgroupSearchScope sets NetgroupSearchScope field to given value.

### HasNetgroupSearchScope

`func (o *V11ProvidersLdapIdParams) HasNetgroupSearchScope() bool`

HasNetgroupSearchScope returns a boolean if a field has been set.

### GetNetgroupTripleAttribute

`func (o *V11ProvidersLdapIdParams) GetNetgroupTripleAttribute() string`

GetNetgroupTripleAttribute returns the NetgroupTripleAttribute field if non-nil, zero value otherwise.

### GetNetgroupTripleAttributeOk

`func (o *V11ProvidersLdapIdParams) GetNetgroupTripleAttributeOk() (*string, bool)`

GetNetgroupTripleAttributeOk returns a tuple with the NetgroupTripleAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetgroupTripleAttribute

`func (o *V11ProvidersLdapIdParams) SetNetgroupTripleAttribute(v string)`

SetNetgroupTripleAttribute sets NetgroupTripleAttribute field to given value.

### HasNetgroupTripleAttribute

`func (o *V11ProvidersLdapIdParams) HasNetgroupTripleAttribute() bool`

HasNetgroupTripleAttribute returns a boolean if a field has been set.

### GetNormalizeGroups

`func (o *V11ProvidersLdapIdParams) GetNormalizeGroups() bool`

GetNormalizeGroups returns the NormalizeGroups field if non-nil, zero value otherwise.

### GetNormalizeGroupsOk

`func (o *V11ProvidersLdapIdParams) GetNormalizeGroupsOk() (*bool, bool)`

GetNormalizeGroupsOk returns a tuple with the NormalizeGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNormalizeGroups

`func (o *V11ProvidersLdapIdParams) SetNormalizeGroups(v bool)`

SetNormalizeGroups sets NormalizeGroups field to given value.

### HasNormalizeGroups

`func (o *V11ProvidersLdapIdParams) HasNormalizeGroups() bool`

HasNormalizeGroups returns a boolean if a field has been set.

### GetNormalizeUsers

`func (o *V11ProvidersLdapIdParams) GetNormalizeUsers() bool`

GetNormalizeUsers returns the NormalizeUsers field if non-nil, zero value otherwise.

### GetNormalizeUsersOk

`func (o *V11ProvidersLdapIdParams) GetNormalizeUsersOk() (*bool, bool)`

GetNormalizeUsersOk returns a tuple with the NormalizeUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNormalizeUsers

`func (o *V11ProvidersLdapIdParams) SetNormalizeUsers(v bool)`

SetNormalizeUsers sets NormalizeUsers field to given value.

### HasNormalizeUsers

`func (o *V11ProvidersLdapIdParams) HasNormalizeUsers() bool`

HasNormalizeUsers returns a boolean if a field has been set.

### GetNtPasswordAttribute

`func (o *V11ProvidersLdapIdParams) GetNtPasswordAttribute() string`

GetNtPasswordAttribute returns the NtPasswordAttribute field if non-nil, zero value otherwise.

### GetNtPasswordAttributeOk

`func (o *V11ProvidersLdapIdParams) GetNtPasswordAttributeOk() (*string, bool)`

GetNtPasswordAttributeOk returns a tuple with the NtPasswordAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNtPasswordAttribute

`func (o *V11ProvidersLdapIdParams) SetNtPasswordAttribute(v string)`

SetNtPasswordAttribute sets NtPasswordAttribute field to given value.

### HasNtPasswordAttribute

`func (o *V11ProvidersLdapIdParams) HasNtPasswordAttribute() bool`

HasNtPasswordAttribute returns a boolean if a field has been set.

### GetNtlmSupport

`func (o *V11ProvidersLdapIdParams) GetNtlmSupport() string`

GetNtlmSupport returns the NtlmSupport field if non-nil, zero value otherwise.

### GetNtlmSupportOk

`func (o *V11ProvidersLdapIdParams) GetNtlmSupportOk() (*string, bool)`

GetNtlmSupportOk returns a tuple with the NtlmSupport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNtlmSupport

`func (o *V11ProvidersLdapIdParams) SetNtlmSupport(v string)`

SetNtlmSupport sets NtlmSupport field to given value.

### HasNtlmSupport

`func (o *V11ProvidersLdapIdParams) HasNtlmSupport() bool`

HasNtlmSupport returns a boolean if a field has been set.

### GetProviderDomain

`func (o *V11ProvidersLdapIdParams) GetProviderDomain() string`

GetProviderDomain returns the ProviderDomain field if non-nil, zero value otherwise.

### GetProviderDomainOk

`func (o *V11ProvidersLdapIdParams) GetProviderDomainOk() (*string, bool)`

GetProviderDomainOk returns a tuple with the ProviderDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProviderDomain

`func (o *V11ProvidersLdapIdParams) SetProviderDomain(v string)`

SetProviderDomain sets ProviderDomain field to given value.

### HasProviderDomain

`func (o *V11ProvidersLdapIdParams) HasProviderDomain() bool`

HasProviderDomain returns a boolean if a field has been set.

### GetRequireSecureConnection

`func (o *V11ProvidersLdapIdParams) GetRequireSecureConnection() bool`

GetRequireSecureConnection returns the RequireSecureConnection field if non-nil, zero value otherwise.

### GetRequireSecureConnectionOk

`func (o *V11ProvidersLdapIdParams) GetRequireSecureConnectionOk() (*bool, bool)`

GetRequireSecureConnectionOk returns a tuple with the RequireSecureConnection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRequireSecureConnection

`func (o *V11ProvidersLdapIdParams) SetRequireSecureConnection(v bool)`

SetRequireSecureConnection sets RequireSecureConnection field to given value.

### HasRequireSecureConnection

`func (o *V11ProvidersLdapIdParams) HasRequireSecureConnection() bool`

HasRequireSecureConnection returns a boolean if a field has been set.

### GetRestrictFindable

`func (o *V11ProvidersLdapIdParams) GetRestrictFindable() bool`

GetRestrictFindable returns the RestrictFindable field if non-nil, zero value otherwise.

### GetRestrictFindableOk

`func (o *V11ProvidersLdapIdParams) GetRestrictFindableOk() (*bool, bool)`

GetRestrictFindableOk returns a tuple with the RestrictFindable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRestrictFindable

`func (o *V11ProvidersLdapIdParams) SetRestrictFindable(v bool)`

SetRestrictFindable sets RestrictFindable field to given value.

### HasRestrictFindable

`func (o *V11ProvidersLdapIdParams) HasRestrictFindable() bool`

HasRestrictFindable returns a boolean if a field has been set.

### GetRestrictListable

`func (o *V11ProvidersLdapIdParams) GetRestrictListable() bool`

GetRestrictListable returns the RestrictListable field if non-nil, zero value otherwise.

### GetRestrictListableOk

`func (o *V11ProvidersLdapIdParams) GetRestrictListableOk() (*bool, bool)`

GetRestrictListableOk returns a tuple with the RestrictListable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRestrictListable

`func (o *V11ProvidersLdapIdParams) SetRestrictListable(v bool)`

SetRestrictListable sets RestrictListable field to given value.

### HasRestrictListable

`func (o *V11ProvidersLdapIdParams) HasRestrictListable() bool`

HasRestrictListable returns a boolean if a field has been set.

### GetSearchScope

`func (o *V11ProvidersLdapIdParams) GetSearchScope() string`

GetSearchScope returns the SearchScope field if non-nil, zero value otherwise.

### GetSearchScopeOk

`func (o *V11ProvidersLdapIdParams) GetSearchScopeOk() (*string, bool)`

GetSearchScopeOk returns a tuple with the SearchScope field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSearchScope

`func (o *V11ProvidersLdapIdParams) SetSearchScope(v string)`

SetSearchScope sets SearchScope field to given value.

### HasSearchScope

`func (o *V11ProvidersLdapIdParams) HasSearchScope() bool`

HasSearchScope returns a boolean if a field has been set.

### GetSearchTimeout

`func (o *V11ProvidersLdapIdParams) GetSearchTimeout() int64`

GetSearchTimeout returns the SearchTimeout field if non-nil, zero value otherwise.

### GetSearchTimeoutOk

`func (o *V11ProvidersLdapIdParams) GetSearchTimeoutOk() (*int64, bool)`

GetSearchTimeoutOk returns a tuple with the SearchTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSearchTimeout

`func (o *V11ProvidersLdapIdParams) SetSearchTimeout(v int64)`

SetSearchTimeout sets SearchTimeout field to given value.

### HasSearchTimeout

`func (o *V11ProvidersLdapIdParams) HasSearchTimeout() bool`

HasSearchTimeout returns a boolean if a field has been set.

### GetServerUris

`func (o *V11ProvidersLdapIdParams) GetServerUris() []string`

GetServerUris returns the ServerUris field if non-nil, zero value otherwise.

### GetServerUrisOk

`func (o *V11ProvidersLdapIdParams) GetServerUrisOk() (*[]string, bool)`

GetServerUrisOk returns a tuple with the ServerUris field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerUris

`func (o *V11ProvidersLdapIdParams) SetServerUris(v []string)`

SetServerUris sets ServerUris field to given value.

### HasServerUris

`func (o *V11ProvidersLdapIdParams) HasServerUris() bool`

HasServerUris returns a boolean if a field has been set.

### GetShadowExpireAttribute

`func (o *V11ProvidersLdapIdParams) GetShadowExpireAttribute() string`

GetShadowExpireAttribute returns the ShadowExpireAttribute field if non-nil, zero value otherwise.

### GetShadowExpireAttributeOk

`func (o *V11ProvidersLdapIdParams) GetShadowExpireAttributeOk() (*string, bool)`

GetShadowExpireAttributeOk returns a tuple with the ShadowExpireAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowExpireAttribute

`func (o *V11ProvidersLdapIdParams) SetShadowExpireAttribute(v string)`

SetShadowExpireAttribute sets ShadowExpireAttribute field to given value.

### HasShadowExpireAttribute

`func (o *V11ProvidersLdapIdParams) HasShadowExpireAttribute() bool`

HasShadowExpireAttribute returns a boolean if a field has been set.

### GetShadowFlagAttribute

`func (o *V11ProvidersLdapIdParams) GetShadowFlagAttribute() string`

GetShadowFlagAttribute returns the ShadowFlagAttribute field if non-nil, zero value otherwise.

### GetShadowFlagAttributeOk

`func (o *V11ProvidersLdapIdParams) GetShadowFlagAttributeOk() (*string, bool)`

GetShadowFlagAttributeOk returns a tuple with the ShadowFlagAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowFlagAttribute

`func (o *V11ProvidersLdapIdParams) SetShadowFlagAttribute(v string)`

SetShadowFlagAttribute sets ShadowFlagAttribute field to given value.

### HasShadowFlagAttribute

`func (o *V11ProvidersLdapIdParams) HasShadowFlagAttribute() bool`

HasShadowFlagAttribute returns a boolean if a field has been set.

### GetShadowInactiveAttribute

`func (o *V11ProvidersLdapIdParams) GetShadowInactiveAttribute() string`

GetShadowInactiveAttribute returns the ShadowInactiveAttribute field if non-nil, zero value otherwise.

### GetShadowInactiveAttributeOk

`func (o *V11ProvidersLdapIdParams) GetShadowInactiveAttributeOk() (*string, bool)`

GetShadowInactiveAttributeOk returns a tuple with the ShadowInactiveAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowInactiveAttribute

`func (o *V11ProvidersLdapIdParams) SetShadowInactiveAttribute(v string)`

SetShadowInactiveAttribute sets ShadowInactiveAttribute field to given value.

### HasShadowInactiveAttribute

`func (o *V11ProvidersLdapIdParams) HasShadowInactiveAttribute() bool`

HasShadowInactiveAttribute returns a boolean if a field has been set.

### GetShadowLastChangeAttribute

`func (o *V11ProvidersLdapIdParams) GetShadowLastChangeAttribute() string`

GetShadowLastChangeAttribute returns the ShadowLastChangeAttribute field if non-nil, zero value otherwise.

### GetShadowLastChangeAttributeOk

`func (o *V11ProvidersLdapIdParams) GetShadowLastChangeAttributeOk() (*string, bool)`

GetShadowLastChangeAttributeOk returns a tuple with the ShadowLastChangeAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowLastChangeAttribute

`func (o *V11ProvidersLdapIdParams) SetShadowLastChangeAttribute(v string)`

SetShadowLastChangeAttribute sets ShadowLastChangeAttribute field to given value.

### HasShadowLastChangeAttribute

`func (o *V11ProvidersLdapIdParams) HasShadowLastChangeAttribute() bool`

HasShadowLastChangeAttribute returns a boolean if a field has been set.

### GetShadowMaxAttribute

`func (o *V11ProvidersLdapIdParams) GetShadowMaxAttribute() string`

GetShadowMaxAttribute returns the ShadowMaxAttribute field if non-nil, zero value otherwise.

### GetShadowMaxAttributeOk

`func (o *V11ProvidersLdapIdParams) GetShadowMaxAttributeOk() (*string, bool)`

GetShadowMaxAttributeOk returns a tuple with the ShadowMaxAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowMaxAttribute

`func (o *V11ProvidersLdapIdParams) SetShadowMaxAttribute(v string)`

SetShadowMaxAttribute sets ShadowMaxAttribute field to given value.

### HasShadowMaxAttribute

`func (o *V11ProvidersLdapIdParams) HasShadowMaxAttribute() bool`

HasShadowMaxAttribute returns a boolean if a field has been set.

### GetShadowMinAttribute

`func (o *V11ProvidersLdapIdParams) GetShadowMinAttribute() string`

GetShadowMinAttribute returns the ShadowMinAttribute field if non-nil, zero value otherwise.

### GetShadowMinAttributeOk

`func (o *V11ProvidersLdapIdParams) GetShadowMinAttributeOk() (*string, bool)`

GetShadowMinAttributeOk returns a tuple with the ShadowMinAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowMinAttribute

`func (o *V11ProvidersLdapIdParams) SetShadowMinAttribute(v string)`

SetShadowMinAttribute sets ShadowMinAttribute field to given value.

### HasShadowMinAttribute

`func (o *V11ProvidersLdapIdParams) HasShadowMinAttribute() bool`

HasShadowMinAttribute returns a boolean if a field has been set.

### GetShadowUserFilter

`func (o *V11ProvidersLdapIdParams) GetShadowUserFilter() string`

GetShadowUserFilter returns the ShadowUserFilter field if non-nil, zero value otherwise.

### GetShadowUserFilterOk

`func (o *V11ProvidersLdapIdParams) GetShadowUserFilterOk() (*string, bool)`

GetShadowUserFilterOk returns a tuple with the ShadowUserFilter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowUserFilter

`func (o *V11ProvidersLdapIdParams) SetShadowUserFilter(v string)`

SetShadowUserFilter sets ShadowUserFilter field to given value.

### HasShadowUserFilter

`func (o *V11ProvidersLdapIdParams) HasShadowUserFilter() bool`

HasShadowUserFilter returns a boolean if a field has been set.

### GetShadowWarningAttribute

`func (o *V11ProvidersLdapIdParams) GetShadowWarningAttribute() string`

GetShadowWarningAttribute returns the ShadowWarningAttribute field if non-nil, zero value otherwise.

### GetShadowWarningAttributeOk

`func (o *V11ProvidersLdapIdParams) GetShadowWarningAttributeOk() (*string, bool)`

GetShadowWarningAttributeOk returns a tuple with the ShadowWarningAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowWarningAttribute

`func (o *V11ProvidersLdapIdParams) SetShadowWarningAttribute(v string)`

SetShadowWarningAttribute sets ShadowWarningAttribute field to given value.

### HasShadowWarningAttribute

`func (o *V11ProvidersLdapIdParams) HasShadowWarningAttribute() bool`

HasShadowWarningAttribute returns a boolean if a field has been set.

### GetShellAttribute

`func (o *V11ProvidersLdapIdParams) GetShellAttribute() string`

GetShellAttribute returns the ShellAttribute field if non-nil, zero value otherwise.

### GetShellAttributeOk

`func (o *V11ProvidersLdapIdParams) GetShellAttributeOk() (*string, bool)`

GetShellAttributeOk returns a tuple with the ShellAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShellAttribute

`func (o *V11ProvidersLdapIdParams) SetShellAttribute(v string)`

SetShellAttribute sets ShellAttribute field to given value.

### HasShellAttribute

`func (o *V11ProvidersLdapIdParams) HasShellAttribute() bool`

HasShellAttribute returns a boolean if a field has been set.

### GetSshPublicKeyAttribute

`func (o *V11ProvidersLdapIdParams) GetSshPublicKeyAttribute() string`

GetSshPublicKeyAttribute returns the SshPublicKeyAttribute field if non-nil, zero value otherwise.

### GetSshPublicKeyAttributeOk

`func (o *V11ProvidersLdapIdParams) GetSshPublicKeyAttributeOk() (*string, bool)`

GetSshPublicKeyAttributeOk returns a tuple with the SshPublicKeyAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSshPublicKeyAttribute

`func (o *V11ProvidersLdapIdParams) SetSshPublicKeyAttribute(v string)`

SetSshPublicKeyAttribute sets SshPublicKeyAttribute field to given value.

### HasSshPublicKeyAttribute

`func (o *V11ProvidersLdapIdParams) HasSshPublicKeyAttribute() bool`

HasSshPublicKeyAttribute returns a boolean if a field has been set.

### GetTemplate

`func (o *V11ProvidersLdapIdParams) GetTemplate() string`

GetTemplate returns the Template field if non-nil, zero value otherwise.

### GetTemplateOk

`func (o *V11ProvidersLdapIdParams) GetTemplateOk() (*string, bool)`

GetTemplateOk returns a tuple with the Template field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTemplate

`func (o *V11ProvidersLdapIdParams) SetTemplate(v string)`

SetTemplate sets Template field to given value.

### HasTemplate

`func (o *V11ProvidersLdapIdParams) HasTemplate() bool`

HasTemplate returns a boolean if a field has been set.

### GetTlsProtocolMin

`func (o *V11ProvidersLdapIdParams) GetTlsProtocolMin() string`

GetTlsProtocolMin returns the TlsProtocolMin field if non-nil, zero value otherwise.

### GetTlsProtocolMinOk

`func (o *V11ProvidersLdapIdParams) GetTlsProtocolMinOk() (*string, bool)`

GetTlsProtocolMinOk returns a tuple with the TlsProtocolMin field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTlsProtocolMin

`func (o *V11ProvidersLdapIdParams) SetTlsProtocolMin(v string)`

SetTlsProtocolMin sets TlsProtocolMin field to given value.

### HasTlsProtocolMin

`func (o *V11ProvidersLdapIdParams) HasTlsProtocolMin() bool`

HasTlsProtocolMin returns a boolean if a field has been set.

### GetUidAttribute

`func (o *V11ProvidersLdapIdParams) GetUidAttribute() string`

GetUidAttribute returns the UidAttribute field if non-nil, zero value otherwise.

### GetUidAttributeOk

`func (o *V11ProvidersLdapIdParams) GetUidAttributeOk() (*string, bool)`

GetUidAttributeOk returns a tuple with the UidAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUidAttribute

`func (o *V11ProvidersLdapIdParams) SetUidAttribute(v string)`

SetUidAttribute sets UidAttribute field to given value.

### HasUidAttribute

`func (o *V11ProvidersLdapIdParams) HasUidAttribute() bool`

HasUidAttribute returns a boolean if a field has been set.

### GetUnfindableGroups

`func (o *V11ProvidersLdapIdParams) GetUnfindableGroups() []string`

GetUnfindableGroups returns the UnfindableGroups field if non-nil, zero value otherwise.

### GetUnfindableGroupsOk

`func (o *V11ProvidersLdapIdParams) GetUnfindableGroupsOk() (*[]string, bool)`

GetUnfindableGroupsOk returns a tuple with the UnfindableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnfindableGroups

`func (o *V11ProvidersLdapIdParams) SetUnfindableGroups(v []string)`

SetUnfindableGroups sets UnfindableGroups field to given value.

### HasUnfindableGroups

`func (o *V11ProvidersLdapIdParams) HasUnfindableGroups() bool`

HasUnfindableGroups returns a boolean if a field has been set.

### GetUnfindableUsers

`func (o *V11ProvidersLdapIdParams) GetUnfindableUsers() []string`

GetUnfindableUsers returns the UnfindableUsers field if non-nil, zero value otherwise.

### GetUnfindableUsersOk

`func (o *V11ProvidersLdapIdParams) GetUnfindableUsersOk() (*[]string, bool)`

GetUnfindableUsersOk returns a tuple with the UnfindableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnfindableUsers

`func (o *V11ProvidersLdapIdParams) SetUnfindableUsers(v []string)`

SetUnfindableUsers sets UnfindableUsers field to given value.

### HasUnfindableUsers

`func (o *V11ProvidersLdapIdParams) HasUnfindableUsers() bool`

HasUnfindableUsers returns a boolean if a field has been set.

### GetUniqueGroupMembersAttribute

`func (o *V11ProvidersLdapIdParams) GetUniqueGroupMembersAttribute() string`

GetUniqueGroupMembersAttribute returns the UniqueGroupMembersAttribute field if non-nil, zero value otherwise.

### GetUniqueGroupMembersAttributeOk

`func (o *V11ProvidersLdapIdParams) GetUniqueGroupMembersAttributeOk() (*string, bool)`

GetUniqueGroupMembersAttributeOk returns a tuple with the UniqueGroupMembersAttribute field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUniqueGroupMembersAttribute

`func (o *V11ProvidersLdapIdParams) SetUniqueGroupMembersAttribute(v string)`

SetUniqueGroupMembersAttribute sets UniqueGroupMembersAttribute field to given value.

### HasUniqueGroupMembersAttribute

`func (o *V11ProvidersLdapIdParams) HasUniqueGroupMembersAttribute() bool`

HasUniqueGroupMembersAttribute returns a boolean if a field has been set.

### GetUnlistableGroups

`func (o *V11ProvidersLdapIdParams) GetUnlistableGroups() []string`

GetUnlistableGroups returns the UnlistableGroups field if non-nil, zero value otherwise.

### GetUnlistableGroupsOk

`func (o *V11ProvidersLdapIdParams) GetUnlistableGroupsOk() (*[]string, bool)`

GetUnlistableGroupsOk returns a tuple with the UnlistableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnlistableGroups

`func (o *V11ProvidersLdapIdParams) SetUnlistableGroups(v []string)`

SetUnlistableGroups sets UnlistableGroups field to given value.

### HasUnlistableGroups

`func (o *V11ProvidersLdapIdParams) HasUnlistableGroups() bool`

HasUnlistableGroups returns a boolean if a field has been set.

### GetUnlistableUsers

`func (o *V11ProvidersLdapIdParams) GetUnlistableUsers() []string`

GetUnlistableUsers returns the UnlistableUsers field if non-nil, zero value otherwise.

### GetUnlistableUsersOk

`func (o *V11ProvidersLdapIdParams) GetUnlistableUsersOk() (*[]string, bool)`

GetUnlistableUsersOk returns a tuple with the UnlistableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnlistableUsers

`func (o *V11ProvidersLdapIdParams) SetUnlistableUsers(v []string)`

SetUnlistableUsers sets UnlistableUsers field to given value.

### HasUnlistableUsers

`func (o *V11ProvidersLdapIdParams) HasUnlistableUsers() bool`

HasUnlistableUsers returns a boolean if a field has been set.

### GetUserBaseDn

`func (o *V11ProvidersLdapIdParams) GetUserBaseDn() string`

GetUserBaseDn returns the UserBaseDn field if non-nil, zero value otherwise.

### GetUserBaseDnOk

`func (o *V11ProvidersLdapIdParams) GetUserBaseDnOk() (*string, bool)`

GetUserBaseDnOk returns a tuple with the UserBaseDn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserBaseDn

`func (o *V11ProvidersLdapIdParams) SetUserBaseDn(v string)`

SetUserBaseDn sets UserBaseDn field to given value.

### HasUserBaseDn

`func (o *V11ProvidersLdapIdParams) HasUserBaseDn() bool`

HasUserBaseDn returns a boolean if a field has been set.

### GetUserDomain

`func (o *V11ProvidersLdapIdParams) GetUserDomain() string`

GetUserDomain returns the UserDomain field if non-nil, zero value otherwise.

### GetUserDomainOk

`func (o *V11ProvidersLdapIdParams) GetUserDomainOk() (*string, bool)`

GetUserDomainOk returns a tuple with the UserDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserDomain

`func (o *V11ProvidersLdapIdParams) SetUserDomain(v string)`

SetUserDomain sets UserDomain field to given value.

### HasUserDomain

`func (o *V11ProvidersLdapIdParams) HasUserDomain() bool`

HasUserDomain returns a boolean if a field has been set.

### GetUserFilter

`func (o *V11ProvidersLdapIdParams) GetUserFilter() string`

GetUserFilter returns the UserFilter field if non-nil, zero value otherwise.

### GetUserFilterOk

`func (o *V11ProvidersLdapIdParams) GetUserFilterOk() (*string, bool)`

GetUserFilterOk returns a tuple with the UserFilter field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserFilter

`func (o *V11ProvidersLdapIdParams) SetUserFilter(v string)`

SetUserFilter sets UserFilter field to given value.

### HasUserFilter

`func (o *V11ProvidersLdapIdParams) HasUserFilter() bool`

HasUserFilter returns a boolean if a field has been set.

### GetUserSearchScope

`func (o *V11ProvidersLdapIdParams) GetUserSearchScope() string`

GetUserSearchScope returns the UserSearchScope field if non-nil, zero value otherwise.

### GetUserSearchScopeOk

`func (o *V11ProvidersLdapIdParams) GetUserSearchScopeOk() (*string, bool)`

GetUserSearchScopeOk returns a tuple with the UserSearchScope field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserSearchScope

`func (o *V11ProvidersLdapIdParams) SetUserSearchScope(v string)`

SetUserSearchScope sets UserSearchScope field to given value.

### HasUserSearchScope

`func (o *V11ProvidersLdapIdParams) HasUserSearchScope() bool`

HasUserSearchScope returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


