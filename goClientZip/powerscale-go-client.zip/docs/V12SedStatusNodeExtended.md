# V12SedStatusNodeExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ErrorMsg** | Pointer to **string** | information of the error if there is an error status. Empty if no error occurred. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Location** | Pointer to **string** | Current location of the key. | [optional] 
**RemoteKeyId** | Pointer to **string** | Key ID in the remote KMIP server. | [optional] 
**Status** | Pointer to **string** | Current key migration status. If no SEDs are avaiable and KMIP is not supported, it will show OFFLINE status. | [optional] 

## Methods

### NewV12SedStatusNodeExtended

`func NewV12SedStatusNodeExtended() *V12SedStatusNodeExtended`

NewV12SedStatusNodeExtended instantiates a new V12SedStatusNodeExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SedStatusNodeExtendedWithDefaults

`func NewV12SedStatusNodeExtendedWithDefaults() *V12SedStatusNodeExtended`

NewV12SedStatusNodeExtendedWithDefaults instantiates a new V12SedStatusNodeExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetErrorMsg

`func (o *V12SedStatusNodeExtended) GetErrorMsg() string`

GetErrorMsg returns the ErrorMsg field if non-nil, zero value otherwise.

### GetErrorMsgOk

`func (o *V12SedStatusNodeExtended) GetErrorMsgOk() (*string, bool)`

GetErrorMsgOk returns a tuple with the ErrorMsg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetErrorMsg

`func (o *V12SedStatusNodeExtended) SetErrorMsg(v string)`

SetErrorMsg sets ErrorMsg field to given value.

### HasErrorMsg

`func (o *V12SedStatusNodeExtended) HasErrorMsg() bool`

HasErrorMsg returns a boolean if a field has been set.

### GetId

`func (o *V12SedStatusNodeExtended) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12SedStatusNodeExtended) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12SedStatusNodeExtended) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V12SedStatusNodeExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V12SedStatusNodeExtended) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12SedStatusNodeExtended) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12SedStatusNodeExtended) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V12SedStatusNodeExtended) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetLocation

`func (o *V12SedStatusNodeExtended) GetLocation() string`

GetLocation returns the Location field if non-nil, zero value otherwise.

### GetLocationOk

`func (o *V12SedStatusNodeExtended) GetLocationOk() (*string, bool)`

GetLocationOk returns a tuple with the Location field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocation

`func (o *V12SedStatusNodeExtended) SetLocation(v string)`

SetLocation sets Location field to given value.

### HasLocation

`func (o *V12SedStatusNodeExtended) HasLocation() bool`

HasLocation returns a boolean if a field has been set.

### GetRemoteKeyId

`func (o *V12SedStatusNodeExtended) GetRemoteKeyId() string`

GetRemoteKeyId returns the RemoteKeyId field if non-nil, zero value otherwise.

### GetRemoteKeyIdOk

`func (o *V12SedStatusNodeExtended) GetRemoteKeyIdOk() (*string, bool)`

GetRemoteKeyIdOk returns a tuple with the RemoteKeyId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteKeyId

`func (o *V12SedStatusNodeExtended) SetRemoteKeyId(v string)`

SetRemoteKeyId sets RemoteKeyId field to given value.

### HasRemoteKeyId

`func (o *V12SedStatusNodeExtended) HasRemoteKeyId() bool`

HasRemoteKeyId returns a boolean if a field has been set.

### GetStatus

`func (o *V12SedStatusNodeExtended) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12SedStatusNodeExtended) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12SedStatusNodeExtended) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V12SedStatusNodeExtended) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


