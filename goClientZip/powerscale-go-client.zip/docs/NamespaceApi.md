# \NamespaceApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CopyDirectory**](NamespaceApi.md#CopyDirectory) | **Put** /namespace/{DirectoryCopyTarget} | 
[**CopyFile**](NamespaceApi.md#CopyFile) | **Put** /namespace/{FileCopyTarget} | 
[**CreateAccessPoint**](NamespaceApi.md#CreateAccessPoint) | **Put** /namespace/AccessPointName&#x3D;{AccessPointName} | 
[**CreateDirectory**](NamespaceApi.md#CreateDirectory) | **Put** /namespace/{DirectoryPath} | 
[**CreateDirectoryWithAccessPointContainerPath**](NamespaceApi.md#CreateDirectoryWithAccessPointContainerPath) | **Put** /namespace/{AccessPoint}/{ContainerPath} | 
[**CreateFile**](NamespaceApi.md#CreateFile) | **Put** /namespace/FilePath&#x3D;{FilePath} | 
[**DeleteAccessPoint**](NamespaceApi.md#DeleteAccessPoint) | **Delete** /namespace/AccessPointName&#x3D;{AccessPointName} | 
[**DeleteDirectory**](NamespaceApi.md#DeleteDirectory) | **Delete** /namespace/{DirectoryPath} | 
[**DeleteDirectoryWithAccessPointContainerPath**](NamespaceApi.md#DeleteDirectoryWithAccessPointContainerPath) | **Delete** /namespace/{AccessPoint}/{ContainerPath} | 
[**DeleteFile**](NamespaceApi.md#DeleteFile) | **Delete** /namespace/FilePath&#x3D;{FilePath} | 
[**GetAcl**](NamespaceApi.md#GetAcl) | **Get** /namespace/{NamespacePath} | 
[**GetDirectoryAttributes**](NamespaceApi.md#GetDirectoryAttributes) | **Head** /namespace/{DirectoryPath} | 
[**GetDirectoryContents**](NamespaceApi.md#GetDirectoryContents) | **Get** /namespace/{DirectoryPath} | 
[**GetDirectoryMetadata**](NamespaceApi.md#GetDirectoryMetadata) | **Get** /namespace/{DirectoryMetadataPath} | 
[**GetDirectoryWithAccessPointContainerPath**](NamespaceApi.md#GetDirectoryWithAccessPointContainerPath) | **Get** /namespace/{AccessPoint}/{ContainerPath} | 
[**GetFileAttributes**](NamespaceApi.md#GetFileAttributes) | **Head** /namespace/FilePath&#x3D;{FilePath} | 
[**GetFileContents**](NamespaceApi.md#GetFileContents) | **Get** /namespace/FilePath&#x3D;{FilePath} | 
[**GetFileMetadata**](NamespaceApi.md#GetFileMetadata) | **Get** /namespace/FileMetadataPath&#x3D;{FileMetadataPath} | 
[**GetWormProperties**](NamespaceApi.md#GetWormProperties) | **Get** /namespace/{WormFilePath} | 
[**ListAccessPoints**](NamespaceApi.md#ListAccessPoints) | **Get** /namespace | 
[**MoveDirectory**](NamespaceApi.md#MoveDirectory) | **Post** /namespace/{DirectoryPath} | 
[**MoveDirectoryWithAccessPointContainerPath**](NamespaceApi.md#MoveDirectoryWithAccessPointContainerPath) | **Post** /namespace/{AccessPoint}/{ContainerPath} | 
[**MoveFile**](NamespaceApi.md#MoveFile) | **Post** /namespace/FilePath&#x3D;{FilePath} | 
[**QueryDirectory**](NamespaceApi.md#QueryDirectory) | **Post** /namespace/QueryPath&#x3D;{QueryPath} | 
[**SetAcl**](NamespaceApi.md#SetAcl) | **Put** /namespace/{NamespacePath} | 
[**SetDirectoryMetadata**](NamespaceApi.md#SetDirectoryMetadata) | **Put** /namespace/{DirectoryMetadataPath} | 
[**SetFileMetadata**](NamespaceApi.md#SetFileMetadata) | **Put** /namespace/FileMetadataPath&#x3D;{FileMetadataPath} | 
[**SetWormProperties**](NamespaceApi.md#SetWormProperties) | **Put** /namespace/{WormFilePath} | 



## CopyDirectory

> CopyErrors CopyDirectory(ctx, directoryCopyTarget).XIsiIfsCopySource(xIsiIfsCopySource).Overwrite(overwrite).Merge(merge).Continue_(continue_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    directoryCopyTarget := "directoryCopyTarget_example" // string | Directory copy destination relative to /.
    xIsiIfsCopySource := "xIsiIfsCopySource_example" // string | Specifies the full path to the source directory.
    overwrite := true // bool | Deletes and replaces the existing user attributes and ACLs of the directory with user-specified attributes and ACLS from the header, when set to true. (optional)
    merge := true // bool | Specifies if the contents of a directory should be merged with an existing directory with the same name. (optional)
    continue_ := true // bool | Specifies whether to continue the copy operation on remaining objects when there is a conflict or error. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.CopyDirectory(context.Background(), directoryCopyTarget).XIsiIfsCopySource(xIsiIfsCopySource).Overwrite(overwrite).Merge(merge).Continue_(continue_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.CopyDirectory``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CopyDirectory`: CopyErrors
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.CopyDirectory`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**directoryCopyTarget** | **string** | Directory copy destination relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiCopyDirectoryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **xIsiIfsCopySource** | **string** | Specifies the full path to the source directory. | 
 **overwrite** | **bool** | Deletes and replaces the existing user attributes and ACLs of the directory with user-specified attributes and ACLS from the header, when set to true. | 
 **merge** | **bool** | Specifies if the contents of a directory should be merged with an existing directory with the same name. | 
 **continue_** | **bool** | Specifies whether to continue the copy operation on remaining objects when there is a conflict or error. | 

### Return type

[**CopyErrors**](CopyErrors.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CopyFile

> CopyErrors CopyFile(ctx, fileCopyTarget).XIsiIfsCopySource(xIsiIfsCopySource).Clone(clone).Snapshot(snapshot).Overwrite(overwrite).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    fileCopyTarget := "fileCopyTarget_example" // string | File copy destination relative to /.
    xIsiIfsCopySource := "xIsiIfsCopySource_example" // string | Specifies the full path to the source file.
    clone := true // bool | You must set this parameter to true in order to clone a file. (optional)
    snapshot := "snapshot_example" // string | Specifies a snapshot name to clone the file from. (optional)
    overwrite := true // bool | Specifies if an existing file should be overwritten by a new file with the same name. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.CopyFile(context.Background(), fileCopyTarget).XIsiIfsCopySource(xIsiIfsCopySource).Clone(clone).Snapshot(snapshot).Overwrite(overwrite).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.CopyFile``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CopyFile`: CopyErrors
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.CopyFile`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**fileCopyTarget** | **string** | File copy destination relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiCopyFileRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **xIsiIfsCopySource** | **string** | Specifies the full path to the source file. | 
 **clone** | **bool** | You must set this parameter to true in order to clone a file. | 
 **snapshot** | **string** | Specifies a snapshot name to clone the file from. | 
 **overwrite** | **bool** | Specifies if an existing file should be overwritten by a new file with the same name. | 

### Return type

[**CopyErrors**](CopyErrors.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAccessPoint

> map[string]interface{} CreateAccessPoint(ctx, accessPointName).AccessPoint(accessPoint).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    accessPointName := "accessPointName_example" // string | Access point name.
    accessPoint := *openapiclient.NewAccessPointCreateParams("Path_example") // AccessPointCreateParams | Access point parameters model.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.CreateAccessPoint(context.Background(), accessPointName).AccessPoint(accessPoint).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.CreateAccessPoint``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAccessPoint`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.CreateAccessPoint`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**accessPointName** | **string** | Access point name. | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAccessPointRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **accessPoint** | [**AccessPointCreateParams**](AccessPointCreateParams.md) | Access point parameters model. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateDirectory

> map[string]interface{} CreateDirectory(ctx, directoryPath).XIsiIfsTargetType(xIsiIfsTargetType).XIsiIfsAccessControl(xIsiIfsAccessControl).XIsiIfsNodePoolName(xIsiIfsNodePoolName).Recursive(recursive).Overwrite(overwrite).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    directoryPath := "directoryPath_example" // string | Directory path relative to /.
    xIsiIfsTargetType := "xIsiIfsTargetType_example" // string | Specifies the resource type. (default to "container")
    xIsiIfsAccessControl := "xIsiIfsAccessControl_example" // string | Specifies a pre-defined ACL value or POSIX mode with a string in octal string format. (optional) (default to "0700")
    xIsiIfsNodePoolName := "xIsiIfsNodePoolName_example" // string | Specifies a pre-defined ACL value or POSIX mode with a string. (optional)
    recursive := true // bool | Specifies the OneFS node pool name. (optional)
    overwrite := true // bool | Deletes and replaces the existing user attributes and ACLs of the directory with user-specified attributes and ACLS from the header, when set to true. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.CreateDirectory(context.Background(), directoryPath).XIsiIfsTargetType(xIsiIfsTargetType).XIsiIfsAccessControl(xIsiIfsAccessControl).XIsiIfsNodePoolName(xIsiIfsNodePoolName).Recursive(recursive).Overwrite(overwrite).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.CreateDirectory``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDirectory`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.CreateDirectory`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**directoryPath** | **string** | Directory path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateDirectoryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **xIsiIfsTargetType** | **string** | Specifies the resource type. | [default to &quot;container&quot;]
 **xIsiIfsAccessControl** | **string** | Specifies a pre-defined ACL value or POSIX mode with a string in octal string format. | [default to &quot;0700&quot;]
 **xIsiIfsNodePoolName** | **string** | Specifies a pre-defined ACL value or POSIX mode with a string. | 
 **recursive** | **bool** | Specifies the OneFS node pool name. | 
 **overwrite** | **bool** | Deletes and replaces the existing user attributes and ACLs of the directory with user-specified attributes and ACLS from the header, when set to true. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateDirectoryWithAccessPointContainerPath

> map[string]interface{} CreateDirectoryWithAccessPointContainerPath(ctx, accessPoint, containerPath).XIsiIfsTargetType(xIsiIfsTargetType).XIsiIfsAccessControl(xIsiIfsAccessControl).XIsiIfsNodePoolName(xIsiIfsNodePoolName).Recursive(recursive).Overwrite(overwrite).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    accessPoint := "accessPoint_example" // string | Access point.
    containerPath := "containerPath_example" // string | Directory path relative to access point.
    xIsiIfsTargetType := "xIsiIfsTargetType_example" // string | Specifies the resource type. (default to "container")
    xIsiIfsAccessControl := "xIsiIfsAccessControl_example" // string | Specifies a pre-defined ACL value or POSIX mode with a string in octal string format. (optional) (default to "0700")
    xIsiIfsNodePoolName := "xIsiIfsNodePoolName_example" // string | Specifies a pre-defined ACL value or POSIX mode with a string. (optional)
    recursive := true // bool | Specifies the OneFS node pool name. (optional)
    overwrite := true // bool | Deletes and replaces the existing user attributes and ACLs of the directory with user-specified attributes and ACLS from the header, when set to true. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.CreateDirectoryWithAccessPointContainerPath(context.Background(), accessPoint, containerPath).XIsiIfsTargetType(xIsiIfsTargetType).XIsiIfsAccessControl(xIsiIfsAccessControl).XIsiIfsNodePoolName(xIsiIfsNodePoolName).Recursive(recursive).Overwrite(overwrite).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.CreateDirectoryWithAccessPointContainerPath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDirectoryWithAccessPointContainerPath`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.CreateDirectoryWithAccessPointContainerPath`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**accessPoint** | **string** | Access point. | 
**containerPath** | **string** | Directory path relative to access point. | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateDirectoryWithAccessPointContainerPathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **xIsiIfsTargetType** | **string** | Specifies the resource type. | [default to &quot;container&quot;]
 **xIsiIfsAccessControl** | **string** | Specifies a pre-defined ACL value or POSIX mode with a string in octal string format. | [default to &quot;0700&quot;]
 **xIsiIfsNodePoolName** | **string** | Specifies a pre-defined ACL value or POSIX mode with a string. | 
 **recursive** | **bool** | Specifies the OneFS node pool name. | 
 **overwrite** | **bool** | Deletes and replaces the existing user attributes and ACLs of the directory with user-specified attributes and ACLS from the header, when set to true. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateFile

> map[string]interface{} CreateFile(ctx, filePath).XIsiIfsTargetType(xIsiIfsTargetType).FileContents(fileContents).XIsiIfsAccessControl(xIsiIfsAccessControl).ContentEncoding(contentEncoding).ContentType(contentType).Overwrite(overwrite).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    filePath := "filePath_example" // string | File path relative to /.
    xIsiIfsTargetType := "xIsiIfsTargetType_example" // string | Specifies the resource type. (default to "object")
    fileContents := "fileContents_example" // string | The contents of the file object.
    xIsiIfsAccessControl := "xIsiIfsAccessControl_example" // string | Specifies a pre-defined ACL value or POSIX mode with a string in octal string format. (optional) (default to "0600")
    contentEncoding := "contentEncoding_example" // string | Specifies the content encoding that was applied to the object content, so that decoding can be applied when retrieving the content. (optional)
    contentType := "contentType_example" // string | Specifies a standard MIME-type description of the content format. (optional) (default to "binary/octet-stream")
    overwrite := true // bool | Deletes and replaces the existing user attributes and ACLs of the directory with user-specified attributes and ACLS from the header, when set to true. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.CreateFile(context.Background(), filePath).XIsiIfsTargetType(xIsiIfsTargetType).FileContents(fileContents).XIsiIfsAccessControl(xIsiIfsAccessControl).ContentEncoding(contentEncoding).ContentType(contentType).Overwrite(overwrite).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.CreateFile``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateFile`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.CreateFile`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**filePath** | **string** | File path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateFileRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **xIsiIfsTargetType** | **string** | Specifies the resource type. | [default to &quot;object&quot;]
 **fileContents** | **string** | The contents of the file object. | 
 **xIsiIfsAccessControl** | **string** | Specifies a pre-defined ACL value or POSIX mode with a string in octal string format. | [default to &quot;0600&quot;]
 **contentEncoding** | **string** | Specifies the content encoding that was applied to the object content, so that decoding can be applied when retrieving the content. | 
 **contentType** | **string** | Specifies a standard MIME-type description of the content format. | [default to &quot;binary/octet-stream&quot;]
 **overwrite** | **bool** | Deletes and replaces the existing user attributes and ACLs of the directory with user-specified attributes and ACLS from the header, when set to true. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAccessPoint

> map[string]interface{} DeleteAccessPoint(ctx, accessPointName).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    accessPointName := "accessPointName_example" // string | Access point name.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.DeleteAccessPoint(context.Background(), accessPointName).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.DeleteAccessPoint``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `DeleteAccessPoint`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.DeleteAccessPoint`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**accessPointName** | **string** | Access point name. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAccessPointRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDirectory

> map[string]interface{} DeleteDirectory(ctx, directoryPath).Recursive(recursive).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    directoryPath := "directoryPath_example" // string | Directory path relative to /.
    recursive := true // bool | Deletes directories recursively, when set to true. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.DeleteDirectory(context.Background(), directoryPath).Recursive(recursive).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.DeleteDirectory``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `DeleteDirectory`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.DeleteDirectory`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**directoryPath** | **string** | Directory path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDirectoryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **recursive** | **bool** | Deletes directories recursively, when set to true. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDirectoryWithAccessPointContainerPath

> map[string]interface{} DeleteDirectoryWithAccessPointContainerPath(ctx, accessPoint, containerPath).Recursive(recursive).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    accessPoint := "accessPoint_example" // string | Access point.
    containerPath := "containerPath_example" // string | Directory path relative to access point.
    recursive := true // bool | Deletes directories recursively, when set to true. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.DeleteDirectoryWithAccessPointContainerPath(context.Background(), accessPoint, containerPath).Recursive(recursive).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.DeleteDirectoryWithAccessPointContainerPath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `DeleteDirectoryWithAccessPointContainerPath`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.DeleteDirectoryWithAccessPointContainerPath`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**accessPoint** | **string** | Access point. | 
**containerPath** | **string** | Directory path relative to access point. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDirectoryWithAccessPointContainerPathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **recursive** | **bool** | Deletes directories recursively, when set to true. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFile

> map[string]interface{} DeleteFile(ctx, filePath).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    filePath := "filePath_example" // string | File path relative to /.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.DeleteFile(context.Background(), filePath).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.DeleteFile``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `DeleteFile`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.DeleteFile`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**filePath** | **string** | File path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteFileRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAcl

> NamespaceAcl GetAcl(ctx, namespacePath).Acl(acl).Nsaccess(nsaccess).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    namespacePath := "namespacePath_example" // string | Namespace path relative to /.
    acl := true // bool | Show access control lists.
    nsaccess := true // bool | Indicates that the operation is on the access point instead of the store path. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.GetAcl(context.Background(), namespacePath).Acl(acl).Nsaccess(nsaccess).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.GetAcl``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAcl`: NamespaceAcl
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.GetAcl`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**namespacePath** | **string** | Namespace path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAclRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **acl** | **bool** | Show access control lists. | 
 **nsaccess** | **bool** | Indicates that the operation is on the access point instead of the store path. | 

### Return type

[**NamespaceAcl**](NamespaceAcl.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDirectoryAttributes

> map[string]interface{} GetDirectoryAttributes(ctx, directoryPath).IfModifiedSince(ifModifiedSince).IfUnmodifiedSince(ifUnmodifiedSince).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    directoryPath := "directoryPath_example" // string | Directory path relative to /.
    ifModifiedSince := "ifModifiedSince_example" // string | Returns only files that were modified since the specified time. If no files were modified since this time, a 304 message is returned. (optional)
    ifUnmodifiedSince := "ifUnmodifiedSince_example" // string | Returns only files that were not modified since the specified time. If there are no unmodified files since this time, a 412 message is returned to indicate that the precondition failed. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.GetDirectoryAttributes(context.Background(), directoryPath).IfModifiedSince(ifModifiedSince).IfUnmodifiedSince(ifUnmodifiedSince).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.GetDirectoryAttributes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDirectoryAttributes`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.GetDirectoryAttributes`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**directoryPath** | **string** | Directory path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDirectoryAttributesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **ifModifiedSince** | **string** | Returns only files that were modified since the specified time. If no files were modified since this time, a 304 message is returned. | 
 **ifUnmodifiedSince** | **string** | Returns only files that were not modified since the specified time. If there are no unmodified files since this time, a 412 message is returned to indicate that the precondition failed. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDirectoryContents

> NamespaceObjects GetDirectoryContents(ctx, directoryPath).Detail(detail).Limit(limit).Resume(resume).Sort(sort).Dir(dir).Type_(type_).Hidden(hidden).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    directoryPath := "directoryPath_example" // string | Directory path relative to /.
    detail := "detail_example" // string | Specifies which object attributes are displayed. (optional)
    limit := int32(56) // int32 | Specifies the maximum number of objects to send to the client. (optional)
    resume := "resume_example" // string | Specifies a token to return in the JSON result to indicate when there is a next page. (optional)
    sort := "sort_example" // string | Specifies one or more attributes to sort on the directory entries. (optional)
    dir := "dir_example" // string | Specifies the sort direction. This value can be either ascending (ASC) or descending (DESC). (optional)
    type_ := "type__example" // string | Specifies the object type to return, which can be one of the following values: container, object, pipe, character_device, block_device, symbolic_link, socket, or whiteout_file. (optional)
    hidden := true // bool | Specifies if hidden objects are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.GetDirectoryContents(context.Background(), directoryPath).Detail(detail).Limit(limit).Resume(resume).Sort(sort).Dir(dir).Type_(type_).Hidden(hidden).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.GetDirectoryContents``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDirectoryContents`: NamespaceObjects
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.GetDirectoryContents`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**directoryPath** | **string** | Directory path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDirectoryContentsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **detail** | **string** | Specifies which object attributes are displayed. | 
 **limit** | **int32** | Specifies the maximum number of objects to send to the client. | 
 **resume** | **string** | Specifies a token to return in the JSON result to indicate when there is a next page. | 
 **sort** | **string** | Specifies one or more attributes to sort on the directory entries. | 
 **dir** | **string** | Specifies the sort direction. This value can be either ascending (ASC) or descending (DESC). | 
 **type_** | **string** | Specifies the object type to return, which can be one of the following values: container, object, pipe, character_device, block_device, symbolic_link, socket, or whiteout_file. | 
 **hidden** | **bool** | Specifies if hidden objects are returned. | 

### Return type

[**NamespaceObjects**](NamespaceObjects.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDirectoryMetadata

> NamespaceMetadataList GetDirectoryMetadata(ctx, directoryMetadataPath).Metadata(metadata).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    directoryMetadataPath := "directoryMetadataPath_example" // string | Directory path relative to /.
    metadata := true // bool | Show directory metadata.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.GetDirectoryMetadata(context.Background(), directoryMetadataPath).Metadata(metadata).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.GetDirectoryMetadata``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDirectoryMetadata`: NamespaceMetadataList
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.GetDirectoryMetadata`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**directoryMetadataPath** | **string** | Directory path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDirectoryMetadataRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **metadata** | **bool** | Show directory metadata. | 

### Return type

[**NamespaceMetadataList**](NamespaceMetadataList.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDirectoryWithAccessPointContainerPath

> NamespaceObjects GetDirectoryWithAccessPointContainerPath(ctx, accessPoint, containerPath).Detail(detail).Limit(limit).Resume(resume).Sort(sort).Dir(dir).Type_(type_).Hidden(hidden).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    accessPoint := "accessPoint_example" // string | Access point.
    containerPath := "containerPath_example" // string | Container path relative to access point.
    detail := "detail_example" // string | Specifies which object attributes are displayed. (optional)
    limit := int32(56) // int32 | Specifies the maximum number of objects to send to the client. (optional)
    resume := "resume_example" // string | Specifies a token to return in the JSON result to indicate when there is a next page. (optional)
    sort := "sort_example" // string | Specifies one or more attributes to sort on the directory entries. (optional)
    dir := "dir_example" // string | Specifies the sort direction. This value can be either ascending (ASC) or descending (DESC). (optional)
    type_ := "type__example" // string | Specifies the object type to return, which can be one of the following values: container, object, pipe, character_device, block_device, symbolic_link, socket, or whiteout_file. (optional)
    hidden := true // bool | Specifies if hidden objects are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.GetDirectoryWithAccessPointContainerPath(context.Background(), accessPoint, containerPath).Detail(detail).Limit(limit).Resume(resume).Sort(sort).Dir(dir).Type_(type_).Hidden(hidden).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.GetDirectoryWithAccessPointContainerPath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDirectoryWithAccessPointContainerPath`: NamespaceObjects
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.GetDirectoryWithAccessPointContainerPath`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**accessPoint** | **string** | Access point. | 
**containerPath** | **string** | Container path relative to access point. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDirectoryWithAccessPointContainerPathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **detail** | **string** | Specifies which object attributes are displayed. | 
 **limit** | **int32** | Specifies the maximum number of objects to send to the client. | 
 **resume** | **string** | Specifies a token to return in the JSON result to indicate when there is a next page. | 
 **sort** | **string** | Specifies one or more attributes to sort on the directory entries. | 
 **dir** | **string** | Specifies the sort direction. This value can be either ascending (ASC) or descending (DESC). | 
 **type_** | **string** | Specifies the object type to return, which can be one of the following values: container, object, pipe, character_device, block_device, symbolic_link, socket, or whiteout_file. | 
 **hidden** | **bool** | Specifies if hidden objects are returned. | 

### Return type

[**NamespaceObjects**](NamespaceObjects.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFileAttributes

> map[string]interface{} GetFileAttributes(ctx, filePath).IfModifiedSince(ifModifiedSince).IfUnmodifiedSince(ifUnmodifiedSince).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    filePath := "filePath_example" // string | File path relative to /.
    ifModifiedSince := "ifModifiedSince_example" // string | Returns only files that were modified since the specified time. If no files were modified since this time, a 304 message is returned. (optional)
    ifUnmodifiedSince := "ifUnmodifiedSince_example" // string | Returns only files that were not modified since the specified time. If there are no unmodified files since this time, a 412 message is returned to indicate that the precondition failed. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.GetFileAttributes(context.Background(), filePath).IfModifiedSince(ifModifiedSince).IfUnmodifiedSince(ifUnmodifiedSince).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.GetFileAttributes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFileAttributes`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.GetFileAttributes`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**filePath** | **string** | File path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFileAttributesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **ifModifiedSince** | **string** | Returns only files that were modified since the specified time. If no files were modified since this time, a 304 message is returned. | 
 **ifUnmodifiedSince** | **string** | Returns only files that were not modified since the specified time. If there are no unmodified files since this time, a 412 message is returned to indicate that the precondition failed. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFileContents

> map[string]interface{} GetFileContents(ctx, filePath).Range_(range_).IfModifiedSince(ifModifiedSince).IfUnmodifiedSince(ifUnmodifiedSince).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    filePath := "filePath_example" // string | File path relative to /.
    range_ := "range__example" // string | Returns the specified range bytes of an object.  (optional)
    ifModifiedSince := "ifModifiedSince_example" // string | Returns only files that were modified since the specified time. If no files were modified since this time, a 304 message is returned. (optional)
    ifUnmodifiedSince := "ifUnmodifiedSince_example" // string | Returns only files that were not modified since the specified time. If there are no unmodified files since this time, a 412 message is returned to indicate that the precondition failed. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.GetFileContents(context.Background(), filePath).Range_(range_).IfModifiedSince(ifModifiedSince).IfUnmodifiedSince(ifUnmodifiedSince).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.GetFileContents``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFileContents`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.GetFileContents`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**filePath** | **string** | File path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFileContentsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **range_** | **string** | Returns the specified range bytes of an object.  | 
 **ifModifiedSince** | **string** | Returns only files that were modified since the specified time. If no files were modified since this time, a 304 message is returned. | 
 **ifUnmodifiedSince** | **string** | Returns only files that were not modified since the specified time. If there are no unmodified files since this time, a 412 message is returned to indicate that the precondition failed. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFileMetadata

> NamespaceMetadataList GetFileMetadata(ctx, fileMetadataPath).Metadata(metadata).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    fileMetadataPath := "fileMetadataPath_example" // string | File path relative to /.
    metadata := true // bool | Show file metadata.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.GetFileMetadata(context.Background(), fileMetadataPath).Metadata(metadata).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.GetFileMetadata``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFileMetadata`: NamespaceMetadataList
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.GetFileMetadata`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**fileMetadataPath** | **string** | File path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFileMetadataRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **metadata** | **bool** | Show file metadata. | 

### Return type

[**NamespaceMetadataList**](NamespaceMetadataList.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetWormProperties

> WormProperties GetWormProperties(ctx, wormFilePath).Worm(worm).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    wormFilePath := "wormFilePath_example" // string | Write once read many file path relative to /.
    worm := true // bool | View WORM properties

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.GetWormProperties(context.Background(), wormFilePath).Worm(worm).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.GetWormProperties``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetWormProperties`: WormProperties
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.GetWormProperties`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**wormFilePath** | **string** | Write once read many file path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetWormPropertiesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **worm** | **bool** | View WORM properties | 

### Return type

[**WormProperties**](WormProperties.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAccessPoints

> NamespaceAccessPoints ListAccessPoints(ctx).Versions(versions).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    versions := true // bool | Protocol versions that are supported for the current namespace access server. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.ListAccessPoints(context.Background()).Versions(versions).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.ListAccessPoints``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAccessPoints`: NamespaceAccessPoints
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.ListAccessPoints`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAccessPointsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **versions** | **bool** | Protocol versions that are supported for the current namespace access server. | 

### Return type

[**NamespaceAccessPoints**](NamespaceAccessPoints.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## MoveDirectory

> map[string]interface{} MoveDirectory(ctx, directoryPath).XIsiIfsSetLocation(xIsiIfsSetLocation).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    directoryPath := "directoryPath_example" // string | Directory path relative to /.
    xIsiIfsSetLocation := "xIsiIfsSetLocation_example" // string | Specifies the full path for the destination directory.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.MoveDirectory(context.Background(), directoryPath).XIsiIfsSetLocation(xIsiIfsSetLocation).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.MoveDirectory``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `MoveDirectory`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.MoveDirectory`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**directoryPath** | **string** | Directory path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiMoveDirectoryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **xIsiIfsSetLocation** | **string** | Specifies the full path for the destination directory. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## MoveDirectoryWithAccessPointContainerPath

> map[string]interface{} MoveDirectoryWithAccessPointContainerPath(ctx, accessPoint, containerPath).XIsiIfsSetLocation(xIsiIfsSetLocation).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    accessPoint := "accessPoint_example" // string | Access point.
    containerPath := "containerPath_example" // string | Directory path relative to access point.
    xIsiIfsSetLocation := "xIsiIfsSetLocation_example" // string | Specifies the full path for the destination directory.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.MoveDirectoryWithAccessPointContainerPath(context.Background(), accessPoint, containerPath).XIsiIfsSetLocation(xIsiIfsSetLocation).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.MoveDirectoryWithAccessPointContainerPath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `MoveDirectoryWithAccessPointContainerPath`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.MoveDirectoryWithAccessPointContainerPath`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**accessPoint** | **string** | Access point. | 
**containerPath** | **string** | Directory path relative to access point. | 

### Other Parameters

Other parameters are passed through a pointer to a apiMoveDirectoryWithAccessPointContainerPathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **xIsiIfsSetLocation** | **string** | Specifies the full path for the destination directory. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## MoveFile

> map[string]interface{} MoveFile(ctx, filePath).XIsiIfsSetLocation(xIsiIfsSetLocation).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    filePath := "filePath_example" // string | File path relative to /.
    xIsiIfsSetLocation := "xIsiIfsSetLocation_example" // string | Specifies the full path for the destination file. 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.MoveFile(context.Background(), filePath).XIsiIfsSetLocation(xIsiIfsSetLocation).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.MoveFile``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `MoveFile`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.MoveFile`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**filePath** | **string** | File path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiMoveFileRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **xIsiIfsSetLocation** | **string** | Specifies the full path for the destination file.  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## QueryDirectory

> NamespaceObjects QueryDirectory(ctx, queryPath).Query(query).DirectoryQuery(directoryQuery).Limit(limit).Detail(detail).Resume(resume).Sort(sort).Dir(dir).Type_(type_).Hidden(hidden).MaxDepth(maxDepth).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    queryPath := "queryPath_example" // string | Directory path relative to /.
    query := true // bool | Enable directory query.
    directoryQuery := *openapiclient.NewDirectoryQuery() // DirectoryQuery | Directory query parameters model.
    limit := int32(56) // int32 | Specifies the maximum number of objects to send to the client. You can set the value to a negative number to retrieve all objects. (optional)
    detail := "detail_example" // string | Specifies which object attributes are displayed. If the detail parameter is excluded, only the name of the object is returned. (optional)
    resume := "resume_example" // string | Specifies a token to return in the JSON result to indicate when there is a next page. (optional)
    sort := "sort_example" // string | Specifies one or more attributes to sort on the directory entries. (optional)
    dir := "dir_example" // string | Specifies the sort direction. This value can be either ascending (ASC) or descending (DESC). (optional)
    type_ := "type__example" // string | Specifies the object type to return, which can be one of the following values: container, object, pipe, character_device, block_device, symbolic_link, socket, or whiteout_file. (optional)
    hidden := true // bool | Specifies if hidden objects are returned. (optional)
    maxDepth := int32(56) // int32 | Specifies the maximum directory level depth to search for objects. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.QueryDirectory(context.Background(), queryPath).Query(query).DirectoryQuery(directoryQuery).Limit(limit).Detail(detail).Resume(resume).Sort(sort).Dir(dir).Type_(type_).Hidden(hidden).MaxDepth(maxDepth).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.QueryDirectory``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `QueryDirectory`: NamespaceObjects
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.QueryDirectory`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**queryPath** | **string** | Directory path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiQueryDirectoryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **query** | **bool** | Enable directory query. | 
 **directoryQuery** | [**DirectoryQuery**](DirectoryQuery.md) | Directory query parameters model. | 
 **limit** | **int32** | Specifies the maximum number of objects to send to the client. You can set the value to a negative number to retrieve all objects. | 
 **detail** | **string** | Specifies which object attributes are displayed. If the detail parameter is excluded, only the name of the object is returned. | 
 **resume** | **string** | Specifies a token to return in the JSON result to indicate when there is a next page. | 
 **sort** | **string** | Specifies one or more attributes to sort on the directory entries. | 
 **dir** | **string** | Specifies the sort direction. This value can be either ascending (ASC) or descending (DESC). | 
 **type_** | **string** | Specifies the object type to return, which can be one of the following values: container, object, pipe, character_device, block_device, symbolic_link, socket, or whiteout_file. | 
 **hidden** | **bool** | Specifies if hidden objects are returned. | 
 **maxDepth** | **int32** | Specifies the maximum directory level depth to search for objects. | 

### Return type

[**NamespaceObjects**](NamespaceObjects.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetAcl

> map[string]interface{} SetAcl(ctx, namespacePath).Acl(acl).NamespaceAcl(namespaceAcl).Nsaccess(nsaccess).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    namespacePath := "namespacePath_example" // string | Namespace path relative to /.
    acl := true // bool | Update access control lists.
    namespaceAcl := *openapiclient.NewNamespaceAcl() // NamespaceAcl | Namespace ACL parameters model.
    nsaccess := true // bool | Indicates that the operation is on the access point instead of the store path. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.SetAcl(context.Background(), namespacePath).Acl(acl).NamespaceAcl(namespaceAcl).Nsaccess(nsaccess).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.SetAcl``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `SetAcl`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.SetAcl`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**namespacePath** | **string** | Namespace path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiSetAclRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **acl** | **bool** | Update access control lists. | 
 **namespaceAcl** | [**NamespaceAcl**](NamespaceAcl.md) | Namespace ACL parameters model. | 
 **nsaccess** | **bool** | Indicates that the operation is on the access point instead of the store path. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetDirectoryMetadata

> map[string]interface{} SetDirectoryMetadata(ctx, directoryMetadataPath).Metadata(metadata).DirectoryMetadata(directoryMetadata).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    directoryMetadataPath := "directoryMetadataPath_example" // string | Directory path relative to /.
    metadata := true // bool | Set directory metadata.
    directoryMetadata := *openapiclient.NewNamespaceMetadata() // NamespaceMetadata | Directory metadata parameters model.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.SetDirectoryMetadata(context.Background(), directoryMetadataPath).Metadata(metadata).DirectoryMetadata(directoryMetadata).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.SetDirectoryMetadata``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `SetDirectoryMetadata`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.SetDirectoryMetadata`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**directoryMetadataPath** | **string** | Directory path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiSetDirectoryMetadataRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **metadata** | **bool** | Set directory metadata. | 
 **directoryMetadata** | [**NamespaceMetadata**](NamespaceMetadata.md) | Directory metadata parameters model. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetFileMetadata

> map[string]interface{} SetFileMetadata(ctx, fileMetadataPath).Metadata(metadata).FileMetadata(fileMetadata).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    fileMetadataPath := "fileMetadataPath_example" // string | File path relative to /.
    metadata := true // bool | Set file metadata.
    fileMetadata := *openapiclient.NewNamespaceMetadata() // NamespaceMetadata | File metadata parameters model.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.SetFileMetadata(context.Background(), fileMetadataPath).Metadata(metadata).FileMetadata(fileMetadata).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.SetFileMetadata``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `SetFileMetadata`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.SetFileMetadata`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**fileMetadataPath** | **string** | File path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiSetFileMetadataRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **metadata** | **bool** | Set file metadata. | 
 **fileMetadata** | [**NamespaceMetadata**](NamespaceMetadata.md) | File metadata parameters model. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## SetWormProperties

> map[string]interface{} SetWormProperties(ctx, wormFilePath).Worm(worm).WormProperties(wormProperties).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    wormFilePath := "wormFilePath_example" // string | Write once read many file path relative to /.
    worm := true // bool | View WORM properties
    wormProperties := *openapiclient.NewWormCreateParams() // WormCreateParams | WORM parameters model.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NamespaceApi.SetWormProperties(context.Background(), wormFilePath).Worm(worm).WormProperties(wormProperties).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NamespaceApi.SetWormProperties``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `SetWormProperties`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NamespaceApi.SetWormProperties`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**wormFilePath** | **string** | Write once read many file path relative to /. | 

### Other Parameters

Other parameters are passed through a pointer to a apiSetWormPropertiesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **worm** | **bool** | View WORM properties | 
 **wormProperties** | [**WormCreateParams**](WormCreateParams.md) | WORM parameters model. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

