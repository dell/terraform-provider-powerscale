# V10ClusterNodeStatusCpu

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Model** | Pointer to **string** | Manufacturer model description of this CPU. | [optional] 
**Overtemp** | Pointer to **string** | CPU overtemp state. | [optional] 
**Proc** | Pointer to **string** | Type of processor and core of this CPU. | [optional] 
**SpeedLimit** | Pointer to **string** | CPU throttling (expressed as a percentage). | [optional] 

## Methods

### NewV10ClusterNodeStatusCpu

`func NewV10ClusterNodeStatusCpu() *V10ClusterNodeStatusCpu`

NewV10ClusterNodeStatusCpu instantiates a new V10ClusterNodeStatusCpu object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeStatusCpuWithDefaults

`func NewV10ClusterNodeStatusCpuWithDefaults() *V10ClusterNodeStatusCpu`

NewV10ClusterNodeStatusCpuWithDefaults instantiates a new V10ClusterNodeStatusCpu object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetModel

`func (o *V10ClusterNodeStatusCpu) GetModel() string`

GetModel returns the Model field if non-nil, zero value otherwise.

### GetModelOk

`func (o *V10ClusterNodeStatusCpu) GetModelOk() (*string, bool)`

GetModelOk returns a tuple with the Model field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetModel

`func (o *V10ClusterNodeStatusCpu) SetModel(v string)`

SetModel sets Model field to given value.

### HasModel

`func (o *V10ClusterNodeStatusCpu) HasModel() bool`

HasModel returns a boolean if a field has been set.

### GetOvertemp

`func (o *V10ClusterNodeStatusCpu) GetOvertemp() string`

GetOvertemp returns the Overtemp field if non-nil, zero value otherwise.

### GetOvertempOk

`func (o *V10ClusterNodeStatusCpu) GetOvertempOk() (*string, bool)`

GetOvertempOk returns a tuple with the Overtemp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOvertemp

`func (o *V10ClusterNodeStatusCpu) SetOvertemp(v string)`

SetOvertemp sets Overtemp field to given value.

### HasOvertemp

`func (o *V10ClusterNodeStatusCpu) HasOvertemp() bool`

HasOvertemp returns a boolean if a field has been set.

### GetProc

`func (o *V10ClusterNodeStatusCpu) GetProc() string`

GetProc returns the Proc field if non-nil, zero value otherwise.

### GetProcOk

`func (o *V10ClusterNodeStatusCpu) GetProcOk() (*string, bool)`

GetProcOk returns a tuple with the Proc field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProc

`func (o *V10ClusterNodeStatusCpu) SetProc(v string)`

SetProc sets Proc field to given value.

### HasProc

`func (o *V10ClusterNodeStatusCpu) HasProc() bool`

HasProc returns a boolean if a field has been set.

### GetSpeedLimit

`func (o *V10ClusterNodeStatusCpu) GetSpeedLimit() string`

GetSpeedLimit returns the SpeedLimit field if non-nil, zero value otherwise.

### GetSpeedLimitOk

`func (o *V10ClusterNodeStatusCpu) GetSpeedLimitOk() (*string, bool)`

GetSpeedLimitOk returns a tuple with the SpeedLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpeedLimit

`func (o *V10ClusterNodeStatusCpu) SetSpeedLimit(v string)`

SetSpeedLimit sets SpeedLimit field to given value.

### HasSpeedLimit

`func (o *V10ClusterNodeStatusCpu) HasSpeedLimit() bool`

HasSpeedLimit returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


