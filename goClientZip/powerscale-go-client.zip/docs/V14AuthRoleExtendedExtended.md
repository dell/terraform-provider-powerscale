# V14AuthRoleExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | Pointer to **string** | Specifies the description of the role. | [optional] 
**Members** | Pointer to [**[]V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) | Specifies the users or groups that have this role. | [optional] 
**Name** | Pointer to **string** | Specifies the name of the role. | [optional] 
**Privileges** | Pointer to [**[]V14AuthIdNtokenPrivilegeItem**](V14AuthIdNtokenPrivilegeItem.md) | Specifies the privileges granted by this role. | [optional] 

## Methods

### NewV14AuthRoleExtendedExtended

`func NewV14AuthRoleExtendedExtended() *V14AuthRoleExtendedExtended`

NewV14AuthRoleExtendedExtended instantiates a new V14AuthRoleExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14AuthRoleExtendedExtendedWithDefaults

`func NewV14AuthRoleExtendedExtendedWithDefaults() *V14AuthRoleExtendedExtended`

NewV14AuthRoleExtendedExtendedWithDefaults instantiates a new V14AuthRoleExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDescription

`func (o *V14AuthRoleExtendedExtended) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V14AuthRoleExtendedExtended) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V14AuthRoleExtendedExtended) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V14AuthRoleExtendedExtended) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetMembers

`func (o *V14AuthRoleExtendedExtended) GetMembers() []V1AuthAccessAccessItemFileGroup`

GetMembers returns the Members field if non-nil, zero value otherwise.

### GetMembersOk

`func (o *V14AuthRoleExtendedExtended) GetMembersOk() (*[]V1AuthAccessAccessItemFileGroup, bool)`

GetMembersOk returns a tuple with the Members field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMembers

`func (o *V14AuthRoleExtendedExtended) SetMembers(v []V1AuthAccessAccessItemFileGroup)`

SetMembers sets Members field to given value.

### HasMembers

`func (o *V14AuthRoleExtendedExtended) HasMembers() bool`

HasMembers returns a boolean if a field has been set.

### GetName

`func (o *V14AuthRoleExtendedExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V14AuthRoleExtendedExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V14AuthRoleExtendedExtended) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V14AuthRoleExtendedExtended) HasName() bool`

HasName returns a boolean if a field has been set.

### GetPrivileges

`func (o *V14AuthRoleExtendedExtended) GetPrivileges() []V14AuthIdNtokenPrivilegeItem`

GetPrivileges returns the Privileges field if non-nil, zero value otherwise.

### GetPrivilegesOk

`func (o *V14AuthRoleExtendedExtended) GetPrivilegesOk() (*[]V14AuthIdNtokenPrivilegeItem, bool)`

GetPrivilegesOk returns a tuple with the Privileges field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrivileges

`func (o *V14AuthRoleExtendedExtended) SetPrivileges(v []V14AuthIdNtokenPrivilegeItem)`

SetPrivileges sets Privileges field to given value.

### HasPrivileges

`func (o *V14AuthRoleExtendedExtended) HasPrivileges() bool`

HasPrivileges returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


