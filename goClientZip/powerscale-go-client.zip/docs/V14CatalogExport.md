# V14CatalogExport

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**File** | **string** | Path to export the signed file to | 
**Hash** | **string** | The sha256 hash of the file stored in catalog | 

## Methods

### NewV14CatalogExport

`func NewV14CatalogExport(file string, hash string, ) *V14CatalogExport`

NewV14CatalogExport instantiates a new V14CatalogExport object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14CatalogExportWithDefaults

`func NewV14CatalogExportWithDefaults() *V14CatalogExport`

NewV14CatalogExportWithDefaults instantiates a new V14CatalogExport object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFile

`func (o *V14CatalogExport) GetFile() string`

GetFile returns the File field if non-nil, zero value otherwise.

### GetFileOk

`func (o *V14CatalogExport) GetFileOk() (*string, bool)`

GetFileOk returns a tuple with the File field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFile

`func (o *V14CatalogExport) SetFile(v string)`

SetFile sets File field to given value.


### GetHash

`func (o *V14CatalogExport) GetHash() string`

GetHash returns the Hash field if non-nil, zero value otherwise.

### GetHashOk

`func (o *V14CatalogExport) GetHashOk() (*string, bool)`

GetHashOk returns a tuple with the Hash field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHash

`func (o *V14CatalogExport) SetHash(v string)`

SetHash sets Hash field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


