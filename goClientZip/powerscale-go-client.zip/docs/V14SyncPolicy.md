# V14SyncPolicy

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AcceleratedFailback** | Pointer to **bool** | If set to true, SyncIQ will perform failback configuration tasks during the next job run, rather than waiting to perform those tasks during the failback process. Performing these tasks ahead of time will increase the speed of failback operations. | [optional] 
**Action** | **string** | If &#39;copy&#39;, source files will be copied to the target cluster.  If &#39;sync&#39;, the target directory will be made an image of the source directory:  Files and directories that have been deleted on the source, have been moved within the target directory, or no longer match the selection criteria will be deleted from the target directory. | 
**AllowCopyFb** | Pointer to **bool** | If set to true, SyncIQ will allow a policy with copy action failback which is not supported by default. | [optional] 
**BandwidthReservation** | Pointer to **int32** | The desired bandwidth reservation for this policy in kb/s. This feature will not activate unless a SyncIQ bandwidth rule is in effect. | [optional] 
**Changelist** | Pointer to **bool** | If true, retain previous source snapshot and incremental repstate, both of which are required for changelist creation. | [optional] 
**CheckIntegrity** | Pointer to **bool** | If true, the sync target performs cyclic redundancy checks (CRC) on the data as it is received. | [optional] 
**CloudDeepCopy** | Pointer to **string** | If set to deny, replicates all CloudPools smartlinks to the target cluster as smartlinks; if the target cluster does not support the smartlinks, the job will fail. If set to force, replicates all smartlinks to the target cluster as regular files. If set to allow, SyncIQ will attempt to replicate smartlinks to the target cluster as smartlinks; if the target cluster does not support the smartlinks, SyncIQ will replicate the smartlinks as regular files. | [optional] 
**DeleteQuotas** | Pointer to **bool** | If true, forcibly remove quotas on the target after they have been removed on the source. | [optional] 
**Description** | Pointer to **string** | User-assigned description of this sync policy. | [optional] 
**DisableFileSplit** | Pointer to **bool** | NOTE: This field should not be changed without the help of PowerScale support.  If true, the 7.2+ file splitting capability will be disabled. | [optional] 
**DisableFofb** | Pointer to **bool** | NOTE: This field should not be changed without the help of PowerScale support.  Enable/disable sync failover/failback. | [optional] 
**DisableQuotaTmpDir** | Pointer to **bool** | If set to true, SyncIQ will not create temporary quota directories to aid in replication to target paths which contain quotas. | [optional] 
**DisableStf** | Pointer to **bool** | NOTE: This field should not be changed without the help of PowerScale support.  Enable/disable the 6.5+ STF based data transfer and uses only treewalk. | [optional] 
**EnableHashTmpdir** | Pointer to **bool** | If true, syncs will use temporary working directory subdirectories to reduce lock contention. | [optional] 
**Enabled** | Pointer to **bool** | If true, jobs will be automatically run based on this policy, according to its schedule. | [optional] 
**EncryptionCipherList** | Pointer to **string** | The cipher list being used with encryption. For SyncIQ targets, this list serves as a list of supported ciphers. For SyncIQ sources, the list of ciphers will be attempted to be used in order. | [optional] 
**ExpectedDataloss** | Pointer to **bool** | NOTE: This field should not be changed without the help of PowerScale support.  Continue sending files even with the corrupted filesystem. | [optional] 
**FileMatchingPattern** | Pointer to [**V1SyncJobPolicyFileMatchingPattern**](V1SyncJobPolicyFileMatchingPattern.md) |  | [optional] 
**ForceInterface** | Pointer to **bool** | NOTE: This field should not be changed without the help of PowerScale support.  Determines whether data is sent only through the subnet and pool specified in the \&quot;source_network\&quot; field. This option can be useful if there are multiple interfaces for the given source subnet.  If you enable this option, the net.inet.ip.choose_ifa_by_ipsrc sysctl should be set. | [optional] 
**IgnoreRecursiveQuota** | Pointer to **bool** | If set to true, SyncIQ will not check the recursive quota in target paths to aid in replication to target paths which contain no quota but target cluster has lots of quotas. | [optional] 
**JobDelay** | Pointer to **int32** | If --schedule is set to When-Source-Modified, the duration to wait after a modification is made before starting a job (default is 0 seconds). | [optional] 
**LinkedServicePolicies** | Pointer to **[]string** | A list of service replication policies that this data replication policy will be associated with. | [optional] 
**LogLevel** | Pointer to **string** | Severity an event must reach before it is logged. | [optional] 
**LogRemovedFiles** | Pointer to **bool** | If true, the system will log any files or directories that are deleted due to a sync. | [optional] 
**Name** | **string** | User-assigned name of this sync policy. | 
**OcspAddress** | Pointer to **string** | The address of the OCSP responder to which to connect. | [optional] 
**OcspIssuerCertificateId** | Pointer to **string** | The ID of the certificate authority that issued the certificate whose revocation status is being checked. | [optional] 
**Password** | Pointer to **string** | The password for the target cluster.  This field is not readable. | [optional] 
**Priority** | Pointer to **int32** | Determines the priority level of a policy. Policies with higher priority will have precedence to run over lower priority policies. Valid range is [0, 1]. Default is 0. | [optional] 
**ReportMaxAge** | Pointer to **int32** | Length of time (in seconds) a policy report will be stored. | [optional] 
**ReportMaxCount** | Pointer to **int32** | Maximum number of policy reports that will be stored on the system. | [optional] 
**RestrictTargetNetwork** | Pointer to **bool** | If you specify true, and you specify a SmartConnect zone in the \&quot;target_host\&quot; field, replication policies will connect only to nodes in the specified SmartConnect zone.  If you specify false, replication policies are not restricted to specific nodes on the target cluster. | [optional] 
**RpoAlert** | Pointer to **int32** | If --schedule is set to a time/date, an alert is created if the specified RPO for this policy is exceeded. The default value is 0, which will not generate RPO alerts. | [optional] 
**Schedule** | Pointer to **string** | The schedule on which new jobs will be run for this policy. | [optional] 
**ServicePolicy** | Pointer to **bool** | If true, this is a service replication policy. | [optional] 
**SkipLookup** | Pointer to **bool** | Skip DNS lookup of target IPs. | [optional] 
**SkipWhenSourceUnmodified** | Pointer to **bool** | If true and --schedule is set to a time/date, the policy will not run if no changes have been made to the contents of the source directory since the last job successfully completed. | [optional] 
**SnapshotSyncExisting** | Pointer to **bool** | If true, snapshot-triggered syncs will include snapshots taken before policy creation time (requires --schedule when-snapshot-taken). | [optional] 
**SnapshotSyncPattern** | Pointer to **string** | The naming pattern that a snapshot must match to trigger a sync when the schedule is when-snapshot-taken (default is \&quot;*\&quot;). | [optional] 
**SourceExcludeDirectories** | Pointer to **[]string** | Directories that will be excluded from the sync.  Modifying this field will result in a full synchronization of all data. | [optional] 
**SourceIncludeDirectories** | Pointer to **[]string** | Directories that will be included in the sync.  Modifying this field will result in a full synchronization of all data. | [optional] 
**SourceNetwork** | Pointer to [**V1SyncPolicySourceNetwork**](V1SyncPolicySourceNetwork.md) |  | [optional] 
**SourceRootPath** | **string** | The root directory on the source cluster the files will be synced from.  Modifying this field will result in a full synchronization of all data. | 
**SourceSnapshotArchive** | Pointer to **bool** | If true, archival snapshots of the source data will be taken on the source cluster before a sync. | [optional] 
**SourceSnapshotExpiration** | Pointer to **int32** | The length of time in seconds to keep snapshots on the source cluster. | [optional] 
**SourceSnapshotPattern** | Pointer to **string** | The name pattern for snapshots taken on the source cluster before a sync. | [optional] 
**SyncExistingSnapshotExpiration** | Pointer to **bool** | If set to true, the expire duration for target archival snapshot is the remaining expire duration of source snapshot, requires --sync-existing-snapshot&#x3D;true | [optional] 
**SyncExistingTargetSnapshotPattern** | Pointer to **string** | The naming pattern for snapshot on the destination cluster when --sync-existing-snapshot is true | [optional] 
**TargetCertificateId** | Pointer to **string** | The ID of the target cluster certificate being used for encryption. | [optional] 
**TargetCompareInitialSync** | Pointer to **bool** | If true, the target creates diffs against the original sync. | [optional] 
**TargetDetectModifications** | Pointer to **bool** | If true, target cluster will detect if files have been changed on the target by legacy tree walk syncs. | [optional] 
**TargetHost** | **string** | Hostname or IP address of sync target cluster.  Modifying the target cluster host can result in the policy being unrunnable if the new target does not match the current target association. | 
**TargetPath** | **string** | Absolute filesystem path on the target cluster for the sync destination. | 
**TargetSnapshotAlias** | Pointer to **string** | The alias of the snapshot taken on the target cluster after the sync completes. A value of @DEFAULT will reset this field to the default creation value. | [optional] 
**TargetSnapshotArchive** | Pointer to **bool** | If true, archival snapshots of the target data will be taken on the target cluster after successful sync completions. | [optional] 
**TargetSnapshotExpiration** | Pointer to **int32** | The length of time in seconds to keep snapshots on the target cluster. | [optional] 
**TargetSnapshotPattern** | Pointer to **string** | The name pattern for snapshots taken on the target cluster after the sync completes.  A value of @DEFAULT will reset this field to the default creation value. | [optional] 
**WorkersPerNode** | Pointer to **int32** | The number of worker threads on a node performing a sync. | [optional] 

## Methods

### NewV14SyncPolicy

`func NewV14SyncPolicy(action string, name string, sourceRootPath string, targetHost string, targetPath string, ) *V14SyncPolicy`

NewV14SyncPolicy instantiates a new V14SyncPolicy object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SyncPolicyWithDefaults

`func NewV14SyncPolicyWithDefaults() *V14SyncPolicy`

NewV14SyncPolicyWithDefaults instantiates a new V14SyncPolicy object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAcceleratedFailback

`func (o *V14SyncPolicy) GetAcceleratedFailback() bool`

GetAcceleratedFailback returns the AcceleratedFailback field if non-nil, zero value otherwise.

### GetAcceleratedFailbackOk

`func (o *V14SyncPolicy) GetAcceleratedFailbackOk() (*bool, bool)`

GetAcceleratedFailbackOk returns a tuple with the AcceleratedFailback field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAcceleratedFailback

`func (o *V14SyncPolicy) SetAcceleratedFailback(v bool)`

SetAcceleratedFailback sets AcceleratedFailback field to given value.

### HasAcceleratedFailback

`func (o *V14SyncPolicy) HasAcceleratedFailback() bool`

HasAcceleratedFailback returns a boolean if a field has been set.

### GetAction

`func (o *V14SyncPolicy) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *V14SyncPolicy) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *V14SyncPolicy) SetAction(v string)`

SetAction sets Action field to given value.


### GetAllowCopyFb

`func (o *V14SyncPolicy) GetAllowCopyFb() bool`

GetAllowCopyFb returns the AllowCopyFb field if non-nil, zero value otherwise.

### GetAllowCopyFbOk

`func (o *V14SyncPolicy) GetAllowCopyFbOk() (*bool, bool)`

GetAllowCopyFbOk returns a tuple with the AllowCopyFb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowCopyFb

`func (o *V14SyncPolicy) SetAllowCopyFb(v bool)`

SetAllowCopyFb sets AllowCopyFb field to given value.

### HasAllowCopyFb

`func (o *V14SyncPolicy) HasAllowCopyFb() bool`

HasAllowCopyFb returns a boolean if a field has been set.

### GetBandwidthReservation

`func (o *V14SyncPolicy) GetBandwidthReservation() int32`

GetBandwidthReservation returns the BandwidthReservation field if non-nil, zero value otherwise.

### GetBandwidthReservationOk

`func (o *V14SyncPolicy) GetBandwidthReservationOk() (*int32, bool)`

GetBandwidthReservationOk returns a tuple with the BandwidthReservation field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBandwidthReservation

`func (o *V14SyncPolicy) SetBandwidthReservation(v int32)`

SetBandwidthReservation sets BandwidthReservation field to given value.

### HasBandwidthReservation

`func (o *V14SyncPolicy) HasBandwidthReservation() bool`

HasBandwidthReservation returns a boolean if a field has been set.

### GetChangelist

`func (o *V14SyncPolicy) GetChangelist() bool`

GetChangelist returns the Changelist field if non-nil, zero value otherwise.

### GetChangelistOk

`func (o *V14SyncPolicy) GetChangelistOk() (*bool, bool)`

GetChangelistOk returns a tuple with the Changelist field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChangelist

`func (o *V14SyncPolicy) SetChangelist(v bool)`

SetChangelist sets Changelist field to given value.

### HasChangelist

`func (o *V14SyncPolicy) HasChangelist() bool`

HasChangelist returns a boolean if a field has been set.

### GetCheckIntegrity

`func (o *V14SyncPolicy) GetCheckIntegrity() bool`

GetCheckIntegrity returns the CheckIntegrity field if non-nil, zero value otherwise.

### GetCheckIntegrityOk

`func (o *V14SyncPolicy) GetCheckIntegrityOk() (*bool, bool)`

GetCheckIntegrityOk returns a tuple with the CheckIntegrity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCheckIntegrity

`func (o *V14SyncPolicy) SetCheckIntegrity(v bool)`

SetCheckIntegrity sets CheckIntegrity field to given value.

### HasCheckIntegrity

`func (o *V14SyncPolicy) HasCheckIntegrity() bool`

HasCheckIntegrity returns a boolean if a field has been set.

### GetCloudDeepCopy

`func (o *V14SyncPolicy) GetCloudDeepCopy() string`

GetCloudDeepCopy returns the CloudDeepCopy field if non-nil, zero value otherwise.

### GetCloudDeepCopyOk

`func (o *V14SyncPolicy) GetCloudDeepCopyOk() (*string, bool)`

GetCloudDeepCopyOk returns a tuple with the CloudDeepCopy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudDeepCopy

`func (o *V14SyncPolicy) SetCloudDeepCopy(v string)`

SetCloudDeepCopy sets CloudDeepCopy field to given value.

### HasCloudDeepCopy

`func (o *V14SyncPolicy) HasCloudDeepCopy() bool`

HasCloudDeepCopy returns a boolean if a field has been set.

### GetDeleteQuotas

`func (o *V14SyncPolicy) GetDeleteQuotas() bool`

GetDeleteQuotas returns the DeleteQuotas field if non-nil, zero value otherwise.

### GetDeleteQuotasOk

`func (o *V14SyncPolicy) GetDeleteQuotasOk() (*bool, bool)`

GetDeleteQuotasOk returns a tuple with the DeleteQuotas field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeleteQuotas

`func (o *V14SyncPolicy) SetDeleteQuotas(v bool)`

SetDeleteQuotas sets DeleteQuotas field to given value.

### HasDeleteQuotas

`func (o *V14SyncPolicy) HasDeleteQuotas() bool`

HasDeleteQuotas returns a boolean if a field has been set.

### GetDescription

`func (o *V14SyncPolicy) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V14SyncPolicy) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V14SyncPolicy) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V14SyncPolicy) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDisableFileSplit

`func (o *V14SyncPolicy) GetDisableFileSplit() bool`

GetDisableFileSplit returns the DisableFileSplit field if non-nil, zero value otherwise.

### GetDisableFileSplitOk

`func (o *V14SyncPolicy) GetDisableFileSplitOk() (*bool, bool)`

GetDisableFileSplitOk returns a tuple with the DisableFileSplit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisableFileSplit

`func (o *V14SyncPolicy) SetDisableFileSplit(v bool)`

SetDisableFileSplit sets DisableFileSplit field to given value.

### HasDisableFileSplit

`func (o *V14SyncPolicy) HasDisableFileSplit() bool`

HasDisableFileSplit returns a boolean if a field has been set.

### GetDisableFofb

`func (o *V14SyncPolicy) GetDisableFofb() bool`

GetDisableFofb returns the DisableFofb field if non-nil, zero value otherwise.

### GetDisableFofbOk

`func (o *V14SyncPolicy) GetDisableFofbOk() (*bool, bool)`

GetDisableFofbOk returns a tuple with the DisableFofb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisableFofb

`func (o *V14SyncPolicy) SetDisableFofb(v bool)`

SetDisableFofb sets DisableFofb field to given value.

### HasDisableFofb

`func (o *V14SyncPolicy) HasDisableFofb() bool`

HasDisableFofb returns a boolean if a field has been set.

### GetDisableQuotaTmpDir

`func (o *V14SyncPolicy) GetDisableQuotaTmpDir() bool`

GetDisableQuotaTmpDir returns the DisableQuotaTmpDir field if non-nil, zero value otherwise.

### GetDisableQuotaTmpDirOk

`func (o *V14SyncPolicy) GetDisableQuotaTmpDirOk() (*bool, bool)`

GetDisableQuotaTmpDirOk returns a tuple with the DisableQuotaTmpDir field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisableQuotaTmpDir

`func (o *V14SyncPolicy) SetDisableQuotaTmpDir(v bool)`

SetDisableQuotaTmpDir sets DisableQuotaTmpDir field to given value.

### HasDisableQuotaTmpDir

`func (o *V14SyncPolicy) HasDisableQuotaTmpDir() bool`

HasDisableQuotaTmpDir returns a boolean if a field has been set.

### GetDisableStf

`func (o *V14SyncPolicy) GetDisableStf() bool`

GetDisableStf returns the DisableStf field if non-nil, zero value otherwise.

### GetDisableStfOk

`func (o *V14SyncPolicy) GetDisableStfOk() (*bool, bool)`

GetDisableStfOk returns a tuple with the DisableStf field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisableStf

`func (o *V14SyncPolicy) SetDisableStf(v bool)`

SetDisableStf sets DisableStf field to given value.

### HasDisableStf

`func (o *V14SyncPolicy) HasDisableStf() bool`

HasDisableStf returns a boolean if a field has been set.

### GetEnableHashTmpdir

`func (o *V14SyncPolicy) GetEnableHashTmpdir() bool`

GetEnableHashTmpdir returns the EnableHashTmpdir field if non-nil, zero value otherwise.

### GetEnableHashTmpdirOk

`func (o *V14SyncPolicy) GetEnableHashTmpdirOk() (*bool, bool)`

GetEnableHashTmpdirOk returns a tuple with the EnableHashTmpdir field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnableHashTmpdir

`func (o *V14SyncPolicy) SetEnableHashTmpdir(v bool)`

SetEnableHashTmpdir sets EnableHashTmpdir field to given value.

### HasEnableHashTmpdir

`func (o *V14SyncPolicy) HasEnableHashTmpdir() bool`

HasEnableHashTmpdir returns a boolean if a field has been set.

### GetEnabled

`func (o *V14SyncPolicy) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V14SyncPolicy) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V14SyncPolicy) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V14SyncPolicy) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetEncryptionCipherList

`func (o *V14SyncPolicy) GetEncryptionCipherList() string`

GetEncryptionCipherList returns the EncryptionCipherList field if non-nil, zero value otherwise.

### GetEncryptionCipherListOk

`func (o *V14SyncPolicy) GetEncryptionCipherListOk() (*string, bool)`

GetEncryptionCipherListOk returns a tuple with the EncryptionCipherList field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEncryptionCipherList

`func (o *V14SyncPolicy) SetEncryptionCipherList(v string)`

SetEncryptionCipherList sets EncryptionCipherList field to given value.

### HasEncryptionCipherList

`func (o *V14SyncPolicy) HasEncryptionCipherList() bool`

HasEncryptionCipherList returns a boolean if a field has been set.

### GetExpectedDataloss

`func (o *V14SyncPolicy) GetExpectedDataloss() bool`

GetExpectedDataloss returns the ExpectedDataloss field if non-nil, zero value otherwise.

### GetExpectedDatalossOk

`func (o *V14SyncPolicy) GetExpectedDatalossOk() (*bool, bool)`

GetExpectedDatalossOk returns a tuple with the ExpectedDataloss field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpectedDataloss

`func (o *V14SyncPolicy) SetExpectedDataloss(v bool)`

SetExpectedDataloss sets ExpectedDataloss field to given value.

### HasExpectedDataloss

`func (o *V14SyncPolicy) HasExpectedDataloss() bool`

HasExpectedDataloss returns a boolean if a field has been set.

### GetFileMatchingPattern

`func (o *V14SyncPolicy) GetFileMatchingPattern() V1SyncJobPolicyFileMatchingPattern`

GetFileMatchingPattern returns the FileMatchingPattern field if non-nil, zero value otherwise.

### GetFileMatchingPatternOk

`func (o *V14SyncPolicy) GetFileMatchingPatternOk() (*V1SyncJobPolicyFileMatchingPattern, bool)`

GetFileMatchingPatternOk returns a tuple with the FileMatchingPattern field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileMatchingPattern

`func (o *V14SyncPolicy) SetFileMatchingPattern(v V1SyncJobPolicyFileMatchingPattern)`

SetFileMatchingPattern sets FileMatchingPattern field to given value.

### HasFileMatchingPattern

`func (o *V14SyncPolicy) HasFileMatchingPattern() bool`

HasFileMatchingPattern returns a boolean if a field has been set.

### GetForceInterface

`func (o *V14SyncPolicy) GetForceInterface() bool`

GetForceInterface returns the ForceInterface field if non-nil, zero value otherwise.

### GetForceInterfaceOk

`func (o *V14SyncPolicy) GetForceInterfaceOk() (*bool, bool)`

GetForceInterfaceOk returns a tuple with the ForceInterface field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForceInterface

`func (o *V14SyncPolicy) SetForceInterface(v bool)`

SetForceInterface sets ForceInterface field to given value.

### HasForceInterface

`func (o *V14SyncPolicy) HasForceInterface() bool`

HasForceInterface returns a boolean if a field has been set.

### GetIgnoreRecursiveQuota

`func (o *V14SyncPolicy) GetIgnoreRecursiveQuota() bool`

GetIgnoreRecursiveQuota returns the IgnoreRecursiveQuota field if non-nil, zero value otherwise.

### GetIgnoreRecursiveQuotaOk

`func (o *V14SyncPolicy) GetIgnoreRecursiveQuotaOk() (*bool, bool)`

GetIgnoreRecursiveQuotaOk returns a tuple with the IgnoreRecursiveQuota field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoreRecursiveQuota

`func (o *V14SyncPolicy) SetIgnoreRecursiveQuota(v bool)`

SetIgnoreRecursiveQuota sets IgnoreRecursiveQuota field to given value.

### HasIgnoreRecursiveQuota

`func (o *V14SyncPolicy) HasIgnoreRecursiveQuota() bool`

HasIgnoreRecursiveQuota returns a boolean if a field has been set.

### GetJobDelay

`func (o *V14SyncPolicy) GetJobDelay() int32`

GetJobDelay returns the JobDelay field if non-nil, zero value otherwise.

### GetJobDelayOk

`func (o *V14SyncPolicy) GetJobDelayOk() (*int32, bool)`

GetJobDelayOk returns a tuple with the JobDelay field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJobDelay

`func (o *V14SyncPolicy) SetJobDelay(v int32)`

SetJobDelay sets JobDelay field to given value.

### HasJobDelay

`func (o *V14SyncPolicy) HasJobDelay() bool`

HasJobDelay returns a boolean if a field has been set.

### GetLinkedServicePolicies

`func (o *V14SyncPolicy) GetLinkedServicePolicies() []string`

GetLinkedServicePolicies returns the LinkedServicePolicies field if non-nil, zero value otherwise.

### GetLinkedServicePoliciesOk

`func (o *V14SyncPolicy) GetLinkedServicePoliciesOk() (*[]string, bool)`

GetLinkedServicePoliciesOk returns a tuple with the LinkedServicePolicies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLinkedServicePolicies

`func (o *V14SyncPolicy) SetLinkedServicePolicies(v []string)`

SetLinkedServicePolicies sets LinkedServicePolicies field to given value.

### HasLinkedServicePolicies

`func (o *V14SyncPolicy) HasLinkedServicePolicies() bool`

HasLinkedServicePolicies returns a boolean if a field has been set.

### GetLogLevel

`func (o *V14SyncPolicy) GetLogLevel() string`

GetLogLevel returns the LogLevel field if non-nil, zero value otherwise.

### GetLogLevelOk

`func (o *V14SyncPolicy) GetLogLevelOk() (*string, bool)`

GetLogLevelOk returns a tuple with the LogLevel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLogLevel

`func (o *V14SyncPolicy) SetLogLevel(v string)`

SetLogLevel sets LogLevel field to given value.

### HasLogLevel

`func (o *V14SyncPolicy) HasLogLevel() bool`

HasLogLevel returns a boolean if a field has been set.

### GetLogRemovedFiles

`func (o *V14SyncPolicy) GetLogRemovedFiles() bool`

GetLogRemovedFiles returns the LogRemovedFiles field if non-nil, zero value otherwise.

### GetLogRemovedFilesOk

`func (o *V14SyncPolicy) GetLogRemovedFilesOk() (*bool, bool)`

GetLogRemovedFilesOk returns a tuple with the LogRemovedFiles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLogRemovedFiles

`func (o *V14SyncPolicy) SetLogRemovedFiles(v bool)`

SetLogRemovedFiles sets LogRemovedFiles field to given value.

### HasLogRemovedFiles

`func (o *V14SyncPolicy) HasLogRemovedFiles() bool`

HasLogRemovedFiles returns a boolean if a field has been set.

### GetName

`func (o *V14SyncPolicy) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V14SyncPolicy) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V14SyncPolicy) SetName(v string)`

SetName sets Name field to given value.


### GetOcspAddress

`func (o *V14SyncPolicy) GetOcspAddress() string`

GetOcspAddress returns the OcspAddress field if non-nil, zero value otherwise.

### GetOcspAddressOk

`func (o *V14SyncPolicy) GetOcspAddressOk() (*string, bool)`

GetOcspAddressOk returns a tuple with the OcspAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOcspAddress

`func (o *V14SyncPolicy) SetOcspAddress(v string)`

SetOcspAddress sets OcspAddress field to given value.

### HasOcspAddress

`func (o *V14SyncPolicy) HasOcspAddress() bool`

HasOcspAddress returns a boolean if a field has been set.

### GetOcspIssuerCertificateId

`func (o *V14SyncPolicy) GetOcspIssuerCertificateId() string`

GetOcspIssuerCertificateId returns the OcspIssuerCertificateId field if non-nil, zero value otherwise.

### GetOcspIssuerCertificateIdOk

`func (o *V14SyncPolicy) GetOcspIssuerCertificateIdOk() (*string, bool)`

GetOcspIssuerCertificateIdOk returns a tuple with the OcspIssuerCertificateId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOcspIssuerCertificateId

`func (o *V14SyncPolicy) SetOcspIssuerCertificateId(v string)`

SetOcspIssuerCertificateId sets OcspIssuerCertificateId field to given value.

### HasOcspIssuerCertificateId

`func (o *V14SyncPolicy) HasOcspIssuerCertificateId() bool`

HasOcspIssuerCertificateId returns a boolean if a field has been set.

### GetPassword

`func (o *V14SyncPolicy) GetPassword() string`

GetPassword returns the Password field if non-nil, zero value otherwise.

### GetPasswordOk

`func (o *V14SyncPolicy) GetPasswordOk() (*string, bool)`

GetPasswordOk returns a tuple with the Password field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPassword

`func (o *V14SyncPolicy) SetPassword(v string)`

SetPassword sets Password field to given value.

### HasPassword

`func (o *V14SyncPolicy) HasPassword() bool`

HasPassword returns a boolean if a field has been set.

### GetPriority

`func (o *V14SyncPolicy) GetPriority() int32`

GetPriority returns the Priority field if non-nil, zero value otherwise.

### GetPriorityOk

`func (o *V14SyncPolicy) GetPriorityOk() (*int32, bool)`

GetPriorityOk returns a tuple with the Priority field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPriority

`func (o *V14SyncPolicy) SetPriority(v int32)`

SetPriority sets Priority field to given value.

### HasPriority

`func (o *V14SyncPolicy) HasPriority() bool`

HasPriority returns a boolean if a field has been set.

### GetReportMaxAge

`func (o *V14SyncPolicy) GetReportMaxAge() int32`

GetReportMaxAge returns the ReportMaxAge field if non-nil, zero value otherwise.

### GetReportMaxAgeOk

`func (o *V14SyncPolicy) GetReportMaxAgeOk() (*int32, bool)`

GetReportMaxAgeOk returns a tuple with the ReportMaxAge field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReportMaxAge

`func (o *V14SyncPolicy) SetReportMaxAge(v int32)`

SetReportMaxAge sets ReportMaxAge field to given value.

### HasReportMaxAge

`func (o *V14SyncPolicy) HasReportMaxAge() bool`

HasReportMaxAge returns a boolean if a field has been set.

### GetReportMaxCount

`func (o *V14SyncPolicy) GetReportMaxCount() int32`

GetReportMaxCount returns the ReportMaxCount field if non-nil, zero value otherwise.

### GetReportMaxCountOk

`func (o *V14SyncPolicy) GetReportMaxCountOk() (*int32, bool)`

GetReportMaxCountOk returns a tuple with the ReportMaxCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReportMaxCount

`func (o *V14SyncPolicy) SetReportMaxCount(v int32)`

SetReportMaxCount sets ReportMaxCount field to given value.

### HasReportMaxCount

`func (o *V14SyncPolicy) HasReportMaxCount() bool`

HasReportMaxCount returns a boolean if a field has been set.

### GetRestrictTargetNetwork

`func (o *V14SyncPolicy) GetRestrictTargetNetwork() bool`

GetRestrictTargetNetwork returns the RestrictTargetNetwork field if non-nil, zero value otherwise.

### GetRestrictTargetNetworkOk

`func (o *V14SyncPolicy) GetRestrictTargetNetworkOk() (*bool, bool)`

GetRestrictTargetNetworkOk returns a tuple with the RestrictTargetNetwork field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRestrictTargetNetwork

`func (o *V14SyncPolicy) SetRestrictTargetNetwork(v bool)`

SetRestrictTargetNetwork sets RestrictTargetNetwork field to given value.

### HasRestrictTargetNetwork

`func (o *V14SyncPolicy) HasRestrictTargetNetwork() bool`

HasRestrictTargetNetwork returns a boolean if a field has been set.

### GetRpoAlert

`func (o *V14SyncPolicy) GetRpoAlert() int32`

GetRpoAlert returns the RpoAlert field if non-nil, zero value otherwise.

### GetRpoAlertOk

`func (o *V14SyncPolicy) GetRpoAlertOk() (*int32, bool)`

GetRpoAlertOk returns a tuple with the RpoAlert field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRpoAlert

`func (o *V14SyncPolicy) SetRpoAlert(v int32)`

SetRpoAlert sets RpoAlert field to given value.

### HasRpoAlert

`func (o *V14SyncPolicy) HasRpoAlert() bool`

HasRpoAlert returns a boolean if a field has been set.

### GetSchedule

`func (o *V14SyncPolicy) GetSchedule() string`

GetSchedule returns the Schedule field if non-nil, zero value otherwise.

### GetScheduleOk

`func (o *V14SyncPolicy) GetScheduleOk() (*string, bool)`

GetScheduleOk returns a tuple with the Schedule field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSchedule

`func (o *V14SyncPolicy) SetSchedule(v string)`

SetSchedule sets Schedule field to given value.

### HasSchedule

`func (o *V14SyncPolicy) HasSchedule() bool`

HasSchedule returns a boolean if a field has been set.

### GetServicePolicy

`func (o *V14SyncPolicy) GetServicePolicy() bool`

GetServicePolicy returns the ServicePolicy field if non-nil, zero value otherwise.

### GetServicePolicyOk

`func (o *V14SyncPolicy) GetServicePolicyOk() (*bool, bool)`

GetServicePolicyOk returns a tuple with the ServicePolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServicePolicy

`func (o *V14SyncPolicy) SetServicePolicy(v bool)`

SetServicePolicy sets ServicePolicy field to given value.

### HasServicePolicy

`func (o *V14SyncPolicy) HasServicePolicy() bool`

HasServicePolicy returns a boolean if a field has been set.

### GetSkipLookup

`func (o *V14SyncPolicy) GetSkipLookup() bool`

GetSkipLookup returns the SkipLookup field if non-nil, zero value otherwise.

### GetSkipLookupOk

`func (o *V14SyncPolicy) GetSkipLookupOk() (*bool, bool)`

GetSkipLookupOk returns a tuple with the SkipLookup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSkipLookup

`func (o *V14SyncPolicy) SetSkipLookup(v bool)`

SetSkipLookup sets SkipLookup field to given value.

### HasSkipLookup

`func (o *V14SyncPolicy) HasSkipLookup() bool`

HasSkipLookup returns a boolean if a field has been set.

### GetSkipWhenSourceUnmodified

`func (o *V14SyncPolicy) GetSkipWhenSourceUnmodified() bool`

GetSkipWhenSourceUnmodified returns the SkipWhenSourceUnmodified field if non-nil, zero value otherwise.

### GetSkipWhenSourceUnmodifiedOk

`func (o *V14SyncPolicy) GetSkipWhenSourceUnmodifiedOk() (*bool, bool)`

GetSkipWhenSourceUnmodifiedOk returns a tuple with the SkipWhenSourceUnmodified field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSkipWhenSourceUnmodified

`func (o *V14SyncPolicy) SetSkipWhenSourceUnmodified(v bool)`

SetSkipWhenSourceUnmodified sets SkipWhenSourceUnmodified field to given value.

### HasSkipWhenSourceUnmodified

`func (o *V14SyncPolicy) HasSkipWhenSourceUnmodified() bool`

HasSkipWhenSourceUnmodified returns a boolean if a field has been set.

### GetSnapshotSyncExisting

`func (o *V14SyncPolicy) GetSnapshotSyncExisting() bool`

GetSnapshotSyncExisting returns the SnapshotSyncExisting field if non-nil, zero value otherwise.

### GetSnapshotSyncExistingOk

`func (o *V14SyncPolicy) GetSnapshotSyncExistingOk() (*bool, bool)`

GetSnapshotSyncExistingOk returns a tuple with the SnapshotSyncExisting field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapshotSyncExisting

`func (o *V14SyncPolicy) SetSnapshotSyncExisting(v bool)`

SetSnapshotSyncExisting sets SnapshotSyncExisting field to given value.

### HasSnapshotSyncExisting

`func (o *V14SyncPolicy) HasSnapshotSyncExisting() bool`

HasSnapshotSyncExisting returns a boolean if a field has been set.

### GetSnapshotSyncPattern

`func (o *V14SyncPolicy) GetSnapshotSyncPattern() string`

GetSnapshotSyncPattern returns the SnapshotSyncPattern field if non-nil, zero value otherwise.

### GetSnapshotSyncPatternOk

`func (o *V14SyncPolicy) GetSnapshotSyncPatternOk() (*string, bool)`

GetSnapshotSyncPatternOk returns a tuple with the SnapshotSyncPattern field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSnapshotSyncPattern

`func (o *V14SyncPolicy) SetSnapshotSyncPattern(v string)`

SetSnapshotSyncPattern sets SnapshotSyncPattern field to given value.

### HasSnapshotSyncPattern

`func (o *V14SyncPolicy) HasSnapshotSyncPattern() bool`

HasSnapshotSyncPattern returns a boolean if a field has been set.

### GetSourceExcludeDirectories

`func (o *V14SyncPolicy) GetSourceExcludeDirectories() []string`

GetSourceExcludeDirectories returns the SourceExcludeDirectories field if non-nil, zero value otherwise.

### GetSourceExcludeDirectoriesOk

`func (o *V14SyncPolicy) GetSourceExcludeDirectoriesOk() (*[]string, bool)`

GetSourceExcludeDirectoriesOk returns a tuple with the SourceExcludeDirectories field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceExcludeDirectories

`func (o *V14SyncPolicy) SetSourceExcludeDirectories(v []string)`

SetSourceExcludeDirectories sets SourceExcludeDirectories field to given value.

### HasSourceExcludeDirectories

`func (o *V14SyncPolicy) HasSourceExcludeDirectories() bool`

HasSourceExcludeDirectories returns a boolean if a field has been set.

### GetSourceIncludeDirectories

`func (o *V14SyncPolicy) GetSourceIncludeDirectories() []string`

GetSourceIncludeDirectories returns the SourceIncludeDirectories field if non-nil, zero value otherwise.

### GetSourceIncludeDirectoriesOk

`func (o *V14SyncPolicy) GetSourceIncludeDirectoriesOk() (*[]string, bool)`

GetSourceIncludeDirectoriesOk returns a tuple with the SourceIncludeDirectories field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceIncludeDirectories

`func (o *V14SyncPolicy) SetSourceIncludeDirectories(v []string)`

SetSourceIncludeDirectories sets SourceIncludeDirectories field to given value.

### HasSourceIncludeDirectories

`func (o *V14SyncPolicy) HasSourceIncludeDirectories() bool`

HasSourceIncludeDirectories returns a boolean if a field has been set.

### GetSourceNetwork

`func (o *V14SyncPolicy) GetSourceNetwork() V1SyncPolicySourceNetwork`

GetSourceNetwork returns the SourceNetwork field if non-nil, zero value otherwise.

### GetSourceNetworkOk

`func (o *V14SyncPolicy) GetSourceNetworkOk() (*V1SyncPolicySourceNetwork, bool)`

GetSourceNetworkOk returns a tuple with the SourceNetwork field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceNetwork

`func (o *V14SyncPolicy) SetSourceNetwork(v V1SyncPolicySourceNetwork)`

SetSourceNetwork sets SourceNetwork field to given value.

### HasSourceNetwork

`func (o *V14SyncPolicy) HasSourceNetwork() bool`

HasSourceNetwork returns a boolean if a field has been set.

### GetSourceRootPath

`func (o *V14SyncPolicy) GetSourceRootPath() string`

GetSourceRootPath returns the SourceRootPath field if non-nil, zero value otherwise.

### GetSourceRootPathOk

`func (o *V14SyncPolicy) GetSourceRootPathOk() (*string, bool)`

GetSourceRootPathOk returns a tuple with the SourceRootPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceRootPath

`func (o *V14SyncPolicy) SetSourceRootPath(v string)`

SetSourceRootPath sets SourceRootPath field to given value.


### GetSourceSnapshotArchive

`func (o *V14SyncPolicy) GetSourceSnapshotArchive() bool`

GetSourceSnapshotArchive returns the SourceSnapshotArchive field if non-nil, zero value otherwise.

### GetSourceSnapshotArchiveOk

`func (o *V14SyncPolicy) GetSourceSnapshotArchiveOk() (*bool, bool)`

GetSourceSnapshotArchiveOk returns a tuple with the SourceSnapshotArchive field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceSnapshotArchive

`func (o *V14SyncPolicy) SetSourceSnapshotArchive(v bool)`

SetSourceSnapshotArchive sets SourceSnapshotArchive field to given value.

### HasSourceSnapshotArchive

`func (o *V14SyncPolicy) HasSourceSnapshotArchive() bool`

HasSourceSnapshotArchive returns a boolean if a field has been set.

### GetSourceSnapshotExpiration

`func (o *V14SyncPolicy) GetSourceSnapshotExpiration() int32`

GetSourceSnapshotExpiration returns the SourceSnapshotExpiration field if non-nil, zero value otherwise.

### GetSourceSnapshotExpirationOk

`func (o *V14SyncPolicy) GetSourceSnapshotExpirationOk() (*int32, bool)`

GetSourceSnapshotExpirationOk returns a tuple with the SourceSnapshotExpiration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceSnapshotExpiration

`func (o *V14SyncPolicy) SetSourceSnapshotExpiration(v int32)`

SetSourceSnapshotExpiration sets SourceSnapshotExpiration field to given value.

### HasSourceSnapshotExpiration

`func (o *V14SyncPolicy) HasSourceSnapshotExpiration() bool`

HasSourceSnapshotExpiration returns a boolean if a field has been set.

### GetSourceSnapshotPattern

`func (o *V14SyncPolicy) GetSourceSnapshotPattern() string`

GetSourceSnapshotPattern returns the SourceSnapshotPattern field if non-nil, zero value otherwise.

### GetSourceSnapshotPatternOk

`func (o *V14SyncPolicy) GetSourceSnapshotPatternOk() (*string, bool)`

GetSourceSnapshotPatternOk returns a tuple with the SourceSnapshotPattern field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSourceSnapshotPattern

`func (o *V14SyncPolicy) SetSourceSnapshotPattern(v string)`

SetSourceSnapshotPattern sets SourceSnapshotPattern field to given value.

### HasSourceSnapshotPattern

`func (o *V14SyncPolicy) HasSourceSnapshotPattern() bool`

HasSourceSnapshotPattern returns a boolean if a field has been set.

### GetSyncExistingSnapshotExpiration

`func (o *V14SyncPolicy) GetSyncExistingSnapshotExpiration() bool`

GetSyncExistingSnapshotExpiration returns the SyncExistingSnapshotExpiration field if non-nil, zero value otherwise.

### GetSyncExistingSnapshotExpirationOk

`func (o *V14SyncPolicy) GetSyncExistingSnapshotExpirationOk() (*bool, bool)`

GetSyncExistingSnapshotExpirationOk returns a tuple with the SyncExistingSnapshotExpiration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSyncExistingSnapshotExpiration

`func (o *V14SyncPolicy) SetSyncExistingSnapshotExpiration(v bool)`

SetSyncExistingSnapshotExpiration sets SyncExistingSnapshotExpiration field to given value.

### HasSyncExistingSnapshotExpiration

`func (o *V14SyncPolicy) HasSyncExistingSnapshotExpiration() bool`

HasSyncExistingSnapshotExpiration returns a boolean if a field has been set.

### GetSyncExistingTargetSnapshotPattern

`func (o *V14SyncPolicy) GetSyncExistingTargetSnapshotPattern() string`

GetSyncExistingTargetSnapshotPattern returns the SyncExistingTargetSnapshotPattern field if non-nil, zero value otherwise.

### GetSyncExistingTargetSnapshotPatternOk

`func (o *V14SyncPolicy) GetSyncExistingTargetSnapshotPatternOk() (*string, bool)`

GetSyncExistingTargetSnapshotPatternOk returns a tuple with the SyncExistingTargetSnapshotPattern field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSyncExistingTargetSnapshotPattern

`func (o *V14SyncPolicy) SetSyncExistingTargetSnapshotPattern(v string)`

SetSyncExistingTargetSnapshotPattern sets SyncExistingTargetSnapshotPattern field to given value.

### HasSyncExistingTargetSnapshotPattern

`func (o *V14SyncPolicy) HasSyncExistingTargetSnapshotPattern() bool`

HasSyncExistingTargetSnapshotPattern returns a boolean if a field has been set.

### GetTargetCertificateId

`func (o *V14SyncPolicy) GetTargetCertificateId() string`

GetTargetCertificateId returns the TargetCertificateId field if non-nil, zero value otherwise.

### GetTargetCertificateIdOk

`func (o *V14SyncPolicy) GetTargetCertificateIdOk() (*string, bool)`

GetTargetCertificateIdOk returns a tuple with the TargetCertificateId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetCertificateId

`func (o *V14SyncPolicy) SetTargetCertificateId(v string)`

SetTargetCertificateId sets TargetCertificateId field to given value.

### HasTargetCertificateId

`func (o *V14SyncPolicy) HasTargetCertificateId() bool`

HasTargetCertificateId returns a boolean if a field has been set.

### GetTargetCompareInitialSync

`func (o *V14SyncPolicy) GetTargetCompareInitialSync() bool`

GetTargetCompareInitialSync returns the TargetCompareInitialSync field if non-nil, zero value otherwise.

### GetTargetCompareInitialSyncOk

`func (o *V14SyncPolicy) GetTargetCompareInitialSyncOk() (*bool, bool)`

GetTargetCompareInitialSyncOk returns a tuple with the TargetCompareInitialSync field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetCompareInitialSync

`func (o *V14SyncPolicy) SetTargetCompareInitialSync(v bool)`

SetTargetCompareInitialSync sets TargetCompareInitialSync field to given value.

### HasTargetCompareInitialSync

`func (o *V14SyncPolicy) HasTargetCompareInitialSync() bool`

HasTargetCompareInitialSync returns a boolean if a field has been set.

### GetTargetDetectModifications

`func (o *V14SyncPolicy) GetTargetDetectModifications() bool`

GetTargetDetectModifications returns the TargetDetectModifications field if non-nil, zero value otherwise.

### GetTargetDetectModificationsOk

`func (o *V14SyncPolicy) GetTargetDetectModificationsOk() (*bool, bool)`

GetTargetDetectModificationsOk returns a tuple with the TargetDetectModifications field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetDetectModifications

`func (o *V14SyncPolicy) SetTargetDetectModifications(v bool)`

SetTargetDetectModifications sets TargetDetectModifications field to given value.

### HasTargetDetectModifications

`func (o *V14SyncPolicy) HasTargetDetectModifications() bool`

HasTargetDetectModifications returns a boolean if a field has been set.

### GetTargetHost

`func (o *V14SyncPolicy) GetTargetHost() string`

GetTargetHost returns the TargetHost field if non-nil, zero value otherwise.

### GetTargetHostOk

`func (o *V14SyncPolicy) GetTargetHostOk() (*string, bool)`

GetTargetHostOk returns a tuple with the TargetHost field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetHost

`func (o *V14SyncPolicy) SetTargetHost(v string)`

SetTargetHost sets TargetHost field to given value.


### GetTargetPath

`func (o *V14SyncPolicy) GetTargetPath() string`

GetTargetPath returns the TargetPath field if non-nil, zero value otherwise.

### GetTargetPathOk

`func (o *V14SyncPolicy) GetTargetPathOk() (*string, bool)`

GetTargetPathOk returns a tuple with the TargetPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetPath

`func (o *V14SyncPolicy) SetTargetPath(v string)`

SetTargetPath sets TargetPath field to given value.


### GetTargetSnapshotAlias

`func (o *V14SyncPolicy) GetTargetSnapshotAlias() string`

GetTargetSnapshotAlias returns the TargetSnapshotAlias field if non-nil, zero value otherwise.

### GetTargetSnapshotAliasOk

`func (o *V14SyncPolicy) GetTargetSnapshotAliasOk() (*string, bool)`

GetTargetSnapshotAliasOk returns a tuple with the TargetSnapshotAlias field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetSnapshotAlias

`func (o *V14SyncPolicy) SetTargetSnapshotAlias(v string)`

SetTargetSnapshotAlias sets TargetSnapshotAlias field to given value.

### HasTargetSnapshotAlias

`func (o *V14SyncPolicy) HasTargetSnapshotAlias() bool`

HasTargetSnapshotAlias returns a boolean if a field has been set.

### GetTargetSnapshotArchive

`func (o *V14SyncPolicy) GetTargetSnapshotArchive() bool`

GetTargetSnapshotArchive returns the TargetSnapshotArchive field if non-nil, zero value otherwise.

### GetTargetSnapshotArchiveOk

`func (o *V14SyncPolicy) GetTargetSnapshotArchiveOk() (*bool, bool)`

GetTargetSnapshotArchiveOk returns a tuple with the TargetSnapshotArchive field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetSnapshotArchive

`func (o *V14SyncPolicy) SetTargetSnapshotArchive(v bool)`

SetTargetSnapshotArchive sets TargetSnapshotArchive field to given value.

### HasTargetSnapshotArchive

`func (o *V14SyncPolicy) HasTargetSnapshotArchive() bool`

HasTargetSnapshotArchive returns a boolean if a field has been set.

### GetTargetSnapshotExpiration

`func (o *V14SyncPolicy) GetTargetSnapshotExpiration() int32`

GetTargetSnapshotExpiration returns the TargetSnapshotExpiration field if non-nil, zero value otherwise.

### GetTargetSnapshotExpirationOk

`func (o *V14SyncPolicy) GetTargetSnapshotExpirationOk() (*int32, bool)`

GetTargetSnapshotExpirationOk returns a tuple with the TargetSnapshotExpiration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetSnapshotExpiration

`func (o *V14SyncPolicy) SetTargetSnapshotExpiration(v int32)`

SetTargetSnapshotExpiration sets TargetSnapshotExpiration field to given value.

### HasTargetSnapshotExpiration

`func (o *V14SyncPolicy) HasTargetSnapshotExpiration() bool`

HasTargetSnapshotExpiration returns a boolean if a field has been set.

### GetTargetSnapshotPattern

`func (o *V14SyncPolicy) GetTargetSnapshotPattern() string`

GetTargetSnapshotPattern returns the TargetSnapshotPattern field if non-nil, zero value otherwise.

### GetTargetSnapshotPatternOk

`func (o *V14SyncPolicy) GetTargetSnapshotPatternOk() (*string, bool)`

GetTargetSnapshotPatternOk returns a tuple with the TargetSnapshotPattern field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetSnapshotPattern

`func (o *V14SyncPolicy) SetTargetSnapshotPattern(v string)`

SetTargetSnapshotPattern sets TargetSnapshotPattern field to given value.

### HasTargetSnapshotPattern

`func (o *V14SyncPolicy) HasTargetSnapshotPattern() bool`

HasTargetSnapshotPattern returns a boolean if a field has been set.

### GetWorkersPerNode

`func (o *V14SyncPolicy) GetWorkersPerNode() int32`

GetWorkersPerNode returns the WorkersPerNode field if non-nil, zero value otherwise.

### GetWorkersPerNodeOk

`func (o *V14SyncPolicy) GetWorkersPerNodeOk() (*int32, bool)`

GetWorkersPerNodeOk returns a tuple with the WorkersPerNode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWorkersPerNode

`func (o *V14SyncPolicy) SetWorkersPerNode(v int32)`

SetWorkersPerNode sets WorkersPerNode field to given value.

### HasWorkersPerNode

`func (o *V14SyncPolicy) HasWorkersPerNode() bool`

HasWorkersPerNode returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


