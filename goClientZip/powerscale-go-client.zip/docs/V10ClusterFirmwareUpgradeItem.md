# V10ClusterFirmwareUpgradeItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExcludeDevice** | Pointer to **string** | Exclude the specified devices in the firmware upgrade. | [optional] 
**ExcludeType** | Pointer to **string** | Exclude the specified device type in the firmware upgrade. | [optional] 
**FwPkg** | Pointer to **string** | The location (path) of the firmware package which must be within /ifs. | [optional] 
**IncludeDevice** | Pointer to **string** | Include the specified devices in the firmware upgrade. | [optional] 
**IncludeType** | Pointer to **string** | Include the specified device type in the firmware upgrade. | [optional] 
**NoBurn** | Pointer to **bool** | Do not burn the firmware. | [optional] 
**NoReboot** | Pointer to **bool** | Do not reboot the node after an upgrade | [optional] 
**NodesToUpgrade** | Pointer to **[]int32** | The nodes scheduled for upgrade. Order in array determines queue position number. &#39;all&#39; and null option will upgrade firmware on all nodes in &lt;lnn&gt; order (Note: &#39;all&#39; and null options do not apply to simultaneous firmware upgrade). | [optional] 
**UpgradeType** | Pointer to **string** | The type of upgrade to perform. One of the following values: &#39;rolling&#39;, &#39;simultaneous&#39; | [optional] 

## Methods

### NewV10ClusterFirmwareUpgradeItem

`func NewV10ClusterFirmwareUpgradeItem() *V10ClusterFirmwareUpgradeItem`

NewV10ClusterFirmwareUpgradeItem instantiates a new V10ClusterFirmwareUpgradeItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterFirmwareUpgradeItemWithDefaults

`func NewV10ClusterFirmwareUpgradeItemWithDefaults() *V10ClusterFirmwareUpgradeItem`

NewV10ClusterFirmwareUpgradeItemWithDefaults instantiates a new V10ClusterFirmwareUpgradeItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExcludeDevice

`func (o *V10ClusterFirmwareUpgradeItem) GetExcludeDevice() string`

GetExcludeDevice returns the ExcludeDevice field if non-nil, zero value otherwise.

### GetExcludeDeviceOk

`func (o *V10ClusterFirmwareUpgradeItem) GetExcludeDeviceOk() (*string, bool)`

GetExcludeDeviceOk returns a tuple with the ExcludeDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeDevice

`func (o *V10ClusterFirmwareUpgradeItem) SetExcludeDevice(v string)`

SetExcludeDevice sets ExcludeDevice field to given value.

### HasExcludeDevice

`func (o *V10ClusterFirmwareUpgradeItem) HasExcludeDevice() bool`

HasExcludeDevice returns a boolean if a field has been set.

### GetExcludeType

`func (o *V10ClusterFirmwareUpgradeItem) GetExcludeType() string`

GetExcludeType returns the ExcludeType field if non-nil, zero value otherwise.

### GetExcludeTypeOk

`func (o *V10ClusterFirmwareUpgradeItem) GetExcludeTypeOk() (*string, bool)`

GetExcludeTypeOk returns a tuple with the ExcludeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeType

`func (o *V10ClusterFirmwareUpgradeItem) SetExcludeType(v string)`

SetExcludeType sets ExcludeType field to given value.

### HasExcludeType

`func (o *V10ClusterFirmwareUpgradeItem) HasExcludeType() bool`

HasExcludeType returns a boolean if a field has been set.

### GetFwPkg

`func (o *V10ClusterFirmwareUpgradeItem) GetFwPkg() string`

GetFwPkg returns the FwPkg field if non-nil, zero value otherwise.

### GetFwPkgOk

`func (o *V10ClusterFirmwareUpgradeItem) GetFwPkgOk() (*string, bool)`

GetFwPkgOk returns a tuple with the FwPkg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFwPkg

`func (o *V10ClusterFirmwareUpgradeItem) SetFwPkg(v string)`

SetFwPkg sets FwPkg field to given value.

### HasFwPkg

`func (o *V10ClusterFirmwareUpgradeItem) HasFwPkg() bool`

HasFwPkg returns a boolean if a field has been set.

### GetIncludeDevice

`func (o *V10ClusterFirmwareUpgradeItem) GetIncludeDevice() string`

GetIncludeDevice returns the IncludeDevice field if non-nil, zero value otherwise.

### GetIncludeDeviceOk

`func (o *V10ClusterFirmwareUpgradeItem) GetIncludeDeviceOk() (*string, bool)`

GetIncludeDeviceOk returns a tuple with the IncludeDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeDevice

`func (o *V10ClusterFirmwareUpgradeItem) SetIncludeDevice(v string)`

SetIncludeDevice sets IncludeDevice field to given value.

### HasIncludeDevice

`func (o *V10ClusterFirmwareUpgradeItem) HasIncludeDevice() bool`

HasIncludeDevice returns a boolean if a field has been set.

### GetIncludeType

`func (o *V10ClusterFirmwareUpgradeItem) GetIncludeType() string`

GetIncludeType returns the IncludeType field if non-nil, zero value otherwise.

### GetIncludeTypeOk

`func (o *V10ClusterFirmwareUpgradeItem) GetIncludeTypeOk() (*string, bool)`

GetIncludeTypeOk returns a tuple with the IncludeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeType

`func (o *V10ClusterFirmwareUpgradeItem) SetIncludeType(v string)`

SetIncludeType sets IncludeType field to given value.

### HasIncludeType

`func (o *V10ClusterFirmwareUpgradeItem) HasIncludeType() bool`

HasIncludeType returns a boolean if a field has been set.

### GetNoBurn

`func (o *V10ClusterFirmwareUpgradeItem) GetNoBurn() bool`

GetNoBurn returns the NoBurn field if non-nil, zero value otherwise.

### GetNoBurnOk

`func (o *V10ClusterFirmwareUpgradeItem) GetNoBurnOk() (*bool, bool)`

GetNoBurnOk returns a tuple with the NoBurn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoBurn

`func (o *V10ClusterFirmwareUpgradeItem) SetNoBurn(v bool)`

SetNoBurn sets NoBurn field to given value.

### HasNoBurn

`func (o *V10ClusterFirmwareUpgradeItem) HasNoBurn() bool`

HasNoBurn returns a boolean if a field has been set.

### GetNoReboot

`func (o *V10ClusterFirmwareUpgradeItem) GetNoReboot() bool`

GetNoReboot returns the NoReboot field if non-nil, zero value otherwise.

### GetNoRebootOk

`func (o *V10ClusterFirmwareUpgradeItem) GetNoRebootOk() (*bool, bool)`

GetNoRebootOk returns a tuple with the NoReboot field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoReboot

`func (o *V10ClusterFirmwareUpgradeItem) SetNoReboot(v bool)`

SetNoReboot sets NoReboot field to given value.

### HasNoReboot

`func (o *V10ClusterFirmwareUpgradeItem) HasNoReboot() bool`

HasNoReboot returns a boolean if a field has been set.

### GetNodesToUpgrade

`func (o *V10ClusterFirmwareUpgradeItem) GetNodesToUpgrade() []int32`

GetNodesToUpgrade returns the NodesToUpgrade field if non-nil, zero value otherwise.

### GetNodesToUpgradeOk

`func (o *V10ClusterFirmwareUpgradeItem) GetNodesToUpgradeOk() (*[]int32, bool)`

GetNodesToUpgradeOk returns a tuple with the NodesToUpgrade field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodesToUpgrade

`func (o *V10ClusterFirmwareUpgradeItem) SetNodesToUpgrade(v []int32)`

SetNodesToUpgrade sets NodesToUpgrade field to given value.

### HasNodesToUpgrade

`func (o *V10ClusterFirmwareUpgradeItem) HasNodesToUpgrade() bool`

HasNodesToUpgrade returns a boolean if a field has been set.

### GetUpgradeType

`func (o *V10ClusterFirmwareUpgradeItem) GetUpgradeType() string`

GetUpgradeType returns the UpgradeType field if non-nil, zero value otherwise.

### GetUpgradeTypeOk

`func (o *V10ClusterFirmwareUpgradeItem) GetUpgradeTypeOk() (*string, bool)`

GetUpgradeTypeOk returns a tuple with the UpgradeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpgradeType

`func (o *V10ClusterFirmwareUpgradeItem) SetUpgradeType(v string)`

SetUpgradeType sets UpgradeType field to given value.

### HasUpgradeType

`func (o *V10ClusterFirmwareUpgradeItem) HasUpgradeType() bool`

HasUpgradeType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


