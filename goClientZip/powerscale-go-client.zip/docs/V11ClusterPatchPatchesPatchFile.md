# V11ClusterPatchPatchesPatchFile

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Md5** | Pointer to **string** | The md5 checksum of the file. | [optional] 
**Path** | Pointer to **string** | The path of the file. | [optional] 

## Methods

### NewV11ClusterPatchPatchesPatchFile

`func NewV11ClusterPatchPatchesPatchFile() *V11ClusterPatchPatchesPatchFile`

NewV11ClusterPatchPatchesPatchFile instantiates a new V11ClusterPatchPatchesPatchFile object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ClusterPatchPatchesPatchFileWithDefaults

`func NewV11ClusterPatchPatchesPatchFileWithDefaults() *V11ClusterPatchPatchesPatchFile`

NewV11ClusterPatchPatchesPatchFileWithDefaults instantiates a new V11ClusterPatchPatchesPatchFile object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMd5

`func (o *V11ClusterPatchPatchesPatchFile) GetMd5() string`

GetMd5 returns the Md5 field if non-nil, zero value otherwise.

### GetMd5Ok

`func (o *V11ClusterPatchPatchesPatchFile) GetMd5Ok() (*string, bool)`

GetMd5Ok returns a tuple with the Md5 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMd5

`func (o *V11ClusterPatchPatchesPatchFile) SetMd5(v string)`

SetMd5 sets Md5 field to given value.

### HasMd5

`func (o *V11ClusterPatchPatchesPatchFile) HasMd5() bool`

HasMd5 returns a boolean if a field has been set.

### GetPath

`func (o *V11ClusterPatchPatchesPatchFile) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V11ClusterPatchPatchesPatchFile) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V11ClusterPatchPatchesPatchFile) SetPath(v string)`

SetPath sets Path field to given value.

### HasPath

`func (o *V11ClusterPatchPatchesPatchFile) HasPath() bool`

HasPath returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


