# V12SedSettingsSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**KmipEnabled** | **bool** | True if the KMIP SEDS feature is enabled and migration is allowed. When set to false, the KMIP SEDS feature is disabled, migration is not allowed. User can disable the feature only when ALL keys are in LOCAL status. | 
**KmipServer** | **string** | Current kmip server. | 
**Supported** | **bool** | True if the SEDS is supported by the platform. | 

## Methods

### NewV12SedSettingsSettings

`func NewV12SedSettingsSettings(kmipEnabled bool, kmipServer string, supported bool, ) *V12SedSettingsSettings`

NewV12SedSettingsSettings instantiates a new V12SedSettingsSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SedSettingsSettingsWithDefaults

`func NewV12SedSettingsSettingsWithDefaults() *V12SedSettingsSettings`

NewV12SedSettingsSettingsWithDefaults instantiates a new V12SedSettingsSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetKmipEnabled

`func (o *V12SedSettingsSettings) GetKmipEnabled() bool`

GetKmipEnabled returns the KmipEnabled field if non-nil, zero value otherwise.

### GetKmipEnabledOk

`func (o *V12SedSettingsSettings) GetKmipEnabledOk() (*bool, bool)`

GetKmipEnabledOk returns a tuple with the KmipEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKmipEnabled

`func (o *V12SedSettingsSettings) SetKmipEnabled(v bool)`

SetKmipEnabled sets KmipEnabled field to given value.


### GetKmipServer

`func (o *V12SedSettingsSettings) GetKmipServer() string`

GetKmipServer returns the KmipServer field if non-nil, zero value otherwise.

### GetKmipServerOk

`func (o *V12SedSettingsSettings) GetKmipServerOk() (*string, bool)`

GetKmipServerOk returns a tuple with the KmipServer field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKmipServer

`func (o *V12SedSettingsSettings) SetKmipServer(v string)`

SetKmipServer sets KmipServer field to given value.


### GetSupported

`func (o *V12SedSettingsSettings) GetSupported() bool`

GetSupported returns the Supported field if non-nil, zero value otherwise.

### GetSupportedOk

`func (o *V12SedSettingsSettings) GetSupportedOk() (*bool, bool)`

GetSupportedOk returns a tuple with the Supported field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupported

`func (o *V12SedSettingsSettings) SetSupported(v bool)`

SetSupported sets Supported field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


