# V12KmipServerClientCert

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExpirationDate** | Pointer to **int32** | Cluster identity certificate expiration date in UNIX timestamp format. | [optional] 
**Fingerprint** | Pointer to **string** | Cluster identity certificate sha256 fingerprint. | [optional] 
**Serial** | Pointer to **int32** | Cluster identity certificate serial number field. | [optional] 
**Subject** | Pointer to **string** | Cluster identity certificate subject field. | [optional] 

## Methods

### NewV12KmipServerClientCert

`func NewV12KmipServerClientCert() *V12KmipServerClientCert`

NewV12KmipServerClientCert instantiates a new V12KmipServerClientCert object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12KmipServerClientCertWithDefaults

`func NewV12KmipServerClientCertWithDefaults() *V12KmipServerClientCert`

NewV12KmipServerClientCertWithDefaults instantiates a new V12KmipServerClientCert object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExpirationDate

`func (o *V12KmipServerClientCert) GetExpirationDate() int32`

GetExpirationDate returns the ExpirationDate field if non-nil, zero value otherwise.

### GetExpirationDateOk

`func (o *V12KmipServerClientCert) GetExpirationDateOk() (*int32, bool)`

GetExpirationDateOk returns a tuple with the ExpirationDate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpirationDate

`func (o *V12KmipServerClientCert) SetExpirationDate(v int32)`

SetExpirationDate sets ExpirationDate field to given value.

### HasExpirationDate

`func (o *V12KmipServerClientCert) HasExpirationDate() bool`

HasExpirationDate returns a boolean if a field has been set.

### GetFingerprint

`func (o *V12KmipServerClientCert) GetFingerprint() string`

GetFingerprint returns the Fingerprint field if non-nil, zero value otherwise.

### GetFingerprintOk

`func (o *V12KmipServerClientCert) GetFingerprintOk() (*string, bool)`

GetFingerprintOk returns a tuple with the Fingerprint field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFingerprint

`func (o *V12KmipServerClientCert) SetFingerprint(v string)`

SetFingerprint sets Fingerprint field to given value.

### HasFingerprint

`func (o *V12KmipServerClientCert) HasFingerprint() bool`

HasFingerprint returns a boolean if a field has been set.

### GetSerial

`func (o *V12KmipServerClientCert) GetSerial() int32`

GetSerial returns the Serial field if non-nil, zero value otherwise.

### GetSerialOk

`func (o *V12KmipServerClientCert) GetSerialOk() (*int32, bool)`

GetSerialOk returns a tuple with the Serial field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSerial

`func (o *V12KmipServerClientCert) SetSerial(v int32)`

SetSerial sets Serial field to given value.

### HasSerial

`func (o *V12KmipServerClientCert) HasSerial() bool`

HasSerial returns a boolean if a field has been set.

### GetSubject

`func (o *V12KmipServerClientCert) GetSubject() string`

GetSubject returns the Subject field if non-nil, zero value otherwise.

### GetSubjectOk

`func (o *V12KmipServerClientCert) GetSubjectOk() (*string, bool)`

GetSubjectOk returns a tuple with the Subject field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubject

`func (o *V12KmipServerClientCert) SetSubject(v string)`

SetSubject sets Subject field to given value.

### HasSubject

`func (o *V12KmipServerClientCert) HasSubject() bool`

HasSubject returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


