# V12QuotaQuotaThresholdsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Advisory** | **int64** | Usage bytes at which notifications will be sent but writes will not be denied. | 
**AdvisoryExceeded** | **bool** | True if the advisory threshold has been hit. | 
**AdvisoryLastExceeded** | **int64** | Time at which advisory threshold was hit. | 
**Hard** | **int64** | Usage bytes at which further writes will be denied. | 
**HardExceeded** | **bool** | True if the hard threshold has been hit. | 
**HardLastExceeded** | **int64** | Time at which hard threshold was hit. | 
**PercentAdvisory** | Pointer to **float32** | Advisory threshold as percent of hard threshold. Usage bytes at which notifications will be sent but writes will not be denied. | [optional] 
**PercentSoft** | Pointer to **float32** | Soft threshold as percent of hard threshold. Usage bytes at which notifications will be sent and soft grace time will be started. | [optional] 
**Soft** | **int64** | Usage bytes at which notifications will be sent and soft grace time will be started. | 
**SoftExceeded** | **bool** | True if the soft threshold has been hit. | 
**SoftGrace** | **int64** | Time in seconds after which the soft threshold has been hit before writes will be denied. | 
**SoftLastExceeded** | **int64** | Time at which soft threshold was hit | 

## Methods

### NewV12QuotaQuotaThresholdsExtended

`func NewV12QuotaQuotaThresholdsExtended(advisory int64, advisoryExceeded bool, advisoryLastExceeded int64, hard int64, hardExceeded bool, hardLastExceeded int64, soft int64, softExceeded bool, softGrace int64, softLastExceeded int64, ) *V12QuotaQuotaThresholdsExtended`

NewV12QuotaQuotaThresholdsExtended instantiates a new V12QuotaQuotaThresholdsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12QuotaQuotaThresholdsExtendedWithDefaults

`func NewV12QuotaQuotaThresholdsExtendedWithDefaults() *V12QuotaQuotaThresholdsExtended`

NewV12QuotaQuotaThresholdsExtendedWithDefaults instantiates a new V12QuotaQuotaThresholdsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAdvisory

`func (o *V12QuotaQuotaThresholdsExtended) GetAdvisory() int64`

GetAdvisory returns the Advisory field if non-nil, zero value otherwise.

### GetAdvisoryOk

`func (o *V12QuotaQuotaThresholdsExtended) GetAdvisoryOk() (*int64, bool)`

GetAdvisoryOk returns a tuple with the Advisory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAdvisory

`func (o *V12QuotaQuotaThresholdsExtended) SetAdvisory(v int64)`

SetAdvisory sets Advisory field to given value.


### GetAdvisoryExceeded

`func (o *V12QuotaQuotaThresholdsExtended) GetAdvisoryExceeded() bool`

GetAdvisoryExceeded returns the AdvisoryExceeded field if non-nil, zero value otherwise.

### GetAdvisoryExceededOk

`func (o *V12QuotaQuotaThresholdsExtended) GetAdvisoryExceededOk() (*bool, bool)`

GetAdvisoryExceededOk returns a tuple with the AdvisoryExceeded field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAdvisoryExceeded

`func (o *V12QuotaQuotaThresholdsExtended) SetAdvisoryExceeded(v bool)`

SetAdvisoryExceeded sets AdvisoryExceeded field to given value.


### GetAdvisoryLastExceeded

`func (o *V12QuotaQuotaThresholdsExtended) GetAdvisoryLastExceeded() int64`

GetAdvisoryLastExceeded returns the AdvisoryLastExceeded field if non-nil, zero value otherwise.

### GetAdvisoryLastExceededOk

`func (o *V12QuotaQuotaThresholdsExtended) GetAdvisoryLastExceededOk() (*int64, bool)`

GetAdvisoryLastExceededOk returns a tuple with the AdvisoryLastExceeded field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAdvisoryLastExceeded

`func (o *V12QuotaQuotaThresholdsExtended) SetAdvisoryLastExceeded(v int64)`

SetAdvisoryLastExceeded sets AdvisoryLastExceeded field to given value.


### GetHard

`func (o *V12QuotaQuotaThresholdsExtended) GetHard() int64`

GetHard returns the Hard field if non-nil, zero value otherwise.

### GetHardOk

`func (o *V12QuotaQuotaThresholdsExtended) GetHardOk() (*int64, bool)`

GetHardOk returns a tuple with the Hard field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHard

`func (o *V12QuotaQuotaThresholdsExtended) SetHard(v int64)`

SetHard sets Hard field to given value.


### GetHardExceeded

`func (o *V12QuotaQuotaThresholdsExtended) GetHardExceeded() bool`

GetHardExceeded returns the HardExceeded field if non-nil, zero value otherwise.

### GetHardExceededOk

`func (o *V12QuotaQuotaThresholdsExtended) GetHardExceededOk() (*bool, bool)`

GetHardExceededOk returns a tuple with the HardExceeded field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHardExceeded

`func (o *V12QuotaQuotaThresholdsExtended) SetHardExceeded(v bool)`

SetHardExceeded sets HardExceeded field to given value.


### GetHardLastExceeded

`func (o *V12QuotaQuotaThresholdsExtended) GetHardLastExceeded() int64`

GetHardLastExceeded returns the HardLastExceeded field if non-nil, zero value otherwise.

### GetHardLastExceededOk

`func (o *V12QuotaQuotaThresholdsExtended) GetHardLastExceededOk() (*int64, bool)`

GetHardLastExceededOk returns a tuple with the HardLastExceeded field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHardLastExceeded

`func (o *V12QuotaQuotaThresholdsExtended) SetHardLastExceeded(v int64)`

SetHardLastExceeded sets HardLastExceeded field to given value.


### GetPercentAdvisory

`func (o *V12QuotaQuotaThresholdsExtended) GetPercentAdvisory() float32`

GetPercentAdvisory returns the PercentAdvisory field if non-nil, zero value otherwise.

### GetPercentAdvisoryOk

`func (o *V12QuotaQuotaThresholdsExtended) GetPercentAdvisoryOk() (*float32, bool)`

GetPercentAdvisoryOk returns a tuple with the PercentAdvisory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentAdvisory

`func (o *V12QuotaQuotaThresholdsExtended) SetPercentAdvisory(v float32)`

SetPercentAdvisory sets PercentAdvisory field to given value.

### HasPercentAdvisory

`func (o *V12QuotaQuotaThresholdsExtended) HasPercentAdvisory() bool`

HasPercentAdvisory returns a boolean if a field has been set.

### GetPercentSoft

`func (o *V12QuotaQuotaThresholdsExtended) GetPercentSoft() float32`

GetPercentSoft returns the PercentSoft field if non-nil, zero value otherwise.

### GetPercentSoftOk

`func (o *V12QuotaQuotaThresholdsExtended) GetPercentSoftOk() (*float32, bool)`

GetPercentSoftOk returns a tuple with the PercentSoft field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPercentSoft

`func (o *V12QuotaQuotaThresholdsExtended) SetPercentSoft(v float32)`

SetPercentSoft sets PercentSoft field to given value.

### HasPercentSoft

`func (o *V12QuotaQuotaThresholdsExtended) HasPercentSoft() bool`

HasPercentSoft returns a boolean if a field has been set.

### GetSoft

`func (o *V12QuotaQuotaThresholdsExtended) GetSoft() int64`

GetSoft returns the Soft field if non-nil, zero value otherwise.

### GetSoftOk

`func (o *V12QuotaQuotaThresholdsExtended) GetSoftOk() (*int64, bool)`

GetSoftOk returns a tuple with the Soft field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSoft

`func (o *V12QuotaQuotaThresholdsExtended) SetSoft(v int64)`

SetSoft sets Soft field to given value.


### GetSoftExceeded

`func (o *V12QuotaQuotaThresholdsExtended) GetSoftExceeded() bool`

GetSoftExceeded returns the SoftExceeded field if non-nil, zero value otherwise.

### GetSoftExceededOk

`func (o *V12QuotaQuotaThresholdsExtended) GetSoftExceededOk() (*bool, bool)`

GetSoftExceededOk returns a tuple with the SoftExceeded field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSoftExceeded

`func (o *V12QuotaQuotaThresholdsExtended) SetSoftExceeded(v bool)`

SetSoftExceeded sets SoftExceeded field to given value.


### GetSoftGrace

`func (o *V12QuotaQuotaThresholdsExtended) GetSoftGrace() int64`

GetSoftGrace returns the SoftGrace field if non-nil, zero value otherwise.

### GetSoftGraceOk

`func (o *V12QuotaQuotaThresholdsExtended) GetSoftGraceOk() (*int64, bool)`

GetSoftGraceOk returns a tuple with the SoftGrace field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSoftGrace

`func (o *V12QuotaQuotaThresholdsExtended) SetSoftGrace(v int64)`

SetSoftGrace sets SoftGrace field to given value.


### GetSoftLastExceeded

`func (o *V12QuotaQuotaThresholdsExtended) GetSoftLastExceeded() int64`

GetSoftLastExceeded returns the SoftLastExceeded field if non-nil, zero value otherwise.

### GetSoftLastExceededOk

`func (o *V12QuotaQuotaThresholdsExtended) GetSoftLastExceededOk() (*int64, bool)`

GetSoftLastExceededOk returns a tuple with the SoftLastExceeded field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSoftLastExceeded

`func (o *V12QuotaQuotaThresholdsExtended) SetSoftLastExceeded(v int64)`

SetSoftLastExceeded sets SoftLastExceeded field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


