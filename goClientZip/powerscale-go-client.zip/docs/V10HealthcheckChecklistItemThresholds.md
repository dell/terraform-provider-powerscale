# V10HealthcheckChecklistItemThresholds

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Critical** | Pointer to **int32** | Minimum value for CRITICAL - below this EMERGENCY | [optional] 
**Ok** | Pointer to **int32** | Minimum value for OK - must be &gt; warning | [optional] 
**Warning** | Pointer to **int32** | Minimum value for WARNING - must be &gt; critical | [optional] 

## Methods

### NewV10HealthcheckChecklistItemThresholds

`func NewV10HealthcheckChecklistItemThresholds() *V10HealthcheckChecklistItemThresholds`

NewV10HealthcheckChecklistItemThresholds instantiates a new V10HealthcheckChecklistItemThresholds object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckChecklistItemThresholdsWithDefaults

`func NewV10HealthcheckChecklistItemThresholdsWithDefaults() *V10HealthcheckChecklistItemThresholds`

NewV10HealthcheckChecklistItemThresholdsWithDefaults instantiates a new V10HealthcheckChecklistItemThresholds object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCritical

`func (o *V10HealthcheckChecklistItemThresholds) GetCritical() int32`

GetCritical returns the Critical field if non-nil, zero value otherwise.

### GetCriticalOk

`func (o *V10HealthcheckChecklistItemThresholds) GetCriticalOk() (*int32, bool)`

GetCriticalOk returns a tuple with the Critical field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCritical

`func (o *V10HealthcheckChecklistItemThresholds) SetCritical(v int32)`

SetCritical sets Critical field to given value.

### HasCritical

`func (o *V10HealthcheckChecklistItemThresholds) HasCritical() bool`

HasCritical returns a boolean if a field has been set.

### GetOk

`func (o *V10HealthcheckChecklistItemThresholds) GetOk() int32`

GetOk returns the Ok field if non-nil, zero value otherwise.

### GetOkOk

`func (o *V10HealthcheckChecklistItemThresholds) GetOkOk() (*int32, bool)`

GetOkOk returns a tuple with the Ok field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOk

`func (o *V10HealthcheckChecklistItemThresholds) SetOk(v int32)`

SetOk sets Ok field to given value.

### HasOk

`func (o *V10HealthcheckChecklistItemThresholds) HasOk() bool`

HasOk returns a boolean if a field has been set.

### GetWarning

`func (o *V10HealthcheckChecklistItemThresholds) GetWarning() int32`

GetWarning returns the Warning field if non-nil, zero value otherwise.

### GetWarningOk

`func (o *V10HealthcheckChecklistItemThresholds) GetWarningOk() (*int32, bool)`

GetWarningOk returns a tuple with the Warning field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWarning

`func (o *V10HealthcheckChecklistItemThresholds) SetWarning(v int32)`

SetWarning sets Warning field to given value.

### HasWarning

`func (o *V10HealthcheckChecklistItemThresholds) HasWarning() bool`

HasWarning returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


