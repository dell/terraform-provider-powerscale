# V14SnapshotWritableSnapshotSummarySummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ActiveCount** | Pointer to **int32** | Total number of active writable snapshots. | [optional] 
**ActivePhysSize** | Pointer to **int32** | Sum of storage in bytes used by active writable snapshots. | [optional] 
**Count** | Pointer to **int32** | Total number of writable snapshots. | [optional] 
**DeletingCount** | Pointer to **int32** | Total number of delete-pending writable snapshots. | [optional] 
**DeletingPhysSize** | Pointer to **int32** | Sum of storage in bytes used by delete-pending writable snapshots. | [optional] 
**PhysSize** | Pointer to **int32** | Sum of storage in bytes used by all writable snapshots. | [optional] 

## Methods

### NewV14SnapshotWritableSnapshotSummarySummary

`func NewV14SnapshotWritableSnapshotSummarySummary() *V14SnapshotWritableSnapshotSummarySummary`

NewV14SnapshotWritableSnapshotSummarySummary instantiates a new V14SnapshotWritableSnapshotSummarySummary object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SnapshotWritableSnapshotSummarySummaryWithDefaults

`func NewV14SnapshotWritableSnapshotSummarySummaryWithDefaults() *V14SnapshotWritableSnapshotSummarySummary`

NewV14SnapshotWritableSnapshotSummarySummaryWithDefaults instantiates a new V14SnapshotWritableSnapshotSummarySummary object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetActiveCount

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetActiveCount() int32`

GetActiveCount returns the ActiveCount field if non-nil, zero value otherwise.

### GetActiveCountOk

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetActiveCountOk() (*int32, bool)`

GetActiveCountOk returns a tuple with the ActiveCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetActiveCount

`func (o *V14SnapshotWritableSnapshotSummarySummary) SetActiveCount(v int32)`

SetActiveCount sets ActiveCount field to given value.

### HasActiveCount

`func (o *V14SnapshotWritableSnapshotSummarySummary) HasActiveCount() bool`

HasActiveCount returns a boolean if a field has been set.

### GetActivePhysSize

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetActivePhysSize() int32`

GetActivePhysSize returns the ActivePhysSize field if non-nil, zero value otherwise.

### GetActivePhysSizeOk

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetActivePhysSizeOk() (*int32, bool)`

GetActivePhysSizeOk returns a tuple with the ActivePhysSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetActivePhysSize

`func (o *V14SnapshotWritableSnapshotSummarySummary) SetActivePhysSize(v int32)`

SetActivePhysSize sets ActivePhysSize field to given value.

### HasActivePhysSize

`func (o *V14SnapshotWritableSnapshotSummarySummary) HasActivePhysSize() bool`

HasActivePhysSize returns a boolean if a field has been set.

### GetCount

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetCount() int32`

GetCount returns the Count field if non-nil, zero value otherwise.

### GetCountOk

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetCountOk() (*int32, bool)`

GetCountOk returns a tuple with the Count field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCount

`func (o *V14SnapshotWritableSnapshotSummarySummary) SetCount(v int32)`

SetCount sets Count field to given value.

### HasCount

`func (o *V14SnapshotWritableSnapshotSummarySummary) HasCount() bool`

HasCount returns a boolean if a field has been set.

### GetDeletingCount

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetDeletingCount() int32`

GetDeletingCount returns the DeletingCount field if non-nil, zero value otherwise.

### GetDeletingCountOk

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetDeletingCountOk() (*int32, bool)`

GetDeletingCountOk returns a tuple with the DeletingCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeletingCount

`func (o *V14SnapshotWritableSnapshotSummarySummary) SetDeletingCount(v int32)`

SetDeletingCount sets DeletingCount field to given value.

### HasDeletingCount

`func (o *V14SnapshotWritableSnapshotSummarySummary) HasDeletingCount() bool`

HasDeletingCount returns a boolean if a field has been set.

### GetDeletingPhysSize

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetDeletingPhysSize() int32`

GetDeletingPhysSize returns the DeletingPhysSize field if non-nil, zero value otherwise.

### GetDeletingPhysSizeOk

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetDeletingPhysSizeOk() (*int32, bool)`

GetDeletingPhysSizeOk returns a tuple with the DeletingPhysSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeletingPhysSize

`func (o *V14SnapshotWritableSnapshotSummarySummary) SetDeletingPhysSize(v int32)`

SetDeletingPhysSize sets DeletingPhysSize field to given value.

### HasDeletingPhysSize

`func (o *V14SnapshotWritableSnapshotSummarySummary) HasDeletingPhysSize() bool`

HasDeletingPhysSize returns a boolean if a field has been set.

### GetPhysSize

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetPhysSize() int32`

GetPhysSize returns the PhysSize field if non-nil, zero value otherwise.

### GetPhysSizeOk

`func (o *V14SnapshotWritableSnapshotSummarySummary) GetPhysSizeOk() (*int32, bool)`

GetPhysSizeOk returns a tuple with the PhysSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysSize

`func (o *V14SnapshotWritableSnapshotSummarySummary) SetPhysSize(v int32)`

SetPhysSize sets PhysSize field to given value.

### HasPhysSize

`func (o *V14SnapshotWritableSnapshotSummarySummary) HasPhysSize() bool`

HasPhysSize returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


