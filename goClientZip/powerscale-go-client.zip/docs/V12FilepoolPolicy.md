# V12FilepoolPolicy

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Actions** | [**[]V1FilepoolDefaultPolicyAction**](V1FilepoolDefaultPolicyAction.md) | A list of actions to be taken for matching files | 
**ApplyOrder** | Pointer to **int64** | The order in which this policy should be applied (relative to other policies) | [optional] 
**Description** | Pointer to **string** | A description for this policy | [optional] 
**FileMatchingPattern** | [**V1FilepoolPolicyFileMatchingPattern**](V1FilepoolPolicyFileMatchingPattern.md) |  | 
**Name** | **string** | A unique name for this policy | 

## Methods

### NewV12FilepoolPolicy

`func NewV12FilepoolPolicy(actions []V1FilepoolDefaultPolicyAction, fileMatchingPattern V1FilepoolPolicyFileMatchingPattern, name string, ) *V12FilepoolPolicy`

NewV12FilepoolPolicy instantiates a new V12FilepoolPolicy object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12FilepoolPolicyWithDefaults

`func NewV12FilepoolPolicyWithDefaults() *V12FilepoolPolicy`

NewV12FilepoolPolicyWithDefaults instantiates a new V12FilepoolPolicy object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetActions

`func (o *V12FilepoolPolicy) GetActions() []V1FilepoolDefaultPolicyAction`

GetActions returns the Actions field if non-nil, zero value otherwise.

### GetActionsOk

`func (o *V12FilepoolPolicy) GetActionsOk() (*[]V1FilepoolDefaultPolicyAction, bool)`

GetActionsOk returns a tuple with the Actions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetActions

`func (o *V12FilepoolPolicy) SetActions(v []V1FilepoolDefaultPolicyAction)`

SetActions sets Actions field to given value.


### GetApplyOrder

`func (o *V12FilepoolPolicy) GetApplyOrder() int64`

GetApplyOrder returns the ApplyOrder field if non-nil, zero value otherwise.

### GetApplyOrderOk

`func (o *V12FilepoolPolicy) GetApplyOrderOk() (*int64, bool)`

GetApplyOrderOk returns a tuple with the ApplyOrder field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetApplyOrder

`func (o *V12FilepoolPolicy) SetApplyOrder(v int64)`

SetApplyOrder sets ApplyOrder field to given value.

### HasApplyOrder

`func (o *V12FilepoolPolicy) HasApplyOrder() bool`

HasApplyOrder returns a boolean if a field has been set.

### GetDescription

`func (o *V12FilepoolPolicy) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V12FilepoolPolicy) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V12FilepoolPolicy) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V12FilepoolPolicy) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetFileMatchingPattern

`func (o *V12FilepoolPolicy) GetFileMatchingPattern() V1FilepoolPolicyFileMatchingPattern`

GetFileMatchingPattern returns the FileMatchingPattern field if non-nil, zero value otherwise.

### GetFileMatchingPatternOk

`func (o *V12FilepoolPolicy) GetFileMatchingPatternOk() (*V1FilepoolPolicyFileMatchingPattern, bool)`

GetFileMatchingPatternOk returns a tuple with the FileMatchingPattern field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileMatchingPattern

`func (o *V12FilepoolPolicy) SetFileMatchingPattern(v V1FilepoolPolicyFileMatchingPattern)`

SetFileMatchingPattern sets FileMatchingPattern field to given value.


### GetName

`func (o *V12FilepoolPolicy) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12FilepoolPolicy) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12FilepoolPolicy) SetName(v string)`

SetName sets Name field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


