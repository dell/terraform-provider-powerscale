# \NetworkGroupnetsSubnetsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateNetworkGroupnetsSubnetsv3PoolsPoolRebalanceIp**](NetworkGroupnetsSubnetsApi.md#CreateNetworkGroupnetsSubnetsv3PoolsPoolRebalanceIp) | **Post** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{Pool}/rebalance-ips | 
[**CreateNetworkGroupnetsSubnetsv3PoolsPoolRule**](NetworkGroupnetsSubnetsApi.md#CreateNetworkGroupnetsSubnetsv3PoolsPoolRule) | **Post** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{Pool}/rules | 
[**CreateNetworkGroupnetsSubnetsv3PoolsPoolScResumeNode**](NetworkGroupnetsSubnetsApi.md#CreateNetworkGroupnetsSubnetsv3PoolsPoolScResumeNode) | **Post** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{Pool}/sc-resume-nodes | 
[**CreateNetworkGroupnetsSubnetsv3PoolsPoolScSuspendNode**](NetworkGroupnetsSubnetsApi.md#CreateNetworkGroupnetsSubnetsv3PoolsPoolScSuspendNode) | **Post** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{Pool}/sc-suspend-nodes | 
[**GetNetworkGroupnetsSubnetsv7PoolsPoolInterfaces**](NetworkGroupnetsSubnetsApi.md#GetNetworkGroupnetsSubnetsv7PoolsPoolInterfaces) | **Get** /platform/7/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{Pool}/interfaces | 
[**ListNetworkGroupnetsSubnetsv3PoolsPoolRules**](NetworkGroupnetsSubnetsApi.md#ListNetworkGroupnetsSubnetsv3PoolsPoolRules) | **Get** /platform/3/network/groupnets/{Groupnet}/subnets/{Subnet}/pools/{Pool}/rules | 



## CreateNetworkGroupnetsSubnetsv3PoolsPoolRebalanceIp

> map[string]interface{} CreateNetworkGroupnetsSubnetsv3PoolsPoolRebalanceIp(ctx, groupnet, subnet, pool).V3PoolsPoolRebalanceIp(v3PoolsPoolRebalanceIp).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    pool := "pool_example" // string | 
    v3PoolsPoolRebalanceIp := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolRebalanceIp(context.Background(), groupnet, subnet, pool).V3PoolsPoolRebalanceIp(v3PoolsPoolRebalanceIp).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolRebalanceIp``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsSubnetsv3PoolsPoolRebalanceIp`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolRebalanceIp`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 
**pool** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsSubnetsv3PoolsPoolRebalanceIpRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **v3PoolsPoolRebalanceIp** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkGroupnetsSubnetsv3PoolsPoolRule

> CreateResponse CreateNetworkGroupnetsSubnetsv3PoolsPoolRule(ctx, groupnet, subnet, pool).V3PoolsPoolRule(v3PoolsPoolRule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    pool := "pool_example" // string | 
    v3PoolsPoolRule := *openapiclient.NewV3PoolsPoolRule("Iface_example", "Name_example") // V3PoolsPoolRule | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolRule(context.Background(), groupnet, subnet, pool).V3PoolsPoolRule(v3PoolsPoolRule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsSubnetsv3PoolsPoolRule`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolRule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 
**pool** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsSubnetsv3PoolsPoolRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **v3PoolsPoolRule** | [**V3PoolsPoolRule**](V3PoolsPoolRule.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkGroupnetsSubnetsv3PoolsPoolScResumeNode

> map[string]interface{} CreateNetworkGroupnetsSubnetsv3PoolsPoolScResumeNode(ctx, groupnet, subnet, pool).V3PoolsPoolScResumeNode(v3PoolsPoolScResumeNode).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    pool := "pool_example" // string | 
    v3PoolsPoolScResumeNode := *openapiclient.NewV3PoolsPoolScResumeNode([]int32{int32(123)}) // V3PoolsPoolScResumeNode | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolScResumeNode(context.Background(), groupnet, subnet, pool).V3PoolsPoolScResumeNode(v3PoolsPoolScResumeNode).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolScResumeNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsSubnetsv3PoolsPoolScResumeNode`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolScResumeNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 
**pool** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsSubnetsv3PoolsPoolScResumeNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **v3PoolsPoolScResumeNode** | [**V3PoolsPoolScResumeNode**](V3PoolsPoolScResumeNode.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateNetworkGroupnetsSubnetsv3PoolsPoolScSuspendNode

> map[string]interface{} CreateNetworkGroupnetsSubnetsv3PoolsPoolScSuspendNode(ctx, groupnet, subnet, pool).V3PoolsPoolScSuspendNode(v3PoolsPoolScSuspendNode).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    pool := "pool_example" // string | 
    v3PoolsPoolScSuspendNode := *openapiclient.NewV3PoolsPoolScResumeNode([]int32{int32(123)}) // V3PoolsPoolScResumeNode | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolScSuspendNode(context.Background(), groupnet, subnet, pool).V3PoolsPoolScSuspendNode(v3PoolsPoolScSuspendNode).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolScSuspendNode``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkGroupnetsSubnetsv3PoolsPoolScSuspendNode`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsSubnetsApi.CreateNetworkGroupnetsSubnetsv3PoolsPoolScSuspendNode`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 
**pool** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkGroupnetsSubnetsv3PoolsPoolScSuspendNodeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **v3PoolsPoolScSuspendNode** | [**V3PoolsPoolScResumeNode**](V3PoolsPoolScResumeNode.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetNetworkGroupnetsSubnetsv7PoolsPoolInterfaces

> V7PoolsPoolInterfaces GetNetworkGroupnetsSubnetsv7PoolsPoolInterfaces(ctx, groupnet, subnet, pool).Sort(sort).Resume(resume).Limit(limit).Dir(dir).Lnns(lnns).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    pool := "pool_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    lnns := "lnns_example" // string | Get a list of interfaces for the specified lnn. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsSubnetsApi.GetNetworkGroupnetsSubnetsv7PoolsPoolInterfaces(context.Background(), groupnet, subnet, pool).Sort(sort).Resume(resume).Limit(limit).Dir(dir).Lnns(lnns).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsSubnetsApi.GetNetworkGroupnetsSubnetsv7PoolsPoolInterfaces``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetNetworkGroupnetsSubnetsv7PoolsPoolInterfaces`: V7PoolsPoolInterfaces
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsSubnetsApi.GetNetworkGroupnetsSubnetsv7PoolsPoolInterfaces`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 
**pool** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetNetworkGroupnetsSubnetsv7PoolsPoolInterfacesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **lnns** | **string** | Get a list of interfaces for the specified lnn. | 

### Return type

[**V7PoolsPoolInterfaces**](V7PoolsPoolInterfaces.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkGroupnetsSubnetsv3PoolsPoolRules

> V3PoolsPoolRules ListNetworkGroupnetsSubnetsv3PoolsPoolRules(ctx, groupnet, subnet, pool).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    groupnet := "groupnet_example" // string | 
    subnet := "subnet_example" // string | 
    pool := "pool_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkGroupnetsSubnetsApi.ListNetworkGroupnetsSubnetsv3PoolsPoolRules(context.Background(), groupnet, subnet, pool).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkGroupnetsSubnetsApi.ListNetworkGroupnetsSubnetsv3PoolsPoolRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkGroupnetsSubnetsv3PoolsPoolRules`: V3PoolsPoolRules
    fmt.Fprintf(os.Stdout, "Response from `NetworkGroupnetsSubnetsApi.ListNetworkGroupnetsSubnetsv3PoolsPoolRules`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**groupnet** | **string** |  | 
**subnet** | **string** |  | 
**pool** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkGroupnetsSubnetsv3PoolsPoolRulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3PoolsPoolRules**](V3PoolsPoolRules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

