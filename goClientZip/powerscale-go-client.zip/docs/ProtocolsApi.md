# \ProtocolsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateProtocolsv10S3Bucket**](ProtocolsApi.md#CreateProtocolsv10S3Bucket) | **Post** /platform/10/protocols/s3/buckets | 
[**CreateProtocolsv10S3Key**](ProtocolsApi.md#CreateProtocolsv10S3Key) | **Post** /platform/10/protocols/s3/keys/{v10S3KeyId} | 
[**CreateProtocolsv10S3Mykey**](ProtocolsApi.md#CreateProtocolsv10S3Mykey) | **Post** /platform/10/protocols/s3/mykeys | 
[**CreateProtocolsv12NfsNetgroupSaveItem**](ProtocolsApi.md#CreateProtocolsv12NfsNetgroupSaveItem) | **Post** /platform/12/protocols/nfs/netgroup/save | 
[**CreateProtocolsv12S3Bucket**](ProtocolsApi.md#CreateProtocolsv12S3Bucket) | **Post** /platform/12/protocols/s3/buckets | 
[**CreateProtocolsv12SmbShare**](ProtocolsApi.md#CreateProtocolsv12SmbShare) | **Post** /platform/12/protocols/smb/shares | 
[**CreateProtocolsv15NfsAlias**](ProtocolsApi.md#CreateProtocolsv15NfsAlias) | **Post** /platform/15/protocols/nfs/aliases | 
[**CreateProtocolsv15S3Bucket**](ProtocolsApi.md#CreateProtocolsv15S3Bucket) | **Post** /platform/15/protocols/s3/buckets | 
[**CreateProtocolsv1HdfsProxyuser**](ProtocolsApi.md#CreateProtocolsv1HdfsProxyuser) | **Post** /platform/1/protocols/hdfs/proxyusers | 
[**CreateProtocolsv1HdfsRack**](ProtocolsApi.md#CreateProtocolsv1HdfsRack) | **Post** /platform/1/protocols/hdfs/racks | 
[**CreateProtocolsv1NfsExport**](ProtocolsApi.md#CreateProtocolsv1NfsExport) | **Post** /platform/1/protocols/nfs/exports | 
[**CreateProtocolsv1NfsReloadItem**](ProtocolsApi.md#CreateProtocolsv1NfsReloadItem) | **Post** /platform/1/protocols/nfs/reload | 
[**CreateProtocolsv1SmbShare**](ProtocolsApi.md#CreateProtocolsv1SmbShare) | **Post** /platform/1/protocols/smb/shares | 
[**CreateProtocolsv2NfsAlias**](ProtocolsApi.md#CreateProtocolsv2NfsAlias) | **Post** /platform/2/protocols/nfs/aliases | 
[**CreateProtocolsv2NfsExport**](ProtocolsApi.md#CreateProtocolsv2NfsExport) | **Post** /platform/2/protocols/nfs/exports | 
[**CreateProtocolsv2NfsReloadItem**](ProtocolsApi.md#CreateProtocolsv2NfsReloadItem) | **Post** /platform/2/protocols/nfs/reload | 
[**CreateProtocolsv3NdmpSettingsVariable**](ProtocolsApi.md#CreateProtocolsv3NdmpSettingsVariable) | **Post** /platform/3/protocols/ndmp/settings/variables/{v3NdmpSettingsVariableId} | 
[**CreateProtocolsv3NdmpUser**](ProtocolsApi.md#CreateProtocolsv3NdmpUser) | **Post** /platform/3/protocols/ndmp/users | 
[**CreateProtocolsv3NfsNetgroupCheckItem**](ProtocolsApi.md#CreateProtocolsv3NfsNetgroupCheckItem) | **Post** /platform/3/protocols/nfs/netgroup/check | 
[**CreateProtocolsv3NfsNetgroupFlushItem**](ProtocolsApi.md#CreateProtocolsv3NfsNetgroupFlushItem) | **Post** /platform/3/protocols/nfs/netgroup/flush | 
[**CreateProtocolsv3NfsNlmSessionsCheckItem**](ProtocolsApi.md#CreateProtocolsv3NfsNlmSessionsCheckItem) | **Post** /platform/3/protocols/nfs/nlm/sessions-check | 
[**CreateProtocolsv3NfsReloadItem**](ProtocolsApi.md#CreateProtocolsv3NfsReloadItem) | **Post** /platform/3/protocols/nfs/reload | 
[**CreateProtocolsv3NtpServer**](ProtocolsApi.md#CreateProtocolsv3NtpServer) | **Post** /platform/3/protocols/ntp/servers | 
[**CreateProtocolsv3SmbLogLevelFilter**](ProtocolsApi.md#CreateProtocolsv3SmbLogLevelFilter) | **Post** /platform/3/protocols/smb/log-level/filters | 
[**CreateProtocolsv3SmbShare**](ProtocolsApi.md#CreateProtocolsv3SmbShare) | **Post** /platform/3/protocols/smb/shares | 
[**CreateProtocolsv3SwiftAccount**](ProtocolsApi.md#CreateProtocolsv3SwiftAccount) | **Post** /platform/3/protocols/swift/accounts | 
[**CreateProtocolsv4NdmpSettingsPreferredIp**](ProtocolsApi.md#CreateProtocolsv4NdmpSettingsPreferredIp) | **Post** /platform/4/protocols/ndmp/settings/preferred-ips | 
[**CreateProtocolsv4NfsExport**](ProtocolsApi.md#CreateProtocolsv4NfsExport) | **Post** /platform/4/protocols/nfs/exports | 
[**CreateProtocolsv4SmbShare**](ProtocolsApi.md#CreateProtocolsv4SmbShare) | **Post** /platform/4/protocols/smb/shares | 
[**CreateProtocolsv6SmbShare**](ProtocolsApi.md#CreateProtocolsv6SmbShare) | **Post** /platform/6/protocols/smb/shares | 
[**CreateProtocolsv7SmbShare**](ProtocolsApi.md#CreateProtocolsv7SmbShare) | **Post** /platform/7/protocols/smb/shares | 
[**DeleteProtocolsv10S3Bucket**](ProtocolsApi.md#DeleteProtocolsv10S3Bucket) | **Delete** /platform/10/protocols/s3/buckets/{v10S3BucketId} | 
[**DeleteProtocolsv10S3Key**](ProtocolsApi.md#DeleteProtocolsv10S3Key) | **Delete** /platform/10/protocols/s3/keys/{v10S3KeyId} | 
[**DeleteProtocolsv10S3Mykeys**](ProtocolsApi.md#DeleteProtocolsv10S3Mykeys) | **Delete** /platform/10/protocols/s3/mykeys | 
[**DeleteProtocolsv11NfsExport**](ProtocolsApi.md#DeleteProtocolsv11NfsExport) | **Delete** /platform/11/protocols/nfs/exports/{v11NfsExportId} | 
[**DeleteProtocolsv12S3Bucket**](ProtocolsApi.md#DeleteProtocolsv12S3Bucket) | **Delete** /platform/12/protocols/s3/buckets/{v12S3BucketId} | 
[**DeleteProtocolsv12SmbShare**](ProtocolsApi.md#DeleteProtocolsv12SmbShare) | **Delete** /platform/12/protocols/smb/shares/{v12SmbShareId} | 
[**DeleteProtocolsv12SmbShares**](ProtocolsApi.md#DeleteProtocolsv12SmbShares) | **Delete** /platform/12/protocols/smb/shares | 
[**DeleteProtocolsv1HdfsProxyuser**](ProtocolsApi.md#DeleteProtocolsv1HdfsProxyuser) | **Delete** /platform/1/protocols/hdfs/proxyusers/{v1HdfsProxyuserId} | 
[**DeleteProtocolsv1HdfsProxyusersNameMember**](ProtocolsApi.md#DeleteProtocolsv1HdfsProxyusersNameMember) | **Delete** /platform/1/protocols/hdfs/proxyusers/{Name}/members/{v1HdfsProxyusersNameMemberId} | 
[**DeleteProtocolsv1HdfsRack**](ProtocolsApi.md#DeleteProtocolsv1HdfsRack) | **Delete** /platform/1/protocols/hdfs/racks/{v1HdfsRackId} | 
[**DeleteProtocolsv1NfsExport**](ProtocolsApi.md#DeleteProtocolsv1NfsExport) | **Delete** /platform/1/protocols/nfs/exports/{v1NfsExportId} | 
[**DeleteProtocolsv1NfsNlmSession**](ProtocolsApi.md#DeleteProtocolsv1NfsNlmSession) | **Delete** /platform/1/protocols/nfs/nlm/sessions/{v1NfsNlmSessionId} | 
[**DeleteProtocolsv1SmbOpenfile**](ProtocolsApi.md#DeleteProtocolsv1SmbOpenfile) | **Delete** /platform/1/protocols/smb/openfiles/{v1SmbOpenfileId} | 
[**DeleteProtocolsv1SmbSession**](ProtocolsApi.md#DeleteProtocolsv1SmbSession) | **Delete** /platform/1/protocols/smb/sessions/{v1SmbSessionId} | 
[**DeleteProtocolsv1SmbSessionsComputerUser**](ProtocolsApi.md#DeleteProtocolsv1SmbSessionsComputerUser) | **Delete** /platform/1/protocols/smb/sessions/{Computer}/{v1SmbSessionsComputerUser} | 
[**DeleteProtocolsv1SmbShare**](ProtocolsApi.md#DeleteProtocolsv1SmbShare) | **Delete** /platform/1/protocols/smb/shares/{v1SmbShareId} | 
[**DeleteProtocolsv1SmbShares**](ProtocolsApi.md#DeleteProtocolsv1SmbShares) | **Delete** /platform/1/protocols/smb/shares | 
[**DeleteProtocolsv2NfsAlias**](ProtocolsApi.md#DeleteProtocolsv2NfsAlias) | **Delete** /platform/2/protocols/nfs/aliases/{v2NfsAliasId} | 
[**DeleteProtocolsv2NfsExport**](ProtocolsApi.md#DeleteProtocolsv2NfsExport) | **Delete** /platform/2/protocols/nfs/exports/{v2NfsExportId} | 
[**DeleteProtocolsv2NfsNlmSession**](ProtocolsApi.md#DeleteProtocolsv2NfsNlmSession) | **Delete** /platform/2/protocols/nfs/nlm/sessions/{v2NfsNlmSessionId} | 
[**DeleteProtocolsv3NdmpContextsBackupById**](ProtocolsApi.md#DeleteProtocolsv3NdmpContextsBackupById) | **Delete** /platform/3/protocols/ndmp/contexts/backup/{v3NdmpContextsBackupId} | 
[**DeleteProtocolsv3NdmpContextsBreById**](ProtocolsApi.md#DeleteProtocolsv3NdmpContextsBreById) | **Delete** /platform/3/protocols/ndmp/contexts/bre/{v3NdmpContextsBreId} | 
[**DeleteProtocolsv3NdmpContextsRestoreById**](ProtocolsApi.md#DeleteProtocolsv3NdmpContextsRestoreById) | **Delete** /platform/3/protocols/ndmp/contexts/restore/{v3NdmpContextsRestoreId} | 
[**DeleteProtocolsv3NdmpDumpdate**](ProtocolsApi.md#DeleteProtocolsv3NdmpDumpdate) | **Delete** /platform/3/protocols/ndmp/dumpdates/{v3NdmpDumpdateId} | 
[**DeleteProtocolsv3NdmpSession**](ProtocolsApi.md#DeleteProtocolsv3NdmpSession) | **Delete** /platform/3/protocols/ndmp/sessions/{v3NdmpSessionId} | 
[**DeleteProtocolsv3NdmpSettingsVariable**](ProtocolsApi.md#DeleteProtocolsv3NdmpSettingsVariable) | **Delete** /platform/3/protocols/ndmp/settings/variables/{v3NdmpSettingsVariableId} | 
[**DeleteProtocolsv3NdmpUser**](ProtocolsApi.md#DeleteProtocolsv3NdmpUser) | **Delete** /platform/3/protocols/ndmp/users/{v3NdmpUserId} | 
[**DeleteProtocolsv3NfsNlmSession**](ProtocolsApi.md#DeleteProtocolsv3NfsNlmSession) | **Delete** /platform/3/protocols/nfs/nlm/sessions/{v3NfsNlmSessionId} | 
[**DeleteProtocolsv3NtpServer**](ProtocolsApi.md#DeleteProtocolsv3NtpServer) | **Delete** /platform/3/protocols/ntp/servers/{v3NtpServerId} | 
[**DeleteProtocolsv3NtpServers**](ProtocolsApi.md#DeleteProtocolsv3NtpServers) | **Delete** /platform/3/protocols/ntp/servers | 
[**DeleteProtocolsv3SmbLogLevelFilter**](ProtocolsApi.md#DeleteProtocolsv3SmbLogLevelFilter) | **Delete** /platform/3/protocols/smb/log-level/filters/{v3SmbLogLevelFilterId} | 
[**DeleteProtocolsv3SmbLogLevelFilters**](ProtocolsApi.md#DeleteProtocolsv3SmbLogLevelFilters) | **Delete** /platform/3/protocols/smb/log-level/filters | 
[**DeleteProtocolsv3SmbShare**](ProtocolsApi.md#DeleteProtocolsv3SmbShare) | **Delete** /platform/3/protocols/smb/shares/{v3SmbShareId} | 
[**DeleteProtocolsv3SmbShares**](ProtocolsApi.md#DeleteProtocolsv3SmbShares) | **Delete** /platform/3/protocols/smb/shares | 
[**DeleteProtocolsv3SwiftAccount**](ProtocolsApi.md#DeleteProtocolsv3SwiftAccount) | **Delete** /platform/3/protocols/swift/accounts/{v3SwiftAccountId} | 
[**DeleteProtocolsv4NdmpSettingsPreferredIp**](ProtocolsApi.md#DeleteProtocolsv4NdmpSettingsPreferredIp) | **Delete** /platform/4/protocols/ndmp/settings/preferred-ips/{v4NdmpSettingsPreferredIpId} | 
[**DeleteProtocolsv4SmbShares**](ProtocolsApi.md#DeleteProtocolsv4SmbShares) | **Delete** /platform/4/protocols/smb/shares | 
[**DeleteProtocolsv5HdfsFsimageLatest**](ProtocolsApi.md#DeleteProtocolsv5HdfsFsimageLatest) | **Delete** /platform/5/protocols/hdfs/fsimage/latest | 
[**DeleteProtocolsv5HdfsInotifyStream**](ProtocolsApi.md#DeleteProtocolsv5HdfsInotifyStream) | **Delete** /platform/5/protocols/hdfs/inotify/stream | 
[**DeleteProtocolsv6SmbShare**](ProtocolsApi.md#DeleteProtocolsv6SmbShare) | **Delete** /platform/6/protocols/smb/shares/{v6SmbShareId} | 
[**DeleteProtocolsv6SmbShares**](ProtocolsApi.md#DeleteProtocolsv6SmbShares) | **Delete** /platform/6/protocols/smb/shares | 
[**DeleteProtocolsv7SmbShare**](ProtocolsApi.md#DeleteProtocolsv7SmbShare) | **Delete** /platform/7/protocols/smb/shares/{v7SmbShareId} | 
[**DeleteProtocolsv7SmbShares**](ProtocolsApi.md#DeleteProtocolsv7SmbShares) | **Delete** /platform/7/protocols/smb/shares | 
[**GetProtocolsv10S3Bucket**](ProtocolsApi.md#GetProtocolsv10S3Bucket) | **Get** /platform/10/protocols/s3/buckets/{v10S3BucketId} | 
[**GetProtocolsv10S3Key**](ProtocolsApi.md#GetProtocolsv10S3Key) | **Get** /platform/10/protocols/s3/keys/{v10S3KeyId} | 
[**GetProtocolsv10S3LogLevel**](ProtocolsApi.md#GetProtocolsv10S3LogLevel) | **Get** /platform/10/protocols/s3/log-level | 
[**GetProtocolsv10S3SettingsGlobal**](ProtocolsApi.md#GetProtocolsv10S3SettingsGlobal) | **Get** /platform/10/protocols/s3/settings/global | 
[**GetProtocolsv10S3SettingsZone**](ProtocolsApi.md#GetProtocolsv10S3SettingsZone) | **Get** /platform/10/protocols/s3/settings/zone | 
[**GetProtocolsv11HdfsSettingsGlobal**](ProtocolsApi.md#GetProtocolsv11HdfsSettingsGlobal) | **Get** /platform/11/protocols/hdfs/settings/global | 
[**GetProtocolsv11NfsExport**](ProtocolsApi.md#GetProtocolsv11NfsExport) | **Get** /platform/11/protocols/nfs/exports/{v11NfsExportId} | 
[**GetProtocolsv11SmbSessions**](ProtocolsApi.md#GetProtocolsv11SmbSessions) | **Get** /platform/11/protocols/smb/sessions | 
[**GetProtocolsv12HdfsLogLevel**](ProtocolsApi.md#GetProtocolsv12HdfsLogLevel) | **Get** /platform/12/protocols/hdfs/log-level | 
[**GetProtocolsv12HdfsSettings**](ProtocolsApi.md#GetProtocolsv12HdfsSettings) | **Get** /platform/12/protocols/hdfs/settings | 
[**GetProtocolsv12NfsLogLevel**](ProtocolsApi.md#GetProtocolsv12NfsLogLevel) | **Get** /platform/12/protocols/nfs/log-level | 
[**GetProtocolsv12NfsSettingsGlobal**](ProtocolsApi.md#GetProtocolsv12NfsSettingsGlobal) | **Get** /platform/12/protocols/nfs/settings/global | 
[**GetProtocolsv12S3Bucket**](ProtocolsApi.md#GetProtocolsv12S3Bucket) | **Get** /platform/12/protocols/s3/buckets/{v12S3BucketId} | 
[**GetProtocolsv12S3SettingsZone**](ProtocolsApi.md#GetProtocolsv12S3SettingsZone) | **Get** /platform/12/protocols/s3/settings/zone | 
[**GetProtocolsv12SmbLogLevel**](ProtocolsApi.md#GetProtocolsv12SmbLogLevel) | **Get** /platform/12/protocols/smb/log-level | 
[**GetProtocolsv12SmbShare**](ProtocolsApi.md#GetProtocolsv12SmbShare) | **Get** /platform/12/protocols/smb/shares/{v12SmbShareId} | 
[**GetProtocolsv14NfsSettingsGlobal**](ProtocolsApi.md#GetProtocolsv14NfsSettingsGlobal) | **Get** /platform/14/protocols/nfs/settings/global | 
[**GetProtocolsv15HttpService**](ProtocolsApi.md#GetProtocolsv15HttpService) | **Get** /platform/15/protocols/http/services/{v15HttpServiceId} | 
[**GetProtocolsv15HttpServices**](ProtocolsApi.md#GetProtocolsv15HttpServices) | **Get** /platform/15/protocols/http/services | 
[**GetProtocolsv1HdfsProxyuser**](ProtocolsApi.md#GetProtocolsv1HdfsProxyuser) | **Get** /platform/1/protocols/hdfs/proxyusers/{v1HdfsProxyuserId} | 
[**GetProtocolsv1HdfsRack**](ProtocolsApi.md#GetProtocolsv1HdfsRack) | **Get** /platform/1/protocols/hdfs/racks/{v1HdfsRackId} | 
[**GetProtocolsv1NfsCheck**](ProtocolsApi.md#GetProtocolsv1NfsCheck) | **Get** /platform/1/protocols/nfs/check | 
[**GetProtocolsv1NfsExport**](ProtocolsApi.md#GetProtocolsv1NfsExport) | **Get** /platform/1/protocols/nfs/exports/{v1NfsExportId} | 
[**GetProtocolsv1NfsExportsSummary**](ProtocolsApi.md#GetProtocolsv1NfsExportsSummary) | **Get** /platform/1/protocols/nfs/exports-summary | 
[**GetProtocolsv1NfsNlmLocks**](ProtocolsApi.md#GetProtocolsv1NfsNlmLocks) | **Get** /platform/1/protocols/nfs/nlm/locks | 
[**GetProtocolsv1NfsNlmSessions**](ProtocolsApi.md#GetProtocolsv1NfsNlmSessions) | **Get** /platform/1/protocols/nfs/nlm/sessions | 
[**GetProtocolsv1NfsNlmWaiters**](ProtocolsApi.md#GetProtocolsv1NfsNlmWaiters) | **Get** /platform/1/protocols/nfs/nlm/waiters | 
[**GetProtocolsv1NfsSettingsExport**](ProtocolsApi.md#GetProtocolsv1NfsSettingsExport) | **Get** /platform/1/protocols/nfs/settings/export | 
[**GetProtocolsv1SmbOpenfiles**](ProtocolsApi.md#GetProtocolsv1SmbOpenfiles) | **Get** /platform/1/protocols/smb/openfiles | 
[**GetProtocolsv1SmbSessions**](ProtocolsApi.md#GetProtocolsv1SmbSessions) | **Get** /platform/1/protocols/smb/sessions | 
[**GetProtocolsv1SmbSettingsGlobal**](ProtocolsApi.md#GetProtocolsv1SmbSettingsGlobal) | **Get** /platform/1/protocols/smb/settings/global | 
[**GetProtocolsv1SmbSettingsShare**](ProtocolsApi.md#GetProtocolsv1SmbSettingsShare) | **Get** /platform/1/protocols/smb/settings/share | 
[**GetProtocolsv1SmbShare**](ProtocolsApi.md#GetProtocolsv1SmbShare) | **Get** /platform/1/protocols/smb/shares/{v1SmbShareId} | 
[**GetProtocolsv1SmbSharesSummary**](ProtocolsApi.md#GetProtocolsv1SmbSharesSummary) | **Get** /platform/1/protocols/smb/shares-summary | 
[**GetProtocolsv2NfsAlias**](ProtocolsApi.md#GetProtocolsv2NfsAlias) | **Get** /platform/2/protocols/nfs/aliases/{v2NfsAliasId} | 
[**GetProtocolsv2NfsCheck**](ProtocolsApi.md#GetProtocolsv2NfsCheck) | **Get** /platform/2/protocols/nfs/check | 
[**GetProtocolsv2NfsExport**](ProtocolsApi.md#GetProtocolsv2NfsExport) | **Get** /platform/2/protocols/nfs/exports/{v2NfsExportId} | 
[**GetProtocolsv2NfsExportsSummary**](ProtocolsApi.md#GetProtocolsv2NfsExportsSummary) | **Get** /platform/2/protocols/nfs/exports-summary | 
[**GetProtocolsv2NfsNlmLocks**](ProtocolsApi.md#GetProtocolsv2NfsNlmLocks) | **Get** /platform/2/protocols/nfs/nlm/locks | 
[**GetProtocolsv2NfsNlmSessions**](ProtocolsApi.md#GetProtocolsv2NfsNlmSessions) | **Get** /platform/2/protocols/nfs/nlm/sessions | 
[**GetProtocolsv2NfsNlmWaiters**](ProtocolsApi.md#GetProtocolsv2NfsNlmWaiters) | **Get** /platform/2/protocols/nfs/nlm/waiters | 
[**GetProtocolsv2NfsSettingsExport**](ProtocolsApi.md#GetProtocolsv2NfsSettingsExport) | **Get** /platform/2/protocols/nfs/settings/export | 
[**GetProtocolsv2NfsSettingsZone**](ProtocolsApi.md#GetProtocolsv2NfsSettingsZone) | **Get** /platform/2/protocols/nfs/settings/zone | 
[**GetProtocolsv3FtpSettings**](ProtocolsApi.md#GetProtocolsv3FtpSettings) | **Get** /platform/3/protocols/ftp/settings | 
[**GetProtocolsv3HdfsLogLevel**](ProtocolsApi.md#GetProtocolsv3HdfsLogLevel) | **Get** /platform/3/protocols/hdfs/log-level | 
[**GetProtocolsv3HttpSettings**](ProtocolsApi.md#GetProtocolsv3HttpSettings) | **Get** /platform/3/protocols/http/settings | 
[**GetProtocolsv3NdmpContextsBackup**](ProtocolsApi.md#GetProtocolsv3NdmpContextsBackup) | **Get** /platform/3/protocols/ndmp/contexts/backup | 
[**GetProtocolsv3NdmpContextsBackupById**](ProtocolsApi.md#GetProtocolsv3NdmpContextsBackupById) | **Get** /platform/3/protocols/ndmp/contexts/backup/{v3NdmpContextsBackupId} | 
[**GetProtocolsv3NdmpContextsBre**](ProtocolsApi.md#GetProtocolsv3NdmpContextsBre) | **Get** /platform/3/protocols/ndmp/contexts/bre | 
[**GetProtocolsv3NdmpContextsBreById**](ProtocolsApi.md#GetProtocolsv3NdmpContextsBreById) | **Get** /platform/3/protocols/ndmp/contexts/bre/{v3NdmpContextsBreId} | 
[**GetProtocolsv3NdmpContextsRestore**](ProtocolsApi.md#GetProtocolsv3NdmpContextsRestore) | **Get** /platform/3/protocols/ndmp/contexts/restore | 
[**GetProtocolsv3NdmpContextsRestoreById**](ProtocolsApi.md#GetProtocolsv3NdmpContextsRestoreById) | **Get** /platform/3/protocols/ndmp/contexts/restore/{v3NdmpContextsRestoreId} | 
[**GetProtocolsv3NdmpDiagnostics**](ProtocolsApi.md#GetProtocolsv3NdmpDiagnostics) | **Get** /platform/3/protocols/ndmp/diagnostics | 
[**GetProtocolsv3NdmpDumpdate**](ProtocolsApi.md#GetProtocolsv3NdmpDumpdate) | **Get** /platform/3/protocols/ndmp/dumpdates/{v3NdmpDumpdateId} | 
[**GetProtocolsv3NdmpLogs**](ProtocolsApi.md#GetProtocolsv3NdmpLogs) | **Get** /platform/3/protocols/ndmp/logs | 
[**GetProtocolsv3NdmpSession**](ProtocolsApi.md#GetProtocolsv3NdmpSession) | **Get** /platform/3/protocols/ndmp/sessions/{v3NdmpSessionId} | 
[**GetProtocolsv3NdmpSessions**](ProtocolsApi.md#GetProtocolsv3NdmpSessions) | **Get** /platform/3/protocols/ndmp/sessions | 
[**GetProtocolsv3NdmpSettingsDmas**](ProtocolsApi.md#GetProtocolsv3NdmpSettingsDmas) | **Get** /platform/3/protocols/ndmp/settings/dmas | 
[**GetProtocolsv3NdmpSettingsGlobal**](ProtocolsApi.md#GetProtocolsv3NdmpSettingsGlobal) | **Get** /platform/3/protocols/ndmp/settings/global | 
[**GetProtocolsv3NdmpSettingsVariable**](ProtocolsApi.md#GetProtocolsv3NdmpSettingsVariable) | **Get** /platform/3/protocols/ndmp/settings/variables/{v3NdmpSettingsVariableId} | 
[**GetProtocolsv3NdmpUser**](ProtocolsApi.md#GetProtocolsv3NdmpUser) | **Get** /platform/3/protocols/ndmp/users/{v3NdmpUserId} | 
[**GetProtocolsv3NfsLogLevel**](ProtocolsApi.md#GetProtocolsv3NfsLogLevel) | **Get** /platform/3/protocols/nfs/log-level | 
[**GetProtocolsv3NfsNetgroup**](ProtocolsApi.md#GetProtocolsv3NfsNetgroup) | **Get** /platform/3/protocols/nfs/netgroup | 
[**GetProtocolsv3NfsNlmSession**](ProtocolsApi.md#GetProtocolsv3NfsNlmSession) | **Get** /platform/3/protocols/nfs/nlm/sessions/{v3NfsNlmSessionId} | 
[**GetProtocolsv3NfsNlmSessions**](ProtocolsApi.md#GetProtocolsv3NfsNlmSessions) | **Get** /platform/3/protocols/nfs/nlm/sessions | 
[**GetProtocolsv3NfsSettingsGlobal**](ProtocolsApi.md#GetProtocolsv3NfsSettingsGlobal) | **Get** /platform/3/protocols/nfs/settings/global | 
[**GetProtocolsv3NtpServer**](ProtocolsApi.md#GetProtocolsv3NtpServer) | **Get** /platform/3/protocols/ntp/servers/{v3NtpServerId} | 
[**GetProtocolsv3NtpSettings**](ProtocolsApi.md#GetProtocolsv3NtpSettings) | **Get** /platform/3/protocols/ntp/settings | 
[**GetProtocolsv3SmbLogLevel**](ProtocolsApi.md#GetProtocolsv3SmbLogLevel) | **Get** /platform/3/protocols/smb/log-level | 
[**GetProtocolsv3SmbLogLevelFilter**](ProtocolsApi.md#GetProtocolsv3SmbLogLevelFilter) | **Get** /platform/3/protocols/smb/log-level/filters/{v3SmbLogLevelFilterId} | 
[**GetProtocolsv3SmbSettingsGlobal**](ProtocolsApi.md#GetProtocolsv3SmbSettingsGlobal) | **Get** /platform/3/protocols/smb/settings/global | 
[**GetProtocolsv3SmbSettingsShare**](ProtocolsApi.md#GetProtocolsv3SmbSettingsShare) | **Get** /platform/3/protocols/smb/settings/share | 
[**GetProtocolsv3SmbShare**](ProtocolsApi.md#GetProtocolsv3SmbShare) | **Get** /platform/3/protocols/smb/shares/{v3SmbShareId} | 
[**GetProtocolsv3SnmpSettings**](ProtocolsApi.md#GetProtocolsv3SnmpSettings) | **Get** /platform/3/protocols/snmp/settings | 
[**GetProtocolsv3SwiftAccount**](ProtocolsApi.md#GetProtocolsv3SwiftAccount) | **Get** /platform/3/protocols/swift/accounts/{v3SwiftAccountId} | 
[**GetProtocolsv4HdfsRangerPluginSettings**](ProtocolsApi.md#GetProtocolsv4HdfsRangerPluginSettings) | **Get** /platform/4/protocols/hdfs/ranger-plugin/settings | 
[**GetProtocolsv4NdmpSettingsPreferredIp**](ProtocolsApi.md#GetProtocolsv4NdmpSettingsPreferredIp) | **Get** /platform/4/protocols/ndmp/settings/preferred-ips/{v4NdmpSettingsPreferredIpId} | 
[**GetProtocolsv5HdfsFsimageJob**](ProtocolsApi.md#GetProtocolsv5HdfsFsimageJob) | **Get** /platform/5/protocols/hdfs/fsimage/job | 
[**GetProtocolsv5HdfsFsimageJobSettings**](ProtocolsApi.md#GetProtocolsv5HdfsFsimageJobSettings) | **Get** /platform/5/protocols/hdfs/fsimage/job/settings | 
[**GetProtocolsv5HdfsFsimageLatest**](ProtocolsApi.md#GetProtocolsv5HdfsFsimageLatest) | **Get** /platform/5/protocols/hdfs/fsimage/latest | 
[**GetProtocolsv5HdfsFsimageSettings**](ProtocolsApi.md#GetProtocolsv5HdfsFsimageSettings) | **Get** /platform/5/protocols/hdfs/fsimage/settings | 
[**GetProtocolsv5HdfsInotifySettings**](ProtocolsApi.md#GetProtocolsv5HdfsInotifySettings) | **Get** /platform/5/protocols/hdfs/inotify/settings | 
[**GetProtocolsv5HdfsInotifyStream**](ProtocolsApi.md#GetProtocolsv5HdfsInotifyStream) | **Get** /platform/5/protocols/hdfs/inotify/stream | 
[**GetProtocolsv5SnmpSettings**](ProtocolsApi.md#GetProtocolsv5SnmpSettings) | **Get** /platform/5/protocols/snmp/settings | 
[**GetProtocolsv6SmbSettingsGlobal**](ProtocolsApi.md#GetProtocolsv6SmbSettingsGlobal) | **Get** /platform/6/protocols/smb/settings/global | 
[**GetProtocolsv6SmbSettingsShare**](ProtocolsApi.md#GetProtocolsv6SmbSettingsShare) | **Get** /platform/6/protocols/smb/settings/share | 
[**GetProtocolsv6SmbSettingsZone**](ProtocolsApi.md#GetProtocolsv6SmbSettingsZone) | **Get** /platform/6/protocols/smb/settings/zone | 
[**GetProtocolsv6SmbShare**](ProtocolsApi.md#GetProtocolsv6SmbShare) | **Get** /platform/6/protocols/smb/shares/{v6SmbShareId} | 
[**GetProtocolsv7HdfsCryptoSettings**](ProtocolsApi.md#GetProtocolsv7HdfsCryptoSettings) | **Get** /platform/7/protocols/hdfs/crypto/settings | 
[**GetProtocolsv7NfsSettingsGlobal**](ProtocolsApi.md#GetProtocolsv7NfsSettingsGlobal) | **Get** /platform/7/protocols/nfs/settings/global | 
[**GetProtocolsv7SmbSettingsGlobal**](ProtocolsApi.md#GetProtocolsv7SmbSettingsGlobal) | **Get** /platform/7/protocols/smb/settings/global | 
[**GetProtocolsv7SmbSettingsShare**](ProtocolsApi.md#GetProtocolsv7SmbSettingsShare) | **Get** /platform/7/protocols/smb/settings/share | 
[**GetProtocolsv7SmbShare**](ProtocolsApi.md#GetProtocolsv7SmbShare) | **Get** /platform/7/protocols/smb/shares/{v7SmbShareId} | 
[**GetProtocolsv7SshSettings**](ProtocolsApi.md#GetProtocolsv7SshSettings) | **Get** /platform/7/protocols/ssh/settings | 
[**GetProtocolsv8SshSettings**](ProtocolsApi.md#GetProtocolsv8SshSettings) | **Get** /platform/8/protocols/ssh/settings | 
[**GetProtocolsv9HdfsSettings**](ProtocolsApi.md#GetProtocolsv9HdfsSettings) | **Get** /platform/9/protocols/hdfs/settings | 
[**ListProtocolsv10S3Buckets**](ProtocolsApi.md#ListProtocolsv10S3Buckets) | **Get** /platform/10/protocols/s3/buckets | 
[**ListProtocolsv10S3Mykeys**](ProtocolsApi.md#ListProtocolsv10S3Mykeys) | **Get** /platform/10/protocols/s3/mykeys | 
[**ListProtocolsv12S3Buckets**](ProtocolsApi.md#ListProtocolsv12S3Buckets) | **Get** /platform/12/protocols/s3/buckets | 
[**ListProtocolsv12SmbShares**](ProtocolsApi.md#ListProtocolsv12SmbShares) | **Get** /platform/12/protocols/smb/shares | 
[**ListProtocolsv15NfsAliases**](ProtocolsApi.md#ListProtocolsv15NfsAliases) | **Get** /platform/15/protocols/nfs/aliases | 
[**ListProtocolsv15S3Buckets**](ProtocolsApi.md#ListProtocolsv15S3Buckets) | **Get** /platform/15/protocols/s3/buckets | 
[**ListProtocolsv1HdfsProxyusers**](ProtocolsApi.md#ListProtocolsv1HdfsProxyusers) | **Get** /platform/1/protocols/hdfs/proxyusers | 
[**ListProtocolsv1HdfsRacks**](ProtocolsApi.md#ListProtocolsv1HdfsRacks) | **Get** /platform/1/protocols/hdfs/racks | 
[**ListProtocolsv1NfsExports**](ProtocolsApi.md#ListProtocolsv1NfsExports) | **Get** /platform/1/protocols/nfs/exports | 
[**ListProtocolsv1SmbShares**](ProtocolsApi.md#ListProtocolsv1SmbShares) | **Get** /platform/1/protocols/smb/shares | 
[**ListProtocolsv2NfsAliases**](ProtocolsApi.md#ListProtocolsv2NfsAliases) | **Get** /platform/2/protocols/nfs/aliases | 
[**ListProtocolsv2NfsExports**](ProtocolsApi.md#ListProtocolsv2NfsExports) | **Get** /platform/2/protocols/nfs/exports | 
[**ListProtocolsv3NdmpUsers**](ProtocolsApi.md#ListProtocolsv3NdmpUsers) | **Get** /platform/3/protocols/ndmp/users | 
[**ListProtocolsv3NtpServers**](ProtocolsApi.md#ListProtocolsv3NtpServers) | **Get** /platform/3/protocols/ntp/servers | 
[**ListProtocolsv3SmbLogLevelFilters**](ProtocolsApi.md#ListProtocolsv3SmbLogLevelFilters) | **Get** /platform/3/protocols/smb/log-level/filters | 
[**ListProtocolsv3SmbShares**](ProtocolsApi.md#ListProtocolsv3SmbShares) | **Get** /platform/3/protocols/smb/shares | 
[**ListProtocolsv3SwiftAccounts**](ProtocolsApi.md#ListProtocolsv3SwiftAccounts) | **Get** /platform/3/protocols/swift/accounts | 
[**ListProtocolsv4NdmpSettingsPreferredIps**](ProtocolsApi.md#ListProtocolsv4NdmpSettingsPreferredIps) | **Get** /platform/4/protocols/ndmp/settings/preferred-ips | 
[**ListProtocolsv4NfsExports**](ProtocolsApi.md#ListProtocolsv4NfsExports) | **Get** /platform/4/protocols/nfs/exports | 
[**ListProtocolsv4SmbShares**](ProtocolsApi.md#ListProtocolsv4SmbShares) | **Get** /platform/4/protocols/smb/shares | 
[**ListProtocolsv6SmbShares**](ProtocolsApi.md#ListProtocolsv6SmbShares) | **Get** /platform/6/protocols/smb/shares | 
[**ListProtocolsv7SmbShares**](ProtocolsApi.md#ListProtocolsv7SmbShares) | **Get** /platform/7/protocols/smb/shares | 
[**UpdateProtocolsv10S3Bucket**](ProtocolsApi.md#UpdateProtocolsv10S3Bucket) | **Put** /platform/10/protocols/s3/buckets/{v10S3BucketId} | 
[**UpdateProtocolsv10S3LogLevel**](ProtocolsApi.md#UpdateProtocolsv10S3LogLevel) | **Put** /platform/10/protocols/s3/log-level | 
[**UpdateProtocolsv10S3SettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv10S3SettingsGlobal) | **Put** /platform/10/protocols/s3/settings/global | 
[**UpdateProtocolsv10S3SettingsZone**](ProtocolsApi.md#UpdateProtocolsv10S3SettingsZone) | **Put** /platform/10/protocols/s3/settings/zone | 
[**UpdateProtocolsv11HdfsSettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv11HdfsSettingsGlobal) | **Put** /platform/11/protocols/hdfs/settings/global | 
[**UpdateProtocolsv11NfsExport**](ProtocolsApi.md#UpdateProtocolsv11NfsExport) | **Put** /platform/11/protocols/nfs/exports/{v11NfsExportId} | 
[**UpdateProtocolsv12HdfsLogLevel**](ProtocolsApi.md#UpdateProtocolsv12HdfsLogLevel) | **Put** /platform/12/protocols/hdfs/log-level | 
[**UpdateProtocolsv12HdfsSettings**](ProtocolsApi.md#UpdateProtocolsv12HdfsSettings) | **Put** /platform/12/protocols/hdfs/settings | 
[**UpdateProtocolsv12NfsLogLevel**](ProtocolsApi.md#UpdateProtocolsv12NfsLogLevel) | **Put** /platform/12/protocols/nfs/log-level | 
[**UpdateProtocolsv12NfsSettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv12NfsSettingsGlobal) | **Put** /platform/12/protocols/nfs/settings/global | 
[**UpdateProtocolsv12S3Bucket**](ProtocolsApi.md#UpdateProtocolsv12S3Bucket) | **Put** /platform/12/protocols/s3/buckets/{v12S3BucketId} | 
[**UpdateProtocolsv12S3SettingsZone**](ProtocolsApi.md#UpdateProtocolsv12S3SettingsZone) | **Put** /platform/12/protocols/s3/settings/zone | 
[**UpdateProtocolsv12SmbLogLevel**](ProtocolsApi.md#UpdateProtocolsv12SmbLogLevel) | **Put** /platform/12/protocols/smb/log-level | 
[**UpdateProtocolsv12SmbShare**](ProtocolsApi.md#UpdateProtocolsv12SmbShare) | **Put** /platform/12/protocols/smb/shares/{v12SmbShareId} | 
[**UpdateProtocolsv14NfsSettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv14NfsSettingsGlobal) | **Put** /platform/14/protocols/nfs/settings/global | 
[**UpdateProtocolsv15HttpService**](ProtocolsApi.md#UpdateProtocolsv15HttpService) | **Put** /platform/15/protocols/http/services/{v15HttpServiceId} | 
[**UpdateProtocolsv1HdfsProxyuser**](ProtocolsApi.md#UpdateProtocolsv1HdfsProxyuser) | **Put** /platform/1/protocols/hdfs/proxyusers/{v1HdfsProxyuserId} | 
[**UpdateProtocolsv1HdfsProxyusersNameMember**](ProtocolsApi.md#UpdateProtocolsv1HdfsProxyusersNameMember) | **Put** /platform/1/protocols/hdfs/proxyusers/{Name}/members/{v1HdfsProxyusersNameMemberId} | 
[**UpdateProtocolsv1HdfsRack**](ProtocolsApi.md#UpdateProtocolsv1HdfsRack) | **Put** /platform/1/protocols/hdfs/racks/{v1HdfsRackId} | 
[**UpdateProtocolsv1NfsExport**](ProtocolsApi.md#UpdateProtocolsv1NfsExport) | **Put** /platform/1/protocols/nfs/exports/{v1NfsExportId} | 
[**UpdateProtocolsv1NfsSettingsExport**](ProtocolsApi.md#UpdateProtocolsv1NfsSettingsExport) | **Put** /platform/1/protocols/nfs/settings/export | 
[**UpdateProtocolsv1SmbSettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv1SmbSettingsGlobal) | **Put** /platform/1/protocols/smb/settings/global | 
[**UpdateProtocolsv1SmbSettingsShare**](ProtocolsApi.md#UpdateProtocolsv1SmbSettingsShare) | **Put** /platform/1/protocols/smb/settings/share | 
[**UpdateProtocolsv1SmbShare**](ProtocolsApi.md#UpdateProtocolsv1SmbShare) | **Put** /platform/1/protocols/smb/shares/{v1SmbShareId} | 
[**UpdateProtocolsv2NfsAlias**](ProtocolsApi.md#UpdateProtocolsv2NfsAlias) | **Put** /platform/2/protocols/nfs/aliases/{v2NfsAliasId} | 
[**UpdateProtocolsv2NfsExport**](ProtocolsApi.md#UpdateProtocolsv2NfsExport) | **Put** /platform/2/protocols/nfs/exports/{v2NfsExportId} | 
[**UpdateProtocolsv2NfsSettingsExport**](ProtocolsApi.md#UpdateProtocolsv2NfsSettingsExport) | **Put** /platform/2/protocols/nfs/settings/export | 
[**UpdateProtocolsv2NfsSettingsZone**](ProtocolsApi.md#UpdateProtocolsv2NfsSettingsZone) | **Put** /platform/2/protocols/nfs/settings/zone | 
[**UpdateProtocolsv3FtpSettings**](ProtocolsApi.md#UpdateProtocolsv3FtpSettings) | **Put** /platform/3/protocols/ftp/settings | 
[**UpdateProtocolsv3HdfsLogLevel**](ProtocolsApi.md#UpdateProtocolsv3HdfsLogLevel) | **Put** /platform/3/protocols/hdfs/log-level | 
[**UpdateProtocolsv3HttpSettings**](ProtocolsApi.md#UpdateProtocolsv3HttpSettings) | **Put** /platform/3/protocols/http/settings | 
[**UpdateProtocolsv3NdmpDiagnostics**](ProtocolsApi.md#UpdateProtocolsv3NdmpDiagnostics) | **Put** /platform/3/protocols/ndmp/diagnostics | 
[**UpdateProtocolsv3NdmpSettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv3NdmpSettingsGlobal) | **Put** /platform/3/protocols/ndmp/settings/global | 
[**UpdateProtocolsv3NdmpSettingsVariable**](ProtocolsApi.md#UpdateProtocolsv3NdmpSettingsVariable) | **Put** /platform/3/protocols/ndmp/settings/variables/{v3NdmpSettingsVariableId} | 
[**UpdateProtocolsv3NdmpUser**](ProtocolsApi.md#UpdateProtocolsv3NdmpUser) | **Put** /platform/3/protocols/ndmp/users/{v3NdmpUserId} | 
[**UpdateProtocolsv3NfsLogLevel**](ProtocolsApi.md#UpdateProtocolsv3NfsLogLevel) | **Put** /platform/3/protocols/nfs/log-level | 
[**UpdateProtocolsv3NfsNetgroup**](ProtocolsApi.md#UpdateProtocolsv3NfsNetgroup) | **Put** /platform/3/protocols/nfs/netgroup | 
[**UpdateProtocolsv3NfsSettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv3NfsSettingsGlobal) | **Put** /platform/3/protocols/nfs/settings/global | 
[**UpdateProtocolsv3NtpServer**](ProtocolsApi.md#UpdateProtocolsv3NtpServer) | **Put** /platform/3/protocols/ntp/servers/{v3NtpServerId} | 
[**UpdateProtocolsv3NtpSettings**](ProtocolsApi.md#UpdateProtocolsv3NtpSettings) | **Put** /platform/3/protocols/ntp/settings | 
[**UpdateProtocolsv3SmbLogLevel**](ProtocolsApi.md#UpdateProtocolsv3SmbLogLevel) | **Put** /platform/3/protocols/smb/log-level | 
[**UpdateProtocolsv3SmbSettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv3SmbSettingsGlobal) | **Put** /platform/3/protocols/smb/settings/global | 
[**UpdateProtocolsv3SmbSettingsShare**](ProtocolsApi.md#UpdateProtocolsv3SmbSettingsShare) | **Put** /platform/3/protocols/smb/settings/share | 
[**UpdateProtocolsv3SmbShare**](ProtocolsApi.md#UpdateProtocolsv3SmbShare) | **Put** /platform/3/protocols/smb/shares/{v3SmbShareId} | 
[**UpdateProtocolsv3SnmpSettings**](ProtocolsApi.md#UpdateProtocolsv3SnmpSettings) | **Put** /platform/3/protocols/snmp/settings | 
[**UpdateProtocolsv3SwiftAccount**](ProtocolsApi.md#UpdateProtocolsv3SwiftAccount) | **Put** /platform/3/protocols/swift/accounts/{v3SwiftAccountId} | 
[**UpdateProtocolsv4HdfsRangerPluginSettings**](ProtocolsApi.md#UpdateProtocolsv4HdfsRangerPluginSettings) | **Put** /platform/4/protocols/hdfs/ranger-plugin/settings | 
[**UpdateProtocolsv4NdmpSettingsPreferredIp**](ProtocolsApi.md#UpdateProtocolsv4NdmpSettingsPreferredIp) | **Put** /platform/4/protocols/ndmp/settings/preferred-ips/{v4NdmpSettingsPreferredIpId} | 
[**UpdateProtocolsv5HdfsFsimageJobSettings**](ProtocolsApi.md#UpdateProtocolsv5HdfsFsimageJobSettings) | **Put** /platform/5/protocols/hdfs/fsimage/job/settings | 
[**UpdateProtocolsv5HdfsFsimageSettings**](ProtocolsApi.md#UpdateProtocolsv5HdfsFsimageSettings) | **Put** /platform/5/protocols/hdfs/fsimage/settings | 
[**UpdateProtocolsv5HdfsInotifySettings**](ProtocolsApi.md#UpdateProtocolsv5HdfsInotifySettings) | **Put** /platform/5/protocols/hdfs/inotify/settings | 
[**UpdateProtocolsv5SnmpSettings**](ProtocolsApi.md#UpdateProtocolsv5SnmpSettings) | **Put** /platform/5/protocols/snmp/settings | 
[**UpdateProtocolsv6SmbSettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv6SmbSettingsGlobal) | **Put** /platform/6/protocols/smb/settings/global | 
[**UpdateProtocolsv6SmbSettingsShare**](ProtocolsApi.md#UpdateProtocolsv6SmbSettingsShare) | **Put** /platform/6/protocols/smb/settings/share | 
[**UpdateProtocolsv6SmbSettingsZone**](ProtocolsApi.md#UpdateProtocolsv6SmbSettingsZone) | **Put** /platform/6/protocols/smb/settings/zone | 
[**UpdateProtocolsv6SmbShare**](ProtocolsApi.md#UpdateProtocolsv6SmbShare) | **Put** /platform/6/protocols/smb/shares/{v6SmbShareId} | 
[**UpdateProtocolsv7HdfsCryptoSettings**](ProtocolsApi.md#UpdateProtocolsv7HdfsCryptoSettings) | **Put** /platform/7/protocols/hdfs/crypto/settings | 
[**UpdateProtocolsv7NfsSettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv7NfsSettingsGlobal) | **Put** /platform/7/protocols/nfs/settings/global | 
[**UpdateProtocolsv7SmbSettingsGlobal**](ProtocolsApi.md#UpdateProtocolsv7SmbSettingsGlobal) | **Put** /platform/7/protocols/smb/settings/global | 
[**UpdateProtocolsv7SmbSettingsShare**](ProtocolsApi.md#UpdateProtocolsv7SmbSettingsShare) | **Put** /platform/7/protocols/smb/settings/share | 
[**UpdateProtocolsv7SmbShare**](ProtocolsApi.md#UpdateProtocolsv7SmbShare) | **Put** /platform/7/protocols/smb/shares/{v7SmbShareId} | 
[**UpdateProtocolsv7SshSettings**](ProtocolsApi.md#UpdateProtocolsv7SshSettings) | **Put** /platform/7/protocols/ssh/settings | 
[**UpdateProtocolsv8SshSettings**](ProtocolsApi.md#UpdateProtocolsv8SshSettings) | **Put** /platform/8/protocols/ssh/settings | 
[**UpdateProtocolsv9HdfsSettings**](ProtocolsApi.md#UpdateProtocolsv9HdfsSettings) | **Put** /platform/9/protocols/hdfs/settings | 



## CreateProtocolsv10S3Bucket

> CreateResponse CreateProtocolsv10S3Bucket(ctx).V10S3Bucket(v10S3Bucket).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3Bucket := *openapiclient.NewV10S3Bucket("Name_example", "Path_example") // V10S3Bucket | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv10S3Bucket(context.Background()).V10S3Bucket(v10S3Bucket).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv10S3Bucket``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv10S3Bucket`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv10S3Bucket`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv10S3BucketRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10S3Bucket** | [**V10S3Bucket**](V10S3Bucket.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv10S3Key

> Createv10S3KeyResponse CreateProtocolsv10S3Key(ctx, v10S3KeyId).V10S3Key(v10S3Key).Force(force).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3KeyId := "v10S3KeyId_example" // string | Generate a new secret key/access ID for given user.
    v10S3Key := *openapiclient.NewV10S3Key() // V10S3Key | 
    force := true // bool | Forces to create new key. (optional)
    zone := "zone_example" // string | Specifies access zone containing user. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv10S3Key(context.Background(), v10S3KeyId).V10S3Key(v10S3Key).Force(force).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv10S3Key``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv10S3Key`: Createv10S3KeyResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv10S3Key`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10S3KeyId** | **string** | Generate a new secret key/access ID for given user. | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv10S3KeyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v10S3Key** | [**V10S3Key**](V10S3Key.md) |  | 
 **force** | **bool** | Forces to create new key. | 
 **zone** | **string** | Specifies access zone containing user. | 

### Return type

[**Createv10S3KeyResponse**](Createv10S3KeyResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv10S3Mykey

> Createv10S3KeyResponse CreateProtocolsv10S3Mykey(ctx).V10S3Mykey(v10S3Mykey).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3Mykey := *openapiclient.NewV10S3Key() // V10S3Key | 
    force := true // bool | Forces to create new key. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv10S3Mykey(context.Background()).V10S3Mykey(v10S3Mykey).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv10S3Mykey``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv10S3Mykey`: Createv10S3KeyResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv10S3Mykey`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv10S3MykeyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10S3Mykey** | [**V10S3Key**](V10S3Key.md) |  | 
 **force** | **bool** | Forces to create new key. | 

### Return type

[**Createv10S3KeyResponse**](Createv10S3KeyResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv12NfsNetgroupSaveItem

> map[string]interface{} CreateProtocolsv12NfsNetgroupSaveItem(ctx).V12NfsNetgroupSaveItem(v12NfsNetgroupSaveItem).Host(host).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12NfsNetgroupSaveItem := map[string]interface{}{ ... } // map[string]interface{} | 
    host := "host_example" // string | IP address of node to save. If unspecified, all nodes on the cluster are saved. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv12NfsNetgroupSaveItem(context.Background()).V12NfsNetgroupSaveItem(v12NfsNetgroupSaveItem).Host(host).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv12NfsNetgroupSaveItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv12NfsNetgroupSaveItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv12NfsNetgroupSaveItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv12NfsNetgroupSaveItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12NfsNetgroupSaveItem** | **map[string]interface{}** |  | 
 **host** | **string** | IP address of node to save. If unspecified, all nodes on the cluster are saved. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv12S3Bucket

> CreateResponse CreateProtocolsv12S3Bucket(ctx).V12S3Bucket(v12S3Bucket).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12S3Bucket := *openapiclient.NewV10S3Bucket("Name_example", "Path_example") // V10S3Bucket | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv12S3Bucket(context.Background()).V12S3Bucket(v12S3Bucket).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv12S3Bucket``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv12S3Bucket`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv12S3Bucket`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv12S3BucketRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12S3Bucket** | [**V10S3Bucket**](V10S3Bucket.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv12SmbShare

> Createv12SmbShareResponse CreateProtocolsv12SmbShare(ctx).V12SmbShare(v12SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SmbShare := *openapiclient.NewV12SmbShare("Name_example", "Path_example") // V12SmbShare | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv12SmbShare(context.Background()).V12SmbShare(v12SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv12SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv12SmbShare`: Createv12SmbShareResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv12SmbShare`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv12SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12SmbShare** | [**V12SmbShare**](V12SmbShare.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**Createv12SmbShareResponse**](Createv12SmbShareResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv15NfsAlias

> Createv15NfsAliasResponse CreateProtocolsv15NfsAlias(ctx).V15NfsAlias(v15NfsAlias).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15NfsAlias := *openapiclient.NewV15NfsAlias("Name_example", "Path_example") // V15NfsAlias | 
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv15NfsAlias(context.Background()).V15NfsAlias(v15NfsAlias).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv15NfsAlias``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv15NfsAlias`: Createv15NfsAliasResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv15NfsAlias`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv15NfsAliasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15NfsAlias** | [**V15NfsAlias**](V15NfsAlias.md) |  | 
 **zone** | **string** | Access zone | 

### Return type

[**Createv15NfsAliasResponse**](Createv15NfsAliasResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv15S3Bucket

> CreateResponse CreateProtocolsv15S3Bucket(ctx).V15S3Bucket(v15S3Bucket).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15S3Bucket := *openapiclient.NewV10S3Bucket("Name_example", "Path_example") // V10S3Bucket | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv15S3Bucket(context.Background()).V15S3Bucket(v15S3Bucket).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv15S3Bucket``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv15S3Bucket`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv15S3Bucket`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv15S3BucketRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15S3Bucket** | [**V10S3Bucket**](V10S3Bucket.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv1HdfsProxyuser

> CreateResponse CreateProtocolsv1HdfsProxyuser(ctx).V1HdfsProxyuser(v1HdfsProxyuser).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1HdfsProxyuser := *openapiclient.NewV1HdfsProxyuser("Name_example") // V1HdfsProxyuser | 
    zone := "zone_example" // string | Access zone which contains HDFS proxyuser. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv1HdfsProxyuser(context.Background()).V1HdfsProxyuser(v1HdfsProxyuser).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv1HdfsProxyuser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv1HdfsProxyuser`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv1HdfsProxyuser`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv1HdfsProxyuserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1HdfsProxyuser** | [**V1HdfsProxyuser**](V1HdfsProxyuser.md) |  | 
 **zone** | **string** | Access zone which contains HDFS proxyuser. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv1HdfsRack

> CreateResponse CreateProtocolsv1HdfsRack(ctx).V1HdfsRack(v1HdfsRack).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1HdfsRack := *openapiclient.NewV1HdfsRack("Name_example") // V1HdfsRack | 
    zone := "zone_example" // string | Access zone which contains HDFS rack. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv1HdfsRack(context.Background()).V1HdfsRack(v1HdfsRack).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv1HdfsRack``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv1HdfsRack`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv1HdfsRack`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv1HdfsRackRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1HdfsRack** | [**V1HdfsRack**](V1HdfsRack.md) |  | 
 **zone** | **string** | Access zone which contains HDFS rack. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv1NfsExport

> Createv3EventEventResponse CreateProtocolsv1NfsExport(ctx).V1NfsExport(v1NfsExport).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1NfsExport := *openapiclient.NewV1NfsExport([]string{"Paths_example"}) // V1NfsExport | 
    force := true // bool | If true, the export will be created even if it conflicts with another export. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv1NfsExport(context.Background()).V1NfsExport(v1NfsExport).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv1NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv1NfsExport`: Createv3EventEventResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv1NfsExport`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv1NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1NfsExport** | [**V1NfsExport**](V1NfsExport.md) |  | 
 **force** | **bool** | If true, the export will be created even if it conflicts with another export. | 

### Return type

[**Createv3EventEventResponse**](Createv3EventEventResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv1NfsReloadItem

> map[string]interface{} CreateProtocolsv1NfsReloadItem(ctx).V1NfsReloadItem(v1NfsReloadItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1NfsReloadItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv1NfsReloadItem(context.Background()).V1NfsReloadItem(v1NfsReloadItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv1NfsReloadItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv1NfsReloadItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv1NfsReloadItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv1NfsReloadItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1NfsReloadItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv1SmbShare

> CreateResponse CreateProtocolsv1SmbShare(ctx).V1SmbShare(v1SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SmbShare := *openapiclient.NewV1SmbShare("Name_example", "Path_example") // V1SmbShare | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv1SmbShare(context.Background()).V1SmbShare(v1SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv1SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv1SmbShare`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv1SmbShare`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv1SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SmbShare** | [**V1SmbShare**](V1SmbShare.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv2NfsAlias

> Createv15NfsAliasResponse CreateProtocolsv2NfsAlias(ctx).V2NfsAlias(v2NfsAlias).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsAlias := *openapiclient.NewV2NfsAlias("Name_example", "Path_example") // V2NfsAlias | 
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv2NfsAlias(context.Background()).V2NfsAlias(v2NfsAlias).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv2NfsAlias``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv2NfsAlias`: Createv15NfsAliasResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv2NfsAlias`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv2NfsAliasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v2NfsAlias** | [**V2NfsAlias**](V2NfsAlias.md) |  | 
 **zone** | **string** | Access zone | 

### Return type

[**Createv15NfsAliasResponse**](Createv15NfsAliasResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv2NfsExport

> Createv3EventEventResponse CreateProtocolsv2NfsExport(ctx).V2NfsExport(v2NfsExport).Force(force).IgnoreUnresolvableHosts(ignoreUnresolvableHosts).Zone(zone).IgnoreConflicts(ignoreConflicts).IgnoreBadPaths(ignoreBadPaths).IgnoreBadAuth(ignoreBadAuth).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsExport := *openapiclient.NewV2NfsExport([]string{"Paths_example"}) // V2NfsExport | 
    force := true // bool | If true, the export will be created even if it conflicts with another export. (optional)
    ignoreUnresolvableHosts := true // bool | Ignore unresolvable hosts. (optional)
    zone := "zone_example" // string | Access zone (optional)
    ignoreConflicts := true // bool | Ignore conflicts with existing exports. (optional)
    ignoreBadPaths := true // bool | Ignore nonexistent or otherwise bad paths. (optional)
    ignoreBadAuth := true // bool | Ignore invalid users. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv2NfsExport(context.Background()).V2NfsExport(v2NfsExport).Force(force).IgnoreUnresolvableHosts(ignoreUnresolvableHosts).Zone(zone).IgnoreConflicts(ignoreConflicts).IgnoreBadPaths(ignoreBadPaths).IgnoreBadAuth(ignoreBadAuth).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv2NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv2NfsExport`: Createv3EventEventResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv2NfsExport`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv2NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v2NfsExport** | [**V2NfsExport**](V2NfsExport.md) |  | 
 **force** | **bool** | If true, the export will be created even if it conflicts with another export. | 
 **ignoreUnresolvableHosts** | **bool** | Ignore unresolvable hosts. | 
 **zone** | **string** | Access zone | 
 **ignoreConflicts** | **bool** | Ignore conflicts with existing exports. | 
 **ignoreBadPaths** | **bool** | Ignore nonexistent or otherwise bad paths. | 
 **ignoreBadAuth** | **bool** | Ignore invalid users. | 

### Return type

[**Createv3EventEventResponse**](Createv3EventEventResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv2NfsReloadItem

> map[string]interface{} CreateProtocolsv2NfsReloadItem(ctx).V2NfsReloadItem(v2NfsReloadItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsReloadItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv2NfsReloadItem(context.Background()).V2NfsReloadItem(v2NfsReloadItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv2NfsReloadItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv2NfsReloadItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv2NfsReloadItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv2NfsReloadItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v2NfsReloadItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv3NdmpSettingsVariable

> map[string]interface{} CreateProtocolsv3NdmpSettingsVariable(ctx, v3NdmpSettingsVariableId).V3NdmpSettingsVariable(v3NdmpSettingsVariable).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpSettingsVariableId := "v3NdmpSettingsVariableId_example" // string | Create a preferred NDMP environment variable.
    v3NdmpSettingsVariable := *openapiclient.NewV3NdmpSettingsVariableCreateParams("Value_example", "Name_example", "Path_example") // V3NdmpSettingsVariableCreateParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv3NdmpSettingsVariable(context.Background(), v3NdmpSettingsVariableId).V3NdmpSettingsVariable(v3NdmpSettingsVariable).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv3NdmpSettingsVariable``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv3NdmpSettingsVariable`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv3NdmpSettingsVariable`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpSettingsVariableId** | **string** | Create a preferred NDMP environment variable. | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv3NdmpSettingsVariableRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3NdmpSettingsVariable** | [**V3NdmpSettingsVariableCreateParams**](V3NdmpSettingsVariableCreateParams.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv3NdmpUser

> map[string]interface{} CreateProtocolsv3NdmpUser(ctx).V3NdmpUser(v3NdmpUser).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpUser := *openapiclient.NewV3NdmpUser("Name_example", "Password_example") // V3NdmpUser | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv3NdmpUser(context.Background()).V3NdmpUser(v3NdmpUser).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv3NdmpUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv3NdmpUser`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv3NdmpUser`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv3NdmpUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NdmpUser** | [**V3NdmpUser**](V3NdmpUser.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv3NfsNetgroupCheckItem

> map[string]interface{} CreateProtocolsv3NfsNetgroupCheckItem(ctx).V3NfsNetgroupCheckItem(v3NfsNetgroupCheckItem).Host(host).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NfsNetgroupCheckItem := map[string]interface{}{ ... } // map[string]interface{} | 
    host := "host_example" // string | IP address of node to update. If unspecified, the local nodes cache is updated. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv3NfsNetgroupCheckItem(context.Background()).V3NfsNetgroupCheckItem(v3NfsNetgroupCheckItem).Host(host).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv3NfsNetgroupCheckItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv3NfsNetgroupCheckItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv3NfsNetgroupCheckItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv3NfsNetgroupCheckItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NfsNetgroupCheckItem** | **map[string]interface{}** |  | 
 **host** | **string** | IP address of node to update. If unspecified, the local nodes cache is updated. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv3NfsNetgroupFlushItem

> map[string]interface{} CreateProtocolsv3NfsNetgroupFlushItem(ctx).V3NfsNetgroupFlushItem(v3NfsNetgroupFlushItem).Host(host).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NfsNetgroupFlushItem := map[string]interface{}{ ... } // map[string]interface{} | 
    host := "host_example" // string | IP address of node to flush. If unspecified, all nodes on the cluster are flushed. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv3NfsNetgroupFlushItem(context.Background()).V3NfsNetgroupFlushItem(v3NfsNetgroupFlushItem).Host(host).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv3NfsNetgroupFlushItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv3NfsNetgroupFlushItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv3NfsNetgroupFlushItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv3NfsNetgroupFlushItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NfsNetgroupFlushItem** | **map[string]interface{}** |  | 
 **host** | **string** | IP address of node to flush. If unspecified, all nodes on the cluster are flushed. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv3NfsNlmSessionsCheckItem

> Createv3NfsNlmSessionsCheckItemResponse CreateProtocolsv3NfsNlmSessionsCheckItem(ctx).V3NfsNlmSessionsCheckItem(v3NfsNlmSessionsCheckItem).ClusterIp(clusterIp).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NfsNlmSessionsCheckItem := map[string]interface{}{ ... } // map[string]interface{} | 
    clusterIp := "clusterIp_example" // string | An IP address for which NSM has client records (optional)
    zone := "zone_example" // string | Represents an extant auth zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv3NfsNlmSessionsCheckItem(context.Background()).V3NfsNlmSessionsCheckItem(v3NfsNlmSessionsCheckItem).ClusterIp(clusterIp).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv3NfsNlmSessionsCheckItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv3NfsNlmSessionsCheckItem`: Createv3NfsNlmSessionsCheckItemResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv3NfsNlmSessionsCheckItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv3NfsNlmSessionsCheckItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NfsNlmSessionsCheckItem** | **map[string]interface{}** |  | 
 **clusterIp** | **string** | An IP address for which NSM has client records | 
 **zone** | **string** | Represents an extant auth zone | 

### Return type

[**Createv3NfsNlmSessionsCheckItemResponse**](Createv3NfsNlmSessionsCheckItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv3NfsReloadItem

> map[string]interface{} CreateProtocolsv3NfsReloadItem(ctx).V3NfsReloadItem(v3NfsReloadItem).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NfsReloadItem := map[string]interface{}{ ... } // map[string]interface{} | 
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv3NfsReloadItem(context.Background()).V3NfsReloadItem(v3NfsReloadItem).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv3NfsReloadItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv3NfsReloadItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv3NfsReloadItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv3NfsReloadItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NfsReloadItem** | **map[string]interface{}** |  | 
 **zone** | **string** | Access zone | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv3NtpServer

> map[string]interface{} CreateProtocolsv3NtpServer(ctx).V3NtpServer(v3NtpServer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NtpServer := *openapiclient.NewV3NtpServer("Name_example") // V3NtpServer | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv3NtpServer(context.Background()).V3NtpServer(v3NtpServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv3NtpServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv3NtpServer`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv3NtpServer`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv3NtpServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NtpServer** | [**V3NtpServer**](V3NtpServer.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv3SmbLogLevelFilter

> Createv3SmbLogLevelFilterResponse CreateProtocolsv3SmbLogLevelFilter(ctx).V3SmbLogLevelFilter(v3SmbLogLevelFilter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SmbLogLevelFilter := *openapiclient.NewV3SmbLogLevelFilter("Level_example") // V3SmbLogLevelFilter | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv3SmbLogLevelFilter(context.Background()).V3SmbLogLevelFilter(v3SmbLogLevelFilter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv3SmbLogLevelFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv3SmbLogLevelFilter`: Createv3SmbLogLevelFilterResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv3SmbLogLevelFilter`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv3SmbLogLevelFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SmbLogLevelFilter** | [**V3SmbLogLevelFilter**](V3SmbLogLevelFilter.md) |  | 

### Return type

[**Createv3SmbLogLevelFilterResponse**](Createv3SmbLogLevelFilterResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv3SmbShare

> CreateResponse CreateProtocolsv3SmbShare(ctx).V3SmbShare(v3SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SmbShare := *openapiclient.NewV3SmbShare("Name_example", "Path_example") // V3SmbShare | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv3SmbShare(context.Background()).V3SmbShare(v3SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv3SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv3SmbShare`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv3SmbShare`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv3SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SmbShare** | [**V3SmbShare**](V3SmbShare.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv3SwiftAccount

> map[string]interface{} CreateProtocolsv3SwiftAccount(ctx).V3SwiftAccount(v3SwiftAccount).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SwiftAccount := *openapiclient.NewV3SwiftAccount("Name_example") // V3SwiftAccount | 
    zone := "zone_example" // string | Access zone which contains Swift account. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv3SwiftAccount(context.Background()).V3SwiftAccount(v3SwiftAccount).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv3SwiftAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv3SwiftAccount`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv3SwiftAccount`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv3SwiftAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SwiftAccount** | [**V3SwiftAccount**](V3SwiftAccount.md) |  | 
 **zone** | **string** | Access zone which contains Swift account. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv4NdmpSettingsPreferredIp

> map[string]interface{} CreateProtocolsv4NdmpSettingsPreferredIp(ctx).V4NdmpSettingsPreferredIp(v4NdmpSettingsPreferredIp).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4NdmpSettingsPreferredIp := *openapiclient.NewV4NdmpSettingsPreferredIp([]openapiclient.V4NdmpSettingsPreferredIpDataSubnet{*openapiclient.NewV4NdmpSettingsPreferredIpDataSubnet()}, "Scope_example") // V4NdmpSettingsPreferredIp | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv4NdmpSettingsPreferredIp(context.Background()).V4NdmpSettingsPreferredIp(v4NdmpSettingsPreferredIp).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv4NdmpSettingsPreferredIp``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv4NdmpSettingsPreferredIp`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv4NdmpSettingsPreferredIp`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv4NdmpSettingsPreferredIpRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4NdmpSettingsPreferredIp** | [**V4NdmpSettingsPreferredIp**](V4NdmpSettingsPreferredIp.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv4NfsExport

> Createv3EventEventResponse CreateProtocolsv4NfsExport(ctx).V4NfsExport(v4NfsExport).Force(force).IgnoreUnresolvableHosts(ignoreUnresolvableHosts).Zone(zone).IgnoreConflicts(ignoreConflicts).IgnoreBadPaths(ignoreBadPaths).IgnoreBadAuth(ignoreBadAuth).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4NfsExport := *openapiclient.NewV2NfsExport([]string{"Paths_example"}) // V2NfsExport | 
    force := true // bool | If true, the export will be created even if it conflicts with another export. (optional)
    ignoreUnresolvableHosts := true // bool | Ignore unresolvable hosts. (optional)
    zone := "zone_example" // string | Access zone (optional)
    ignoreConflicts := true // bool | Ignore conflicts with existing exports. (optional)
    ignoreBadPaths := true // bool | Ignore nonexistent or otherwise bad paths. (optional)
    ignoreBadAuth := true // bool | Ignore invalid users. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv4NfsExport(context.Background()).V4NfsExport(v4NfsExport).Force(force).IgnoreUnresolvableHosts(ignoreUnresolvableHosts).Zone(zone).IgnoreConflicts(ignoreConflicts).IgnoreBadPaths(ignoreBadPaths).IgnoreBadAuth(ignoreBadAuth).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv4NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv4NfsExport`: Createv3EventEventResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv4NfsExport`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv4NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4NfsExport** | [**V2NfsExport**](V2NfsExport.md) |  | 
 **force** | **bool** | If true, the export will be created even if it conflicts with another export. | 
 **ignoreUnresolvableHosts** | **bool** | Ignore unresolvable hosts. | 
 **zone** | **string** | Access zone | 
 **ignoreConflicts** | **bool** | Ignore conflicts with existing exports. | 
 **ignoreBadPaths** | **bool** | Ignore nonexistent or otherwise bad paths. | 
 **ignoreBadAuth** | **bool** | Ignore invalid users. | 

### Return type

[**Createv3EventEventResponse**](Createv3EventEventResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv4SmbShare

> CreateResponse CreateProtocolsv4SmbShare(ctx).V4SmbShare(v4SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4SmbShare := *openapiclient.NewV3SmbShare("Name_example", "Path_example") // V3SmbShare | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv4SmbShare(context.Background()).V4SmbShare(v4SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv4SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv4SmbShare`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv4SmbShare`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv4SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4SmbShare** | [**V3SmbShare**](V3SmbShare.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv6SmbShare

> Createv12SmbShareResponse CreateProtocolsv6SmbShare(ctx).V6SmbShare(v6SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v6SmbShare := *openapiclient.NewV6SmbShare("Name_example", "Path_example") // V6SmbShare | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv6SmbShare(context.Background()).V6SmbShare(v6SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv6SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv6SmbShare`: Createv12SmbShareResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv6SmbShare`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv6SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v6SmbShare** | [**V6SmbShare**](V6SmbShare.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**Createv12SmbShareResponse**](Createv12SmbShareResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateProtocolsv7SmbShare

> Createv12SmbShareResponse CreateProtocolsv7SmbShare(ctx).V7SmbShare(v7SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SmbShare := *openapiclient.NewV7SmbShare("Name_example", "Path_example") // V7SmbShare | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.CreateProtocolsv7SmbShare(context.Background()).V7SmbShare(v7SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.CreateProtocolsv7SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateProtocolsv7SmbShare`: Createv12SmbShareResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.CreateProtocolsv7SmbShare`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateProtocolsv7SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SmbShare** | [**V7SmbShare**](V7SmbShare.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**Createv12SmbShareResponse**](Createv12SmbShareResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv10S3Bucket

> DeleteProtocolsv10S3Bucket(ctx, v10S3BucketId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3BucketId := "v10S3BucketId_example" // string | Delete the bucket.
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv10S3Bucket(context.Background(), v10S3BucketId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv10S3Bucket``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10S3BucketId** | **string** | Delete the bucket. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv10S3BucketRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv10S3Key

> DeleteProtocolsv10S3Key(ctx, v10S3KeyId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3KeyId := "v10S3KeyId_example" // string | Delete secret key information for given user.
    zone := "zone_example" // string | Specifies access zone containing user. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv10S3Key(context.Background(), v10S3KeyId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv10S3Key``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10S3KeyId** | **string** | Delete secret key information for given user. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv10S3KeyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies access zone containing user. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv10S3Mykeys

> DeleteProtocolsv10S3Mykeys(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv10S3Mykeys(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv10S3Mykeys``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv10S3MykeysRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv11NfsExport

> DeleteProtocolsv11NfsExport(ctx, v11NfsExportId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11NfsExportId := "v11NfsExportId_example" // string | Delete the export.
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv11NfsExport(context.Background(), v11NfsExportId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv11NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11NfsExportId** | **string** | Delete the export. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv11NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Access zone | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv12S3Bucket

> DeleteProtocolsv12S3Bucket(ctx, v12S3BucketId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12S3BucketId := "v12S3BucketId_example" // string | Delete the bucket.
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv12S3Bucket(context.Background(), v12S3BucketId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv12S3Bucket``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12S3BucketId** | **string** | Delete the bucket. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv12S3BucketRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv12SmbShare

> DeleteProtocolsv12SmbShare(ctx, v12SmbShareId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SmbShareId := "v12SmbShareId_example" // string | Delete the share.
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv12SmbShare(context.Background(), v12SmbShareId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv12SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12SmbShareId** | **string** | Delete the share. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv12SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv12SmbShares

> DeleteProtocolsv12SmbShares(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv12SmbShares(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv12SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv12SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv1HdfsProxyuser

> DeleteProtocolsv1HdfsProxyuser(ctx, v1HdfsProxyuserId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1HdfsProxyuserId := "v1HdfsProxyuserId_example" // string | Delete an HDFS proxyuser.
    zone := "zone_example" // string | Access zone which contains HDFS proxyuser. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv1HdfsProxyuser(context.Background(), v1HdfsProxyuserId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv1HdfsProxyuser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1HdfsProxyuserId** | **string** | Delete an HDFS proxyuser. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv1HdfsProxyuserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Access zone which contains HDFS proxyuser. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv1HdfsProxyusersNameMember

> DeleteProtocolsv1HdfsProxyusersNameMember(ctx, v1HdfsProxyusersNameMemberId, name).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1HdfsProxyusersNameMemberId := "v1HdfsProxyusersNameMemberId_example" // string | Remove a member from the HDFS proxyuser.
    name := "name_example" // string | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv1HdfsProxyusersNameMember(context.Background(), v1HdfsProxyusersNameMemberId, name).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv1HdfsProxyusersNameMember``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1HdfsProxyusersNameMemberId** | **string** | Remove a member from the HDFS proxyuser. | 
**name** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv1HdfsProxyusersNameMemberRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv1HdfsRack

> DeleteProtocolsv1HdfsRack(ctx, v1HdfsRackId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1HdfsRackId := "v1HdfsRackId_example" // string | Delete the HDFS rack.
    zone := "zone_example" // string | Access zone which contains HDFS rack. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv1HdfsRack(context.Background(), v1HdfsRackId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv1HdfsRack``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1HdfsRackId** | **string** | Delete the HDFS rack. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv1HdfsRackRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Access zone which contains HDFS rack. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv1NfsExport

> DeleteProtocolsv1NfsExport(ctx, v1NfsExportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1NfsExportId := "v1NfsExportId_example" // string | Delete the export.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv1NfsExport(context.Background(), v1NfsExportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv1NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1NfsExportId** | **string** | Delete the export. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv1NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv1NfsNlmSession

> DeleteProtocolsv1NfsNlmSession(ctx, v1NfsNlmSessionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1NfsNlmSessionId := "v1NfsNlmSessionId_example" // string | Delete an NLM session.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv1NfsNlmSession(context.Background(), v1NfsNlmSessionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv1NfsNlmSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1NfsNlmSessionId** | **string** | Delete an NLM session. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv1NfsNlmSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv1SmbOpenfile

> DeleteProtocolsv1SmbOpenfile(ctx, v1SmbOpenfileId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SmbOpenfileId := "v1SmbOpenfileId_example" // string | Close the file in the SMB server.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv1SmbOpenfile(context.Background(), v1SmbOpenfileId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv1SmbOpenfile``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SmbOpenfileId** | **string** | Close the file in the SMB server. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv1SmbOpenfileRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv1SmbSession

> DeleteProtocolsv1SmbSession(ctx, v1SmbSessionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SmbSessionId := "v1SmbSessionId_example" // string | Close the SMB session.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv1SmbSession(context.Background(), v1SmbSessionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv1SmbSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SmbSessionId** | **string** | Close the SMB session. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv1SmbSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv1SmbSessionsComputerUser

> DeleteProtocolsv1SmbSessionsComputerUser(ctx, v1SmbSessionsComputerUser, computer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SmbSessionsComputerUser := "v1SmbSessionsComputerUser_example" // string | Close the SMB session.
    computer := "computer_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv1SmbSessionsComputerUser(context.Background(), v1SmbSessionsComputerUser, computer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv1SmbSessionsComputerUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SmbSessionsComputerUser** | **string** | Close the SMB session. | 
**computer** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv1SmbSessionsComputerUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv1SmbShare

> DeleteProtocolsv1SmbShare(ctx, v1SmbShareId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SmbShareId := "v1SmbShareId_example" // string | Delete the share.
    zone := "zone_example" // string | Zone which contains this share. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv1SmbShare(context.Background(), v1SmbShareId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv1SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SmbShareId** | **string** | Delete the share. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv1SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Zone which contains this share. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv1SmbShares

> DeleteProtocolsv1SmbShares(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv1SmbShares(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv1SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv1SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv2NfsAlias

> DeleteProtocolsv2NfsAlias(ctx, v2NfsAliasId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsAliasId := "v2NfsAliasId_example" // string | Delete the export.
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv2NfsAlias(context.Background(), v2NfsAliasId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv2NfsAlias``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v2NfsAliasId** | **string** | Delete the export. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv2NfsAliasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Access zone | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv2NfsExport

> DeleteProtocolsv2NfsExport(ctx, v2NfsExportId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsExportId := "v2NfsExportId_example" // string | Delete the export.
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv2NfsExport(context.Background(), v2NfsExportId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv2NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v2NfsExportId** | **string** | Delete the export. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv2NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Access zone | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv2NfsNlmSession

> DeleteProtocolsv2NfsNlmSession(ctx, v2NfsNlmSessionId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsNlmSessionId := "v2NfsNlmSessionId_example" // string | Delete an NLM session.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv2NfsNlmSession(context.Background(), v2NfsNlmSessionId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv2NfsNlmSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v2NfsNlmSessionId** | **string** | Delete an NLM session. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv2NfsNlmSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3NdmpContextsBackupById

> DeleteProtocolsv3NdmpContextsBackupById(ctx, v3NdmpContextsBackupId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpContextsBackupId := "v3NdmpContextsBackupId_example" // string | Delete a backup context

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3NdmpContextsBackupById(context.Background(), v3NdmpContextsBackupId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3NdmpContextsBackupById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpContextsBackupId** | **string** | Delete a backup context | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3NdmpContextsBackupByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3NdmpContextsBreById

> DeleteProtocolsv3NdmpContextsBreById(ctx, v3NdmpContextsBreId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpContextsBreId := "v3NdmpContextsBreId_example" // string | Delete a NDMP BRE context

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3NdmpContextsBreById(context.Background(), v3NdmpContextsBreId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3NdmpContextsBreById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpContextsBreId** | **string** | Delete a NDMP BRE context | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3NdmpContextsBreByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3NdmpContextsRestoreById

> DeleteProtocolsv3NdmpContextsRestoreById(ctx, v3NdmpContextsRestoreId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpContextsRestoreId := "v3NdmpContextsRestoreId_example" // string | Delete a restore context

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3NdmpContextsRestoreById(context.Background(), v3NdmpContextsRestoreId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3NdmpContextsRestoreById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpContextsRestoreId** | **string** | Delete a restore context | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3NdmpContextsRestoreByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3NdmpDumpdate

> DeleteProtocolsv3NdmpDumpdate(ctx, v3NdmpDumpdateId).Level(level).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpDumpdateId := "v3NdmpDumpdateId_example" // string | Delete dumpdates entries of a specified path.
    level := int32(56) // int32 | Level is an input from 0 to 10. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3NdmpDumpdate(context.Background(), v3NdmpDumpdateId).Level(level).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3NdmpDumpdate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpDumpdateId** | **string** | Delete dumpdates entries of a specified path. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3NdmpDumpdateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **level** | **int32** | Level is an input from 0 to 10. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3NdmpSession

> DeleteProtocolsv3NdmpSession(ctx, v3NdmpSessionId).Lnn(lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpSessionId := "v3NdmpSessionId_example" // string | Delete the ndmp session.
    lnn := "lnn_example" // string | Logical node number. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3NdmpSession(context.Background(), v3NdmpSessionId).Lnn(lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3NdmpSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpSessionId** | **string** | Delete the ndmp session. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3NdmpSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **lnn** | **string** | Logical node number. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3NdmpSettingsVariable

> DeleteProtocolsv3NdmpSettingsVariable(ctx, v3NdmpSettingsVariableId).Name(name).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpSettingsVariableId := "v3NdmpSettingsVariableId_example" // string | Delete preferred environment variable entries
    name := "name_example" // string | Name of the variable to delete. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3NdmpSettingsVariable(context.Background(), v3NdmpSettingsVariableId).Name(name).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3NdmpSettingsVariable``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpSettingsVariableId** | **string** | Delete preferred environment variable entries | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3NdmpSettingsVariableRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **name** | **string** | Name of the variable to delete. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3NdmpUser

> DeleteProtocolsv3NdmpUser(ctx, v3NdmpUserId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpUserId := "v3NdmpUserId_example" // string | Delete the user.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3NdmpUser(context.Background(), v3NdmpUserId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3NdmpUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpUserId** | **string** | Delete the user. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3NdmpUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3NfsNlmSession

> DeleteProtocolsv3NfsNlmSession(ctx, v3NfsNlmSessionId).ClusterIp(clusterIp).Zone(zone).Refresh(refresh).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NfsNlmSessionId := "v3NfsNlmSessionId_example" // string | Delete all lock state for this host.
    clusterIp := "clusterIp_example" // string | An IP address for which NSM has client records (optional)
    zone := "zone_example" // string | Represents an extant auth zone (optional)
    refresh := true // bool | if set to true, the client will be given a chance to reclaim its locks before they are destroyed (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3NfsNlmSession(context.Background(), v3NfsNlmSessionId).ClusterIp(clusterIp).Zone(zone).Refresh(refresh).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3NfsNlmSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NfsNlmSessionId** | **string** | Delete all lock state for this host. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3NfsNlmSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **clusterIp** | **string** | An IP address for which NSM has client records | 
 **zone** | **string** | Represents an extant auth zone | 
 **refresh** | **bool** | if set to true, the client will be given a chance to reclaim its locks before they are destroyed | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3NtpServer

> DeleteProtocolsv3NtpServer(ctx, v3NtpServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NtpServerId := "v3NtpServerId_example" // string | Delete an NTP server entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3NtpServer(context.Background(), v3NtpServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3NtpServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NtpServerId** | **string** | Delete an NTP server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3NtpServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3NtpServers

> DeleteProtocolsv3NtpServers(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3NtpServers(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3NtpServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3NtpServersRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3SmbLogLevelFilter

> DeleteProtocolsv3SmbLogLevelFilter(ctx, v3SmbLogLevelFilterId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SmbLogLevelFilterId := "v3SmbLogLevelFilterId_example" // string | Delete log filter.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3SmbLogLevelFilter(context.Background(), v3SmbLogLevelFilterId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3SmbLogLevelFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SmbLogLevelFilterId** | **string** | Delete log filter. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3SmbLogLevelFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3SmbLogLevelFilters

> DeleteProtocolsv3SmbLogLevelFilters(ctx).Level(level).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    level := "level_example" // string | Valid SMB logging levels (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3SmbLogLevelFilters(context.Background()).Level(level).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3SmbLogLevelFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3SmbLogLevelFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **level** | **string** | Valid SMB logging levels | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3SmbShare

> DeleteProtocolsv3SmbShare(ctx, v3SmbShareId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SmbShareId := "v3SmbShareId_example" // string | Delete the share.
    zone := "zone_example" // string | Zone which contains this share. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3SmbShare(context.Background(), v3SmbShareId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SmbShareId** | **string** | Delete the share. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Zone which contains this share. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3SmbShares

> DeleteProtocolsv3SmbShares(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3SmbShares(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv3SwiftAccount

> DeleteProtocolsv3SwiftAccount(ctx, v3SwiftAccountId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SwiftAccountId := "v3SwiftAccountId_example" // string | Delete a Swift account.
    zone := "zone_example" // string | Access zone which contains Swift account. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv3SwiftAccount(context.Background(), v3SwiftAccountId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv3SwiftAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SwiftAccountId** | **string** | Delete a Swift account. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv3SwiftAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Access zone which contains Swift account. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv4NdmpSettingsPreferredIp

> DeleteProtocolsv4NdmpSettingsPreferredIp(ctx, v4NdmpSettingsPreferredIpId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4NdmpSettingsPreferredIpId := "v4NdmpSettingsPreferredIpId_example" // string | Delete a preferred ip preference.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv4NdmpSettingsPreferredIp(context.Background(), v4NdmpSettingsPreferredIpId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv4NdmpSettingsPreferredIp``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4NdmpSettingsPreferredIpId** | **string** | Delete a preferred ip preference. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv4NdmpSettingsPreferredIpRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv4SmbShares

> DeleteProtocolsv4SmbShares(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv4SmbShares(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv4SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv4SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv5HdfsFsimageLatest

> DeleteProtocolsv5HdfsFsimageLatest(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains HDFS FSImage. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv5HdfsFsimageLatest(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv5HdfsFsimageLatest``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv5HdfsFsimageLatestRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains HDFS FSImage. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv5HdfsInotifyStream

> DeleteProtocolsv5HdfsInotifyStream(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which exposes HDFS INotify. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv5HdfsInotifyStream(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv5HdfsInotifyStream``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv5HdfsInotifyStreamRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which exposes HDFS INotify. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv6SmbShare

> DeleteProtocolsv6SmbShare(ctx, v6SmbShareId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v6SmbShareId := "v6SmbShareId_example" // string | Delete the share.
    zone := "zone_example" // string | Zone which contains this share. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv6SmbShare(context.Background(), v6SmbShareId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv6SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v6SmbShareId** | **string** | Delete the share. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv6SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Zone which contains this share. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv6SmbShares

> DeleteProtocolsv6SmbShares(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv6SmbShares(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv6SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv6SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv7SmbShare

> DeleteProtocolsv7SmbShare(ctx, v7SmbShareId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SmbShareId := "v7SmbShareId_example" // string | Delete the share.
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv7SmbShare(context.Background(), v7SmbShareId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv7SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SmbShareId** | **string** | Delete the share. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv7SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteProtocolsv7SmbShares

> DeleteProtocolsv7SmbShares(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.DeleteProtocolsv7SmbShares(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.DeleteProtocolsv7SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteProtocolsv7SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv10S3Bucket

> V10S3BucketsExtended GetProtocolsv10S3Bucket(ctx, v10S3BucketId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3BucketId := "v10S3BucketId_example" // string | Retrieve bucket.
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv10S3Bucket(context.Background(), v10S3BucketId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv10S3Bucket``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv10S3Bucket`: V10S3BucketsExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv10S3Bucket`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10S3BucketId** | **string** | Retrieve bucket. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv10S3BucketRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V10S3BucketsExtended**](V10S3BucketsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv10S3Key

> V10S3Keys GetProtocolsv10S3Key(ctx, v10S3KeyId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3KeyId := "v10S3KeyId_example" // string | Get access ID information for given user.
    zone := "zone_example" // string | Specifies access zone containing user. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv10S3Key(context.Background(), v10S3KeyId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv10S3Key``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv10S3Key`: V10S3Keys
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv10S3Key`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10S3KeyId** | **string** | Get access ID information for given user. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv10S3KeyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies access zone containing user. | 

### Return type

[**V10S3Keys**](V10S3Keys.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv10S3LogLevel

> V10S3LogLevel GetProtocolsv10S3LogLevel(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv10S3LogLevel(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv10S3LogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv10S3LogLevel`: V10S3LogLevel
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv10S3LogLevel`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv10S3LogLevelRequest struct via the builder pattern


### Return type

[**V10S3LogLevel**](V10S3LogLevel.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv10S3SettingsGlobal

> V10S3SettingsGlobal GetProtocolsv10S3SettingsGlobal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv10S3SettingsGlobal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv10S3SettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv10S3SettingsGlobal`: V10S3SettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv10S3SettingsGlobal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv10S3SettingsGlobalRequest struct via the builder pattern


### Return type

[**V10S3SettingsGlobal**](V10S3SettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv10S3SettingsZone

> V10S3SettingsZone GetProtocolsv10S3SettingsZone(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv10S3SettingsZone(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv10S3SettingsZone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv10S3SettingsZone`: V10S3SettingsZone
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv10S3SettingsZone`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv10S3SettingsZoneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone | 

### Return type

[**V10S3SettingsZone**](V10S3SettingsZone.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv11HdfsSettingsGlobal

> V11HdfsSettingsGlobal GetProtocolsv11HdfsSettingsGlobal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv11HdfsSettingsGlobal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv11HdfsSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv11HdfsSettingsGlobal`: V11HdfsSettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv11HdfsSettingsGlobal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv11HdfsSettingsGlobalRequest struct via the builder pattern


### Return type

[**V11HdfsSettingsGlobal**](V11HdfsSettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv11NfsExport

> V11NfsExports GetProtocolsv11NfsExport(ctx, v11NfsExportId).Scope(scope).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11NfsExportId := "v11NfsExportId_example" // string | Retrieve export information.
    scope := "scope_example" // string | When specified as 'effective', or not specified, all fields are returned. When specified as 'user', only fields with non-default values are shown. When specified as 'default', the original values are returned. (optional)
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv11NfsExport(context.Background(), v11NfsExportId).Scope(scope).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv11NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv11NfsExport`: V11NfsExports
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv11NfsExport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11NfsExportId** | **string** | Retrieve export information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv11NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | When specified as &#39;effective&#39;, or not specified, all fields are returned. When specified as &#39;user&#39;, only fields with non-default values are shown. When specified as &#39;default&#39;, the original values are returned. | 
 **zone** | **string** | Access zone | 

### Return type

[**V11NfsExports**](V11NfsExports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv11SmbSessions

> V11SmbSessions GetProtocolsv11SmbSessions(ctx).Lnn(lnn).Limit(limit).LnnSkip(lnnSkip).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := "lnn_example" // string | The node to fetch open sessions from. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    lnnSkip := "lnnSkip_example" // string | When parameter lnn=all, don't fetch open session info from this node. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv11SmbSessions(context.Background()).Lnn(lnn).Limit(limit).LnnSkip(lnnSkip).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv11SmbSessions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv11SmbSessions`: V11SmbSessions
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv11SmbSessions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv11SmbSessionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lnn** | **string** | The node to fetch open sessions from. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **lnnSkip** | **string** | When parameter lnn&#x3D;all, don&#39;t fetch open session info from this node. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V11SmbSessions**](V11SmbSessions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv12HdfsLogLevel

> V12HdfsLogLevel GetProtocolsv12HdfsLogLevel(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv12HdfsLogLevel(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv12HdfsLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv12HdfsLogLevel`: V12HdfsLogLevel
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv12HdfsLogLevel`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv12HdfsLogLevelRequest struct via the builder pattern


### Return type

[**V12HdfsLogLevel**](V12HdfsLogLevel.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv12HdfsSettings

> V12HdfsSettings GetProtocolsv12HdfsSettings(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains HDFS settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv12HdfsSettings(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv12HdfsSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv12HdfsSettings`: V12HdfsSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv12HdfsSettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv12HdfsSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains HDFS settings. | 

### Return type

[**V12HdfsSettings**](V12HdfsSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv12NfsLogLevel

> V12NfsLogLevel GetProtocolsv12NfsLogLevel(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv12NfsLogLevel(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv12NfsLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv12NfsLogLevel`: V12NfsLogLevel
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv12NfsLogLevel`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv12NfsLogLevelRequest struct via the builder pattern


### Return type

[**V12NfsLogLevel**](V12NfsLogLevel.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv12NfsSettingsGlobal

> V12NfsSettingsGlobal GetProtocolsv12NfsSettingsGlobal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv12NfsSettingsGlobal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv12NfsSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv12NfsSettingsGlobal`: V12NfsSettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv12NfsSettingsGlobal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv12NfsSettingsGlobalRequest struct via the builder pattern


### Return type

[**V12NfsSettingsGlobal**](V12NfsSettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv12S3Bucket

> V12S3BucketsExtended GetProtocolsv12S3Bucket(ctx, v12S3BucketId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12S3BucketId := "v12S3BucketId_example" // string | Retrieve bucket.
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv12S3Bucket(context.Background(), v12S3BucketId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv12S3Bucket``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv12S3Bucket`: V12S3BucketsExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv12S3Bucket`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12S3BucketId** | **string** | Retrieve bucket. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv12S3BucketRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V12S3BucketsExtended**](V12S3BucketsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv12S3SettingsZone

> V12S3SettingsZone GetProtocolsv12S3SettingsZone(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv12S3SettingsZone(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv12S3SettingsZone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv12S3SettingsZone`: V12S3SettingsZone
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv12S3SettingsZone`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv12S3SettingsZoneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone | 

### Return type

[**V12S3SettingsZone**](V12S3SettingsZone.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv12SmbLogLevel

> V12SmbLogLevel GetProtocolsv12SmbLogLevel(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv12SmbLogLevel(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv12SmbLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv12SmbLogLevel`: V12SmbLogLevel
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv12SmbLogLevel`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv12SmbLogLevelRequest struct via the builder pattern


### Return type

[**V12SmbLogLevel**](V12SmbLogLevel.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv12SmbShare

> V12SmbSharesExtended GetProtocolsv12SmbShare(ctx, v12SmbShareId).Scope(scope).ResolveNames(resolveNames).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SmbShareId := "v12SmbShareId_example" // string | Retrieve share.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv12SmbShare(context.Background(), v12SmbShareId).Scope(scope).ResolveNames(resolveNames).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv12SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv12SmbShare`: V12SmbSharesExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv12SmbShare`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12SmbShareId** | **string** | Retrieve share. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv12SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V12SmbSharesExtended**](V12SmbSharesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv14NfsSettingsGlobal

> V14NfsSettingsGlobal GetProtocolsv14NfsSettingsGlobal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv14NfsSettingsGlobal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv14NfsSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv14NfsSettingsGlobal`: V14NfsSettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv14NfsSettingsGlobal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv14NfsSettingsGlobalRequest struct via the builder pattern


### Return type

[**V14NfsSettingsGlobal**](V14NfsSettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv15HttpService

> V15HttpServicesExtended GetProtocolsv15HttpService(ctx, v15HttpServiceId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15HttpServiceId := "v15HttpServiceId_example" // string | Get the HTTP service status.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv15HttpService(context.Background(), v15HttpServiceId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv15HttpService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv15HttpService`: V15HttpServicesExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv15HttpService`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15HttpServiceId** | **string** | Get the HTTP service status. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv15HttpServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V15HttpServicesExtended**](V15HttpServicesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv15HttpServices

> V15HttpServices GetProtocolsv15HttpServices(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv15HttpServices(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv15HttpServices``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv15HttpServices`: V15HttpServices
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv15HttpServices`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv15HttpServicesRequest struct via the builder pattern


### Return type

[**V15HttpServices**](V15HttpServices.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1HdfsProxyuser

> V1HdfsProxyusersExtended GetProtocolsv1HdfsProxyuser(ctx, v1HdfsProxyuserId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1HdfsProxyuserId := "v1HdfsProxyuserId_example" // string | View the proxyuser.
    zone := "zone_example" // string | Access zone which contains HDFS proxyuser. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1HdfsProxyuser(context.Background(), v1HdfsProxyuserId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1HdfsProxyuser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1HdfsProxyuser`: V1HdfsProxyusersExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1HdfsProxyuser`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1HdfsProxyuserId** | **string** | View the proxyuser. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1HdfsProxyuserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Access zone which contains HDFS proxyuser. | 

### Return type

[**V1HdfsProxyusersExtended**](V1HdfsProxyusersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1HdfsRack

> V1HdfsRacksExtended GetProtocolsv1HdfsRack(ctx, v1HdfsRackId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1HdfsRackId := "v1HdfsRackId_example" // string | Retrieve the HDFS rack.
    zone := "zone_example" // string | Access zone which contains HDFS rack. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1HdfsRack(context.Background(), v1HdfsRackId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1HdfsRack``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1HdfsRack`: V1HdfsRacksExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1HdfsRack`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1HdfsRackId** | **string** | Retrieve the HDFS rack. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1HdfsRackRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Access zone which contains HDFS rack. | 

### Return type

[**V1HdfsRacksExtended**](V1HdfsRacksExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1NfsCheck

> V1NfsCheckExtended GetProtocolsv1NfsCheck(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1NfsCheck(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1NfsCheck``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1NfsCheck`: V1NfsCheckExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1NfsCheck`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1NfsCheckRequest struct via the builder pattern


### Return type

[**V1NfsCheckExtended**](V1NfsCheckExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1NfsExport

> V1NfsExportsExtended GetProtocolsv1NfsExport(ctx, v1NfsExportId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1NfsExportId := "v1NfsExportId_example" // string | Retrieve export information.
    scope := "scope_example" // string | If specified as effective or not specified, all export fields are shown.  If specified as user, only fields with non-default values are shown. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1NfsExport(context.Background(), v1NfsExportId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1NfsExport`: V1NfsExportsExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1NfsExport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1NfsExportId** | **string** | Retrieve export information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as effective or not specified, all export fields are shown.  If specified as user, only fields with non-default values are shown. | 

### Return type

[**V1NfsExportsExtended**](V1NfsExportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1NfsExportsSummary

> V1NfsExportsSummary GetProtocolsv1NfsExportsSummary(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1NfsExportsSummary(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1NfsExportsSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1NfsExportsSummary`: V1NfsExportsSummary
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1NfsExportsSummary`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1NfsExportsSummaryRequest struct via the builder pattern


### Return type

[**V1NfsExportsSummary**](V1NfsExportsSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1NfsNlmLocks

> V1NfsNlmLocks GetProtocolsv1NfsNlmLocks(ctx).Sort(sort).Created(created).Lin(lin).Resume(resume).Client(client).Limit(limit).ClientId(clientId).Path(path).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    created := "created_example" // string | Return locks created after the specified unix epoch time. (optional)
    lin := "lin_example" // string | Filter locks by the specified LIN in /ifs that is locked. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    client := "client_example" // string | Filter locks by the specified client host name and IP address. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    clientId := "clientId_example" // string | Filter locks by the specified client ID. (optional)
    path := "path_example" // string | Filter locks by the specified path under /ifs. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1NfsNlmLocks(context.Background()).Sort(sort).Created(created).Lin(lin).Resume(resume).Client(client).Limit(limit).ClientId(clientId).Path(path).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1NfsNlmLocks``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1NfsNlmLocks`: V1NfsNlmLocks
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1NfsNlmLocks`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1NfsNlmLocksRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **created** | **string** | Return locks created after the specified unix epoch time. | 
 **lin** | **string** | Filter locks by the specified LIN in /ifs that is locked. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **client** | **string** | Filter locks by the specified client host name and IP address. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **clientId** | **string** | Filter locks by the specified client ID. | 
 **path** | **string** | Filter locks by the specified path under /ifs. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1NfsNlmLocks**](V1NfsNlmLocks.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1NfsNlmSessions

> V1NfsNlmSessions GetProtocolsv1NfsNlmSessions(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1NfsNlmSessions(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1NfsNlmSessions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1NfsNlmSessions`: V1NfsNlmSessions
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1NfsNlmSessions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1NfsNlmSessionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1NfsNlmSessions**](V1NfsNlmSessions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1NfsNlmWaiters

> V1NfsNlmWaiters GetProtocolsv1NfsNlmWaiters(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1NfsNlmWaiters(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1NfsNlmWaiters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1NfsNlmWaiters`: V1NfsNlmWaiters
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1NfsNlmWaiters`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1NfsNlmWaitersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1NfsNlmWaiters**](V1NfsNlmWaiters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1NfsSettingsExport

> V1NfsSettingsExport GetProtocolsv1NfsSettingsExport(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as effective or not specified, all fields are returned.  If specified as user, only fields with non-default values are shown.  If specified as default, the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1NfsSettingsExport(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1NfsSettingsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1NfsSettingsExport`: V1NfsSettingsExport
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1NfsSettingsExport`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1NfsSettingsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as effective or not specified, all fields are returned.  If specified as user, only fields with non-default values are shown.  If specified as default, the original values are returned. | 

### Return type

[**V1NfsSettingsExport**](V1NfsSettingsExport.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1SmbOpenfiles

> V1SmbOpenfiles GetProtocolsv1SmbOpenfiles(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Order results by this field. Default is id. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1SmbOpenfiles(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1SmbOpenfiles``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1SmbOpenfiles`: V1SmbOpenfiles
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1SmbOpenfiles`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1SmbOpenfilesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Order results by this field. Default is id. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SmbOpenfiles**](V1SmbOpenfiles.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1SmbSessions

> V1SmbSessions GetProtocolsv1SmbSessions(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Order results by this field. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1SmbSessions(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1SmbSessions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1SmbSessions`: V1SmbSessions
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1SmbSessions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1SmbSessionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Order results by this field. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SmbSessions**](V1SmbSessions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1SmbSettingsGlobal

> V1SmbSettingsGlobal GetProtocolsv1SmbSettingsGlobal(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1SmbSettingsGlobal(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1SmbSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1SmbSettingsGlobal`: V1SmbSettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1SmbSettingsGlobal`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1SmbSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1SmbSettingsGlobal**](V1SmbSettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1SmbSettingsShare

> V1SmbSettingsShare GetProtocolsv1SmbSettingsShare(ctx).Scope(scope).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    zone := "zone_example" // string | Zone which contains these share settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1SmbSettingsShare(context.Background()).Scope(scope).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1SmbSettingsShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1SmbSettingsShare`: V1SmbSettingsShare
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1SmbSettingsShare`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1SmbSettingsShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **zone** | **string** | Zone which contains these share settings. | 

### Return type

[**V1SmbSettingsShare**](V1SmbSettingsShare.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1SmbShare

> V1SmbSharesExtended GetProtocolsv1SmbShare(ctx, v1SmbShareId).Scope(scope).ResolveNames(resolveNames).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SmbShareId := "v1SmbShareId_example" // string | Retrieve share.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    zone := "zone_example" // string | Zone which contains this share. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1SmbShare(context.Background(), v1SmbShareId).Scope(scope).ResolveNames(resolveNames).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1SmbShare`: V1SmbSharesExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1SmbShare`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SmbShareId** | **string** | Retrieve share. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **zone** | **string** | Zone which contains this share. | 

### Return type

[**V1SmbSharesExtended**](V1SmbSharesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv1SmbSharesSummary

> V1SmbSharesSummary GetProtocolsv1SmbSharesSummary(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv1SmbSharesSummary(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv1SmbSharesSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv1SmbSharesSummary`: V1SmbSharesSummary
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv1SmbSharesSummary`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv1SmbSharesSummaryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V1SmbSharesSummary**](V1SmbSharesSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv2NfsAlias

> V2NfsAliases GetProtocolsv2NfsAlias(ctx, v2NfsAliasId).Scope(scope).Check(check).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsAliasId := "v2NfsAliasId_example" // string | Retrieve export information.
    scope := "scope_example" // string | When specified as 'effective', or not specified, all fields are returned. When specified as 'user', only fields with non-default values are shown. When specified as 'default', the original values are returned. (optional)
    check := true // bool | Check for conflicts when viewing alias. (optional)
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv2NfsAlias(context.Background(), v2NfsAliasId).Scope(scope).Check(check).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv2NfsAlias``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv2NfsAlias`: V2NfsAliases
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv2NfsAlias`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v2NfsAliasId** | **string** | Retrieve export information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv2NfsAliasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | When specified as &#39;effective&#39;, or not specified, all fields are returned. When specified as &#39;user&#39;, only fields with non-default values are shown. When specified as &#39;default&#39;, the original values are returned. | 
 **check** | **bool** | Check for conflicts when viewing alias. | 
 **zone** | **string** | Access zone | 

### Return type

[**V2NfsAliases**](V2NfsAliases.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv2NfsCheck

> V1NfsCheckExtended GetProtocolsv2NfsCheck(ctx).IgnoreBadPaths(ignoreBadPaths).IgnoreBadAuth(ignoreBadAuth).Zone(zone).IgnoreUnresolvableHosts(ignoreUnresolvableHosts).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    ignoreBadPaths := true // bool | Ignore nonexistent or otherwise bad paths. (optional)
    ignoreBadAuth := true // bool | Ignore invalid users. (optional)
    zone := "zone_example" // string | Access zone (optional)
    ignoreUnresolvableHosts := true // bool | Ignore unresolvable hosts. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv2NfsCheck(context.Background()).IgnoreBadPaths(ignoreBadPaths).IgnoreBadAuth(ignoreBadAuth).Zone(zone).IgnoreUnresolvableHosts(ignoreUnresolvableHosts).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv2NfsCheck``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv2NfsCheck`: V1NfsCheckExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv2NfsCheck`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv2NfsCheckRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ignoreBadPaths** | **bool** | Ignore nonexistent or otherwise bad paths. | 
 **ignoreBadAuth** | **bool** | Ignore invalid users. | 
 **zone** | **string** | Access zone | 
 **ignoreUnresolvableHosts** | **bool** | Ignore unresolvable hosts. | 

### Return type

[**V1NfsCheckExtended**](V1NfsCheckExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv2NfsExport

> V2NfsExportsExtended GetProtocolsv2NfsExport(ctx, v2NfsExportId).Scope(scope).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsExportId := "v2NfsExportId_example" // string | Retrieve export information.
    scope := "scope_example" // string | When specified as 'effective', or not specified, all fields are returned. When specified as 'user', only fields with non-default values are shown. When specified as 'default', the original values are returned. (optional)
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv2NfsExport(context.Background(), v2NfsExportId).Scope(scope).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv2NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv2NfsExport`: V2NfsExportsExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv2NfsExport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v2NfsExportId** | **string** | Retrieve export information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv2NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | When specified as &#39;effective&#39;, or not specified, all fields are returned. When specified as &#39;user&#39;, only fields with non-default values are shown. When specified as &#39;default&#39;, the original values are returned. | 
 **zone** | **string** | Access zone | 

### Return type

[**V2NfsExportsExtended**](V2NfsExportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv2NfsExportsSummary

> V1NfsExportsSummary GetProtocolsv2NfsExportsSummary(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv2NfsExportsSummary(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv2NfsExportsSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv2NfsExportsSummary`: V1NfsExportsSummary
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv2NfsExportsSummary`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv2NfsExportsSummaryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone | 

### Return type

[**V1NfsExportsSummary**](V1NfsExportsSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv2NfsNlmLocks

> V2NfsNlmLocks GetProtocolsv2NfsNlmLocks(ctx).Sort(sort).Created(created).Lin(lin).Resume(resume).Client(client).Limit(limit).ClientId(clientId).Path(path).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    created := "created_example" // string | Return locks created after the specified unix epoch time. (optional)
    lin := "lin_example" // string | Filter locks by the specified LIN in /ifs that is locked. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    client := "client_example" // string | Filter locks by the specified client host name and IP address. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    clientId := "clientId_example" // string | Filter locks by the specified client ID. (optional)
    path := "path_example" // string | Filter locks by the specified path under /ifs. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv2NfsNlmLocks(context.Background()).Sort(sort).Created(created).Lin(lin).Resume(resume).Client(client).Limit(limit).ClientId(clientId).Path(path).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv2NfsNlmLocks``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv2NfsNlmLocks`: V2NfsNlmLocks
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv2NfsNlmLocks`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv2NfsNlmLocksRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **created** | **string** | Return locks created after the specified unix epoch time. | 
 **lin** | **string** | Filter locks by the specified LIN in /ifs that is locked. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **client** | **string** | Filter locks by the specified client host name and IP address. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **clientId** | **string** | Filter locks by the specified client ID. | 
 **path** | **string** | Filter locks by the specified path under /ifs. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V2NfsNlmLocks**](V2NfsNlmLocks.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv2NfsNlmSessions

> V2NfsNlmSessions GetProtocolsv2NfsNlmSessions(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv2NfsNlmSessions(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv2NfsNlmSessions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv2NfsNlmSessions`: V2NfsNlmSessions
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv2NfsNlmSessions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv2NfsNlmSessionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V2NfsNlmSessions**](V2NfsNlmSessions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv2NfsNlmWaiters

> V2NfsNlmWaiters GetProtocolsv2NfsNlmWaiters(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv2NfsNlmWaiters(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv2NfsNlmWaiters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv2NfsNlmWaiters`: V2NfsNlmWaiters
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv2NfsNlmWaiters`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv2NfsNlmWaitersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V2NfsNlmWaiters**](V2NfsNlmWaiters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv2NfsSettingsExport

> V2NfsSettingsExport GetProtocolsv2NfsSettingsExport(ctx).Scope(scope).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv2NfsSettingsExport(context.Background()).Scope(scope).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv2NfsSettingsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv2NfsSettingsExport`: V2NfsSettingsExport
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv2NfsSettingsExport`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv2NfsSettingsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **zone** | **string** | Access zone | 

### Return type

[**V2NfsSettingsExport**](V2NfsSettingsExport.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv2NfsSettingsZone

> V2NfsSettingsZone GetProtocolsv2NfsSettingsZone(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv2NfsSettingsZone(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv2NfsSettingsZone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv2NfsSettingsZone`: V2NfsSettingsZone
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv2NfsSettingsZone`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv2NfsSettingsZoneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone | 

### Return type

[**V2NfsSettingsZone**](V2NfsSettingsZone.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3FtpSettings

> V3FtpSettings GetProtocolsv3FtpSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3FtpSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3FtpSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3FtpSettings`: V3FtpSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3FtpSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3FtpSettingsRequest struct via the builder pattern


### Return type

[**V3FtpSettings**](V3FtpSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3HdfsLogLevel

> V3HdfsLogLevel GetProtocolsv3HdfsLogLevel(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3HdfsLogLevel(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3HdfsLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3HdfsLogLevel`: V3HdfsLogLevel
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3HdfsLogLevel`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3HdfsLogLevelRequest struct via the builder pattern


### Return type

[**V3HdfsLogLevel**](V3HdfsLogLevel.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3HttpSettings

> V3HttpSettings GetProtocolsv3HttpSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3HttpSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3HttpSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3HttpSettings`: V3HttpSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3HttpSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3HttpSettingsRequest struct via the builder pattern


### Return type

[**V3HttpSettings**](V3HttpSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpContextsBackup

> V3NdmpContextsBackup GetProtocolsv3NdmpContextsBackup(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpContextsBackup(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpContextsBackup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpContextsBackup`: V3NdmpContextsBackup
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpContextsBackup`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpContextsBackupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3NdmpContextsBackup**](V3NdmpContextsBackup.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpContextsBackupById

> V3NdmpContextsBackupExtended GetProtocolsv3NdmpContextsBackupById(ctx, v3NdmpContextsBackupId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpContextsBackupId := "v3NdmpContextsBackupId_example" // string | View a NDMP backup context

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpContextsBackupById(context.Background(), v3NdmpContextsBackupId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpContextsBackupById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpContextsBackupById`: V3NdmpContextsBackupExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpContextsBackupById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpContextsBackupId** | **string** | View a NDMP backup context | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpContextsBackupByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NdmpContextsBackupExtended**](V3NdmpContextsBackupExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpContextsBre

> V3NdmpContextsBre GetProtocolsv3NdmpContextsBre(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpContextsBre(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpContextsBre``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpContextsBre`: V3NdmpContextsBre
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpContextsBre`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpContextsBreRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3NdmpContextsBre**](V3NdmpContextsBre.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpContextsBreById

> V3NdmpContextsBreExtended GetProtocolsv3NdmpContextsBreById(ctx, v3NdmpContextsBreId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpContextsBreId := "v3NdmpContextsBreId_example" // string | View a NDMP BRE context

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpContextsBreById(context.Background(), v3NdmpContextsBreId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpContextsBreById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpContextsBreById`: V3NdmpContextsBreExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpContextsBreById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpContextsBreId** | **string** | View a NDMP BRE context | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpContextsBreByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NdmpContextsBreExtended**](V3NdmpContextsBreExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpContextsRestore

> V3NdmpContextsBackup GetProtocolsv3NdmpContextsRestore(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpContextsRestore(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpContextsRestore``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpContextsRestore`: V3NdmpContextsBackup
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpContextsRestore`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpContextsRestoreRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3NdmpContextsBackup**](V3NdmpContextsBackup.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpContextsRestoreById

> V3NdmpContextsBackupExtended GetProtocolsv3NdmpContextsRestoreById(ctx, v3NdmpContextsRestoreId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpContextsRestoreId := "v3NdmpContextsRestoreId_example" // string | View a NDMP restore context

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpContextsRestoreById(context.Background(), v3NdmpContextsRestoreId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpContextsRestoreById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpContextsRestoreById`: V3NdmpContextsBackupExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpContextsRestoreById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpContextsRestoreId** | **string** | View a NDMP restore context | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpContextsRestoreByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NdmpContextsBackupExtended**](V3NdmpContextsBackupExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpDiagnostics

> V3NdmpDiagnostics GetProtocolsv3NdmpDiagnostics(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpDiagnostics(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpDiagnostics``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpDiagnostics`: V3NdmpDiagnostics
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpDiagnostics`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpDiagnosticsRequest struct via the builder pattern


### Return type

[**V3NdmpDiagnostics**](V3NdmpDiagnostics.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpDumpdate

> V3NdmpDumpdates GetProtocolsv3NdmpDumpdate(ctx, v3NdmpDumpdateId).Sort(sort).Resume(resume).Level(level).Limit(limit).Path(path).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpDumpdateId := "v3NdmpDumpdateId_example" // string | List of dumpdates entries.
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    level := int32(56) // int32 | Filter by dumpdate level. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    path := "path_example" // string | Filter by file path. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpDumpdate(context.Background(), v3NdmpDumpdateId).Sort(sort).Resume(resume).Level(level).Limit(limit).Path(path).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpDumpdate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpDumpdate`: V3NdmpDumpdates
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpDumpdate`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpDumpdateId** | **string** | List of dumpdates entries. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpDumpdateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **level** | **int32** | Filter by dumpdate level. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **path** | **string** | Filter by file path. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3NdmpDumpdates**](V3NdmpDumpdates.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpLogs

> V3NdmpLogs GetProtocolsv3NdmpLogs(ctx).Lnn(lnn).Page(page).Pagesize(pagesize).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := "lnn_example" // string | Logical node number. (optional)
    page := int32(56) // int32 | The page number of the NDMP logs file. (optional)
    pagesize := int32(56) // int32 | The page size of each page of the NDMP log file. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpLogs(context.Background()).Lnn(lnn).Page(page).Pagesize(pagesize).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpLogs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpLogs`: V3NdmpLogs
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpLogs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpLogsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lnn** | **string** | Logical node number. | 
 **page** | **int32** | The page number of the NDMP logs file. | 
 **pagesize** | **int32** | The page size of each page of the NDMP log file. | 

### Return type

[**V3NdmpLogs**](V3NdmpLogs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpSession

> V3NdmpSessionsExtended GetProtocolsv3NdmpSession(ctx, v3NdmpSessionId).Lnn(lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpSessionId := "v3NdmpSessionId_example" // string | Retrieve the ndmp session.
    lnn := "lnn_example" // string | Logical node number. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpSession(context.Background(), v3NdmpSessionId).Lnn(lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpSession`: V3NdmpSessionsExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpSession`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpSessionId** | **string** | Retrieve the ndmp session. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **lnn** | **string** | Logical node number. | 

### Return type

[**V3NdmpSessionsExtended**](V3NdmpSessionsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpSessions

> V3NdmpSessions GetProtocolsv3NdmpSessions(ctx).Consolidate(consolidate).Node(node).Session(session).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    consolidate := true // bool | Combine sessions in the same context. (optional)
    node := "node_example" // string | Only return sessions of the node. (optional)
    session := "session_example" // string | Only return the specified session. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpSessions(context.Background()).Consolidate(consolidate).Node(node).Session(session).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpSessions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpSessions`: V3NdmpSessions
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpSessions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpSessionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **consolidate** | **bool** | Combine sessions in the same context. | 
 **node** | **string** | Only return sessions of the node. | 
 **session** | **string** | Only return the specified session. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3NdmpSessions**](V3NdmpSessions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpSettingsDmas

> V3NdmpSettingsDmas GetProtocolsv3NdmpSettingsDmas(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpSettingsDmas(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpSettingsDmas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpSettingsDmas`: V3NdmpSettingsDmas
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpSettingsDmas`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpSettingsDmasRequest struct via the builder pattern


### Return type

[**V3NdmpSettingsDmas**](V3NdmpSettingsDmas.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpSettingsGlobal

> V3NdmpSettingsGlobal GetProtocolsv3NdmpSettingsGlobal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpSettingsGlobal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpSettingsGlobal`: V3NdmpSettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpSettingsGlobal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpSettingsGlobalRequest struct via the builder pattern


### Return type

[**V3NdmpSettingsGlobal**](V3NdmpSettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpSettingsVariable

> V3NdmpSettingsVariables GetProtocolsv3NdmpSettingsVariable(ctx, v3NdmpSettingsVariableId).Path(path).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpSettingsVariableId := "v3NdmpSettingsVariableId_example" // string | List of preferred environment variables.
    path := "path_example" // string | Return variables of the path. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpSettingsVariable(context.Background(), v3NdmpSettingsVariableId).Path(path).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpSettingsVariable``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpSettingsVariable`: V3NdmpSettingsVariables
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpSettingsVariable`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpSettingsVariableId** | **string** | List of preferred environment variables. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpSettingsVariableRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **path** | **string** | Return variables of the path. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3NdmpSettingsVariables**](V3NdmpSettingsVariables.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NdmpUser

> V3NdmpUsersExtended GetProtocolsv3NdmpUser(ctx, v3NdmpUserId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpUserId := "v3NdmpUserId_example" // string | Retrieve the user.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NdmpUser(context.Background(), v3NdmpUserId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NdmpUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NdmpUser`: V3NdmpUsersExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NdmpUser`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpUserId** | **string** | Retrieve the user. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NdmpUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NdmpUsersExtended**](V3NdmpUsersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NfsLogLevel

> V3NfsLogLevel GetProtocolsv3NfsLogLevel(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NfsLogLevel(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NfsLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NfsLogLevel`: V3NfsLogLevel
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NfsLogLevel`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NfsLogLevelRequest struct via the builder pattern


### Return type

[**V3NfsLogLevel**](V3NfsLogLevel.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NfsNetgroup

> V3NfsNetgroup GetProtocolsv3NfsNetgroup(ctx).Host(host).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    host := "host_example" // string | Host to retrieve netgroup cache settings from. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NfsNetgroup(context.Background()).Host(host).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NfsNetgroup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NfsNetgroup`: V3NfsNetgroup
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NfsNetgroup`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NfsNetgroupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **host** | **string** | Host to retrieve netgroup cache settings from. | 

### Return type

[**V3NfsNetgroup**](V3NfsNetgroup.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NfsNlmSession

> V3NfsNlmSessionsExtended GetProtocolsv3NfsNlmSession(ctx, v3NfsNlmSessionId).ClusterIp(clusterIp).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NfsNlmSessionId := "v3NfsNlmSessionId_example" // string | Retrieve all lock state for a single client.
    clusterIp := "clusterIp_example" // string | An IP address for which NSM has client records (optional)
    zone := "zone_example" // string | Represents an extant auth zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NfsNlmSession(context.Background(), v3NfsNlmSessionId).ClusterIp(clusterIp).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NfsNlmSession``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NfsNlmSession`: V3NfsNlmSessionsExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NfsNlmSession`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NfsNlmSessionId** | **string** | Retrieve all lock state for a single client. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NfsNlmSessionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **clusterIp** | **string** | An IP address for which NSM has client records | 
 **zone** | **string** | Represents an extant auth zone | 

### Return type

[**V3NfsNlmSessionsExtended**](V3NfsNlmSessionsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NfsNlmSessions

> V3NfsNlmSessions GetProtocolsv3NfsNlmSessions(ctx).Sort(sort).Ip(ip).Limit(limit).Zone(zone).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    ip := "ip_example" // string | An IP address for which NSM has client records (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    zone := "zone_example" // string | Represents an extant auth zone (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NfsNlmSessions(context.Background()).Sort(sort).Ip(ip).Limit(limit).Zone(zone).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NfsNlmSessions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NfsNlmSessions`: V3NfsNlmSessions
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NfsNlmSessions`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NfsNlmSessionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **ip** | **string** | An IP address for which NSM has client records | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **zone** | **string** | Represents an extant auth zone | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3NfsNlmSessions**](V3NfsNlmSessions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NfsSettingsGlobal

> V3NfsSettingsGlobal GetProtocolsv3NfsSettingsGlobal(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | When specified as 'effective', or not specified, all fields are returned. When specified as 'user', only fields with non-default values are shown. When specified as 'default', the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NfsSettingsGlobal(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NfsSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NfsSettingsGlobal`: V3NfsSettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NfsSettingsGlobal`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NfsSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | When specified as &#39;effective&#39;, or not specified, all fields are returned. When specified as &#39;user&#39;, only fields with non-default values are shown. When specified as &#39;default&#39;, the original values are returned. | 

### Return type

[**V3NfsSettingsGlobal**](V3NfsSettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NtpServer

> V3NtpServersExtended GetProtocolsv3NtpServer(ctx, v3NtpServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NtpServerId := "v3NtpServerId_example" // string | Retrieve one NTP server.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NtpServer(context.Background(), v3NtpServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NtpServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NtpServer`: V3NtpServersExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NtpServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NtpServerId** | **string** | Retrieve one NTP server. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NtpServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NtpServersExtended**](V3NtpServersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3NtpSettings

> V3NtpSettings GetProtocolsv3NtpSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3NtpSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3NtpSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3NtpSettings`: V3NtpSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3NtpSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3NtpSettingsRequest struct via the builder pattern


### Return type

[**V3NtpSettings**](V3NtpSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3SmbLogLevel

> V3SmbLogLevel GetProtocolsv3SmbLogLevel(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3SmbLogLevel(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3SmbLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3SmbLogLevel`: V3SmbLogLevel
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3SmbLogLevel`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3SmbLogLevelRequest struct via the builder pattern


### Return type

[**V3SmbLogLevel**](V3SmbLogLevel.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3SmbLogLevelFilter

> V3SmbLogLevelFilters GetProtocolsv3SmbLogLevelFilter(ctx, v3SmbLogLevelFilterId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SmbLogLevelFilterId := "v3SmbLogLevelFilterId_example" // string | View log filter.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3SmbLogLevelFilter(context.Background(), v3SmbLogLevelFilterId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3SmbLogLevelFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3SmbLogLevelFilter`: V3SmbLogLevelFilters
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3SmbLogLevelFilter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SmbLogLevelFilterId** | **string** | View log filter. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3SmbLogLevelFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3SmbLogLevelFilters**](V3SmbLogLevelFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3SmbSettingsGlobal

> V3SmbSettingsGlobal GetProtocolsv3SmbSettingsGlobal(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3SmbSettingsGlobal(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3SmbSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3SmbSettingsGlobal`: V3SmbSettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3SmbSettingsGlobal`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3SmbSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V3SmbSettingsGlobal**](V3SmbSettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3SmbSettingsShare

> V3SmbSettingsShare GetProtocolsv3SmbSettingsShare(ctx).Scope(scope).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    zone := "zone_example" // string | Zone which contains these share settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3SmbSettingsShare(context.Background()).Scope(scope).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3SmbSettingsShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3SmbSettingsShare`: V3SmbSettingsShare
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3SmbSettingsShare`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3SmbSettingsShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **zone** | **string** | Zone which contains these share settings. | 

### Return type

[**V3SmbSettingsShare**](V3SmbSettingsShare.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3SmbShare

> V3SmbSharesExtended GetProtocolsv3SmbShare(ctx, v3SmbShareId).Scope(scope).ResolveNames(resolveNames).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SmbShareId := "v3SmbShareId_example" // string | Retrieve share.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    zone := "zone_example" // string | Zone which contains this share. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3SmbShare(context.Background(), v3SmbShareId).Scope(scope).ResolveNames(resolveNames).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3SmbShare`: V3SmbSharesExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3SmbShare`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SmbShareId** | **string** | Retrieve share. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **zone** | **string** | Zone which contains this share. | 

### Return type

[**V3SmbSharesExtended**](V3SmbSharesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3SnmpSettings

> V3SnmpSettings GetProtocolsv3SnmpSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3SnmpSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3SnmpSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3SnmpSettings`: V3SnmpSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3SnmpSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3SnmpSettingsRequest struct via the builder pattern


### Return type

[**V3SnmpSettings**](V3SnmpSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv3SwiftAccount

> V3SwiftAccountsExtended GetProtocolsv3SwiftAccount(ctx, v3SwiftAccountId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SwiftAccountId := "v3SwiftAccountId_example" // string | List a swift account.
    zone := "zone_example" // string | Access zone which contains Swift account. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv3SwiftAccount(context.Background(), v3SwiftAccountId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv3SwiftAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv3SwiftAccount`: V3SwiftAccountsExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv3SwiftAccount`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SwiftAccountId** | **string** | List a swift account. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv3SwiftAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Access zone which contains Swift account. | 

### Return type

[**V3SwiftAccountsExtended**](V3SwiftAccountsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv4HdfsRangerPluginSettings

> V4HdfsRangerPluginSettings GetProtocolsv4HdfsRangerPluginSettings(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains HDFS ranger-plugin settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv4HdfsRangerPluginSettings(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv4HdfsRangerPluginSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv4HdfsRangerPluginSettings`: V4HdfsRangerPluginSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv4HdfsRangerPluginSettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv4HdfsRangerPluginSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains HDFS ranger-plugin settings. | 

### Return type

[**V4HdfsRangerPluginSettings**](V4HdfsRangerPluginSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv4NdmpSettingsPreferredIp

> V4NdmpSettingsPreferredIpsExtended GetProtocolsv4NdmpSettingsPreferredIp(ctx, v4NdmpSettingsPreferredIpId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4NdmpSettingsPreferredIpId := "v4NdmpSettingsPreferredIpId_example" // string | Get one preference by id.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv4NdmpSettingsPreferredIp(context.Background(), v4NdmpSettingsPreferredIpId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv4NdmpSettingsPreferredIp``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv4NdmpSettingsPreferredIp`: V4NdmpSettingsPreferredIpsExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv4NdmpSettingsPreferredIp`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4NdmpSettingsPreferredIpId** | **string** | Get one preference by id. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv4NdmpSettingsPreferredIpRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4NdmpSettingsPreferredIpsExtended**](V4NdmpSettingsPreferredIpsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv5HdfsFsimageJob

> V5HdfsFsimageJob GetProtocolsv5HdfsFsimageJob(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains job information. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv5HdfsFsimageJob(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv5HdfsFsimageJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv5HdfsFsimageJob`: V5HdfsFsimageJob
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv5HdfsFsimageJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv5HdfsFsimageJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains job information. | 

### Return type

[**V5HdfsFsimageJob**](V5HdfsFsimageJob.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv5HdfsFsimageJobSettings

> V5HdfsFsimageJobSettings GetProtocolsv5HdfsFsimageJobSettings(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains job settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv5HdfsFsimageJobSettings(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv5HdfsFsimageJobSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv5HdfsFsimageJobSettings`: V5HdfsFsimageJobSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv5HdfsFsimageJobSettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv5HdfsFsimageJobSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains job settings. | 

### Return type

[**V5HdfsFsimageJobSettings**](V5HdfsFsimageJobSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv5HdfsFsimageLatest

> V5HdfsFsimageLatest GetProtocolsv5HdfsFsimageLatest(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains HDFS FSImage. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv5HdfsFsimageLatest(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv5HdfsFsimageLatest``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv5HdfsFsimageLatest`: V5HdfsFsimageLatest
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv5HdfsFsimageLatest`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv5HdfsFsimageLatestRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains HDFS FSImage. | 

### Return type

[**V5HdfsFsimageLatest**](V5HdfsFsimageLatest.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv5HdfsFsimageSettings

> V5HdfsFsimageSettings GetProtocolsv5HdfsFsimageSettings(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains FSImage settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv5HdfsFsimageSettings(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv5HdfsFsimageSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv5HdfsFsimageSettings`: V5HdfsFsimageSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv5HdfsFsimageSettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv5HdfsFsimageSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains FSImage settings. | 

### Return type

[**V5HdfsFsimageSettings**](V5HdfsFsimageSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv5HdfsInotifySettings

> V5HdfsInotifySettings GetProtocolsv5HdfsInotifySettings(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains INotify settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv5HdfsInotifySettings(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv5HdfsInotifySettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv5HdfsInotifySettings`: V5HdfsInotifySettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv5HdfsInotifySettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv5HdfsInotifySettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains INotify settings. | 

### Return type

[**V5HdfsInotifySettings**](V5HdfsInotifySettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv5HdfsInotifyStream

> V5HdfsInotifyStream GetProtocolsv5HdfsInotifyStream(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which exposes HDFS INotify. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv5HdfsInotifyStream(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv5HdfsInotifyStream``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv5HdfsInotifyStream`: V5HdfsInotifyStream
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv5HdfsInotifyStream`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv5HdfsInotifyStreamRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which exposes HDFS INotify. | 

### Return type

[**V5HdfsInotifyStream**](V5HdfsInotifyStream.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv5SnmpSettings

> V5SnmpSettings GetProtocolsv5SnmpSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv5SnmpSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv5SnmpSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv5SnmpSettings`: V5SnmpSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv5SnmpSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv5SnmpSettingsRequest struct via the builder pattern


### Return type

[**V5SnmpSettings**](V5SnmpSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv6SmbSettingsGlobal

> V6SmbSettingsGlobal GetProtocolsv6SmbSettingsGlobal(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv6SmbSettingsGlobal(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv6SmbSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv6SmbSettingsGlobal`: V6SmbSettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv6SmbSettingsGlobal`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv6SmbSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V6SmbSettingsGlobal**](V6SmbSettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv6SmbSettingsShare

> V6SmbSettingsShare GetProtocolsv6SmbSettingsShare(ctx).Scope(scope).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    zone := "zone_example" // string | Zone which contains these share settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv6SmbSettingsShare(context.Background()).Scope(scope).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv6SmbSettingsShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv6SmbSettingsShare`: V6SmbSettingsShare
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv6SmbSettingsShare`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv6SmbSettingsShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **zone** | **string** | Zone which contains these share settings. | 

### Return type

[**V6SmbSettingsShare**](V6SmbSettingsShare.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv6SmbSettingsZone

> V6SmbSettingsZone GetProtocolsv6SmbSettingsZone(ctx).Scope(scope).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    zone := "zone_example" // string | Name of the access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv6SmbSettingsZone(context.Background()).Scope(scope).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv6SmbSettingsZone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv6SmbSettingsZone`: V6SmbSettingsZone
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv6SmbSettingsZone`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv6SmbSettingsZoneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **zone** | **string** | Name of the access zone | 

### Return type

[**V6SmbSettingsZone**](V6SmbSettingsZone.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv6SmbShare

> V6SmbSharesExtended GetProtocolsv6SmbShare(ctx, v6SmbShareId).Scope(scope).ResolveNames(resolveNames).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v6SmbShareId := "v6SmbShareId_example" // string | Retrieve share.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    zone := "zone_example" // string | Zone which contains this share. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv6SmbShare(context.Background(), v6SmbShareId).Scope(scope).ResolveNames(resolveNames).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv6SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv6SmbShare`: V6SmbSharesExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv6SmbShare`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v6SmbShareId** | **string** | Retrieve share. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv6SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **zone** | **string** | Zone which contains this share. | 

### Return type

[**V6SmbSharesExtended**](V6SmbSharesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv7HdfsCryptoSettings

> V7HdfsCryptoSettings GetProtocolsv7HdfsCryptoSettings(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv7HdfsCryptoSettings(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv7HdfsCryptoSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv7HdfsCryptoSettings`: V7HdfsCryptoSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv7HdfsCryptoSettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv7HdfsCryptoSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V7HdfsCryptoSettings**](V7HdfsCryptoSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv7NfsSettingsGlobal

> V7NfsSettingsGlobal GetProtocolsv7NfsSettingsGlobal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv7NfsSettingsGlobal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv7NfsSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv7NfsSettingsGlobal`: V7NfsSettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv7NfsSettingsGlobal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv7NfsSettingsGlobalRequest struct via the builder pattern


### Return type

[**V7NfsSettingsGlobal**](V7NfsSettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv7SmbSettingsGlobal

> V6SmbSettingsGlobal GetProtocolsv7SmbSettingsGlobal(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv7SmbSettingsGlobal(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv7SmbSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv7SmbSettingsGlobal`: V6SmbSettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv7SmbSettingsGlobal`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv7SmbSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V6SmbSettingsGlobal**](V6SmbSettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv7SmbSettingsShare

> V7SmbSettingsShare GetProtocolsv7SmbSettingsShare(ctx).Scope(scope).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv7SmbSettingsShare(context.Background()).Scope(scope).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv7SmbSettingsShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv7SmbSettingsShare`: V7SmbSettingsShare
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv7SmbSettingsShare`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv7SmbSettingsShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V7SmbSettingsShare**](V7SmbSettingsShare.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv7SmbShare

> V7SmbSharesExtended GetProtocolsv7SmbShare(ctx, v7SmbShareId).Scope(scope).ResolveNames(resolveNames).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SmbShareId := "v7SmbShareId_example" // string | Retrieve share.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv7SmbShare(context.Background(), v7SmbShareId).Scope(scope).ResolveNames(resolveNames).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv7SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv7SmbShare`: V7SmbSharesExtended
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv7SmbShare`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SmbShareId** | **string** | Retrieve share. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv7SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V7SmbSharesExtended**](V7SmbSharesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv7SshSettings

> V7SshSettings GetProtocolsv7SshSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv7SshSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv7SshSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv7SshSettings`: V7SshSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv7SshSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv7SshSettingsRequest struct via the builder pattern


### Return type

[**V7SshSettings**](V7SshSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv8SshSettings

> V8SshSettings GetProtocolsv8SshSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv8SshSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv8SshSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv8SshSettings`: V8SshSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv8SshSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv8SshSettingsRequest struct via the builder pattern


### Return type

[**V8SshSettings**](V8SshSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetProtocolsv9HdfsSettings

> V9HdfsSettings GetProtocolsv9HdfsSettings(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains HDFS settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.GetProtocolsv9HdfsSettings(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.GetProtocolsv9HdfsSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetProtocolsv9HdfsSettings`: V9HdfsSettings
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.GetProtocolsv9HdfsSettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetProtocolsv9HdfsSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains HDFS settings. | 

### Return type

[**V9HdfsSettings**](V9HdfsSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv10S3Buckets

> V10S3Buckets ListProtocolsv10S3Buckets(ctx).Sort(sort).Zone(zone).Resume(resume).Limit(limit).Owner(owner).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    owner := "owner_example" // string | Specifies the name of the owner. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv10S3Buckets(context.Background()).Sort(sort).Zone(zone).Resume(resume).Limit(limit).Owner(owner).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv10S3Buckets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv10S3Buckets`: V10S3Buckets
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv10S3Buckets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv10S3BucketsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **zone** | **string** | Specifies which access zone to use. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **owner** | **string** | Specifies the name of the owner. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V10S3Buckets**](V10S3Buckets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv10S3Mykeys

> Createv10S3KeyResponse ListProtocolsv10S3Mykeys(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv10S3Mykeys(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv10S3Mykeys``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv10S3Mykeys`: Createv10S3KeyResponse
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv10S3Mykeys`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv10S3MykeysRequest struct via the builder pattern


### Return type

[**Createv10S3KeyResponse**](Createv10S3KeyResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv12S3Buckets

> V12S3Buckets ListProtocolsv12S3Buckets(ctx).Sort(sort).Zone(zone).Resume(resume).Limit(limit).Owner(owner).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    owner := "owner_example" // string | Specifies the name of the owner. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv12S3Buckets(context.Background()).Sort(sort).Zone(zone).Resume(resume).Limit(limit).Owner(owner).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv12S3Buckets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv12S3Buckets`: V12S3Buckets
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv12S3Buckets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv12S3BucketsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **zone** | **string** | Specifies which access zone to use. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **owner** | **string** | Specifies the name of the owner. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V12S3Buckets**](V12S3Buckets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv12SmbShares

> V12SmbShares ListProtocolsv12SmbShares(ctx).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Offset(offset).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    offset := int32(56) // int32 | The position of the first item returned for a paginated query within the full result set. (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv12SmbShares(context.Background()).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Offset(offset).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv12SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv12SmbShares`: V12SmbShares
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv12SmbShares`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv12SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **zone** | **string** | Specifies which access zone to use. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **offset** | **int32** | The position of the first item returned for a paginated query within the full result set. | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V12SmbShares**](V12SmbShares.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv15NfsAliases

> V15NfsAliases ListProtocolsv15NfsAliases(ctx).Sort(sort).Zone(zone).Resume(resume).Limit(limit).Check(check).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    zone := "zone_example" // string | Access zone (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    check := true // bool | Check for conflicts when listing aliases. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv15NfsAliases(context.Background()).Sort(sort).Zone(zone).Resume(resume).Limit(limit).Check(check).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv15NfsAliases``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv15NfsAliases`: V15NfsAliases
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv15NfsAliases`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv15NfsAliasesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **zone** | **string** | Access zone | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **check** | **bool** | Check for conflicts when listing aliases. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V15NfsAliases**](V15NfsAliases.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv15S3Buckets

> V12S3Buckets ListProtocolsv15S3Buckets(ctx).Sort(sort).Zone(zone).Resume(resume).Limit(limit).Offset(offset).Owner(owner).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    offset := int32(56) // int32 | The position of the first item returned for a paginated query within the full result set. (optional)
    owner := "owner_example" // string | Specifies the name of the owner. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv15S3Buckets(context.Background()).Sort(sort).Zone(zone).Resume(resume).Limit(limit).Offset(offset).Owner(owner).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv15S3Buckets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv15S3Buckets`: V12S3Buckets
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv15S3Buckets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv15S3BucketsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **zone** | **string** | Specifies which access zone to use. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **offset** | **int32** | The position of the first item returned for a paginated query within the full result set. | 
 **owner** | **string** | Specifies the name of the owner. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V12S3Buckets**](V12S3Buckets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv1HdfsProxyusers

> V1HdfsProxyusers ListProtocolsv1HdfsProxyusers(ctx).Limit(limit).Zone(zone).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    zone := "zone_example" // string | Access zone which contains HDFS proxyusers. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv1HdfsProxyusers(context.Background()).Limit(limit).Zone(zone).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv1HdfsProxyusers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv1HdfsProxyusers`: V1HdfsProxyusers
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv1HdfsProxyusers`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv1HdfsProxyusersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **zone** | **string** | Access zone which contains HDFS proxyusers. | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1HdfsProxyusers**](V1HdfsProxyusers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv1HdfsRacks

> V1HdfsRacks ListProtocolsv1HdfsRacks(ctx).Limit(limit).Zone(zone).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    zone := "zone_example" // string | Access zone which contains HDFS racks. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv1HdfsRacks(context.Background()).Limit(limit).Zone(zone).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv1HdfsRacks``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv1HdfsRacks`: V1HdfsRacks
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv1HdfsRacks`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv1HdfsRacksRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **zone** | **string** | Access zone which contains HDFS racks. | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1HdfsRacks**](V1HdfsRacks.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv1NfsExports

> V1NfsExports ListProtocolsv1NfsExports(ctx).Sort(sort).Resume(resume).Limit(limit).Offset(offset).Scope(scope).Check(check).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. Default is id. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    offset := int32(56) // int32 | The position of the first item returned for a paginated query within the full result set. (optional)
    scope := "scope_example" // string | If specified as effective or not specified, all export fields are shown.  If specified as user, only fields with non-default values are shown. (optional)
    check := true // bool | Check for conflicts when listing exports. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv1NfsExports(context.Background()).Sort(sort).Resume(resume).Limit(limit).Offset(offset).Scope(scope).Check(check).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv1NfsExports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv1NfsExports`: V1NfsExports
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv1NfsExports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv1NfsExportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. Default is id. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **offset** | **int32** | The position of the first item returned for a paginated query within the full result set. | 
 **scope** | **string** | If specified as effective or not specified, all export fields are shown.  If specified as user, only fields with non-default values are shown. | 
 **check** | **bool** | Check for conflicts when listing exports. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1NfsExports**](V1NfsExports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv1SmbShares

> V1SmbShares ListProtocolsv1SmbShares(ctx).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Order results by this field. Default is id. (optional)
    zone := "zone_example" // string | Zone which contains this share. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv1SmbShares(context.Background()).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv1SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv1SmbShares`: V1SmbShares
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv1SmbShares`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv1SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Order results by this field. Default is id. | 
 **zone** | **string** | Zone which contains this share. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1SmbShares**](V1SmbShares.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv2NfsAliases

> V15NfsAliases ListProtocolsv2NfsAliases(ctx).Sort(sort).Zone(zone).Resume(resume).Limit(limit).Check(check).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    zone := "zone_example" // string | Access zone (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    check := true // bool | Check for conflicts when listing aliases. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv2NfsAliases(context.Background()).Sort(sort).Zone(zone).Resume(resume).Limit(limit).Check(check).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv2NfsAliases``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv2NfsAliases`: V15NfsAliases
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv2NfsAliases`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv2NfsAliasesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **zone** | **string** | Access zone | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **check** | **bool** | Check for conflicts when listing aliases. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V15NfsAliases**](V15NfsAliases.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv2NfsExports

> V2NfsExports ListProtocolsv2NfsExports(ctx).Sort(sort).Zone(zone).Resume(resume).Scope(scope).Limit(limit).Offset(offset).Path(path).Check(check).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. Default is id. (optional)
    zone := "zone_example" // string | Access zone (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    scope := "scope_example" // string | When specified as 'effective', or not specified, all fields are returned. When specified as 'user', only fields with non-default values are shown. When specified as 'default', the original values are returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    offset := int32(56) // int32 | The position of the first item returned for a paginated query within the full result set. (optional)
    path := "path_example" // string | If specified, only exports that explicitly reference at least one of the given paths will be returned. (optional)
    check := true // bool | Check for conflicts when listing exports. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv2NfsExports(context.Background()).Sort(sort).Zone(zone).Resume(resume).Scope(scope).Limit(limit).Offset(offset).Path(path).Check(check).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv2NfsExports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv2NfsExports`: V2NfsExports
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv2NfsExports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv2NfsExportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. Default is id. | 
 **zone** | **string** | Access zone | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **scope** | **string** | When specified as &#39;effective&#39;, or not specified, all fields are returned. When specified as &#39;user&#39;, only fields with non-default values are shown. When specified as &#39;default&#39;, the original values are returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **offset** | **int32** | The position of the first item returned for a paginated query within the full result set. | 
 **path** | **string** | If specified, only exports that explicitly reference at least one of the given paths will be returned. | 
 **check** | **bool** | Check for conflicts when listing exports. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V2NfsExports**](V2NfsExports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv3NdmpUsers

> V3NdmpUsers ListProtocolsv3NdmpUsers(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv3NdmpUsers(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv3NdmpUsers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv3NdmpUsers`: V3NdmpUsers
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv3NdmpUsers`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv3NdmpUsersRequest struct via the builder pattern


### Return type

[**V3NdmpUsers**](V3NdmpUsers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv3NtpServers

> V3NtpServers ListProtocolsv3NtpServers(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv3NtpServers(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv3NtpServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv3NtpServers`: V3NtpServers
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv3NtpServers`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv3NtpServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3NtpServers**](V3NtpServers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv3SmbLogLevelFilters

> V3SmbLogLevelFilters ListProtocolsv3SmbLogLevelFilters(ctx).Sort(sort).Dir(dir).Level(level).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    level := "level_example" // string | Valid SMB logging levels (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv3SmbLogLevelFilters(context.Background()).Sort(sort).Dir(dir).Level(level).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv3SmbLogLevelFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv3SmbLogLevelFilters`: V3SmbLogLevelFilters
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv3SmbLogLevelFilters`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv3SmbLogLevelFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **dir** | **string** | The direction of the sort. | 
 **level** | **string** | Valid SMB logging levels | 

### Return type

[**V3SmbLogLevelFilters**](V3SmbLogLevelFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv3SmbShares

> V3SmbShares ListProtocolsv3SmbShares(ctx).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Order results by this field. Default is id. (optional)
    zone := "zone_example" // string | Zone which contains this share. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv3SmbShares(context.Background()).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv3SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv3SmbShares`: V3SmbShares
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv3SmbShares`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv3SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Order results by this field. Default is id. | 
 **zone** | **string** | Zone which contains this share. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3SmbShares**](V3SmbShares.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv3SwiftAccounts

> V3SwiftAccounts ListProtocolsv3SwiftAccounts(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains Swift accounts. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv3SwiftAccounts(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv3SwiftAccounts``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv3SwiftAccounts`: V3SwiftAccounts
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv3SwiftAccounts`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv3SwiftAccountsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains Swift accounts. | 

### Return type

[**V3SwiftAccounts**](V3SwiftAccounts.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv4NdmpSettingsPreferredIps

> V4NdmpSettingsPreferredIps ListProtocolsv4NdmpSettingsPreferredIps(ctx).Scope(scope).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | Either cluster or a network subnet defined in OneFS. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv4NdmpSettingsPreferredIps(context.Background()).Scope(scope).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv4NdmpSettingsPreferredIps``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv4NdmpSettingsPreferredIps`: V4NdmpSettingsPreferredIps
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv4NdmpSettingsPreferredIps`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv4NdmpSettingsPreferredIpsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | Either cluster or a network subnet defined in OneFS. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V4NdmpSettingsPreferredIps**](V4NdmpSettingsPreferredIps.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv4NfsExports

> V2NfsExports ListProtocolsv4NfsExports(ctx).Sort(sort).Zone(zone).Resume(resume).Scope(scope).Limit(limit).Offset(offset).Path(path).Check(check).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. Default is id. (optional)
    zone := "zone_example" // string | Access zone (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    scope := "scope_example" // string | When specified as 'effective', or not specified, all fields are returned. When specified as 'user', only fields with non-default values are shown. When specified as 'default', the original values are returned. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    offset := int32(56) // int32 | The position of the first item returned for a paginated query within the full result set. (optional)
    path := "path_example" // string | If specified, only exports that explicitly reference at least one of the given paths will be returned. (optional)
    check := true // bool | Check for conflicts when listing exports. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv4NfsExports(context.Background()).Sort(sort).Zone(zone).Resume(resume).Scope(scope).Limit(limit).Offset(offset).Path(path).Check(check).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv4NfsExports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv4NfsExports`: V2NfsExports
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv4NfsExports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv4NfsExportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. Default is id. | 
 **zone** | **string** | Access zone | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **scope** | **string** | When specified as &#39;effective&#39;, or not specified, all fields are returned. When specified as &#39;user&#39;, only fields with non-default values are shown. When specified as &#39;default&#39;, the original values are returned. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **offset** | **int32** | The position of the first item returned for a paginated query within the full result set. | 
 **path** | **string** | If specified, only exports that explicitly reference at least one of the given paths will be returned. | 
 **check** | **bool** | Check for conflicts when listing exports. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V2NfsExports**](V2NfsExports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv4SmbShares

> V3SmbShares ListProtocolsv4SmbShares(ctx).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Offset(offset).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Order results by this field. Default is id. (optional)
    zone := "zone_example" // string | Zone which contains this share. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    offset := int32(56) // int32 | The position of the first item returned for a paginated query within the full result set. (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv4SmbShares(context.Background()).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Offset(offset).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv4SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv4SmbShares`: V3SmbShares
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv4SmbShares`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv4SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Order results by this field. Default is id. | 
 **zone** | **string** | Zone which contains this share. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **offset** | **int32** | The position of the first item returned for a paginated query within the full result set. | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3SmbShares**](V3SmbShares.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv6SmbShares

> V6SmbShares ListProtocolsv6SmbShares(ctx).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Order results by this field. Default is id. (optional)
    zone := "zone_example" // string | Zone which contains this share. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv6SmbShares(context.Background()).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv6SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv6SmbShares`: V6SmbShares
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv6SmbShares`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv6SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Order results by this field. Default is id. | 
 **zone** | **string** | Zone which contains this share. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V6SmbShares**](V6SmbShares.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListProtocolsv7SmbShares

> V7SmbShares ListProtocolsv7SmbShares(ctx).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Offset(offset).Scope(scope).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    offset := int32(56) // int32 | The position of the first item returned for a paginated query within the full result set. (optional)
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ProtocolsApi.ListProtocolsv7SmbShares(context.Background()).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Offset(offset).Scope(scope).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.ListProtocolsv7SmbShares``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListProtocolsv7SmbShares`: V7SmbShares
    fmt.Fprintf(os.Stdout, "Response from `ProtocolsApi.ListProtocolsv7SmbShares`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListProtocolsv7SmbSharesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **zone** | **string** | Specifies which access zone to use. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **offset** | **int32** | The position of the first item returned for a paginated query within the full result set. | 
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7SmbShares**](V7SmbShares.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv10S3Bucket

> UpdateProtocolsv10S3Bucket(ctx, v10S3BucketId).V10S3Bucket(v10S3Bucket).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3BucketId := "v10S3BucketId_example" // string | Modify bucket. All input fields are optional, but one or more must be supplied.
    v10S3Bucket := *openapiclient.NewV10S3BucketExtendedExtended() // V10S3BucketExtendedExtended | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv10S3Bucket(context.Background(), v10S3BucketId).V10S3Bucket(v10S3Bucket).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv10S3Bucket``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10S3BucketId** | **string** | Modify bucket. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv10S3BucketRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v10S3Bucket** | [**V10S3BucketExtendedExtended**](V10S3BucketExtendedExtended.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv10S3LogLevel

> UpdateProtocolsv10S3LogLevel(ctx).V10S3LogLevel(v10S3LogLevel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3LogLevel := *openapiclient.NewV10S3LogLevel() // V10S3LogLevel | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv10S3LogLevel(context.Background()).V10S3LogLevel(v10S3LogLevel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv10S3LogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv10S3LogLevelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10S3LogLevel** | [**V10S3LogLevel**](V10S3LogLevel.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv10S3SettingsGlobal

> UpdateProtocolsv10S3SettingsGlobal(ctx).V10S3SettingsGlobal(v10S3SettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3SettingsGlobal := *openapiclient.NewV10S3SettingsGlobalSettings() // V10S3SettingsGlobalSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv10S3SettingsGlobal(context.Background()).V10S3SettingsGlobal(v10S3SettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv10S3SettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv10S3SettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10S3SettingsGlobal** | [**V10S3SettingsGlobalSettings**](V10S3SettingsGlobalSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv10S3SettingsZone

> UpdateProtocolsv10S3SettingsZone(ctx).V10S3SettingsZone(v10S3SettingsZone).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10S3SettingsZone := *openapiclient.NewV10S3SettingsZoneSettings() // V10S3SettingsZoneSettings | 
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv10S3SettingsZone(context.Background()).V10S3SettingsZone(v10S3SettingsZone).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv10S3SettingsZone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv10S3SettingsZoneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10S3SettingsZone** | [**V10S3SettingsZoneSettings**](V10S3SettingsZoneSettings.md) |  | 
 **zone** | **string** | Access zone | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv11HdfsSettingsGlobal

> UpdateProtocolsv11HdfsSettingsGlobal(ctx).V11HdfsSettingsGlobal(v11HdfsSettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11HdfsSettingsGlobal := *openapiclient.NewV11HdfsSettingsGlobalGlobalSettings() // V11HdfsSettingsGlobalGlobalSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv11HdfsSettingsGlobal(context.Background()).V11HdfsSettingsGlobal(v11HdfsSettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv11HdfsSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv11HdfsSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v11HdfsSettingsGlobal** | [**V11HdfsSettingsGlobalGlobalSettings**](V11HdfsSettingsGlobalGlobalSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv11NfsExport

> UpdateProtocolsv11NfsExport(ctx, v11NfsExportId).V11NfsExport(v11NfsExport).Force(force).IgnoreUnresolvableHosts(ignoreUnresolvableHosts).Zone(zone).IgnoreConflicts(ignoreConflicts).IgnoreBadPaths(ignoreBadPaths).IgnoreBadAuth(ignoreBadAuth).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11NfsExportId := "v11NfsExportId_example" // string | Modify the export. All input fields are optional, but one or more must be supplied.
    v11NfsExport := *openapiclient.NewV11NfsExport() // V11NfsExport | 
    force := true // bool | If true, the export will be updated even if that change conflicts with another export. (optional)
    ignoreUnresolvableHosts := true // bool | Ignore unresolvable hosts. (optional)
    zone := "zone_example" // string | Access zone (optional)
    ignoreConflicts := true // bool | Ignore conflicts with existing exports. (optional)
    ignoreBadPaths := true // bool | Ignore nonexistent or otherwise bad paths. (optional)
    ignoreBadAuth := true // bool | Ignore invalid users. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv11NfsExport(context.Background(), v11NfsExportId).V11NfsExport(v11NfsExport).Force(force).IgnoreUnresolvableHosts(ignoreUnresolvableHosts).Zone(zone).IgnoreConflicts(ignoreConflicts).IgnoreBadPaths(ignoreBadPaths).IgnoreBadAuth(ignoreBadAuth).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv11NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11NfsExportId** | **string** | Modify the export. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv11NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v11NfsExport** | [**V11NfsExport**](V11NfsExport.md) |  | 
 **force** | **bool** | If true, the export will be updated even if that change conflicts with another export. | 
 **ignoreUnresolvableHosts** | **bool** | Ignore unresolvable hosts. | 
 **zone** | **string** | Access zone | 
 **ignoreConflicts** | **bool** | Ignore conflicts with existing exports. | 
 **ignoreBadPaths** | **bool** | Ignore nonexistent or otherwise bad paths. | 
 **ignoreBadAuth** | **bool** | Ignore invalid users. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv12HdfsLogLevel

> UpdateProtocolsv12HdfsLogLevel(ctx).V12HdfsLogLevel(v12HdfsLogLevel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12HdfsLogLevel := *openapiclient.NewV12HdfsLogLevel() // V12HdfsLogLevel | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv12HdfsLogLevel(context.Background()).V12HdfsLogLevel(v12HdfsLogLevel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv12HdfsLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv12HdfsLogLevelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12HdfsLogLevel** | [**V12HdfsLogLevel**](V12HdfsLogLevel.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv12HdfsSettings

> UpdateProtocolsv12HdfsSettings(ctx).V12HdfsSettings(v12HdfsSettings).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12HdfsSettings := *openapiclient.NewV12HdfsSettingsSettings() // V12HdfsSettingsSettings | 
    zone := "zone_example" // string | Access zone which contains HDFS settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv12HdfsSettings(context.Background()).V12HdfsSettings(v12HdfsSettings).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv12HdfsSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv12HdfsSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12HdfsSettings** | [**V12HdfsSettingsSettings**](V12HdfsSettingsSettings.md) |  | 
 **zone** | **string** | Access zone which contains HDFS settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv12NfsLogLevel

> UpdateProtocolsv12NfsLogLevel(ctx).V12NfsLogLevel(v12NfsLogLevel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12NfsLogLevel := *openapiclient.NewV12NfsLogLevel() // V12NfsLogLevel | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv12NfsLogLevel(context.Background()).V12NfsLogLevel(v12NfsLogLevel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv12NfsLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv12NfsLogLevelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12NfsLogLevel** | [**V12NfsLogLevel**](V12NfsLogLevel.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv12NfsSettingsGlobal

> UpdateProtocolsv12NfsSettingsGlobal(ctx).V12NfsSettingsGlobal(v12NfsSettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12NfsSettingsGlobal := *openapiclient.NewV12NfsSettingsGlobalSettings() // V12NfsSettingsGlobalSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv12NfsSettingsGlobal(context.Background()).V12NfsSettingsGlobal(v12NfsSettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv12NfsSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv12NfsSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12NfsSettingsGlobal** | [**V12NfsSettingsGlobalSettings**](V12NfsSettingsGlobalSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv12S3Bucket

> UpdateProtocolsv12S3Bucket(ctx, v12S3BucketId).V12S3Bucket(v12S3Bucket).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12S3BucketId := "v12S3BucketId_example" // string | Modify bucket. All input fields are optional, but one or more must be supplied.
    v12S3Bucket := *openapiclient.NewV10S3BucketExtendedExtended() // V10S3BucketExtendedExtended | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv12S3Bucket(context.Background(), v12S3BucketId).V12S3Bucket(v12S3Bucket).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv12S3Bucket``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12S3BucketId** | **string** | Modify bucket. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv12S3BucketRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12S3Bucket** | [**V10S3BucketExtendedExtended**](V10S3BucketExtendedExtended.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv12S3SettingsZone

> UpdateProtocolsv12S3SettingsZone(ctx).V12S3SettingsZone(v12S3SettingsZone).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12S3SettingsZone := *openapiclient.NewV12S3SettingsZoneSettings() // V12S3SettingsZoneSettings | 
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv12S3SettingsZone(context.Background()).V12S3SettingsZone(v12S3SettingsZone).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv12S3SettingsZone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv12S3SettingsZoneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12S3SettingsZone** | [**V12S3SettingsZoneSettings**](V12S3SettingsZoneSettings.md) |  | 
 **zone** | **string** | Access zone | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv12SmbLogLevel

> UpdateProtocolsv12SmbLogLevel(ctx).V12SmbLogLevel(v12SmbLogLevel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SmbLogLevel := *openapiclient.NewV12SmbLogLevel() // V12SmbLogLevel | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv12SmbLogLevel(context.Background()).V12SmbLogLevel(v12SmbLogLevel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv12SmbLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv12SmbLogLevelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12SmbLogLevel** | [**V12SmbLogLevel**](V12SmbLogLevel.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv12SmbShare

> UpdateProtocolsv12SmbShare(ctx, v12SmbShareId).V12SmbShare(v12SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SmbShareId := "v12SmbShareId_example" // string | Modify share. All input fields are optional, but one or more must be supplied.
    v12SmbShare := *openapiclient.NewV12SmbShareExtendedExtended() // V12SmbShareExtendedExtended | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv12SmbShare(context.Background(), v12SmbShareId).V12SmbShare(v12SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv12SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12SmbShareId** | **string** | Modify share. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv12SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12SmbShare** | [**V12SmbShareExtendedExtended**](V12SmbShareExtendedExtended.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv14NfsSettingsGlobal

> UpdateProtocolsv14NfsSettingsGlobal(ctx).V14NfsSettingsGlobal(v14NfsSettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14NfsSettingsGlobal := *openapiclient.NewV14NfsSettingsGlobalSettings() // V14NfsSettingsGlobalSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv14NfsSettingsGlobal(context.Background()).V14NfsSettingsGlobal(v14NfsSettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv14NfsSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv14NfsSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14NfsSettingsGlobal** | [**V14NfsSettingsGlobalSettings**](V14NfsSettingsGlobalSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv15HttpService

> UpdateProtocolsv15HttpService(ctx, v15HttpServiceId).V15HttpService(v15HttpService).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15HttpServiceId := "v15HttpServiceId_example" // string | Modify HTTP services.
    v15HttpService := *openapiclient.NewV15HttpServiceExtended() // V15HttpServiceExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv15HttpService(context.Background(), v15HttpServiceId).V15HttpService(v15HttpService).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv15HttpService``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15HttpServiceId** | **string** | Modify HTTP services. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv15HttpServiceRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v15HttpService** | [**V15HttpServiceExtended**](V15HttpServiceExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv1HdfsProxyuser

> UpdateProtocolsv1HdfsProxyuser(ctx, v1HdfsProxyuserId).V1HdfsProxyuser(v1HdfsProxyuser).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1HdfsProxyuserId := "v1HdfsProxyuserId_example" // string | Modify an HDFS proxyuser.
    v1HdfsProxyuser := map[string]interface{}{ ... } // map[string]interface{} | 
    zone := "zone_example" // string | Access zone which contains HDFS proxyuser. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv1HdfsProxyuser(context.Background(), v1HdfsProxyuserId).V1HdfsProxyuser(v1HdfsProxyuser).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv1HdfsProxyuser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1HdfsProxyuserId** | **string** | Modify an HDFS proxyuser. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv1HdfsProxyuserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1HdfsProxyuser** | **map[string]interface{}** |  | 
 **zone** | **string** | Access zone which contains HDFS proxyuser. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv1HdfsProxyusersNameMember

> UpdateProtocolsv1HdfsProxyusersNameMember(ctx, v1HdfsProxyusersNameMemberId, name).V1HdfsProxyusersNameMember(v1HdfsProxyusersNameMember).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1HdfsProxyusersNameMemberId := "v1HdfsProxyusersNameMemberId_example" // string | Create a new HDFS proxyuser.
    name := "name_example" // string | 
    v1HdfsProxyusersNameMember := map[string]interface{}{ ... } // map[string]interface{} | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv1HdfsProxyusersNameMember(context.Background(), v1HdfsProxyusersNameMemberId, name).V1HdfsProxyusersNameMember(v1HdfsProxyusersNameMember).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv1HdfsProxyusersNameMember``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1HdfsProxyusersNameMemberId** | **string** | Create a new HDFS proxyuser. | 
**name** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv1HdfsProxyusersNameMemberRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v1HdfsProxyusersNameMember** | **map[string]interface{}** |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv1HdfsRack

> UpdateProtocolsv1HdfsRack(ctx, v1HdfsRackId).V1HdfsRack(v1HdfsRack).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1HdfsRackId := "v1HdfsRackId_example" // string | Modify the HDFS rack
    v1HdfsRack := *openapiclient.NewV1HdfsRackExtendedExtended() // V1HdfsRackExtendedExtended | 
    zone := "zone_example" // string | Access zone which contains HDFS rack. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv1HdfsRack(context.Background(), v1HdfsRackId).V1HdfsRack(v1HdfsRack).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv1HdfsRack``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1HdfsRackId** | **string** | Modify the HDFS rack | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv1HdfsRackRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1HdfsRack** | [**V1HdfsRackExtendedExtended**](V1HdfsRackExtendedExtended.md) |  | 
 **zone** | **string** | Access zone which contains HDFS rack. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv1NfsExport

> UpdateProtocolsv1NfsExport(ctx, v1NfsExportId).V1NfsExport(v1NfsExport).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1NfsExportId := "v1NfsExportId_example" // string | Modify the export. All input fields are optional, but one or more must be supplied.
    v1NfsExport := *openapiclient.NewV1NfsExportExtendedExtended() // V1NfsExportExtendedExtended | 
    force := true // bool | If true, the export will be updated even if that change conflicts with another export. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv1NfsExport(context.Background(), v1NfsExportId).V1NfsExport(v1NfsExport).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv1NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1NfsExportId** | **string** | Modify the export. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv1NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1NfsExport** | [**V1NfsExportExtendedExtended**](V1NfsExportExtendedExtended.md) |  | 
 **force** | **bool** | If true, the export will be updated even if that change conflicts with another export. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv1NfsSettingsExport

> UpdateProtocolsv1NfsSettingsExport(ctx).V1NfsSettingsExport(v1NfsSettingsExport).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1NfsSettingsExport := *openapiclient.NewV1NfsSettingsExportSettings() // V1NfsSettingsExportSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv1NfsSettingsExport(context.Background()).V1NfsSettingsExport(v1NfsSettingsExport).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv1NfsSettingsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv1NfsSettingsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1NfsSettingsExport** | [**V1NfsSettingsExportSettings**](V1NfsSettingsExportSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv1SmbSettingsGlobal

> UpdateProtocolsv1SmbSettingsGlobal(ctx).V1SmbSettingsGlobal(v1SmbSettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SmbSettingsGlobal := *openapiclient.NewV1SmbSettingsGlobalSettings() // V1SmbSettingsGlobalSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv1SmbSettingsGlobal(context.Background()).V1SmbSettingsGlobal(v1SmbSettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv1SmbSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv1SmbSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SmbSettingsGlobal** | [**V1SmbSettingsGlobalSettings**](V1SmbSettingsGlobalSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv1SmbSettingsShare

> UpdateProtocolsv1SmbSettingsShare(ctx).V1SmbSettingsShare(v1SmbSettingsShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SmbSettingsShare := *openapiclient.NewV1SmbSettingsShareSettings() // V1SmbSettingsShareSettings | 
    zone := "zone_example" // string | Zone which contains these share settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv1SmbSettingsShare(context.Background()).V1SmbSettingsShare(v1SmbSettingsShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv1SmbSettingsShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv1SmbSettingsShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SmbSettingsShare** | [**V1SmbSettingsShareSettings**](V1SmbSettingsShareSettings.md) |  | 
 **zone** | **string** | Zone which contains these share settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv1SmbShare

> UpdateProtocolsv1SmbShare(ctx, v1SmbShareId).V1SmbShare(v1SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SmbShareId := "v1SmbShareId_example" // string | Modify share. All input fields are optional, but one or more must be supplied.
    v1SmbShare := *openapiclient.NewV1SmbShareExtendedExtended() // V1SmbShareExtendedExtended | 
    zone := "zone_example" // string | Zone which contains this share. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv1SmbShare(context.Background(), v1SmbShareId).V1SmbShare(v1SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv1SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SmbShareId** | **string** | Modify share. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv1SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SmbShare** | [**V1SmbShareExtendedExtended**](V1SmbShareExtendedExtended.md) |  | 
 **zone** | **string** | Zone which contains this share. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv2NfsAlias

> UpdateProtocolsv2NfsAlias(ctx, v2NfsAliasId).V2NfsAlias(v2NfsAlias).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsAliasId := "v2NfsAliasId_example" // string | Modify the alias. All input fields are optional, but one or more must be supplied.
    v2NfsAlias := *openapiclient.NewV2NfsAliasExtended() // V2NfsAliasExtended | 
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv2NfsAlias(context.Background(), v2NfsAliasId).V2NfsAlias(v2NfsAlias).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv2NfsAlias``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v2NfsAliasId** | **string** | Modify the alias. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv2NfsAliasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v2NfsAlias** | [**V2NfsAliasExtended**](V2NfsAliasExtended.md) |  | 
 **zone** | **string** | Access zone | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv2NfsExport

> UpdateProtocolsv2NfsExport(ctx, v2NfsExportId).V2NfsExport(v2NfsExport).Force(force).IgnoreUnresolvableHosts(ignoreUnresolvableHosts).Zone(zone).IgnoreConflicts(ignoreConflicts).IgnoreBadPaths(ignoreBadPaths).IgnoreBadAuth(ignoreBadAuth).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsExportId := "v2NfsExportId_example" // string | Modify the export. All input fields are optional, but one or more must be supplied.
    v2NfsExport := *openapiclient.NewV2NfsExportExtendedExtended() // V2NfsExportExtendedExtended | 
    force := true // bool | If true, the export will be updated even if that change conflicts with another export. (optional)
    ignoreUnresolvableHosts := true // bool | Ignore unresolvable hosts. (optional)
    zone := "zone_example" // string | Access zone (optional)
    ignoreConflicts := true // bool | Ignore conflicts with existing exports. (optional)
    ignoreBadPaths := true // bool | Ignore nonexistent or otherwise bad paths. (optional)
    ignoreBadAuth := true // bool | Ignore invalid users. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv2NfsExport(context.Background(), v2NfsExportId).V2NfsExport(v2NfsExport).Force(force).IgnoreUnresolvableHosts(ignoreUnresolvableHosts).Zone(zone).IgnoreConflicts(ignoreConflicts).IgnoreBadPaths(ignoreBadPaths).IgnoreBadAuth(ignoreBadAuth).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv2NfsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v2NfsExportId** | **string** | Modify the export. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv2NfsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v2NfsExport** | [**V2NfsExportExtendedExtended**](V2NfsExportExtendedExtended.md) |  | 
 **force** | **bool** | If true, the export will be updated even if that change conflicts with another export. | 
 **ignoreUnresolvableHosts** | **bool** | Ignore unresolvable hosts. | 
 **zone** | **string** | Access zone | 
 **ignoreConflicts** | **bool** | Ignore conflicts with existing exports. | 
 **ignoreBadPaths** | **bool** | Ignore nonexistent or otherwise bad paths. | 
 **ignoreBadAuth** | **bool** | Ignore invalid users. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv2NfsSettingsExport

> UpdateProtocolsv2NfsSettingsExport(ctx).V2NfsSettingsExport(v2NfsSettingsExport).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsSettingsExport := *openapiclient.NewV2NfsSettingsExportSettings() // V2NfsSettingsExportSettings | 
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv2NfsSettingsExport(context.Background()).V2NfsSettingsExport(v2NfsSettingsExport).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv2NfsSettingsExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv2NfsSettingsExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v2NfsSettingsExport** | [**V2NfsSettingsExportSettings**](V2NfsSettingsExportSettings.md) |  | 
 **zone** | **string** | Access zone | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv2NfsSettingsZone

> UpdateProtocolsv2NfsSettingsZone(ctx).V2NfsSettingsZone(v2NfsSettingsZone).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v2NfsSettingsZone := *openapiclient.NewV2NfsSettingsZoneSettings() // V2NfsSettingsZoneSettings | 
    zone := "zone_example" // string | Access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv2NfsSettingsZone(context.Background()).V2NfsSettingsZone(v2NfsSettingsZone).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv2NfsSettingsZone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv2NfsSettingsZoneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v2NfsSettingsZone** | [**V2NfsSettingsZoneSettings**](V2NfsSettingsZoneSettings.md) |  | 
 **zone** | **string** | Access zone | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3FtpSettings

> UpdateProtocolsv3FtpSettings(ctx).V3FtpSettings(v3FtpSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3FtpSettings := *openapiclient.NewV3FtpSettingsSettings() // V3FtpSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3FtpSettings(context.Background()).V3FtpSettings(v3FtpSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3FtpSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3FtpSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3FtpSettings** | [**V3FtpSettingsSettings**](V3FtpSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3HdfsLogLevel

> UpdateProtocolsv3HdfsLogLevel(ctx).V3HdfsLogLevel(v3HdfsLogLevel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HdfsLogLevel := *openapiclient.NewV3HdfsLogLevel() // V3HdfsLogLevel | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3HdfsLogLevel(context.Background()).V3HdfsLogLevel(v3HdfsLogLevel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3HdfsLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3HdfsLogLevelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3HdfsLogLevel** | [**V3HdfsLogLevel**](V3HdfsLogLevel.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3HttpSettings

> UpdateProtocolsv3HttpSettings(ctx).V3HttpSettings(v3HttpSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HttpSettings := *openapiclient.NewV3HttpSettingsSettings() // V3HttpSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3HttpSettings(context.Background()).V3HttpSettings(v3HttpSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3HttpSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3HttpSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3HttpSettings** | [**V3HttpSettingsSettings**](V3HttpSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3NdmpDiagnostics

> UpdateProtocolsv3NdmpDiagnostics(ctx).V3NdmpDiagnostics(v3NdmpDiagnostics).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpDiagnostics := *openapiclient.NewV3NdmpDiagnosticsDiagnostics() // V3NdmpDiagnosticsDiagnostics | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3NdmpDiagnostics(context.Background()).V3NdmpDiagnostics(v3NdmpDiagnostics).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3NdmpDiagnostics``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3NdmpDiagnosticsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NdmpDiagnostics** | [**V3NdmpDiagnosticsDiagnostics**](V3NdmpDiagnosticsDiagnostics.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3NdmpSettingsGlobal

> UpdateProtocolsv3NdmpSettingsGlobal(ctx).V3NdmpSettingsGlobal(v3NdmpSettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpSettingsGlobal := *openapiclient.NewV3NdmpSettingsGlobalGlobal() // V3NdmpSettingsGlobalGlobal | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3NdmpSettingsGlobal(context.Background()).V3NdmpSettingsGlobal(v3NdmpSettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3NdmpSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3NdmpSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NdmpSettingsGlobal** | [**V3NdmpSettingsGlobalGlobal**](V3NdmpSettingsGlobalGlobal.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3NdmpSettingsVariable

> UpdateProtocolsv3NdmpSettingsVariable(ctx, v3NdmpSettingsVariableId).V3NdmpSettingsVariable(v3NdmpSettingsVariable).Name(name).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpSettingsVariableId := "v3NdmpSettingsVariableId_example" // string | Modify or create a NDMP preferred environment variable.
    v3NdmpSettingsVariable := *openapiclient.NewV3NdmpSettingsVariable("Value_example") // V3NdmpSettingsVariable | 
    name := "name_example" // string | Name of the variable to modify. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3NdmpSettingsVariable(context.Background(), v3NdmpSettingsVariableId).V3NdmpSettingsVariable(v3NdmpSettingsVariable).Name(name).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3NdmpSettingsVariable``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpSettingsVariableId** | **string** | Modify or create a NDMP preferred environment variable. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3NdmpSettingsVariableRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3NdmpSettingsVariable** | [**V3NdmpSettingsVariable**](V3NdmpSettingsVariable.md) |  | 
 **name** | **string** | Name of the variable to modify. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3NdmpUser

> UpdateProtocolsv3NdmpUser(ctx, v3NdmpUserId).V3NdmpUser(v3NdmpUser).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NdmpUserId := "v3NdmpUserId_example" // string | Modify the user
    v3NdmpUser := *openapiclient.NewV3NdmpUserExtendedExtended("Password_example") // V3NdmpUserExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3NdmpUser(context.Background(), v3NdmpUserId).V3NdmpUser(v3NdmpUser).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3NdmpUser``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NdmpUserId** | **string** | Modify the user | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3NdmpUserRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3NdmpUser** | [**V3NdmpUserExtendedExtended**](V3NdmpUserExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3NfsLogLevel

> UpdateProtocolsv3NfsLogLevel(ctx).V3NfsLogLevel(v3NfsLogLevel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NfsLogLevel := *openapiclient.NewV3NfsLogLevel() // V3NfsLogLevel | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3NfsLogLevel(context.Background()).V3NfsLogLevel(v3NfsLogLevel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3NfsLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3NfsLogLevelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NfsLogLevel** | [**V3NfsLogLevel**](V3NfsLogLevel.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3NfsNetgroup

> UpdateProtocolsv3NfsNetgroup(ctx).V3NfsNetgroup(v3NfsNetgroup).Host(host).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NfsNetgroup := *openapiclient.NewV3NfsNetgroup() // V3NfsNetgroup | 
    host := "host_example" // string | Host to retrieve netgroup cache settings for. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3NfsNetgroup(context.Background()).V3NfsNetgroup(v3NfsNetgroup).Host(host).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3NfsNetgroup``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3NfsNetgroupRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NfsNetgroup** | [**V3NfsNetgroup**](V3NfsNetgroup.md) |  | 
 **host** | **string** | Host to retrieve netgroup cache settings for. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3NfsSettingsGlobal

> UpdateProtocolsv3NfsSettingsGlobal(ctx).V3NfsSettingsGlobal(v3NfsSettingsGlobal).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NfsSettingsGlobal := *openapiclient.NewV3NfsSettingsGlobalSettings() // V3NfsSettingsGlobalSettings | 
    scope := "scope_example" // string | When specified as 'effective', or not specified, all fields are returned. When specified as 'user', only fields with non-default values are shown. When specified as 'default', the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3NfsSettingsGlobal(context.Background()).V3NfsSettingsGlobal(v3NfsSettingsGlobal).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3NfsSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3NfsSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NfsSettingsGlobal** | [**V3NfsSettingsGlobalSettings**](V3NfsSettingsGlobalSettings.md) |  | 
 **scope** | **string** | When specified as &#39;effective&#39;, or not specified, all fields are returned. When specified as &#39;user&#39;, only fields with non-default values are shown. When specified as &#39;default&#39;, the original values are returned. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3NtpServer

> UpdateProtocolsv3NtpServer(ctx, v3NtpServerId).V3NtpServer(v3NtpServer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NtpServerId := "v3NtpServerId_example" // string | Modify the key value for an NTP server.
    v3NtpServer := *openapiclient.NewV3NtpServerExtendedExtended("Key_example") // V3NtpServerExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3NtpServer(context.Background(), v3NtpServerId).V3NtpServer(v3NtpServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3NtpServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3NtpServerId** | **string** | Modify the key value for an NTP server. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3NtpServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3NtpServer** | [**V3NtpServerExtendedExtended**](V3NtpServerExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3NtpSettings

> UpdateProtocolsv3NtpSettings(ctx).V3NtpSettings(v3NtpSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3NtpSettings := *openapiclient.NewV3NtpSettingsSettings() // V3NtpSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3NtpSettings(context.Background()).V3NtpSettings(v3NtpSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3NtpSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3NtpSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3NtpSettings** | [**V3NtpSettingsSettings**](V3NtpSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3SmbLogLevel

> UpdateProtocolsv3SmbLogLevel(ctx).V3SmbLogLevel(v3SmbLogLevel).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SmbLogLevel := *openapiclient.NewV3SmbLogLevel() // V3SmbLogLevel | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3SmbLogLevel(context.Background()).V3SmbLogLevel(v3SmbLogLevel).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3SmbLogLevel``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3SmbLogLevelRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SmbLogLevel** | [**V3SmbLogLevel**](V3SmbLogLevel.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3SmbSettingsGlobal

> UpdateProtocolsv3SmbSettingsGlobal(ctx).V3SmbSettingsGlobal(v3SmbSettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SmbSettingsGlobal := *openapiclient.NewV3SmbSettingsGlobalSettings() // V3SmbSettingsGlobalSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3SmbSettingsGlobal(context.Background()).V3SmbSettingsGlobal(v3SmbSettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3SmbSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3SmbSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SmbSettingsGlobal** | [**V3SmbSettingsGlobalSettings**](V3SmbSettingsGlobalSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3SmbSettingsShare

> UpdateProtocolsv3SmbSettingsShare(ctx).V3SmbSettingsShare(v3SmbSettingsShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SmbSettingsShare := *openapiclient.NewV3SmbSettingsShareSettings() // V3SmbSettingsShareSettings | 
    zone := "zone_example" // string | Zone which contains these share settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3SmbSettingsShare(context.Background()).V3SmbSettingsShare(v3SmbSettingsShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3SmbSettingsShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3SmbSettingsShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SmbSettingsShare** | [**V3SmbSettingsShareSettings**](V3SmbSettingsShareSettings.md) |  | 
 **zone** | **string** | Zone which contains these share settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3SmbShare

> UpdateProtocolsv3SmbShare(ctx, v3SmbShareId).V3SmbShare(v3SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SmbShareId := "v3SmbShareId_example" // string | Modify share. All input fields are optional, but one or more must be supplied.
    v3SmbShare := *openapiclient.NewV3SmbShareExtendedExtended() // V3SmbShareExtendedExtended | 
    zone := "zone_example" // string | Zone which contains this share. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3SmbShare(context.Background(), v3SmbShareId).V3SmbShare(v3SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SmbShareId** | **string** | Modify share. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3SmbShare** | [**V3SmbShareExtendedExtended**](V3SmbShareExtendedExtended.md) |  | 
 **zone** | **string** | Zone which contains this share. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3SnmpSettings

> UpdateProtocolsv3SnmpSettings(ctx).V3SnmpSettings(v3SnmpSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SnmpSettings := *openapiclient.NewV3SnmpSettingsExtended() // V3SnmpSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3SnmpSettings(context.Background()).V3SnmpSettings(v3SnmpSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3SnmpSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3SnmpSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SnmpSettings** | [**V3SnmpSettingsExtended**](V3SnmpSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv3SwiftAccount

> UpdateProtocolsv3SwiftAccount(ctx, v3SwiftAccountId).V3SwiftAccount(v3SwiftAccount).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SwiftAccountId := "v3SwiftAccountId_example" // string | Modify a Swift account
    v3SwiftAccount := *openapiclient.NewV3SwiftAccount("Name_example") // V3SwiftAccount | 
    zone := "zone_example" // string | Access zone which contains Swift account. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv3SwiftAccount(context.Background(), v3SwiftAccountId).V3SwiftAccount(v3SwiftAccount).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv3SwiftAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3SwiftAccountId** | **string** | Modify a Swift account | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv3SwiftAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3SwiftAccount** | [**V3SwiftAccount**](V3SwiftAccount.md) |  | 
 **zone** | **string** | Access zone which contains Swift account. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv4HdfsRangerPluginSettings

> UpdateProtocolsv4HdfsRangerPluginSettings(ctx).V4HdfsRangerPluginSettings(v4HdfsRangerPluginSettings).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4HdfsRangerPluginSettings := *openapiclient.NewV4HdfsRangerPluginSettingsSettings() // V4HdfsRangerPluginSettingsSettings | 
    zone := "zone_example" // string | Access zone which contains HDFS ranger-plugin settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv4HdfsRangerPluginSettings(context.Background()).V4HdfsRangerPluginSettings(v4HdfsRangerPluginSettings).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv4HdfsRangerPluginSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv4HdfsRangerPluginSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4HdfsRangerPluginSettings** | [**V4HdfsRangerPluginSettingsSettings**](V4HdfsRangerPluginSettingsSettings.md) |  | 
 **zone** | **string** | Access zone which contains HDFS ranger-plugin settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv4NdmpSettingsPreferredIp

> UpdateProtocolsv4NdmpSettingsPreferredIp(ctx, v4NdmpSettingsPreferredIpId).V4NdmpSettingsPreferredIp(v4NdmpSettingsPreferredIp).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4NdmpSettingsPreferredIpId := "v4NdmpSettingsPreferredIpId_example" // string | Modify a preferred ip preference.
    v4NdmpSettingsPreferredIp := *openapiclient.NewV4NdmpSettingsPreferredIpExtended([]openapiclient.V4NdmpSettingsPreferredIpDataSubnet{*openapiclient.NewV4NdmpSettingsPreferredIpDataSubnet()}) // V4NdmpSettingsPreferredIpExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv4NdmpSettingsPreferredIp(context.Background(), v4NdmpSettingsPreferredIpId).V4NdmpSettingsPreferredIp(v4NdmpSettingsPreferredIp).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv4NdmpSettingsPreferredIp``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4NdmpSettingsPreferredIpId** | **string** | Modify a preferred ip preference. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv4NdmpSettingsPreferredIpRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v4NdmpSettingsPreferredIp** | [**V4NdmpSettingsPreferredIpExtended**](V4NdmpSettingsPreferredIpExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv5HdfsFsimageJobSettings

> UpdateProtocolsv5HdfsFsimageJobSettings(ctx).V5HdfsFsimageJobSettings(v5HdfsFsimageJobSettings).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5HdfsFsimageJobSettings := *openapiclient.NewV5HdfsFsimageJobSettingsSettings() // V5HdfsFsimageJobSettingsSettings | 
    zone := "zone_example" // string | Access zone which contains job settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv5HdfsFsimageJobSettings(context.Background()).V5HdfsFsimageJobSettings(v5HdfsFsimageJobSettings).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv5HdfsFsimageJobSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv5HdfsFsimageJobSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v5HdfsFsimageJobSettings** | [**V5HdfsFsimageJobSettingsSettings**](V5HdfsFsimageJobSettingsSettings.md) |  | 
 **zone** | **string** | Access zone which contains job settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv5HdfsFsimageSettings

> UpdateProtocolsv5HdfsFsimageSettings(ctx).V5HdfsFsimageSettings(v5HdfsFsimageSettings).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5HdfsFsimageSettings := *openapiclient.NewV5HdfsFsimageSettingsSettings() // V5HdfsFsimageSettingsSettings | 
    zone := "zone_example" // string | Access zone which contains FSImage settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv5HdfsFsimageSettings(context.Background()).V5HdfsFsimageSettings(v5HdfsFsimageSettings).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv5HdfsFsimageSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv5HdfsFsimageSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v5HdfsFsimageSettings** | [**V5HdfsFsimageSettingsSettings**](V5HdfsFsimageSettingsSettings.md) |  | 
 **zone** | **string** | Access zone which contains FSImage settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv5HdfsInotifySettings

> UpdateProtocolsv5HdfsInotifySettings(ctx).V5HdfsInotifySettings(v5HdfsInotifySettings).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5HdfsInotifySettings := *openapiclient.NewV5HdfsInotifySettingsSettings() // V5HdfsInotifySettingsSettings | 
    zone := "zone_example" // string | Access zone which contains INotify settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv5HdfsInotifySettings(context.Background()).V5HdfsInotifySettings(v5HdfsInotifySettings).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv5HdfsInotifySettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv5HdfsInotifySettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v5HdfsInotifySettings** | [**V5HdfsInotifySettingsSettings**](V5HdfsInotifySettingsSettings.md) |  | 
 **zone** | **string** | Access zone which contains INotify settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv5SnmpSettings

> UpdateProtocolsv5SnmpSettings(ctx).V5SnmpSettings(v5SnmpSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5SnmpSettings := *openapiclient.NewV5SnmpSettingsExtended() // V5SnmpSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv5SnmpSettings(context.Background()).V5SnmpSettings(v5SnmpSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv5SnmpSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv5SnmpSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v5SnmpSettings** | [**V5SnmpSettingsExtended**](V5SnmpSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv6SmbSettingsGlobal

> UpdateProtocolsv6SmbSettingsGlobal(ctx).V6SmbSettingsGlobal(v6SmbSettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v6SmbSettingsGlobal := *openapiclient.NewV6SmbSettingsGlobalSettings() // V6SmbSettingsGlobalSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv6SmbSettingsGlobal(context.Background()).V6SmbSettingsGlobal(v6SmbSettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv6SmbSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv6SmbSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v6SmbSettingsGlobal** | [**V6SmbSettingsGlobalSettings**](V6SmbSettingsGlobalSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv6SmbSettingsShare

> UpdateProtocolsv6SmbSettingsShare(ctx).V6SmbSettingsShare(v6SmbSettingsShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v6SmbSettingsShare := *openapiclient.NewV6SmbSettingsShareSettings() // V6SmbSettingsShareSettings | 
    zone := "zone_example" // string | Zone which contains these share settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv6SmbSettingsShare(context.Background()).V6SmbSettingsShare(v6SmbSettingsShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv6SmbSettingsShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv6SmbSettingsShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v6SmbSettingsShare** | [**V6SmbSettingsShareSettings**](V6SmbSettingsShareSettings.md) |  | 
 **zone** | **string** | Zone which contains these share settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv6SmbSettingsZone

> UpdateProtocolsv6SmbSettingsZone(ctx).V6SmbSettingsZone(v6SmbSettingsZone).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v6SmbSettingsZone := *openapiclient.NewV6SmbSettingsZoneSettings() // V6SmbSettingsZoneSettings | 
    zone := "zone_example" // string | Name of the access zone (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv6SmbSettingsZone(context.Background()).V6SmbSettingsZone(v6SmbSettingsZone).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv6SmbSettingsZone``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv6SmbSettingsZoneRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v6SmbSettingsZone** | [**V6SmbSettingsZoneSettings**](V6SmbSettingsZoneSettings.md) |  | 
 **zone** | **string** | Name of the access zone | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv6SmbShare

> UpdateProtocolsv6SmbShare(ctx, v6SmbShareId).V6SmbShare(v6SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v6SmbShareId := "v6SmbShareId_example" // string | Modify share. All input fields are optional, but one or more must be supplied.
    v6SmbShare := *openapiclient.NewV6SmbShareExtendedExtended() // V6SmbShareExtendedExtended | 
    zone := "zone_example" // string | Zone which contains this share. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv6SmbShare(context.Background(), v6SmbShareId).V6SmbShare(v6SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv6SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v6SmbShareId** | **string** | Modify share. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv6SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v6SmbShare** | [**V6SmbShareExtendedExtended**](V6SmbShareExtendedExtended.md) |  | 
 **zone** | **string** | Zone which contains this share. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv7HdfsCryptoSettings

> UpdateProtocolsv7HdfsCryptoSettings(ctx).V7HdfsCryptoSettings(v7HdfsCryptoSettings).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7HdfsCryptoSettings := *openapiclient.NewV7HdfsCryptoSettingsSettings() // V7HdfsCryptoSettingsSettings | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv7HdfsCryptoSettings(context.Background()).V7HdfsCryptoSettings(v7HdfsCryptoSettings).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv7HdfsCryptoSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv7HdfsCryptoSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7HdfsCryptoSettings** | [**V7HdfsCryptoSettingsSettings**](V7HdfsCryptoSettingsSettings.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv7NfsSettingsGlobal

> UpdateProtocolsv7NfsSettingsGlobal(ctx).V7NfsSettingsGlobal(v7NfsSettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7NfsSettingsGlobal := *openapiclient.NewV7NfsSettingsGlobalSettings() // V7NfsSettingsGlobalSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv7NfsSettingsGlobal(context.Background()).V7NfsSettingsGlobal(v7NfsSettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv7NfsSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv7NfsSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7NfsSettingsGlobal** | [**V7NfsSettingsGlobalSettings**](V7NfsSettingsGlobalSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv7SmbSettingsGlobal

> UpdateProtocolsv7SmbSettingsGlobal(ctx).V7SmbSettingsGlobal(v7SmbSettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SmbSettingsGlobal := *openapiclient.NewV6SmbSettingsGlobalSettings() // V6SmbSettingsGlobalSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv7SmbSettingsGlobal(context.Background()).V7SmbSettingsGlobal(v7SmbSettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv7SmbSettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv7SmbSettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SmbSettingsGlobal** | [**V6SmbSettingsGlobalSettings**](V6SmbSettingsGlobalSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv7SmbSettingsShare

> UpdateProtocolsv7SmbSettingsShare(ctx).V7SmbSettingsShare(v7SmbSettingsShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SmbSettingsShare := *openapiclient.NewV7SmbSettingsShareSettings() // V7SmbSettingsShareSettings | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv7SmbSettingsShare(context.Background()).V7SmbSettingsShare(v7SmbSettingsShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv7SmbSettingsShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv7SmbSettingsShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SmbSettingsShare** | [**V7SmbSettingsShareSettings**](V7SmbSettingsShareSettings.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv7SmbShare

> UpdateProtocolsv7SmbShare(ctx, v7SmbShareId).V7SmbShare(v7SmbShare).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SmbShareId := "v7SmbShareId_example" // string | Modify share. All input fields are optional, but one or more must be supplied.
    v7SmbShare := *openapiclient.NewV7SmbShareExtendedExtended() // V7SmbShareExtendedExtended | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv7SmbShare(context.Background(), v7SmbShareId).V7SmbShare(v7SmbShare).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv7SmbShare``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SmbShareId** | **string** | Modify share. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv7SmbShareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7SmbShare** | [**V7SmbShareExtendedExtended**](V7SmbShareExtendedExtended.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv7SshSettings

> UpdateProtocolsv7SshSettings(ctx).V7SshSettings(v7SshSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SshSettings := *openapiclient.NewV7SshSettingsExtended() // V7SshSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv7SshSettings(context.Background()).V7SshSettings(v7SshSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv7SshSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv7SshSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SshSettings** | [**V7SshSettingsExtended**](V7SshSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv8SshSettings

> UpdateProtocolsv8SshSettings(ctx).V8SshSettings(v8SshSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v8SshSettings := *openapiclient.NewV8SshSettingsExtended() // V8SshSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv8SshSettings(context.Background()).V8SshSettings(v8SshSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv8SshSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv8SshSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v8SshSettings** | [**V8SshSettingsExtended**](V8SshSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateProtocolsv9HdfsSettings

> UpdateProtocolsv9HdfsSettings(ctx).V9HdfsSettings(v9HdfsSettings).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9HdfsSettings := *openapiclient.NewV9HdfsSettingsSettings() // V9HdfsSettingsSettings | 
    zone := "zone_example" // string | Access zone which contains HDFS settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ProtocolsApi.UpdateProtocolsv9HdfsSettings(context.Background()).V9HdfsSettings(v9HdfsSettings).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ProtocolsApi.UpdateProtocolsv9HdfsSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateProtocolsv9HdfsSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v9HdfsSettings** | [**V9HdfsSettingsSettings**](V9HdfsSettingsSettings.md) |  | 
 **zone** | **string** | Access zone which contains HDFS settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

