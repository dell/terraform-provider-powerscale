# V14AuthPrivileges

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Privileges** | Pointer to [**[]V14AuthPrivilege**](V14AuthPrivilege.md) |  | [optional] 

## Methods

### NewV14AuthPrivileges

`func NewV14AuthPrivileges() *V14AuthPrivileges`

NewV14AuthPrivileges instantiates a new V14AuthPrivileges object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14AuthPrivilegesWithDefaults

`func NewV14AuthPrivilegesWithDefaults() *V14AuthPrivileges`

NewV14AuthPrivilegesWithDefaults instantiates a new V14AuthPrivileges object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPrivileges

`func (o *V14AuthPrivileges) GetPrivileges() []V14AuthPrivilege`

GetPrivileges returns the Privileges field if non-nil, zero value otherwise.

### GetPrivilegesOk

`func (o *V14AuthPrivileges) GetPrivilegesOk() (*[]V14AuthPrivilege, bool)`

GetPrivilegesOk returns a tuple with the Privileges field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrivileges

`func (o *V14AuthPrivileges) SetPrivileges(v []V14AuthPrivilege)`

SetPrivileges sets Privileges field to given value.

### HasPrivileges

`func (o *V14AuthPrivileges) HasPrivileges() bool`

HasPrivileges returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


