# Createv12SedMigrateItemResponseSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MigrationMsg** | **string** | Non-error message reported to user about the migration process. | 

## Methods

### NewCreatev12SedMigrateItemResponseSettings

`func NewCreatev12SedMigrateItemResponseSettings(migrationMsg string, ) *Createv12SedMigrateItemResponseSettings`

NewCreatev12SedMigrateItemResponseSettings instantiates a new Createv12SedMigrateItemResponseSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev12SedMigrateItemResponseSettingsWithDefaults

`func NewCreatev12SedMigrateItemResponseSettingsWithDefaults() *Createv12SedMigrateItemResponseSettings`

NewCreatev12SedMigrateItemResponseSettingsWithDefaults instantiates a new Createv12SedMigrateItemResponseSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMigrationMsg

`func (o *Createv12SedMigrateItemResponseSettings) GetMigrationMsg() string`

GetMigrationMsg returns the MigrationMsg field if non-nil, zero value otherwise.

### GetMigrationMsgOk

`func (o *Createv12SedMigrateItemResponseSettings) GetMigrationMsgOk() (*string, bool)`

GetMigrationMsgOk returns a tuple with the MigrationMsg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMigrationMsg

`func (o *Createv12SedMigrateItemResponseSettings) SetMigrationMsg(v string)`

SetMigrationMsg sets MigrationMsg field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


