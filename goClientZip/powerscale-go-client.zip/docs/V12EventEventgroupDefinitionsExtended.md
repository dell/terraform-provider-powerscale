# V12EventEventgroupDefinitionsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EventgroupDefinitions** | Pointer to [**[]V12EventEventgroupDefinitionsEventgroupDefinition**](V12EventEventgroupDefinitionsEventgroupDefinition.md) |  | [optional] 

## Methods

### NewV12EventEventgroupDefinitionsExtended

`func NewV12EventEventgroupDefinitionsExtended() *V12EventEventgroupDefinitionsExtended`

NewV12EventEventgroupDefinitionsExtended instantiates a new V12EventEventgroupDefinitionsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventEventgroupDefinitionsExtendedWithDefaults

`func NewV12EventEventgroupDefinitionsExtendedWithDefaults() *V12EventEventgroupDefinitionsExtended`

NewV12EventEventgroupDefinitionsExtendedWithDefaults instantiates a new V12EventEventgroupDefinitionsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEventgroupDefinitions

`func (o *V12EventEventgroupDefinitionsExtended) GetEventgroupDefinitions() []V12EventEventgroupDefinitionsEventgroupDefinition`

GetEventgroupDefinitions returns the EventgroupDefinitions field if non-nil, zero value otherwise.

### GetEventgroupDefinitionsOk

`func (o *V12EventEventgroupDefinitionsExtended) GetEventgroupDefinitionsOk() (*[]V12EventEventgroupDefinitionsEventgroupDefinition, bool)`

GetEventgroupDefinitionsOk returns a tuple with the EventgroupDefinitions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventgroupDefinitions

`func (o *V12EventEventgroupDefinitionsExtended) SetEventgroupDefinitions(v []V12EventEventgroupDefinitionsEventgroupDefinition)`

SetEventgroupDefinitions sets EventgroupDefinitions field to given value.

### HasEventgroupDefinitions

`func (o *V12EventEventgroupDefinitionsExtended) HasEventgroupDefinitions() bool`

HasEventgroupDefinitions returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


