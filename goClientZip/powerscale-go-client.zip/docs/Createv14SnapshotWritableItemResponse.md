# Createv14SnapshotWritableItemResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Created** | **int32** | The Unix Epoch time the writable snapshot was created. | 
**DstPath** | **string** | The user supplied /ifs path of writable snapshot. | 
**Id** | **int32** | The system ID given to the writable snapshot. This is useful for debugging. | 
**LogSize** | **int32** | The sum in bytes of logical size of files in this writable snapshot. | 
**PhysSize** | **int32** | The amount of storage in bytes used to store this writable snapshot. | 
**SrcId** | **int32** | The system ID of the user supplied source snapshot. This is useful for debugging. | 
**SrcPath** | **string** | The /ifs path of user supplied source snapshot. This will be null for writable snapshots pending delete. | 
**SrcSnap** | **string** | The user supplied source snapshot name or ID. This will be null for writable snapshots pending delete. | 
**State** | **string** | Writable Snapshot state. | 

## Methods

### NewCreatev14SnapshotWritableItemResponse

`func NewCreatev14SnapshotWritableItemResponse(created int32, dstPath string, id int32, logSize int32, physSize int32, srcId int32, srcPath string, srcSnap string, state string, ) *Createv14SnapshotWritableItemResponse`

NewCreatev14SnapshotWritableItemResponse instantiates a new Createv14SnapshotWritableItemResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev14SnapshotWritableItemResponseWithDefaults

`func NewCreatev14SnapshotWritableItemResponseWithDefaults() *Createv14SnapshotWritableItemResponse`

NewCreatev14SnapshotWritableItemResponseWithDefaults instantiates a new Createv14SnapshotWritableItemResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCreated

`func (o *Createv14SnapshotWritableItemResponse) GetCreated() int32`

GetCreated returns the Created field if non-nil, zero value otherwise.

### GetCreatedOk

`func (o *Createv14SnapshotWritableItemResponse) GetCreatedOk() (*int32, bool)`

GetCreatedOk returns a tuple with the Created field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreated

`func (o *Createv14SnapshotWritableItemResponse) SetCreated(v int32)`

SetCreated sets Created field to given value.


### GetDstPath

`func (o *Createv14SnapshotWritableItemResponse) GetDstPath() string`

GetDstPath returns the DstPath field if non-nil, zero value otherwise.

### GetDstPathOk

`func (o *Createv14SnapshotWritableItemResponse) GetDstPathOk() (*string, bool)`

GetDstPathOk returns a tuple with the DstPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDstPath

`func (o *Createv14SnapshotWritableItemResponse) SetDstPath(v string)`

SetDstPath sets DstPath field to given value.


### GetId

`func (o *Createv14SnapshotWritableItemResponse) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv14SnapshotWritableItemResponse) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv14SnapshotWritableItemResponse) SetId(v int32)`

SetId sets Id field to given value.


### GetLogSize

`func (o *Createv14SnapshotWritableItemResponse) GetLogSize() int32`

GetLogSize returns the LogSize field if non-nil, zero value otherwise.

### GetLogSizeOk

`func (o *Createv14SnapshotWritableItemResponse) GetLogSizeOk() (*int32, bool)`

GetLogSizeOk returns a tuple with the LogSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLogSize

`func (o *Createv14SnapshotWritableItemResponse) SetLogSize(v int32)`

SetLogSize sets LogSize field to given value.


### GetPhysSize

`func (o *Createv14SnapshotWritableItemResponse) GetPhysSize() int32`

GetPhysSize returns the PhysSize field if non-nil, zero value otherwise.

### GetPhysSizeOk

`func (o *Createv14SnapshotWritableItemResponse) GetPhysSizeOk() (*int32, bool)`

GetPhysSizeOk returns a tuple with the PhysSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysSize

`func (o *Createv14SnapshotWritableItemResponse) SetPhysSize(v int32)`

SetPhysSize sets PhysSize field to given value.


### GetSrcId

`func (o *Createv14SnapshotWritableItemResponse) GetSrcId() int32`

GetSrcId returns the SrcId field if non-nil, zero value otherwise.

### GetSrcIdOk

`func (o *Createv14SnapshotWritableItemResponse) GetSrcIdOk() (*int32, bool)`

GetSrcIdOk returns a tuple with the SrcId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcId

`func (o *Createv14SnapshotWritableItemResponse) SetSrcId(v int32)`

SetSrcId sets SrcId field to given value.


### GetSrcPath

`func (o *Createv14SnapshotWritableItemResponse) GetSrcPath() string`

GetSrcPath returns the SrcPath field if non-nil, zero value otherwise.

### GetSrcPathOk

`func (o *Createv14SnapshotWritableItemResponse) GetSrcPathOk() (*string, bool)`

GetSrcPathOk returns a tuple with the SrcPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcPath

`func (o *Createv14SnapshotWritableItemResponse) SetSrcPath(v string)`

SetSrcPath sets SrcPath field to given value.


### GetSrcSnap

`func (o *Createv14SnapshotWritableItemResponse) GetSrcSnap() string`

GetSrcSnap returns the SrcSnap field if non-nil, zero value otherwise.

### GetSrcSnapOk

`func (o *Createv14SnapshotWritableItemResponse) GetSrcSnapOk() (*string, bool)`

GetSrcSnapOk returns a tuple with the SrcSnap field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcSnap

`func (o *Createv14SnapshotWritableItemResponse) SetSrcSnap(v string)`

SetSrcSnap sets SrcSnap field to given value.


### GetState

`func (o *Createv14SnapshotWritableItemResponse) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *Createv14SnapshotWritableItemResponse) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *Createv14SnapshotWritableItemResponse) SetState(v string)`

SetState sets State field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


