# V12ClusterFirmwareUpgradeItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlertTimeout** | Pointer to **int32** | The duration in seconds after drain begins that an alert will be raised. An alert timeout must be set to a smaller value than the drain timeout to be used. If not specified, an alert will not be raised (legacy behavior). | [optional] 
**DrainTimeout** | Pointer to **int32** | The duration in seconds that upgrade waits for all SMB clients to disconnect from a node before rebooting it. A value of 0 means wait indefinitely. If not specified, upgrade proceeds with reboots regardless of SMB client connections (legacy behavior). | [optional] 
**ExcludeDevice** | Pointer to **string** | Exclude the specified devices in the firmware upgrade. | [optional] 
**ExcludeType** | Pointer to **string** | Exclude the specified device type in the firmware upgrade. | [optional] 
**FwPkg** | Pointer to **string** | The location (path) of the firmware package which must be within /ifs. | [optional] 
**FwPkgId** | Pointer to **string** | The ID of the signed artifact stored in the catalog. | [optional] 
**IncludeDevice** | Pointer to **string** | Include the specified devices in the firmware upgrade. | [optional] 
**IncludeType** | Pointer to **string** | Include the specified device type in the firmware upgrade. | [optional] 
**NoBurn** | Pointer to **bool** | Do not burn the firmware. | [optional] 
**NoReboot** | Pointer to **bool** | Do not reboot the node after an upgrade | [optional] 
**NodesToUpgrade** | Pointer to **[]int32** | The nodes scheduled for upgrade. Order in array determines queue position number. &#39;all&#39; and null option will upgrade firmware on all nodes in &lt;lnn&gt; order (Note: &#39;all&#39; and null options do not apply to simultaneous firmware upgrade). | [optional] 
**UpgradeType** | **string** | The type of upgrade to perform. One of the following values: &#39;rolling&#39;, &#39;simultaneous, parallel&#39; | 

## Methods

### NewV12ClusterFirmwareUpgradeItem

`func NewV12ClusterFirmwareUpgradeItem(upgradeType string, ) *V12ClusterFirmwareUpgradeItem`

NewV12ClusterFirmwareUpgradeItem instantiates a new V12ClusterFirmwareUpgradeItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterFirmwareUpgradeItemWithDefaults

`func NewV12ClusterFirmwareUpgradeItemWithDefaults() *V12ClusterFirmwareUpgradeItem`

NewV12ClusterFirmwareUpgradeItemWithDefaults instantiates a new V12ClusterFirmwareUpgradeItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlertTimeout

`func (o *V12ClusterFirmwareUpgradeItem) GetAlertTimeout() int32`

GetAlertTimeout returns the AlertTimeout field if non-nil, zero value otherwise.

### GetAlertTimeoutOk

`func (o *V12ClusterFirmwareUpgradeItem) GetAlertTimeoutOk() (*int32, bool)`

GetAlertTimeoutOk returns a tuple with the AlertTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlertTimeout

`func (o *V12ClusterFirmwareUpgradeItem) SetAlertTimeout(v int32)`

SetAlertTimeout sets AlertTimeout field to given value.

### HasAlertTimeout

`func (o *V12ClusterFirmwareUpgradeItem) HasAlertTimeout() bool`

HasAlertTimeout returns a boolean if a field has been set.

### GetDrainTimeout

`func (o *V12ClusterFirmwareUpgradeItem) GetDrainTimeout() int32`

GetDrainTimeout returns the DrainTimeout field if non-nil, zero value otherwise.

### GetDrainTimeoutOk

`func (o *V12ClusterFirmwareUpgradeItem) GetDrainTimeoutOk() (*int32, bool)`

GetDrainTimeoutOk returns a tuple with the DrainTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrainTimeout

`func (o *V12ClusterFirmwareUpgradeItem) SetDrainTimeout(v int32)`

SetDrainTimeout sets DrainTimeout field to given value.

### HasDrainTimeout

`func (o *V12ClusterFirmwareUpgradeItem) HasDrainTimeout() bool`

HasDrainTimeout returns a boolean if a field has been set.

### GetExcludeDevice

`func (o *V12ClusterFirmwareUpgradeItem) GetExcludeDevice() string`

GetExcludeDevice returns the ExcludeDevice field if non-nil, zero value otherwise.

### GetExcludeDeviceOk

`func (o *V12ClusterFirmwareUpgradeItem) GetExcludeDeviceOk() (*string, bool)`

GetExcludeDeviceOk returns a tuple with the ExcludeDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeDevice

`func (o *V12ClusterFirmwareUpgradeItem) SetExcludeDevice(v string)`

SetExcludeDevice sets ExcludeDevice field to given value.

### HasExcludeDevice

`func (o *V12ClusterFirmwareUpgradeItem) HasExcludeDevice() bool`

HasExcludeDevice returns a boolean if a field has been set.

### GetExcludeType

`func (o *V12ClusterFirmwareUpgradeItem) GetExcludeType() string`

GetExcludeType returns the ExcludeType field if non-nil, zero value otherwise.

### GetExcludeTypeOk

`func (o *V12ClusterFirmwareUpgradeItem) GetExcludeTypeOk() (*string, bool)`

GetExcludeTypeOk returns a tuple with the ExcludeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeType

`func (o *V12ClusterFirmwareUpgradeItem) SetExcludeType(v string)`

SetExcludeType sets ExcludeType field to given value.

### HasExcludeType

`func (o *V12ClusterFirmwareUpgradeItem) HasExcludeType() bool`

HasExcludeType returns a boolean if a field has been set.

### GetFwPkg

`func (o *V12ClusterFirmwareUpgradeItem) GetFwPkg() string`

GetFwPkg returns the FwPkg field if non-nil, zero value otherwise.

### GetFwPkgOk

`func (o *V12ClusterFirmwareUpgradeItem) GetFwPkgOk() (*string, bool)`

GetFwPkgOk returns a tuple with the FwPkg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFwPkg

`func (o *V12ClusterFirmwareUpgradeItem) SetFwPkg(v string)`

SetFwPkg sets FwPkg field to given value.

### HasFwPkg

`func (o *V12ClusterFirmwareUpgradeItem) HasFwPkg() bool`

HasFwPkg returns a boolean if a field has been set.

### GetFwPkgId

`func (o *V12ClusterFirmwareUpgradeItem) GetFwPkgId() string`

GetFwPkgId returns the FwPkgId field if non-nil, zero value otherwise.

### GetFwPkgIdOk

`func (o *V12ClusterFirmwareUpgradeItem) GetFwPkgIdOk() (*string, bool)`

GetFwPkgIdOk returns a tuple with the FwPkgId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFwPkgId

`func (o *V12ClusterFirmwareUpgradeItem) SetFwPkgId(v string)`

SetFwPkgId sets FwPkgId field to given value.

### HasFwPkgId

`func (o *V12ClusterFirmwareUpgradeItem) HasFwPkgId() bool`

HasFwPkgId returns a boolean if a field has been set.

### GetIncludeDevice

`func (o *V12ClusterFirmwareUpgradeItem) GetIncludeDevice() string`

GetIncludeDevice returns the IncludeDevice field if non-nil, zero value otherwise.

### GetIncludeDeviceOk

`func (o *V12ClusterFirmwareUpgradeItem) GetIncludeDeviceOk() (*string, bool)`

GetIncludeDeviceOk returns a tuple with the IncludeDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeDevice

`func (o *V12ClusterFirmwareUpgradeItem) SetIncludeDevice(v string)`

SetIncludeDevice sets IncludeDevice field to given value.

### HasIncludeDevice

`func (o *V12ClusterFirmwareUpgradeItem) HasIncludeDevice() bool`

HasIncludeDevice returns a boolean if a field has been set.

### GetIncludeType

`func (o *V12ClusterFirmwareUpgradeItem) GetIncludeType() string`

GetIncludeType returns the IncludeType field if non-nil, zero value otherwise.

### GetIncludeTypeOk

`func (o *V12ClusterFirmwareUpgradeItem) GetIncludeTypeOk() (*string, bool)`

GetIncludeTypeOk returns a tuple with the IncludeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeType

`func (o *V12ClusterFirmwareUpgradeItem) SetIncludeType(v string)`

SetIncludeType sets IncludeType field to given value.

### HasIncludeType

`func (o *V12ClusterFirmwareUpgradeItem) HasIncludeType() bool`

HasIncludeType returns a boolean if a field has been set.

### GetNoBurn

`func (o *V12ClusterFirmwareUpgradeItem) GetNoBurn() bool`

GetNoBurn returns the NoBurn field if non-nil, zero value otherwise.

### GetNoBurnOk

`func (o *V12ClusterFirmwareUpgradeItem) GetNoBurnOk() (*bool, bool)`

GetNoBurnOk returns a tuple with the NoBurn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoBurn

`func (o *V12ClusterFirmwareUpgradeItem) SetNoBurn(v bool)`

SetNoBurn sets NoBurn field to given value.

### HasNoBurn

`func (o *V12ClusterFirmwareUpgradeItem) HasNoBurn() bool`

HasNoBurn returns a boolean if a field has been set.

### GetNoReboot

`func (o *V12ClusterFirmwareUpgradeItem) GetNoReboot() bool`

GetNoReboot returns the NoReboot field if non-nil, zero value otherwise.

### GetNoRebootOk

`func (o *V12ClusterFirmwareUpgradeItem) GetNoRebootOk() (*bool, bool)`

GetNoRebootOk returns a tuple with the NoReboot field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoReboot

`func (o *V12ClusterFirmwareUpgradeItem) SetNoReboot(v bool)`

SetNoReboot sets NoReboot field to given value.

### HasNoReboot

`func (o *V12ClusterFirmwareUpgradeItem) HasNoReboot() bool`

HasNoReboot returns a boolean if a field has been set.

### GetNodesToUpgrade

`func (o *V12ClusterFirmwareUpgradeItem) GetNodesToUpgrade() []int32`

GetNodesToUpgrade returns the NodesToUpgrade field if non-nil, zero value otherwise.

### GetNodesToUpgradeOk

`func (o *V12ClusterFirmwareUpgradeItem) GetNodesToUpgradeOk() (*[]int32, bool)`

GetNodesToUpgradeOk returns a tuple with the NodesToUpgrade field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodesToUpgrade

`func (o *V12ClusterFirmwareUpgradeItem) SetNodesToUpgrade(v []int32)`

SetNodesToUpgrade sets NodesToUpgrade field to given value.

### HasNodesToUpgrade

`func (o *V12ClusterFirmwareUpgradeItem) HasNodesToUpgrade() bool`

HasNodesToUpgrade returns a boolean if a field has been set.

### GetUpgradeType

`func (o *V12ClusterFirmwareUpgradeItem) GetUpgradeType() string`

GetUpgradeType returns the UpgradeType field if non-nil, zero value otherwise.

### GetUpgradeTypeOk

`func (o *V12ClusterFirmwareUpgradeItem) GetUpgradeTypeOk() (*string, bool)`

GetUpgradeTypeOk returns a tuple with the UpgradeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpgradeType

`func (o *V12ClusterFirmwareUpgradeItem) SetUpgradeType(v string)`

SetUpgradeType sets UpgradeType field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


