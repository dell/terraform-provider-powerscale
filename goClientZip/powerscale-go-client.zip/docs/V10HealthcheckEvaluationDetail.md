# V10HealthcheckEvaluationDetail

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Details** | Pointer to **map[string]interface{}** | Optional details of the evaluation - raw data | [optional] 
**Hash** | Pointer to **string** | Unique identifier | [optional] 
**Id** | Pointer to **string** | Unique identifier of item | [optional] 
**Node** | Pointer to **string** | Either &#39;cluster&#39; or an lnn | [optional] 
**Parameters** | Pointer to **map[string]interface{}** |  | [optional] 
**Status** | Pointer to **string** | Health status based on default thresholds | [optional] 
**Value** | Pointer to **int32** | Normalized measured value 0 (bad) to 100 (perfect) | [optional] 

## Methods

### NewV10HealthcheckEvaluationDetail

`func NewV10HealthcheckEvaluationDetail() *V10HealthcheckEvaluationDetail`

NewV10HealthcheckEvaluationDetail instantiates a new V10HealthcheckEvaluationDetail object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckEvaluationDetailWithDefaults

`func NewV10HealthcheckEvaluationDetailWithDefaults() *V10HealthcheckEvaluationDetail`

NewV10HealthcheckEvaluationDetailWithDefaults instantiates a new V10HealthcheckEvaluationDetail object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDetails

`func (o *V10HealthcheckEvaluationDetail) GetDetails() map[string]interface{}`

GetDetails returns the Details field if non-nil, zero value otherwise.

### GetDetailsOk

`func (o *V10HealthcheckEvaluationDetail) GetDetailsOk() (*map[string]interface{}, bool)`

GetDetailsOk returns a tuple with the Details field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDetails

`func (o *V10HealthcheckEvaluationDetail) SetDetails(v map[string]interface{})`

SetDetails sets Details field to given value.

### HasDetails

`func (o *V10HealthcheckEvaluationDetail) HasDetails() bool`

HasDetails returns a boolean if a field has been set.

### GetHash

`func (o *V10HealthcheckEvaluationDetail) GetHash() string`

GetHash returns the Hash field if non-nil, zero value otherwise.

### GetHashOk

`func (o *V10HealthcheckEvaluationDetail) GetHashOk() (*string, bool)`

GetHashOk returns a tuple with the Hash field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHash

`func (o *V10HealthcheckEvaluationDetail) SetHash(v string)`

SetHash sets Hash field to given value.

### HasHash

`func (o *V10HealthcheckEvaluationDetail) HasHash() bool`

HasHash returns a boolean if a field has been set.

### GetId

`func (o *V10HealthcheckEvaluationDetail) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10HealthcheckEvaluationDetail) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10HealthcheckEvaluationDetail) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V10HealthcheckEvaluationDetail) HasId() bool`

HasId returns a boolean if a field has been set.

### GetNode

`func (o *V10HealthcheckEvaluationDetail) GetNode() string`

GetNode returns the Node field if non-nil, zero value otherwise.

### GetNodeOk

`func (o *V10HealthcheckEvaluationDetail) GetNodeOk() (*string, bool)`

GetNodeOk returns a tuple with the Node field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNode

`func (o *V10HealthcheckEvaluationDetail) SetNode(v string)`

SetNode sets Node field to given value.

### HasNode

`func (o *V10HealthcheckEvaluationDetail) HasNode() bool`

HasNode returns a boolean if a field has been set.

### GetParameters

`func (o *V10HealthcheckEvaluationDetail) GetParameters() map[string]interface{}`

GetParameters returns the Parameters field if non-nil, zero value otherwise.

### GetParametersOk

`func (o *V10HealthcheckEvaluationDetail) GetParametersOk() (*map[string]interface{}, bool)`

GetParametersOk returns a tuple with the Parameters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParameters

`func (o *V10HealthcheckEvaluationDetail) SetParameters(v map[string]interface{})`

SetParameters sets Parameters field to given value.

### HasParameters

`func (o *V10HealthcheckEvaluationDetail) HasParameters() bool`

HasParameters returns a boolean if a field has been set.

### GetStatus

`func (o *V10HealthcheckEvaluationDetail) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V10HealthcheckEvaluationDetail) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V10HealthcheckEvaluationDetail) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V10HealthcheckEvaluationDetail) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetValue

`func (o *V10HealthcheckEvaluationDetail) GetValue() int32`

GetValue returns the Value field if non-nil, zero value otherwise.

### GetValueOk

`func (o *V10HealthcheckEvaluationDetail) GetValueOk() (*int32, bool)`

GetValueOk returns a tuple with the Value field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValue

`func (o *V10HealthcheckEvaluationDetail) SetValue(v int32)`

SetValue sets Value field to given value.

### HasValue

`func (o *V10HealthcheckEvaluationDetail) HasValue() bool`

HasValue returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


