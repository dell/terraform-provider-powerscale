# \DedupeApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetDedupev1DedupeDedupeSummary**](DedupeApi.md#GetDedupev1DedupeDedupeSummary) | **Get** /platform/1/dedupe/dedupe-summary | 
[**GetDedupev1DedupeReport**](DedupeApi.md#GetDedupev1DedupeReport) | **Get** /platform/1/dedupe/reports/{v1DedupeReportId} | 
[**GetDedupev1DedupeReports**](DedupeApi.md#GetDedupev1DedupeReports) | **Get** /platform/1/dedupe/reports | 
[**GetDedupev1DedupeSettings**](DedupeApi.md#GetDedupev1DedupeSettings) | **Get** /platform/1/dedupe/settings | 
[**GetDedupev6InlineSettings**](DedupeApi.md#GetDedupev6InlineSettings) | **Get** /platform/6/dedupe/inline/settings | 
[**UpdateDedupev1DedupeSettings**](DedupeApi.md#UpdateDedupev1DedupeSettings) | **Put** /platform/1/dedupe/settings | 
[**UpdateDedupev6InlineSettings**](DedupeApi.md#UpdateDedupev6InlineSettings) | **Put** /platform/6/dedupe/inline/settings | 



## GetDedupev1DedupeDedupeSummary

> V1DedupeDedupeSummary GetDedupev1DedupeDedupeSummary(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DedupeApi.GetDedupev1DedupeDedupeSummary(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DedupeApi.GetDedupev1DedupeDedupeSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDedupev1DedupeDedupeSummary`: V1DedupeDedupeSummary
    fmt.Fprintf(os.Stdout, "Response from `DedupeApi.GetDedupev1DedupeDedupeSummary`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetDedupev1DedupeDedupeSummaryRequest struct via the builder pattern


### Return type

[**V1DedupeDedupeSummary**](V1DedupeDedupeSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDedupev1DedupeReport

> V1DedupeReportsExtended GetDedupev1DedupeReport(ctx, v1DedupeReportId).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1DedupeReportId := "v1DedupeReportId_example" // string | Retrieve a report for a single dedupe job.
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DedupeApi.GetDedupev1DedupeReport(context.Background(), v1DedupeReportId).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DedupeApi.GetDedupev1DedupeReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDedupev1DedupeReport`: V1DedupeReportsExtended
    fmt.Fprintf(os.Stdout, "Response from `DedupeApi.GetDedupev1DedupeReport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1DedupeReportId** | **string** | Retrieve a report for a single dedupe job. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDedupev1DedupeReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1DedupeReportsExtended**](V1DedupeReportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDedupev1DedupeReports

> V1DedupeReports GetDedupev1DedupeReports(ctx).Sort(sort).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    begin := int32(56) // int32 | Restrict the query to reports at or after the given time, in seconds since the Epoch. (optional)
    end := int32(56) // int32 | Restrict the query to reports at or before the given time, in seconds since the Epoch. (optional)
    jobId := int32(56) // int32 | Restrict the query to the given job ID. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    jobType := "jobType_example" // string | Restrict the query to the given job type. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DedupeApi.GetDedupev1DedupeReports(context.Background()).Sort(sort).Begin(begin).End(end).JobId(jobId).Resume(resume).JobType(jobType).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DedupeApi.GetDedupev1DedupeReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDedupev1DedupeReports`: V1DedupeReports
    fmt.Fprintf(os.Stdout, "Response from `DedupeApi.GetDedupev1DedupeReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetDedupev1DedupeReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **begin** | **int32** | Restrict the query to reports at or after the given time, in seconds since the Epoch. | 
 **end** | **int32** | Restrict the query to reports at or before the given time, in seconds since the Epoch. | 
 **jobId** | **int32** | Restrict the query to the given job ID. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **jobType** | **string** | Restrict the query to the given job type. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1DedupeReports**](V1DedupeReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDedupev1DedupeSettings

> V1DedupeSettings GetDedupev1DedupeSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DedupeApi.GetDedupev1DedupeSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DedupeApi.GetDedupev1DedupeSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDedupev1DedupeSettings`: V1DedupeSettings
    fmt.Fprintf(os.Stdout, "Response from `DedupeApi.GetDedupev1DedupeSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetDedupev1DedupeSettingsRequest struct via the builder pattern


### Return type

[**V1DedupeSettings**](V1DedupeSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDedupev6InlineSettings

> V6InlineSettings GetDedupev6InlineSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DedupeApi.GetDedupev6InlineSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DedupeApi.GetDedupev6InlineSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDedupev6InlineSettings`: V6InlineSettings
    fmt.Fprintf(os.Stdout, "Response from `DedupeApi.GetDedupev6InlineSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetDedupev6InlineSettingsRequest struct via the builder pattern


### Return type

[**V6InlineSettings**](V6InlineSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDedupev1DedupeSettings

> UpdateDedupev1DedupeSettings(ctx).V1DedupeSettings(v1DedupeSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1DedupeSettings := *openapiclient.NewV1DedupeSettingsExtended() // V1DedupeSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DedupeApi.UpdateDedupev1DedupeSettings(context.Background()).V1DedupeSettings(v1DedupeSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DedupeApi.UpdateDedupev1DedupeSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateDedupev1DedupeSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1DedupeSettings** | [**V1DedupeSettingsExtended**](V1DedupeSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDedupev6InlineSettings

> UpdateDedupev6InlineSettings(ctx).V6InlineSettings(v6InlineSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v6InlineSettings := *openapiclient.NewV6InlineSettingsSettings("Mode_example") // V6InlineSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DedupeApi.UpdateDedupev6InlineSettings(context.Background()).V6InlineSettings(v6InlineSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DedupeApi.UpdateDedupev6InlineSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateDedupev6InlineSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v6InlineSettings** | [**V6InlineSettingsSettings**](V6InlineSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

