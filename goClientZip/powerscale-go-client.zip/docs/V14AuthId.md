# V14AuthId

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ntoken** | Pointer to [**V14AuthIdNtoken**](V14AuthIdNtoken.md) |  | [optional] 

## Methods

### NewV14AuthId

`func NewV14AuthId() *V14AuthId`

NewV14AuthId instantiates a new V14AuthId object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14AuthIdWithDefaults

`func NewV14AuthIdWithDefaults() *V14AuthId`

NewV14AuthIdWithDefaults instantiates a new V14AuthId object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNtoken

`func (o *V14AuthId) GetNtoken() V14AuthIdNtoken`

GetNtoken returns the Ntoken field if non-nil, zero value otherwise.

### GetNtokenOk

`func (o *V14AuthId) GetNtokenOk() (*V14AuthIdNtoken, bool)`

GetNtokenOk returns a tuple with the Ntoken field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNtoken

`func (o *V14AuthId) SetNtoken(v V14AuthIdNtoken)`

SetNtoken sets Ntoken field to given value.

### HasNtoken

`func (o *V14AuthId) HasNtoken() bool`

HasNtoken returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


