# V11ProvidersLdap

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ldap** | Pointer to [**[]V11ProvidersLdapLdapItem**](V11ProvidersLdapLdapItem.md) |  | [optional] 

## Methods

### NewV11ProvidersLdap

`func NewV11ProvidersLdap() *V11ProvidersLdap`

NewV11ProvidersLdap instantiates a new V11ProvidersLdap object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ProvidersLdapWithDefaults

`func NewV11ProvidersLdapWithDefaults() *V11ProvidersLdap`

NewV11ProvidersLdapWithDefaults instantiates a new V11ProvidersLdap object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetLdap

`func (o *V11ProvidersLdap) GetLdap() []V11ProvidersLdapLdapItem`

GetLdap returns the Ldap field if non-nil, zero value otherwise.

### GetLdapOk

`func (o *V11ProvidersLdap) GetLdapOk() (*[]V11ProvidersLdapLdapItem, bool)`

GetLdapOk returns a tuple with the Ldap field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLdap

`func (o *V11ProvidersLdap) SetLdap(v []V11ProvidersLdapLdapItem)`

SetLdap sets Ldap field to given value.

### HasLdap

`func (o *V11ProvidersLdap) HasLdap() bool`

HasLdap returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


