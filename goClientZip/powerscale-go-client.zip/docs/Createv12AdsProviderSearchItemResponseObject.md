# Createv12AdsProviderSearchItemResponseObject

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | Pointer to **string** |  | [optional] 
**DisplayName** | Pointer to **string** |  | [optional] 
**Id** | Pointer to [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | [optional] 

## Methods

### NewCreatev12AdsProviderSearchItemResponseObject

`func NewCreatev12AdsProviderSearchItemResponseObject() *Createv12AdsProviderSearchItemResponseObject`

NewCreatev12AdsProviderSearchItemResponseObject instantiates a new Createv12AdsProviderSearchItemResponseObject object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev12AdsProviderSearchItemResponseObjectWithDefaults

`func NewCreatev12AdsProviderSearchItemResponseObjectWithDefaults() *Createv12AdsProviderSearchItemResponseObject`

NewCreatev12AdsProviderSearchItemResponseObjectWithDefaults instantiates a new Createv12AdsProviderSearchItemResponseObject object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDescription

`func (o *Createv12AdsProviderSearchItemResponseObject) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *Createv12AdsProviderSearchItemResponseObject) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *Createv12AdsProviderSearchItemResponseObject) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *Createv12AdsProviderSearchItemResponseObject) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetDisplayName

`func (o *Createv12AdsProviderSearchItemResponseObject) GetDisplayName() string`

GetDisplayName returns the DisplayName field if non-nil, zero value otherwise.

### GetDisplayNameOk

`func (o *Createv12AdsProviderSearchItemResponseObject) GetDisplayNameOk() (*string, bool)`

GetDisplayNameOk returns a tuple with the DisplayName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisplayName

`func (o *Createv12AdsProviderSearchItemResponseObject) SetDisplayName(v string)`

SetDisplayName sets DisplayName field to given value.

### HasDisplayName

`func (o *Createv12AdsProviderSearchItemResponseObject) HasDisplayName() bool`

HasDisplayName returns a boolean if a field has been set.

### GetId

`func (o *Createv12AdsProviderSearchItemResponseObject) GetId() V1AuthAccessAccessItemFileGroup`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv12AdsProviderSearchItemResponseObject) GetIdOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv12AdsProviderSearchItemResponseObject) SetId(v V1AuthAccessAccessItemFileGroup)`

SetId sets Id field to given value.

### HasId

`func (o *Createv12AdsProviderSearchItemResponseObject) HasId() bool`

HasId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


