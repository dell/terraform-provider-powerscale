# Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Binding** | Pointer to **string** | SAML binding that PowerScale can use. | [optional] 
**IsDefault** | Pointer to **bool** | When true this is the endpoint that PowerScale will use if this same metadata is used to create an IDP on PowerScale. There will be at most one item in the list set to true. | [optional] 
**ResponseUrl** | Pointer to **string** | URL specifying the location of where to send responses to. | [optional] 
**Url** | Pointer to **string** | URL specifying the location of the endpoint. | [optional] 

## Methods

### NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint

`func NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint() *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint`

NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint instantiates a new Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpointWithDefaults

`func NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpointWithDefaults() *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint`

NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpointWithDefaults instantiates a new Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBinding

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) GetBinding() string`

GetBinding returns the Binding field if non-nil, zero value otherwise.

### GetBindingOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) GetBindingOk() (*string, bool)`

GetBindingOk returns a tuple with the Binding field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBinding

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) SetBinding(v string)`

SetBinding sets Binding field to given value.

### HasBinding

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) HasBinding() bool`

HasBinding returns a boolean if a field has been set.

### GetIsDefault

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) GetIsDefault() bool`

GetIsDefault returns the IsDefault field if non-nil, zero value otherwise.

### GetIsDefaultOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) GetIsDefaultOk() (*bool, bool)`

GetIsDefaultOk returns a tuple with the IsDefault field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsDefault

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) SetIsDefault(v bool)`

SetIsDefault sets IsDefault field to given value.

### HasIsDefault

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) HasIsDefault() bool`

HasIsDefault returns a boolean if a field has been set.

### GetResponseUrl

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) GetResponseUrl() string`

GetResponseUrl returns the ResponseUrl field if non-nil, zero value otherwise.

### GetResponseUrlOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) GetResponseUrlOk() (*string, bool)`

GetResponseUrlOk returns a tuple with the ResponseUrl field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResponseUrl

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) SetResponseUrl(v string)`

SetResponseUrl sets ResponseUrl field to given value.

### HasResponseUrl

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) HasResponseUrl() bool`

HasResponseUrl returns a boolean if a field has been set.

### GetUrl

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) GetUrl() string`

GetUrl returns the Url field if non-nil, zero value otherwise.

### GetUrlOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) GetUrlOk() (*string, bool)`

GetUrlOk returns a tuple with the Url field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUrl

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) SetUrl(v string)`

SetUrl sets Url field to given value.

### HasUrl

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint) HasUrl() bool`

HasUrl returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


