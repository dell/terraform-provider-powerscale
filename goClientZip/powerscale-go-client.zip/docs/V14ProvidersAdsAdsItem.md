# V14ProvidersAdsAdsItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllocateGids** | Pointer to **bool** | Allocates an ID for an unmapped Active Directory (ADS) group. ADS groups without GIDs can be proactively assigned a GID by the ID mapper. If the ID mapper option is disabled, GIDs are not proactively assigned, and when a primary group for a user does not include a GID, the system may allocate one.  | [optional] 
**AllocateUids** | Pointer to **bool** | Allocates a user ID for an unmapped Active Directory (ADS) user. ADS users without UIDs can be proactively assigned a UID by the ID mapper. IF the ID mapper option is disabled, UIDs are not proactively assigned, and when an identify for a user does not include a UID, the system may allocate one. | [optional] 
**AssumeDefaultDomain** | Pointer to **bool** | Enables lookup of unqualified user names in the primary domain. | [optional] 
**Authentication** | Pointer to **bool** | Enables authentication and identity management through the authentication provider. | [optional] 
**CheckOnlineInterval** | Pointer to **int32** | Specifies the time in seconds between provider online checks. | [optional] 
**ControllerTime** | Pointer to **int32** | Specifies the current time for the domain controllers. | [optional] 
**CreateHomeDirectory** | Pointer to **bool** | Automatically creates a home directory on the first login. | [optional] 
**DomainOfflineAlerts** | Pointer to **bool** | Sends an alert if the domain goes offline. | [optional] 
**DupSpns** | Pointer to **[]string** | Get duplicate SPNs in the provider domain | [optional] 
**ExtraExpectedSpns** | Pointer to **[]string** | List of additional SPNs to expect beyond what automatic checking routines might find | [optional] 
**FindableGroups** | Pointer to **[]string** | Sets list of groups that can be resolved. | [optional] 
**FindableUsers** | Pointer to **[]string** | Sets list of users that can be resolved. | [optional] 
**Forest** | Pointer to **string** | Specifies the Active Directory forest. | [optional] 
**Groupnet** | Pointer to **string** | Groupnet identifier. | [optional] 
**HomeDirectoryTemplate** | Pointer to **string** | Specifies the path to the home directory template. | [optional] 
**Hostname** | Pointer to **string** | Specifies the fully qualified hostname stored in the machine account. | [optional] 
**Id** | Pointer to **string** | Specifies the ID of the Active Directory provider instance. | [optional] 
**IgnoreAllTrusts** | Pointer to **bool** | If set to true, ignores all trusted domains. | [optional] 
**IgnoredTrustedDomains** | Pointer to **[]string** | Includes trusted domains when &#39;ignore_all_trusts&#39; is set to false. | [optional] 
**IncludeTrustedDomains** | Pointer to **[]string** | Includes trusted domains when &#39;ignore_all_trusts&#39; is set to true. | [optional] 
**Instance** | Pointer to **string** | Specifies Active Directory provider instance. | [optional] 
**LdapSignAndSeal** | Pointer to **bool** | Enables encryption and signing on LDAP requests. | [optional] 
**LoginShell** | Pointer to **string** | Specifies the login shell path. | [optional] 
**LookupDomains** | Pointer to **[]string** | Limits user and group lookups to the specified domains. | [optional] 
**LookupGroups** | Pointer to **bool** | Looks up AD groups in other providers before allocating a group ID. | [optional] 
**LookupNormalizeGroups** | Pointer to **bool** | Normalizes AD group names to lowercase before look up. | [optional] 
**LookupNormalizeUsers** | Pointer to **bool** | Normalize AD user names to lowercase before look up. | [optional] 
**LookupUsers** | Pointer to **bool** | Looks up AD users in other providers before allocating a user ID. | [optional] 
**MachineAccount** | Pointer to **string** | Specifies the machine account name when creating a SAM account with Active Directory. | [optional] 
**MachinePasswordChanges** | Pointer to **bool** | Enables periodic changes of the machine password for security. | [optional] 
**MachinePasswordLifespan** | Pointer to **int32** | Sets maximum age of a password in seconds. | [optional] 
**Name** | Pointer to **string** | Specifies the Active Directory provider name. | [optional] 
**NetbiosDomain** | Pointer to **string** | Specifies the NetBIOS domain name associated with the machine account. | [optional] 
**NodeDcAffinity** | Pointer to **string** | Specifies the domain controller for which the node has affinity. | [optional] 
**NodeDcAffinityTimeout** | Pointer to **int32** | Specifies the timeout for the domain controller for which the local node has affinity. | [optional] 
**NssEnumeration** | Pointer to **bool** | Enables the Active Directory provider to respond to &#39;getpwent&#39; and &#39;getgrent&#39; requests. | [optional] 
**PrimaryDomain** | Pointer to **string** | Specifies the AD domain to which the provider is joined. | [optional] 
**RestrictFindable** | Pointer to **bool** | Check the provider for filtered lists of findable and unfindable users and groups. | [optional] 
**RpcCallTimeout** | Pointer to **int32** | The maximum amount of time (in seconds) an RPC call to Active Directory is allowed to take. | [optional] 
**ServerRetryLimit** | Pointer to **int32** | The number of retries attempted when a call to Active Directory fails due to network error. | [optional] 
**SfuSupport** | Pointer to **string** | Specifies whether to support RFC 2307 attributes on ADS domain controllers. | [optional] 
**Site** | Pointer to **string** | Specifies the site for the Active Directory. | [optional] 
**Status** | Pointer to **string** | Specifies the status of the provider. | [optional] 
**StoreSfuMappings** | Pointer to **bool** | Stores SFU mappings permanently in the ID mapper. | [optional] 
**System** | Pointer to **bool** | If set to true, indicates that this provider instance was created by OneFS and cannot be removed. | [optional] 
**UnfindableGroups** | Pointer to **[]string** | Specifies groups that cannot be resolved by the provider. | [optional] 
**UnfindableUsers** | Pointer to **[]string** | Specifies users that cannot be resolved by the provider. | [optional] 
**ZoneName** | Pointer to **string** | Specifies the name of the access zone in which this provider was created. | [optional] 

## Methods

### NewV14ProvidersAdsAdsItem

`func NewV14ProvidersAdsAdsItem() *V14ProvidersAdsAdsItem`

NewV14ProvidersAdsAdsItem instantiates a new V14ProvidersAdsAdsItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ProvidersAdsAdsItemWithDefaults

`func NewV14ProvidersAdsAdsItemWithDefaults() *V14ProvidersAdsAdsItem`

NewV14ProvidersAdsAdsItemWithDefaults instantiates a new V14ProvidersAdsAdsItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllocateGids

`func (o *V14ProvidersAdsAdsItem) GetAllocateGids() bool`

GetAllocateGids returns the AllocateGids field if non-nil, zero value otherwise.

### GetAllocateGidsOk

`func (o *V14ProvidersAdsAdsItem) GetAllocateGidsOk() (*bool, bool)`

GetAllocateGidsOk returns a tuple with the AllocateGids field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllocateGids

`func (o *V14ProvidersAdsAdsItem) SetAllocateGids(v bool)`

SetAllocateGids sets AllocateGids field to given value.

### HasAllocateGids

`func (o *V14ProvidersAdsAdsItem) HasAllocateGids() bool`

HasAllocateGids returns a boolean if a field has been set.

### GetAllocateUids

`func (o *V14ProvidersAdsAdsItem) GetAllocateUids() bool`

GetAllocateUids returns the AllocateUids field if non-nil, zero value otherwise.

### GetAllocateUidsOk

`func (o *V14ProvidersAdsAdsItem) GetAllocateUidsOk() (*bool, bool)`

GetAllocateUidsOk returns a tuple with the AllocateUids field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllocateUids

`func (o *V14ProvidersAdsAdsItem) SetAllocateUids(v bool)`

SetAllocateUids sets AllocateUids field to given value.

### HasAllocateUids

`func (o *V14ProvidersAdsAdsItem) HasAllocateUids() bool`

HasAllocateUids returns a boolean if a field has been set.

### GetAssumeDefaultDomain

`func (o *V14ProvidersAdsAdsItem) GetAssumeDefaultDomain() bool`

GetAssumeDefaultDomain returns the AssumeDefaultDomain field if non-nil, zero value otherwise.

### GetAssumeDefaultDomainOk

`func (o *V14ProvidersAdsAdsItem) GetAssumeDefaultDomainOk() (*bool, bool)`

GetAssumeDefaultDomainOk returns a tuple with the AssumeDefaultDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAssumeDefaultDomain

`func (o *V14ProvidersAdsAdsItem) SetAssumeDefaultDomain(v bool)`

SetAssumeDefaultDomain sets AssumeDefaultDomain field to given value.

### HasAssumeDefaultDomain

`func (o *V14ProvidersAdsAdsItem) HasAssumeDefaultDomain() bool`

HasAssumeDefaultDomain returns a boolean if a field has been set.

### GetAuthentication

`func (o *V14ProvidersAdsAdsItem) GetAuthentication() bool`

GetAuthentication returns the Authentication field if non-nil, zero value otherwise.

### GetAuthenticationOk

`func (o *V14ProvidersAdsAdsItem) GetAuthenticationOk() (*bool, bool)`

GetAuthenticationOk returns a tuple with the Authentication field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuthentication

`func (o *V14ProvidersAdsAdsItem) SetAuthentication(v bool)`

SetAuthentication sets Authentication field to given value.

### HasAuthentication

`func (o *V14ProvidersAdsAdsItem) HasAuthentication() bool`

HasAuthentication returns a boolean if a field has been set.

### GetCheckOnlineInterval

`func (o *V14ProvidersAdsAdsItem) GetCheckOnlineInterval() int32`

GetCheckOnlineInterval returns the CheckOnlineInterval field if non-nil, zero value otherwise.

### GetCheckOnlineIntervalOk

`func (o *V14ProvidersAdsAdsItem) GetCheckOnlineIntervalOk() (*int32, bool)`

GetCheckOnlineIntervalOk returns a tuple with the CheckOnlineInterval field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCheckOnlineInterval

`func (o *V14ProvidersAdsAdsItem) SetCheckOnlineInterval(v int32)`

SetCheckOnlineInterval sets CheckOnlineInterval field to given value.

### HasCheckOnlineInterval

`func (o *V14ProvidersAdsAdsItem) HasCheckOnlineInterval() bool`

HasCheckOnlineInterval returns a boolean if a field has been set.

### GetControllerTime

`func (o *V14ProvidersAdsAdsItem) GetControllerTime() int32`

GetControllerTime returns the ControllerTime field if non-nil, zero value otherwise.

### GetControllerTimeOk

`func (o *V14ProvidersAdsAdsItem) GetControllerTimeOk() (*int32, bool)`

GetControllerTimeOk returns a tuple with the ControllerTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetControllerTime

`func (o *V14ProvidersAdsAdsItem) SetControllerTime(v int32)`

SetControllerTime sets ControllerTime field to given value.

### HasControllerTime

`func (o *V14ProvidersAdsAdsItem) HasControllerTime() bool`

HasControllerTime returns a boolean if a field has been set.

### GetCreateHomeDirectory

`func (o *V14ProvidersAdsAdsItem) GetCreateHomeDirectory() bool`

GetCreateHomeDirectory returns the CreateHomeDirectory field if non-nil, zero value otherwise.

### GetCreateHomeDirectoryOk

`func (o *V14ProvidersAdsAdsItem) GetCreateHomeDirectoryOk() (*bool, bool)`

GetCreateHomeDirectoryOk returns a tuple with the CreateHomeDirectory field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateHomeDirectory

`func (o *V14ProvidersAdsAdsItem) SetCreateHomeDirectory(v bool)`

SetCreateHomeDirectory sets CreateHomeDirectory field to given value.

### HasCreateHomeDirectory

`func (o *V14ProvidersAdsAdsItem) HasCreateHomeDirectory() bool`

HasCreateHomeDirectory returns a boolean if a field has been set.

### GetDomainOfflineAlerts

`func (o *V14ProvidersAdsAdsItem) GetDomainOfflineAlerts() bool`

GetDomainOfflineAlerts returns the DomainOfflineAlerts field if non-nil, zero value otherwise.

### GetDomainOfflineAlertsOk

`func (o *V14ProvidersAdsAdsItem) GetDomainOfflineAlertsOk() (*bool, bool)`

GetDomainOfflineAlertsOk returns a tuple with the DomainOfflineAlerts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDomainOfflineAlerts

`func (o *V14ProvidersAdsAdsItem) SetDomainOfflineAlerts(v bool)`

SetDomainOfflineAlerts sets DomainOfflineAlerts field to given value.

### HasDomainOfflineAlerts

`func (o *V14ProvidersAdsAdsItem) HasDomainOfflineAlerts() bool`

HasDomainOfflineAlerts returns a boolean if a field has been set.

### GetDupSpns

`func (o *V14ProvidersAdsAdsItem) GetDupSpns() []string`

GetDupSpns returns the DupSpns field if non-nil, zero value otherwise.

### GetDupSpnsOk

`func (o *V14ProvidersAdsAdsItem) GetDupSpnsOk() (*[]string, bool)`

GetDupSpnsOk returns a tuple with the DupSpns field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDupSpns

`func (o *V14ProvidersAdsAdsItem) SetDupSpns(v []string)`

SetDupSpns sets DupSpns field to given value.

### HasDupSpns

`func (o *V14ProvidersAdsAdsItem) HasDupSpns() bool`

HasDupSpns returns a boolean if a field has been set.

### GetExtraExpectedSpns

`func (o *V14ProvidersAdsAdsItem) GetExtraExpectedSpns() []string`

GetExtraExpectedSpns returns the ExtraExpectedSpns field if non-nil, zero value otherwise.

### GetExtraExpectedSpnsOk

`func (o *V14ProvidersAdsAdsItem) GetExtraExpectedSpnsOk() (*[]string, bool)`

GetExtraExpectedSpnsOk returns a tuple with the ExtraExpectedSpns field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExtraExpectedSpns

`func (o *V14ProvidersAdsAdsItem) SetExtraExpectedSpns(v []string)`

SetExtraExpectedSpns sets ExtraExpectedSpns field to given value.

### HasExtraExpectedSpns

`func (o *V14ProvidersAdsAdsItem) HasExtraExpectedSpns() bool`

HasExtraExpectedSpns returns a boolean if a field has been set.

### GetFindableGroups

`func (o *V14ProvidersAdsAdsItem) GetFindableGroups() []string`

GetFindableGroups returns the FindableGroups field if non-nil, zero value otherwise.

### GetFindableGroupsOk

`func (o *V14ProvidersAdsAdsItem) GetFindableGroupsOk() (*[]string, bool)`

GetFindableGroupsOk returns a tuple with the FindableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFindableGroups

`func (o *V14ProvidersAdsAdsItem) SetFindableGroups(v []string)`

SetFindableGroups sets FindableGroups field to given value.

### HasFindableGroups

`func (o *V14ProvidersAdsAdsItem) HasFindableGroups() bool`

HasFindableGroups returns a boolean if a field has been set.

### GetFindableUsers

`func (o *V14ProvidersAdsAdsItem) GetFindableUsers() []string`

GetFindableUsers returns the FindableUsers field if non-nil, zero value otherwise.

### GetFindableUsersOk

`func (o *V14ProvidersAdsAdsItem) GetFindableUsersOk() (*[]string, bool)`

GetFindableUsersOk returns a tuple with the FindableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFindableUsers

`func (o *V14ProvidersAdsAdsItem) SetFindableUsers(v []string)`

SetFindableUsers sets FindableUsers field to given value.

### HasFindableUsers

`func (o *V14ProvidersAdsAdsItem) HasFindableUsers() bool`

HasFindableUsers returns a boolean if a field has been set.

### GetForest

`func (o *V14ProvidersAdsAdsItem) GetForest() string`

GetForest returns the Forest field if non-nil, zero value otherwise.

### GetForestOk

`func (o *V14ProvidersAdsAdsItem) GetForestOk() (*string, bool)`

GetForestOk returns a tuple with the Forest field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForest

`func (o *V14ProvidersAdsAdsItem) SetForest(v string)`

SetForest sets Forest field to given value.

### HasForest

`func (o *V14ProvidersAdsAdsItem) HasForest() bool`

HasForest returns a boolean if a field has been set.

### GetGroupnet

`func (o *V14ProvidersAdsAdsItem) GetGroupnet() string`

GetGroupnet returns the Groupnet field if non-nil, zero value otherwise.

### GetGroupnetOk

`func (o *V14ProvidersAdsAdsItem) GetGroupnetOk() (*string, bool)`

GetGroupnetOk returns a tuple with the Groupnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupnet

`func (o *V14ProvidersAdsAdsItem) SetGroupnet(v string)`

SetGroupnet sets Groupnet field to given value.

### HasGroupnet

`func (o *V14ProvidersAdsAdsItem) HasGroupnet() bool`

HasGroupnet returns a boolean if a field has been set.

### GetHomeDirectoryTemplate

`func (o *V14ProvidersAdsAdsItem) GetHomeDirectoryTemplate() string`

GetHomeDirectoryTemplate returns the HomeDirectoryTemplate field if non-nil, zero value otherwise.

### GetHomeDirectoryTemplateOk

`func (o *V14ProvidersAdsAdsItem) GetHomeDirectoryTemplateOk() (*string, bool)`

GetHomeDirectoryTemplateOk returns a tuple with the HomeDirectoryTemplate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHomeDirectoryTemplate

`func (o *V14ProvidersAdsAdsItem) SetHomeDirectoryTemplate(v string)`

SetHomeDirectoryTemplate sets HomeDirectoryTemplate field to given value.

### HasHomeDirectoryTemplate

`func (o *V14ProvidersAdsAdsItem) HasHomeDirectoryTemplate() bool`

HasHomeDirectoryTemplate returns a boolean if a field has been set.

### GetHostname

`func (o *V14ProvidersAdsAdsItem) GetHostname() string`

GetHostname returns the Hostname field if non-nil, zero value otherwise.

### GetHostnameOk

`func (o *V14ProvidersAdsAdsItem) GetHostnameOk() (*string, bool)`

GetHostnameOk returns a tuple with the Hostname field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostname

`func (o *V14ProvidersAdsAdsItem) SetHostname(v string)`

SetHostname sets Hostname field to given value.

### HasHostname

`func (o *V14ProvidersAdsAdsItem) HasHostname() bool`

HasHostname returns a boolean if a field has been set.

### GetId

`func (o *V14ProvidersAdsAdsItem) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V14ProvidersAdsAdsItem) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V14ProvidersAdsAdsItem) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V14ProvidersAdsAdsItem) HasId() bool`

HasId returns a boolean if a field has been set.

### GetIgnoreAllTrusts

`func (o *V14ProvidersAdsAdsItem) GetIgnoreAllTrusts() bool`

GetIgnoreAllTrusts returns the IgnoreAllTrusts field if non-nil, zero value otherwise.

### GetIgnoreAllTrustsOk

`func (o *V14ProvidersAdsAdsItem) GetIgnoreAllTrustsOk() (*bool, bool)`

GetIgnoreAllTrustsOk returns a tuple with the IgnoreAllTrusts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoreAllTrusts

`func (o *V14ProvidersAdsAdsItem) SetIgnoreAllTrusts(v bool)`

SetIgnoreAllTrusts sets IgnoreAllTrusts field to given value.

### HasIgnoreAllTrusts

`func (o *V14ProvidersAdsAdsItem) HasIgnoreAllTrusts() bool`

HasIgnoreAllTrusts returns a boolean if a field has been set.

### GetIgnoredTrustedDomains

`func (o *V14ProvidersAdsAdsItem) GetIgnoredTrustedDomains() []string`

GetIgnoredTrustedDomains returns the IgnoredTrustedDomains field if non-nil, zero value otherwise.

### GetIgnoredTrustedDomainsOk

`func (o *V14ProvidersAdsAdsItem) GetIgnoredTrustedDomainsOk() (*[]string, bool)`

GetIgnoredTrustedDomainsOk returns a tuple with the IgnoredTrustedDomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoredTrustedDomains

`func (o *V14ProvidersAdsAdsItem) SetIgnoredTrustedDomains(v []string)`

SetIgnoredTrustedDomains sets IgnoredTrustedDomains field to given value.

### HasIgnoredTrustedDomains

`func (o *V14ProvidersAdsAdsItem) HasIgnoredTrustedDomains() bool`

HasIgnoredTrustedDomains returns a boolean if a field has been set.

### GetIncludeTrustedDomains

`func (o *V14ProvidersAdsAdsItem) GetIncludeTrustedDomains() []string`

GetIncludeTrustedDomains returns the IncludeTrustedDomains field if non-nil, zero value otherwise.

### GetIncludeTrustedDomainsOk

`func (o *V14ProvidersAdsAdsItem) GetIncludeTrustedDomainsOk() (*[]string, bool)`

GetIncludeTrustedDomainsOk returns a tuple with the IncludeTrustedDomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeTrustedDomains

`func (o *V14ProvidersAdsAdsItem) SetIncludeTrustedDomains(v []string)`

SetIncludeTrustedDomains sets IncludeTrustedDomains field to given value.

### HasIncludeTrustedDomains

`func (o *V14ProvidersAdsAdsItem) HasIncludeTrustedDomains() bool`

HasIncludeTrustedDomains returns a boolean if a field has been set.

### GetInstance

`func (o *V14ProvidersAdsAdsItem) GetInstance() string`

GetInstance returns the Instance field if non-nil, zero value otherwise.

### GetInstanceOk

`func (o *V14ProvidersAdsAdsItem) GetInstanceOk() (*string, bool)`

GetInstanceOk returns a tuple with the Instance field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstance

`func (o *V14ProvidersAdsAdsItem) SetInstance(v string)`

SetInstance sets Instance field to given value.

### HasInstance

`func (o *V14ProvidersAdsAdsItem) HasInstance() bool`

HasInstance returns a boolean if a field has been set.

### GetLdapSignAndSeal

`func (o *V14ProvidersAdsAdsItem) GetLdapSignAndSeal() bool`

GetLdapSignAndSeal returns the LdapSignAndSeal field if non-nil, zero value otherwise.

### GetLdapSignAndSealOk

`func (o *V14ProvidersAdsAdsItem) GetLdapSignAndSealOk() (*bool, bool)`

GetLdapSignAndSealOk returns a tuple with the LdapSignAndSeal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLdapSignAndSeal

`func (o *V14ProvidersAdsAdsItem) SetLdapSignAndSeal(v bool)`

SetLdapSignAndSeal sets LdapSignAndSeal field to given value.

### HasLdapSignAndSeal

`func (o *V14ProvidersAdsAdsItem) HasLdapSignAndSeal() bool`

HasLdapSignAndSeal returns a boolean if a field has been set.

### GetLoginShell

`func (o *V14ProvidersAdsAdsItem) GetLoginShell() string`

GetLoginShell returns the LoginShell field if non-nil, zero value otherwise.

### GetLoginShellOk

`func (o *V14ProvidersAdsAdsItem) GetLoginShellOk() (*string, bool)`

GetLoginShellOk returns a tuple with the LoginShell field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLoginShell

`func (o *V14ProvidersAdsAdsItem) SetLoginShell(v string)`

SetLoginShell sets LoginShell field to given value.

### HasLoginShell

`func (o *V14ProvidersAdsAdsItem) HasLoginShell() bool`

HasLoginShell returns a boolean if a field has been set.

### GetLookupDomains

`func (o *V14ProvidersAdsAdsItem) GetLookupDomains() []string`

GetLookupDomains returns the LookupDomains field if non-nil, zero value otherwise.

### GetLookupDomainsOk

`func (o *V14ProvidersAdsAdsItem) GetLookupDomainsOk() (*[]string, bool)`

GetLookupDomainsOk returns a tuple with the LookupDomains field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupDomains

`func (o *V14ProvidersAdsAdsItem) SetLookupDomains(v []string)`

SetLookupDomains sets LookupDomains field to given value.

### HasLookupDomains

`func (o *V14ProvidersAdsAdsItem) HasLookupDomains() bool`

HasLookupDomains returns a boolean if a field has been set.

### GetLookupGroups

`func (o *V14ProvidersAdsAdsItem) GetLookupGroups() bool`

GetLookupGroups returns the LookupGroups field if non-nil, zero value otherwise.

### GetLookupGroupsOk

`func (o *V14ProvidersAdsAdsItem) GetLookupGroupsOk() (*bool, bool)`

GetLookupGroupsOk returns a tuple with the LookupGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupGroups

`func (o *V14ProvidersAdsAdsItem) SetLookupGroups(v bool)`

SetLookupGroups sets LookupGroups field to given value.

### HasLookupGroups

`func (o *V14ProvidersAdsAdsItem) HasLookupGroups() bool`

HasLookupGroups returns a boolean if a field has been set.

### GetLookupNormalizeGroups

`func (o *V14ProvidersAdsAdsItem) GetLookupNormalizeGroups() bool`

GetLookupNormalizeGroups returns the LookupNormalizeGroups field if non-nil, zero value otherwise.

### GetLookupNormalizeGroupsOk

`func (o *V14ProvidersAdsAdsItem) GetLookupNormalizeGroupsOk() (*bool, bool)`

GetLookupNormalizeGroupsOk returns a tuple with the LookupNormalizeGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupNormalizeGroups

`func (o *V14ProvidersAdsAdsItem) SetLookupNormalizeGroups(v bool)`

SetLookupNormalizeGroups sets LookupNormalizeGroups field to given value.

### HasLookupNormalizeGroups

`func (o *V14ProvidersAdsAdsItem) HasLookupNormalizeGroups() bool`

HasLookupNormalizeGroups returns a boolean if a field has been set.

### GetLookupNormalizeUsers

`func (o *V14ProvidersAdsAdsItem) GetLookupNormalizeUsers() bool`

GetLookupNormalizeUsers returns the LookupNormalizeUsers field if non-nil, zero value otherwise.

### GetLookupNormalizeUsersOk

`func (o *V14ProvidersAdsAdsItem) GetLookupNormalizeUsersOk() (*bool, bool)`

GetLookupNormalizeUsersOk returns a tuple with the LookupNormalizeUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupNormalizeUsers

`func (o *V14ProvidersAdsAdsItem) SetLookupNormalizeUsers(v bool)`

SetLookupNormalizeUsers sets LookupNormalizeUsers field to given value.

### HasLookupNormalizeUsers

`func (o *V14ProvidersAdsAdsItem) HasLookupNormalizeUsers() bool`

HasLookupNormalizeUsers returns a boolean if a field has been set.

### GetLookupUsers

`func (o *V14ProvidersAdsAdsItem) GetLookupUsers() bool`

GetLookupUsers returns the LookupUsers field if non-nil, zero value otherwise.

### GetLookupUsersOk

`func (o *V14ProvidersAdsAdsItem) GetLookupUsersOk() (*bool, bool)`

GetLookupUsersOk returns a tuple with the LookupUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLookupUsers

`func (o *V14ProvidersAdsAdsItem) SetLookupUsers(v bool)`

SetLookupUsers sets LookupUsers field to given value.

### HasLookupUsers

`func (o *V14ProvidersAdsAdsItem) HasLookupUsers() bool`

HasLookupUsers returns a boolean if a field has been set.

### GetMachineAccount

`func (o *V14ProvidersAdsAdsItem) GetMachineAccount() string`

GetMachineAccount returns the MachineAccount field if non-nil, zero value otherwise.

### GetMachineAccountOk

`func (o *V14ProvidersAdsAdsItem) GetMachineAccountOk() (*string, bool)`

GetMachineAccountOk returns a tuple with the MachineAccount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMachineAccount

`func (o *V14ProvidersAdsAdsItem) SetMachineAccount(v string)`

SetMachineAccount sets MachineAccount field to given value.

### HasMachineAccount

`func (o *V14ProvidersAdsAdsItem) HasMachineAccount() bool`

HasMachineAccount returns a boolean if a field has been set.

### GetMachinePasswordChanges

`func (o *V14ProvidersAdsAdsItem) GetMachinePasswordChanges() bool`

GetMachinePasswordChanges returns the MachinePasswordChanges field if non-nil, zero value otherwise.

### GetMachinePasswordChangesOk

`func (o *V14ProvidersAdsAdsItem) GetMachinePasswordChangesOk() (*bool, bool)`

GetMachinePasswordChangesOk returns a tuple with the MachinePasswordChanges field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMachinePasswordChanges

`func (o *V14ProvidersAdsAdsItem) SetMachinePasswordChanges(v bool)`

SetMachinePasswordChanges sets MachinePasswordChanges field to given value.

### HasMachinePasswordChanges

`func (o *V14ProvidersAdsAdsItem) HasMachinePasswordChanges() bool`

HasMachinePasswordChanges returns a boolean if a field has been set.

### GetMachinePasswordLifespan

`func (o *V14ProvidersAdsAdsItem) GetMachinePasswordLifespan() int32`

GetMachinePasswordLifespan returns the MachinePasswordLifespan field if non-nil, zero value otherwise.

### GetMachinePasswordLifespanOk

`func (o *V14ProvidersAdsAdsItem) GetMachinePasswordLifespanOk() (*int32, bool)`

GetMachinePasswordLifespanOk returns a tuple with the MachinePasswordLifespan field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMachinePasswordLifespan

`func (o *V14ProvidersAdsAdsItem) SetMachinePasswordLifespan(v int32)`

SetMachinePasswordLifespan sets MachinePasswordLifespan field to given value.

### HasMachinePasswordLifespan

`func (o *V14ProvidersAdsAdsItem) HasMachinePasswordLifespan() bool`

HasMachinePasswordLifespan returns a boolean if a field has been set.

### GetName

`func (o *V14ProvidersAdsAdsItem) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V14ProvidersAdsAdsItem) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V14ProvidersAdsAdsItem) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V14ProvidersAdsAdsItem) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNetbiosDomain

`func (o *V14ProvidersAdsAdsItem) GetNetbiosDomain() string`

GetNetbiosDomain returns the NetbiosDomain field if non-nil, zero value otherwise.

### GetNetbiosDomainOk

`func (o *V14ProvidersAdsAdsItem) GetNetbiosDomainOk() (*string, bool)`

GetNetbiosDomainOk returns a tuple with the NetbiosDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNetbiosDomain

`func (o *V14ProvidersAdsAdsItem) SetNetbiosDomain(v string)`

SetNetbiosDomain sets NetbiosDomain field to given value.

### HasNetbiosDomain

`func (o *V14ProvidersAdsAdsItem) HasNetbiosDomain() bool`

HasNetbiosDomain returns a boolean if a field has been set.

### GetNodeDcAffinity

`func (o *V14ProvidersAdsAdsItem) GetNodeDcAffinity() string`

GetNodeDcAffinity returns the NodeDcAffinity field if non-nil, zero value otherwise.

### GetNodeDcAffinityOk

`func (o *V14ProvidersAdsAdsItem) GetNodeDcAffinityOk() (*string, bool)`

GetNodeDcAffinityOk returns a tuple with the NodeDcAffinity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeDcAffinity

`func (o *V14ProvidersAdsAdsItem) SetNodeDcAffinity(v string)`

SetNodeDcAffinity sets NodeDcAffinity field to given value.

### HasNodeDcAffinity

`func (o *V14ProvidersAdsAdsItem) HasNodeDcAffinity() bool`

HasNodeDcAffinity returns a boolean if a field has been set.

### GetNodeDcAffinityTimeout

`func (o *V14ProvidersAdsAdsItem) GetNodeDcAffinityTimeout() int32`

GetNodeDcAffinityTimeout returns the NodeDcAffinityTimeout field if non-nil, zero value otherwise.

### GetNodeDcAffinityTimeoutOk

`func (o *V14ProvidersAdsAdsItem) GetNodeDcAffinityTimeoutOk() (*int32, bool)`

GetNodeDcAffinityTimeoutOk returns a tuple with the NodeDcAffinityTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodeDcAffinityTimeout

`func (o *V14ProvidersAdsAdsItem) SetNodeDcAffinityTimeout(v int32)`

SetNodeDcAffinityTimeout sets NodeDcAffinityTimeout field to given value.

### HasNodeDcAffinityTimeout

`func (o *V14ProvidersAdsAdsItem) HasNodeDcAffinityTimeout() bool`

HasNodeDcAffinityTimeout returns a boolean if a field has been set.

### GetNssEnumeration

`func (o *V14ProvidersAdsAdsItem) GetNssEnumeration() bool`

GetNssEnumeration returns the NssEnumeration field if non-nil, zero value otherwise.

### GetNssEnumerationOk

`func (o *V14ProvidersAdsAdsItem) GetNssEnumerationOk() (*bool, bool)`

GetNssEnumerationOk returns a tuple with the NssEnumeration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNssEnumeration

`func (o *V14ProvidersAdsAdsItem) SetNssEnumeration(v bool)`

SetNssEnumeration sets NssEnumeration field to given value.

### HasNssEnumeration

`func (o *V14ProvidersAdsAdsItem) HasNssEnumeration() bool`

HasNssEnumeration returns a boolean if a field has been set.

### GetPrimaryDomain

`func (o *V14ProvidersAdsAdsItem) GetPrimaryDomain() string`

GetPrimaryDomain returns the PrimaryDomain field if non-nil, zero value otherwise.

### GetPrimaryDomainOk

`func (o *V14ProvidersAdsAdsItem) GetPrimaryDomainOk() (*string, bool)`

GetPrimaryDomainOk returns a tuple with the PrimaryDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrimaryDomain

`func (o *V14ProvidersAdsAdsItem) SetPrimaryDomain(v string)`

SetPrimaryDomain sets PrimaryDomain field to given value.

### HasPrimaryDomain

`func (o *V14ProvidersAdsAdsItem) HasPrimaryDomain() bool`

HasPrimaryDomain returns a boolean if a field has been set.

### GetRestrictFindable

`func (o *V14ProvidersAdsAdsItem) GetRestrictFindable() bool`

GetRestrictFindable returns the RestrictFindable field if non-nil, zero value otherwise.

### GetRestrictFindableOk

`func (o *V14ProvidersAdsAdsItem) GetRestrictFindableOk() (*bool, bool)`

GetRestrictFindableOk returns a tuple with the RestrictFindable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRestrictFindable

`func (o *V14ProvidersAdsAdsItem) SetRestrictFindable(v bool)`

SetRestrictFindable sets RestrictFindable field to given value.

### HasRestrictFindable

`func (o *V14ProvidersAdsAdsItem) HasRestrictFindable() bool`

HasRestrictFindable returns a boolean if a field has been set.

### GetRpcCallTimeout

`func (o *V14ProvidersAdsAdsItem) GetRpcCallTimeout() int32`

GetRpcCallTimeout returns the RpcCallTimeout field if non-nil, zero value otherwise.

### GetRpcCallTimeoutOk

`func (o *V14ProvidersAdsAdsItem) GetRpcCallTimeoutOk() (*int32, bool)`

GetRpcCallTimeoutOk returns a tuple with the RpcCallTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRpcCallTimeout

`func (o *V14ProvidersAdsAdsItem) SetRpcCallTimeout(v int32)`

SetRpcCallTimeout sets RpcCallTimeout field to given value.

### HasRpcCallTimeout

`func (o *V14ProvidersAdsAdsItem) HasRpcCallTimeout() bool`

HasRpcCallTimeout returns a boolean if a field has been set.

### GetServerRetryLimit

`func (o *V14ProvidersAdsAdsItem) GetServerRetryLimit() int32`

GetServerRetryLimit returns the ServerRetryLimit field if non-nil, zero value otherwise.

### GetServerRetryLimitOk

`func (o *V14ProvidersAdsAdsItem) GetServerRetryLimitOk() (*int32, bool)`

GetServerRetryLimitOk returns a tuple with the ServerRetryLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerRetryLimit

`func (o *V14ProvidersAdsAdsItem) SetServerRetryLimit(v int32)`

SetServerRetryLimit sets ServerRetryLimit field to given value.

### HasServerRetryLimit

`func (o *V14ProvidersAdsAdsItem) HasServerRetryLimit() bool`

HasServerRetryLimit returns a boolean if a field has been set.

### GetSfuSupport

`func (o *V14ProvidersAdsAdsItem) GetSfuSupport() string`

GetSfuSupport returns the SfuSupport field if non-nil, zero value otherwise.

### GetSfuSupportOk

`func (o *V14ProvidersAdsAdsItem) GetSfuSupportOk() (*string, bool)`

GetSfuSupportOk returns a tuple with the SfuSupport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSfuSupport

`func (o *V14ProvidersAdsAdsItem) SetSfuSupport(v string)`

SetSfuSupport sets SfuSupport field to given value.

### HasSfuSupport

`func (o *V14ProvidersAdsAdsItem) HasSfuSupport() bool`

HasSfuSupport returns a boolean if a field has been set.

### GetSite

`func (o *V14ProvidersAdsAdsItem) GetSite() string`

GetSite returns the Site field if non-nil, zero value otherwise.

### GetSiteOk

`func (o *V14ProvidersAdsAdsItem) GetSiteOk() (*string, bool)`

GetSiteOk returns a tuple with the Site field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSite

`func (o *V14ProvidersAdsAdsItem) SetSite(v string)`

SetSite sets Site field to given value.

### HasSite

`func (o *V14ProvidersAdsAdsItem) HasSite() bool`

HasSite returns a boolean if a field has been set.

### GetStatus

`func (o *V14ProvidersAdsAdsItem) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V14ProvidersAdsAdsItem) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V14ProvidersAdsAdsItem) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V14ProvidersAdsAdsItem) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetStoreSfuMappings

`func (o *V14ProvidersAdsAdsItem) GetStoreSfuMappings() bool`

GetStoreSfuMappings returns the StoreSfuMappings field if non-nil, zero value otherwise.

### GetStoreSfuMappingsOk

`func (o *V14ProvidersAdsAdsItem) GetStoreSfuMappingsOk() (*bool, bool)`

GetStoreSfuMappingsOk returns a tuple with the StoreSfuMappings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStoreSfuMappings

`func (o *V14ProvidersAdsAdsItem) SetStoreSfuMappings(v bool)`

SetStoreSfuMappings sets StoreSfuMappings field to given value.

### HasStoreSfuMappings

`func (o *V14ProvidersAdsAdsItem) HasStoreSfuMappings() bool`

HasStoreSfuMappings returns a boolean if a field has been set.

### GetSystem

`func (o *V14ProvidersAdsAdsItem) GetSystem() bool`

GetSystem returns the System field if non-nil, zero value otherwise.

### GetSystemOk

`func (o *V14ProvidersAdsAdsItem) GetSystemOk() (*bool, bool)`

GetSystemOk returns a tuple with the System field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystem

`func (o *V14ProvidersAdsAdsItem) SetSystem(v bool)`

SetSystem sets System field to given value.

### HasSystem

`func (o *V14ProvidersAdsAdsItem) HasSystem() bool`

HasSystem returns a boolean if a field has been set.

### GetUnfindableGroups

`func (o *V14ProvidersAdsAdsItem) GetUnfindableGroups() []string`

GetUnfindableGroups returns the UnfindableGroups field if non-nil, zero value otherwise.

### GetUnfindableGroupsOk

`func (o *V14ProvidersAdsAdsItem) GetUnfindableGroupsOk() (*[]string, bool)`

GetUnfindableGroupsOk returns a tuple with the UnfindableGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnfindableGroups

`func (o *V14ProvidersAdsAdsItem) SetUnfindableGroups(v []string)`

SetUnfindableGroups sets UnfindableGroups field to given value.

### HasUnfindableGroups

`func (o *V14ProvidersAdsAdsItem) HasUnfindableGroups() bool`

HasUnfindableGroups returns a boolean if a field has been set.

### GetUnfindableUsers

`func (o *V14ProvidersAdsAdsItem) GetUnfindableUsers() []string`

GetUnfindableUsers returns the UnfindableUsers field if non-nil, zero value otherwise.

### GetUnfindableUsersOk

`func (o *V14ProvidersAdsAdsItem) GetUnfindableUsersOk() (*[]string, bool)`

GetUnfindableUsersOk returns a tuple with the UnfindableUsers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnfindableUsers

`func (o *V14ProvidersAdsAdsItem) SetUnfindableUsers(v []string)`

SetUnfindableUsers sets UnfindableUsers field to given value.

### HasUnfindableUsers

`func (o *V14ProvidersAdsAdsItem) HasUnfindableUsers() bool`

HasUnfindableUsers returns a boolean if a field has been set.

### GetZoneName

`func (o *V14ProvidersAdsAdsItem) GetZoneName() string`

GetZoneName returns the ZoneName field if non-nil, zero value otherwise.

### GetZoneNameOk

`func (o *V14ProvidersAdsAdsItem) GetZoneNameOk() (*string, bool)`

GetZoneNameOk returns a tuple with the ZoneName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZoneName

`func (o *V14ProvidersAdsAdsItem) SetZoneName(v string)`

SetZoneName sets ZoneName field to given value.

### HasZoneName

`func (o *V14ProvidersAdsAdsItem) HasZoneName() bool`

HasZoneName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


