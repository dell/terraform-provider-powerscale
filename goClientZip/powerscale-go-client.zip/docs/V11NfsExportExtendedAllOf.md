# V11NfsExportExtendedAllOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ConflictingPaths** | Pointer to **[]string** | Reports the paths that conflict with another export. | [optional] 
**Id** | Pointer to **int32** | Specifies the system-assigned ID for the export. This ID is returned when an export is created through the POST method. | [optional] 
**UnresolvedClients** | Pointer to **[]string** | Reports clients that cannot be resolved. | [optional] 
**Zone** | Pointer to **string** | Specifies the zone in which the export is valid. | [optional] 

## Methods

### NewV11NfsExportExtendedAllOf

`func NewV11NfsExportExtendedAllOf() *V11NfsExportExtendedAllOf`

NewV11NfsExportExtendedAllOf instantiates a new V11NfsExportExtendedAllOf object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11NfsExportExtendedAllOfWithDefaults

`func NewV11NfsExportExtendedAllOfWithDefaults() *V11NfsExportExtendedAllOf`

NewV11NfsExportExtendedAllOfWithDefaults instantiates a new V11NfsExportExtendedAllOf object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetConflictingPaths

`func (o *V11NfsExportExtendedAllOf) GetConflictingPaths() []string`

GetConflictingPaths returns the ConflictingPaths field if non-nil, zero value otherwise.

### GetConflictingPathsOk

`func (o *V11NfsExportExtendedAllOf) GetConflictingPathsOk() (*[]string, bool)`

GetConflictingPathsOk returns a tuple with the ConflictingPaths field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConflictingPaths

`func (o *V11NfsExportExtendedAllOf) SetConflictingPaths(v []string)`

SetConflictingPaths sets ConflictingPaths field to given value.

### HasConflictingPaths

`func (o *V11NfsExportExtendedAllOf) HasConflictingPaths() bool`

HasConflictingPaths returns a boolean if a field has been set.

### GetId

`func (o *V11NfsExportExtendedAllOf) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11NfsExportExtendedAllOf) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11NfsExportExtendedAllOf) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V11NfsExportExtendedAllOf) HasId() bool`

HasId returns a boolean if a field has been set.

### GetUnresolvedClients

`func (o *V11NfsExportExtendedAllOf) GetUnresolvedClients() []string`

GetUnresolvedClients returns the UnresolvedClients field if non-nil, zero value otherwise.

### GetUnresolvedClientsOk

`func (o *V11NfsExportExtendedAllOf) GetUnresolvedClientsOk() (*[]string, bool)`

GetUnresolvedClientsOk returns a tuple with the UnresolvedClients field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnresolvedClients

`func (o *V11NfsExportExtendedAllOf) SetUnresolvedClients(v []string)`

SetUnresolvedClients sets UnresolvedClients field to given value.

### HasUnresolvedClients

`func (o *V11NfsExportExtendedAllOf) HasUnresolvedClients() bool`

HasUnresolvedClients returns a boolean if a field has been set.

### GetZone

`func (o *V11NfsExportExtendedAllOf) GetZone() string`

GetZone returns the Zone field if non-nil, zero value otherwise.

### GetZoneOk

`func (o *V11NfsExportExtendedAllOf) GetZoneOk() (*string, bool)`

GetZoneOk returns a tuple with the Zone field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZone

`func (o *V11NfsExportExtendedAllOf) SetZone(v string)`

SetZone sets Zone field to given value.

### HasZone

`func (o *V11NfsExportExtendedAllOf) HasZone() bool`

HasZone returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


