# V12SubnetsSubnetPoolIface

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Iface** | Pointer to **string** | A string that defines an interface name. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 

## Methods

### NewV12SubnetsSubnetPoolIface

`func NewV12SubnetsSubnetPoolIface() *V12SubnetsSubnetPoolIface`

NewV12SubnetsSubnetPoolIface instantiates a new V12SubnetsSubnetPoolIface object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SubnetsSubnetPoolIfaceWithDefaults

`func NewV12SubnetsSubnetPoolIfaceWithDefaults() *V12SubnetsSubnetPoolIface`

NewV12SubnetsSubnetPoolIfaceWithDefaults instantiates a new V12SubnetsSubnetPoolIface object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIface

`func (o *V12SubnetsSubnetPoolIface) GetIface() string`

GetIface returns the Iface field if non-nil, zero value otherwise.

### GetIfaceOk

`func (o *V12SubnetsSubnetPoolIface) GetIfaceOk() (*string, bool)`

GetIfaceOk returns a tuple with the Iface field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIface

`func (o *V12SubnetsSubnetPoolIface) SetIface(v string)`

SetIface sets Iface field to given value.

### HasIface

`func (o *V12SubnetsSubnetPoolIface) HasIface() bool`

HasIface returns a boolean if a field has been set.

### GetLnn

`func (o *V12SubnetsSubnetPoolIface) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12SubnetsSubnetPoolIface) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12SubnetsSubnetPoolIface) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V12SubnetsSubnetPoolIface) HasLnn() bool`

HasLnn returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


