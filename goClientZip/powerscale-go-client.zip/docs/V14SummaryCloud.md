# V14SummaryCloud

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Cloud** | Pointer to [**[]V14SummaryCloudCloudItem**](V14SummaryCloudCloudItem.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV14SummaryCloud

`func NewV14SummaryCloud() *V14SummaryCloud`

NewV14SummaryCloud instantiates a new V14SummaryCloud object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SummaryCloudWithDefaults

`func NewV14SummaryCloudWithDefaults() *V14SummaryCloud`

NewV14SummaryCloudWithDefaults instantiates a new V14SummaryCloud object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloud

`func (o *V14SummaryCloud) GetCloud() []V14SummaryCloudCloudItem`

GetCloud returns the Cloud field if non-nil, zero value otherwise.

### GetCloudOk

`func (o *V14SummaryCloud) GetCloudOk() (*[]V14SummaryCloudCloudItem, bool)`

GetCloudOk returns a tuple with the Cloud field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloud

`func (o *V14SummaryCloud) SetCloud(v []V14SummaryCloudCloudItem)`

SetCloud sets Cloud field to given value.

### HasCloud

`func (o *V14SummaryCloud) HasCloud() bool`

HasCloud returns a boolean if a field has been set.

### GetResume

`func (o *V14SummaryCloud) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V14SummaryCloud) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V14SummaryCloud) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V14SummaryCloud) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V14SummaryCloud) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V14SummaryCloud) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V14SummaryCloud) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V14SummaryCloud) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


