# V12StoragepoolNodetype

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | The system ID given to the nodetype. | 
**Manual** | **bool** | Whether or not the nodetype is in a manually managed node pool. | 
**Nodes** | **[]int32** | The nodes that are part of this nodetype. | 
**ProductName** | **string** | The product name of the node type. | 

## Methods

### NewV12StoragepoolNodetype

`func NewV12StoragepoolNodetype(id int32, manual bool, nodes []int32, productName string, ) *V12StoragepoolNodetype`

NewV12StoragepoolNodetype instantiates a new V12StoragepoolNodetype object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12StoragepoolNodetypeWithDefaults

`func NewV12StoragepoolNodetypeWithDefaults() *V12StoragepoolNodetype`

NewV12StoragepoolNodetypeWithDefaults instantiates a new V12StoragepoolNodetype object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *V12StoragepoolNodetype) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12StoragepoolNodetype) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12StoragepoolNodetype) SetId(v int32)`

SetId sets Id field to given value.


### GetManual

`func (o *V12StoragepoolNodetype) GetManual() bool`

GetManual returns the Manual field if non-nil, zero value otherwise.

### GetManualOk

`func (o *V12StoragepoolNodetype) GetManualOk() (*bool, bool)`

GetManualOk returns a tuple with the Manual field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetManual

`func (o *V12StoragepoolNodetype) SetManual(v bool)`

SetManual sets Manual field to given value.


### GetNodes

`func (o *V12StoragepoolNodetype) GetNodes() []int32`

GetNodes returns the Nodes field if non-nil, zero value otherwise.

### GetNodesOk

`func (o *V12StoragepoolNodetype) GetNodesOk() (*[]int32, bool)`

GetNodesOk returns a tuple with the Nodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodes

`func (o *V12StoragepoolNodetype) SetNodes(v []int32)`

SetNodes sets Nodes field to given value.


### GetProductName

`func (o *V12StoragepoolNodetype) GetProductName() string`

GetProductName returns the ProductName field if non-nil, zero value otherwise.

### GetProductNameOk

`func (o *V12StoragepoolNodetype) GetProductNameOk() (*string, bool)`

GetProductNameOk returns a tuple with the ProductName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProductName

`func (o *V12StoragepoolNodetype) SetProductName(v string)`

SetProductName sets ProductName field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


