# V12EventEventgroupDefinitionsEventgroupDefinition

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Category** | Pointer to **string** | ID of eventgroup category: all, 100000000 (SYS_DISK_EVENTS), 200000000 (NODE_STATUS_EVENTS), 300000000 (REBOOT_EVENTS), 400000000 (SW_EVENTS), 500000000 (QUOTA_EVENTS), 600000000 (SNAP_EVENTS), 700000000 (WINNET_EVENTS), 800000000 (FILESYS_EVENTS), 900000000 (HW_EVENTS), 1100000000 (CPOOL_EVENTS). | [optional] 
**Channels** | Pointer to **[]int32** | Channels by which this eventgroup type can be alerted. | [optional] 
**Description** | Pointer to **string** | Human readable description - may contain value placeholders. | [optional] 
**Id** | Pointer to **string** | Unique Identifier. | [optional] 
**Name** | Pointer to **string** | Name for eventgroup. | [optional] 
**NoIgnore** | Pointer to **bool** | True if event should not be ignored. | [optional] 
**Node** | Pointer to **bool** | True if this eventgroup type is node specific, false cluster wide. | [optional] 
**Rules** | Pointer to **[]string** | Alert rules involving this eventgroup type. | [optional] 
**Suppressed** | Pointer to **bool** | True if alerting is suppressed for this eventgroup type. | [optional] 

## Methods

### NewV12EventEventgroupDefinitionsEventgroupDefinition

`func NewV12EventEventgroupDefinitionsEventgroupDefinition() *V12EventEventgroupDefinitionsEventgroupDefinition`

NewV12EventEventgroupDefinitionsEventgroupDefinition instantiates a new V12EventEventgroupDefinitionsEventgroupDefinition object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventEventgroupDefinitionsEventgroupDefinitionWithDefaults

`func NewV12EventEventgroupDefinitionsEventgroupDefinitionWithDefaults() *V12EventEventgroupDefinitionsEventgroupDefinition`

NewV12EventEventgroupDefinitionsEventgroupDefinitionWithDefaults instantiates a new V12EventEventgroupDefinitionsEventgroupDefinition object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCategory

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetCategory() string`

GetCategory returns the Category field if non-nil, zero value otherwise.

### GetCategoryOk

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetCategoryOk() (*string, bool)`

GetCategoryOk returns a tuple with the Category field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCategory

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) SetCategory(v string)`

SetCategory sets Category field to given value.

### HasCategory

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) HasCategory() bool`

HasCategory returns a boolean if a field has been set.

### GetChannels

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetChannels() []int32`

GetChannels returns the Channels field if non-nil, zero value otherwise.

### GetChannelsOk

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetChannelsOk() (*[]int32, bool)`

GetChannelsOk returns a tuple with the Channels field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChannels

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) SetChannels(v []int32)`

SetChannels sets Channels field to given value.

### HasChannels

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) HasChannels() bool`

HasChannels returns a boolean if a field has been set.

### GetDescription

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetId

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) HasId() bool`

HasId returns a boolean if a field has been set.

### GetName

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNoIgnore

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetNoIgnore() bool`

GetNoIgnore returns the NoIgnore field if non-nil, zero value otherwise.

### GetNoIgnoreOk

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetNoIgnoreOk() (*bool, bool)`

GetNoIgnoreOk returns a tuple with the NoIgnore field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoIgnore

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) SetNoIgnore(v bool)`

SetNoIgnore sets NoIgnore field to given value.

### HasNoIgnore

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) HasNoIgnore() bool`

HasNoIgnore returns a boolean if a field has been set.

### GetNode

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetNode() bool`

GetNode returns the Node field if non-nil, zero value otherwise.

### GetNodeOk

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetNodeOk() (*bool, bool)`

GetNodeOk returns a tuple with the Node field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNode

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) SetNode(v bool)`

SetNode sets Node field to given value.

### HasNode

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) HasNode() bool`

HasNode returns a boolean if a field has been set.

### GetRules

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetRules() []string`

GetRules returns the Rules field if non-nil, zero value otherwise.

### GetRulesOk

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetRulesOk() (*[]string, bool)`

GetRulesOk returns a tuple with the Rules field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRules

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) SetRules(v []string)`

SetRules sets Rules field to given value.

### HasRules

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) HasRules() bool`

HasRules returns a boolean if a field has been set.

### GetSuppressed

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetSuppressed() bool`

GetSuppressed returns the Suppressed field if non-nil, zero value otherwise.

### GetSuppressedOk

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) GetSuppressedOk() (*bool, bool)`

GetSuppressedOk returns a tuple with the Suppressed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSuppressed

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) SetSuppressed(v bool)`

SetSuppressed sets Suppressed field to given value.

### HasSuppressed

`func (o *V12EventEventgroupDefinitionsEventgroupDefinition) HasSuppressed() bool`

HasSuppressed returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


