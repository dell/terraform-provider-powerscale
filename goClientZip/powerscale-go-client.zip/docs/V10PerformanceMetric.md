# V10PerformanceMetric

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Datatype** | Pointer to **string** | The data type of the performance metric. | [optional] 
**Description** | Pointer to **string** | Text description of the performance metric. | [optional] 
**Id** | Pointer to **string** | Performance metrics that can be used to configure a performance dataset, and performance metrics used by the default system performance dataset. | [optional] 
**SystemOnly** | Pointer to **bool** | A &#39;system_only&#39; metric is reserved for use by the system. This metric cannot be used to configure a new dataset. | [optional] 
**ValueSet** | Pointer to **string** | The set of applicable values for the metric. | [optional] 

## Methods

### NewV10PerformanceMetric

`func NewV10PerformanceMetric() *V10PerformanceMetric`

NewV10PerformanceMetric instantiates a new V10PerformanceMetric object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10PerformanceMetricWithDefaults

`func NewV10PerformanceMetricWithDefaults() *V10PerformanceMetric`

NewV10PerformanceMetricWithDefaults instantiates a new V10PerformanceMetric object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDatatype

`func (o *V10PerformanceMetric) GetDatatype() string`

GetDatatype returns the Datatype field if non-nil, zero value otherwise.

### GetDatatypeOk

`func (o *V10PerformanceMetric) GetDatatypeOk() (*string, bool)`

GetDatatypeOk returns a tuple with the Datatype field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDatatype

`func (o *V10PerformanceMetric) SetDatatype(v string)`

SetDatatype sets Datatype field to given value.

### HasDatatype

`func (o *V10PerformanceMetric) HasDatatype() bool`

HasDatatype returns a boolean if a field has been set.

### GetDescription

`func (o *V10PerformanceMetric) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V10PerformanceMetric) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V10PerformanceMetric) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V10PerformanceMetric) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetId

`func (o *V10PerformanceMetric) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10PerformanceMetric) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10PerformanceMetric) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V10PerformanceMetric) HasId() bool`

HasId returns a boolean if a field has been set.

### GetSystemOnly

`func (o *V10PerformanceMetric) GetSystemOnly() bool`

GetSystemOnly returns the SystemOnly field if non-nil, zero value otherwise.

### GetSystemOnlyOk

`func (o *V10PerformanceMetric) GetSystemOnlyOk() (*bool, bool)`

GetSystemOnlyOk returns a tuple with the SystemOnly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemOnly

`func (o *V10PerformanceMetric) SetSystemOnly(v bool)`

SetSystemOnly sets SystemOnly field to given value.

### HasSystemOnly

`func (o *V10PerformanceMetric) HasSystemOnly() bool`

HasSystemOnly returns a boolean if a field has been set.

### GetValueSet

`func (o *V10PerformanceMetric) GetValueSet() string`

GetValueSet returns the ValueSet field if non-nil, zero value otherwise.

### GetValueSetOk

`func (o *V10PerformanceMetric) GetValueSetOk() (*string, bool)`

GetValueSetOk returns a tuple with the ValueSet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValueSet

`func (o *V10PerformanceMetric) SetValueSet(v string)`

SetValueSet sets ValueSet field to given value.

### HasValueSet

`func (o *V10PerformanceMetric) HasValueSet() bool`

HasValueSet returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


