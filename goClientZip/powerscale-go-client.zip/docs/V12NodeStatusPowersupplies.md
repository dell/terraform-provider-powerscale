# V12NodeStatusPowersupplies

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errors** | Pointer to [**[]V11NodeStatusError**](V11NodeStatusError.md) | A list of errors encountered by the individual nodes involved in this request, or an empty list if there were no errors. | [optional] 
**Nodes** | Pointer to [**[]V12NodeStatusPowersuppliesNode**](V12NodeStatusPowersuppliesNode.md) | The responses from the individual nodes involved in this request. | [optional] 
**Total** | Pointer to **int32** | The total number of nodes responding. | [optional] 

## Methods

### NewV12NodeStatusPowersupplies

`func NewV12NodeStatusPowersupplies() *V12NodeStatusPowersupplies`

NewV12NodeStatusPowersupplies instantiates a new V12NodeStatusPowersupplies object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NodeStatusPowersuppliesWithDefaults

`func NewV12NodeStatusPowersuppliesWithDefaults() *V12NodeStatusPowersupplies`

NewV12NodeStatusPowersuppliesWithDefaults instantiates a new V12NodeStatusPowersupplies object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetErrors

`func (o *V12NodeStatusPowersupplies) GetErrors() []V11NodeStatusError`

GetErrors returns the Errors field if non-nil, zero value otherwise.

### GetErrorsOk

`func (o *V12NodeStatusPowersupplies) GetErrorsOk() (*[]V11NodeStatusError, bool)`

GetErrorsOk returns a tuple with the Errors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetErrors

`func (o *V12NodeStatusPowersupplies) SetErrors(v []V11NodeStatusError)`

SetErrors sets Errors field to given value.

### HasErrors

`func (o *V12NodeStatusPowersupplies) HasErrors() bool`

HasErrors returns a boolean if a field has been set.

### GetNodes

`func (o *V12NodeStatusPowersupplies) GetNodes() []V12NodeStatusPowersuppliesNode`

GetNodes returns the Nodes field if non-nil, zero value otherwise.

### GetNodesOk

`func (o *V12NodeStatusPowersupplies) GetNodesOk() (*[]V12NodeStatusPowersuppliesNode, bool)`

GetNodesOk returns a tuple with the Nodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodes

`func (o *V12NodeStatusPowersupplies) SetNodes(v []V12NodeStatusPowersuppliesNode)`

SetNodes sets Nodes field to given value.

### HasNodes

`func (o *V12NodeStatusPowersupplies) HasNodes() bool`

HasNodes returns a boolean if a field has been set.

### GetTotal

`func (o *V12NodeStatusPowersupplies) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12NodeStatusPowersupplies) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12NodeStatusPowersupplies) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12NodeStatusPowersupplies) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


