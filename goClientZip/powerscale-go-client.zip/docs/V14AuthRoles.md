# V14AuthRoles

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Roles** | Pointer to [**[]V14AuthRoleExtended**](V14AuthRoleExtended.md) |  | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV14AuthRoles

`func NewV14AuthRoles() *V14AuthRoles`

NewV14AuthRoles instantiates a new V14AuthRoles object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14AuthRolesWithDefaults

`func NewV14AuthRolesWithDefaults() *V14AuthRoles`

NewV14AuthRolesWithDefaults instantiates a new V14AuthRoles object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetResume

`func (o *V14AuthRoles) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V14AuthRoles) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V14AuthRoles) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V14AuthRoles) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetRoles

`func (o *V14AuthRoles) GetRoles() []V14AuthRoleExtended`

GetRoles returns the Roles field if non-nil, zero value otherwise.

### GetRolesOk

`func (o *V14AuthRoles) GetRolesOk() (*[]V14AuthRoleExtended, bool)`

GetRolesOk returns a tuple with the Roles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRoles

`func (o *V14AuthRoles) SetRoles(v []V14AuthRoleExtended)`

SetRoles sets Roles field to given value.

### HasRoles

`func (o *V14AuthRoles) HasRoles() bool`

HasRoles returns a boolean if a field has been set.

### GetTotal

`func (o *V14AuthRoles) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V14AuthRoles) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V14AuthRoles) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V14AuthRoles) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


