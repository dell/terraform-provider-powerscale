# \DatamoverApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateDatamoverv15CertificatesCaItem**](DatamoverApi.md#CreateDatamoverv15CertificatesCaItem) | **Post** /platform/15/datamover/certificates/ca | 
[**CreateDatamoverv15CertificatesIdentityItem**](DatamoverApi.md#CreateDatamoverv15CertificatesIdentityItem) | **Post** /platform/15/datamover/certificates/identity | 
[**CreateDatamoverv15DatamoverAccount**](DatamoverApi.md#CreateDatamoverv15DatamoverAccount) | **Post** /platform/15/datamover/accounts | 
[**CreateDatamoverv15DatamoverBasePolicy**](DatamoverApi.md#CreateDatamoverv15DatamoverBasePolicy) | **Post** /platform/15/datamover/base-policies | 
[**CreateDatamoverv15DatamoverPolicy**](DatamoverApi.md#CreateDatamoverv15DatamoverPolicy) | **Post** /platform/15/datamover/policies | 
[**CreateDatamoverv15ThrottlingBwRule**](DatamoverApi.md#CreateDatamoverv15ThrottlingBwRule) | **Post** /platform/15/datamover/throttling/bw-rules | 
[**DeleteDatamoverv15CertificatesCaById**](DatamoverApi.md#DeleteDatamoverv15CertificatesCaById) | **Delete** /platform/15/datamover/certificates/ca/{v15CertificatesCaId} | 
[**DeleteDatamoverv15CertificatesIdentityById**](DatamoverApi.md#DeleteDatamoverv15CertificatesIdentityById) | **Delete** /platform/15/datamover/certificates/identity/{v15CertificatesIdentityId} | 
[**DeleteDatamoverv15DatamoverAccount**](DatamoverApi.md#DeleteDatamoverv15DatamoverAccount) | **Delete** /platform/15/datamover/accounts/{v15DatamoverAccountId} | 
[**DeleteDatamoverv15DatamoverBasePolicy**](DatamoverApi.md#DeleteDatamoverv15DatamoverBasePolicy) | **Delete** /platform/15/datamover/base-policies/{v15DatamoverBasePolicyId} | 
[**DeleteDatamoverv15DatamoverHistoricalJobs**](DatamoverApi.md#DeleteDatamoverv15DatamoverHistoricalJobs) | **Delete** /platform/15/datamover/historical-jobs | 
[**DeleteDatamoverv15DatamoverPolicy**](DatamoverApi.md#DeleteDatamoverv15DatamoverPolicy) | **Delete** /platform/15/datamover/policies/{v15DatamoverPolicyId} | 
[**DeleteDatamoverv15ThrottlingBwRule**](DatamoverApi.md#DeleteDatamoverv15ThrottlingBwRule) | **Delete** /platform/15/datamover/throttling/bw-rules/{v15ThrottlingBwRuleId} | 
[**GetDatamoverv15CertificatesCaById**](DatamoverApi.md#GetDatamoverv15CertificatesCaById) | **Get** /platform/15/datamover/certificates/ca/{v15CertificatesCaId} | 
[**GetDatamoverv15CertificatesIdentityById**](DatamoverApi.md#GetDatamoverv15CertificatesIdentityById) | **Get** /platform/15/datamover/certificates/identity/{v15CertificatesIdentityId} | 
[**GetDatamoverv15DatamoverAccount**](DatamoverApi.md#GetDatamoverv15DatamoverAccount) | **Get** /platform/15/datamover/accounts/{v15DatamoverAccountId} | 
[**GetDatamoverv15DatamoverBasePolicy**](DatamoverApi.md#GetDatamoverv15DatamoverBasePolicy) | **Get** /platform/15/datamover/base-policies/{v15DatamoverBasePolicyId} | 
[**GetDatamoverv15DatamoverDataset**](DatamoverApi.md#GetDatamoverv15DatamoverDataset) | **Get** /platform/15/datamover/datasets/{v15DatamoverDatasetId} | 
[**GetDatamoverv15DatamoverDatasets**](DatamoverApi.md#GetDatamoverv15DatamoverDatasets) | **Get** /platform/15/datamover/datasets | 
[**GetDatamoverv15DatamoverHistoricalJobs**](DatamoverApi.md#GetDatamoverv15DatamoverHistoricalJobs) | **Get** /platform/15/datamover/historical-jobs | 
[**GetDatamoverv15DatamoverJob**](DatamoverApi.md#GetDatamoverv15DatamoverJob) | **Get** /platform/15/datamover/jobs/{v15DatamoverJobId} | 
[**GetDatamoverv15DatamoverJobs**](DatamoverApi.md#GetDatamoverv15DatamoverJobs) | **Get** /platform/15/datamover/jobs | 
[**GetDatamoverv15DatamoverPolicy**](DatamoverApi.md#GetDatamoverv15DatamoverPolicy) | **Get** /platform/15/datamover/policies/{v15DatamoverPolicyId} | 
[**GetDatamoverv15ThrottlingBwRule**](DatamoverApi.md#GetDatamoverv15ThrottlingBwRule) | **Get** /platform/15/datamover/throttling/bw-rules/{v15ThrottlingBwRuleId} | 
[**GetDatamoverv15ThrottlingSettings**](DatamoverApi.md#GetDatamoverv15ThrottlingSettings) | **Get** /platform/15/datamover/throttling/settings | 
[**ListDatamoverv15CertificatesCa**](DatamoverApi.md#ListDatamoverv15CertificatesCa) | **Get** /platform/15/datamover/certificates/ca | 
[**ListDatamoverv15CertificatesIdentity**](DatamoverApi.md#ListDatamoverv15CertificatesIdentity) | **Get** /platform/15/datamover/certificates/identity | 
[**ListDatamoverv15DatamoverAccounts**](DatamoverApi.md#ListDatamoverv15DatamoverAccounts) | **Get** /platform/15/datamover/accounts | 
[**ListDatamoverv15DatamoverBasePolicies**](DatamoverApi.md#ListDatamoverv15DatamoverBasePolicies) | **Get** /platform/15/datamover/base-policies | 
[**ListDatamoverv15DatamoverPolicies**](DatamoverApi.md#ListDatamoverv15DatamoverPolicies) | **Get** /platform/15/datamover/policies | 
[**ListDatamoverv15ThrottlingBwRules**](DatamoverApi.md#ListDatamoverv15ThrottlingBwRules) | **Get** /platform/15/datamover/throttling/bw-rules | 
[**UpdateDatamoverv15CertificatesCaById**](DatamoverApi.md#UpdateDatamoverv15CertificatesCaById) | **Put** /platform/15/datamover/certificates/ca/{v15CertificatesCaId} | 
[**UpdateDatamoverv15CertificatesIdentityById**](DatamoverApi.md#UpdateDatamoverv15CertificatesIdentityById) | **Put** /platform/15/datamover/certificates/identity/{v15CertificatesIdentityId} | 
[**UpdateDatamoverv15DatamoverAccount**](DatamoverApi.md#UpdateDatamoverv15DatamoverAccount) | **Put** /platform/15/datamover/accounts/{v15DatamoverAccountId} | 
[**UpdateDatamoverv15DatamoverBasePolicy**](DatamoverApi.md#UpdateDatamoverv15DatamoverBasePolicy) | **Put** /platform/15/datamover/base-policies/{v15DatamoverBasePolicyId} | 
[**UpdateDatamoverv15DatamoverJob**](DatamoverApi.md#UpdateDatamoverv15DatamoverJob) | **Put** /platform/15/datamover/jobs/{v15DatamoverJobId} | 
[**UpdateDatamoverv15DatamoverPolicy**](DatamoverApi.md#UpdateDatamoverv15DatamoverPolicy) | **Put** /platform/15/datamover/policies/{v15DatamoverPolicyId} | 
[**UpdateDatamoverv15ThrottlingBwRule**](DatamoverApi.md#UpdateDatamoverv15ThrottlingBwRule) | **Put** /platform/15/datamover/throttling/bw-rules/{v15ThrottlingBwRuleId} | 
[**UpdateDatamoverv15ThrottlingSettings**](DatamoverApi.md#UpdateDatamoverv15ThrottlingSettings) | **Put** /platform/15/datamover/throttling/settings | 



## CreateDatamoverv15CertificatesCaItem

> CreateResponse CreateDatamoverv15CertificatesCaItem(ctx).V15CertificatesCaItem(v15CertificatesCaItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15CertificatesCaItem := *openapiclient.NewV15CertificatesCaItem("CertificatePath_example", "Name_example") // V15CertificatesCaItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.CreateDatamoverv15CertificatesCaItem(context.Background()).V15CertificatesCaItem(v15CertificatesCaItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.CreateDatamoverv15CertificatesCaItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDatamoverv15CertificatesCaItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.CreateDatamoverv15CertificatesCaItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateDatamoverv15CertificatesCaItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15CertificatesCaItem** | [**V15CertificatesCaItem**](V15CertificatesCaItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateDatamoverv15CertificatesIdentityItem

> CreateResponse CreateDatamoverv15CertificatesIdentityItem(ctx).V15CertificatesIdentityItem(v15CertificatesIdentityItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15CertificatesIdentityItem := *openapiclient.NewV15CertificatesIdentityItem("CertificatePath_example", "Name_example") // V15CertificatesIdentityItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.CreateDatamoverv15CertificatesIdentityItem(context.Background()).V15CertificatesIdentityItem(v15CertificatesIdentityItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.CreateDatamoverv15CertificatesIdentityItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDatamoverv15CertificatesIdentityItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.CreateDatamoverv15CertificatesIdentityItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateDatamoverv15CertificatesIdentityItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15CertificatesIdentityItem** | [**V15CertificatesIdentityItem**](V15CertificatesIdentityItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateDatamoverv15DatamoverAccount

> Createv15DatamoverAccountResponse CreateDatamoverv15DatamoverAccount(ctx).V15DatamoverAccount(v15DatamoverAccount).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverAccount := *openapiclient.NewV15DatamoverAccount("AccountType_example", "Name_example", "Uri_example") // V15DatamoverAccount | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.CreateDatamoverv15DatamoverAccount(context.Background()).V15DatamoverAccount(v15DatamoverAccount).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.CreateDatamoverv15DatamoverAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDatamoverv15DatamoverAccount`: Createv15DatamoverAccountResponse
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.CreateDatamoverv15DatamoverAccount`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateDatamoverv15DatamoverAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15DatamoverAccount** | [**V15DatamoverAccount**](V15DatamoverAccount.md) |  | 

### Return type

[**Createv15DatamoverAccountResponse**](Createv15DatamoverAccountResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateDatamoverv15DatamoverBasePolicy

> Createv15DatamoverBasePolicyResponse CreateDatamoverv15DatamoverBasePolicy(ctx).V15DatamoverBasePolicy(v15DatamoverBasePolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverBasePolicy := *openapiclient.NewV15DatamoverBasePolicy("Name_example", []string{"OverrideList_example"}) // V15DatamoverBasePolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.CreateDatamoverv15DatamoverBasePolicy(context.Background()).V15DatamoverBasePolicy(v15DatamoverBasePolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.CreateDatamoverv15DatamoverBasePolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDatamoverv15DatamoverBasePolicy`: Createv15DatamoverBasePolicyResponse
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.CreateDatamoverv15DatamoverBasePolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateDatamoverv15DatamoverBasePolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15DatamoverBasePolicy** | [**V15DatamoverBasePolicy**](V15DatamoverBasePolicy.md) |  | 

### Return type

[**Createv15DatamoverBasePolicyResponse**](Createv15DatamoverBasePolicyResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateDatamoverv15DatamoverPolicy

> Createv15DatamoverBasePolicyResponse CreateDatamoverv15DatamoverPolicy(ctx).V15DatamoverPolicy(v15DatamoverPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverPolicy := *openapiclient.NewV15DatamoverPolicy(false, "Name_example", *openapiclient.NewV15DatamoverPolicyPolicySpecificAttr("PolicyType_example"), "Priority_example") // V15DatamoverPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.CreateDatamoverv15DatamoverPolicy(context.Background()).V15DatamoverPolicy(v15DatamoverPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.CreateDatamoverv15DatamoverPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDatamoverv15DatamoverPolicy`: Createv15DatamoverBasePolicyResponse
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.CreateDatamoverv15DatamoverPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateDatamoverv15DatamoverPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15DatamoverPolicy** | [**V15DatamoverPolicy**](V15DatamoverPolicy.md) |  | 

### Return type

[**Createv15DatamoverBasePolicyResponse**](Createv15DatamoverBasePolicyResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateDatamoverv15ThrottlingBwRule

> Createv15ThrottlingBwRuleResponse CreateDatamoverv15ThrottlingBwRule(ctx).V15ThrottlingBwRule(v15ThrottlingBwRule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15ThrottlingBwRule := *openapiclient.NewV15ThrottlingBwRule(int32(123), "Netmask_example", "RuleType_example") // V15ThrottlingBwRule | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.CreateDatamoverv15ThrottlingBwRule(context.Background()).V15ThrottlingBwRule(v15ThrottlingBwRule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.CreateDatamoverv15ThrottlingBwRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateDatamoverv15ThrottlingBwRule`: Createv15ThrottlingBwRuleResponse
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.CreateDatamoverv15ThrottlingBwRule`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateDatamoverv15ThrottlingBwRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15ThrottlingBwRule** | [**V15ThrottlingBwRule**](V15ThrottlingBwRule.md) |  | 

### Return type

[**Createv15ThrottlingBwRuleResponse**](Createv15ThrottlingBwRuleResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDatamoverv15CertificatesCaById

> DeleteDatamoverv15CertificatesCaById(ctx, v15CertificatesCaId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15CertificatesCaId := "v15CertificatesCaId_example" // string | Delete a trusted Datamover TLS CA certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.DeleteDatamoverv15CertificatesCaById(context.Background(), v15CertificatesCaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.DeleteDatamoverv15CertificatesCaById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15CertificatesCaId** | **string** | Delete a trusted Datamover TLS CA certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDatamoverv15CertificatesCaByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDatamoverv15CertificatesIdentityById

> DeleteDatamoverv15CertificatesIdentityById(ctx, v15CertificatesIdentityId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15CertificatesIdentityId := "v15CertificatesIdentityId_example" // string | Delete a trusted Datamover TLS Identity certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.DeleteDatamoverv15CertificatesIdentityById(context.Background(), v15CertificatesIdentityId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.DeleteDatamoverv15CertificatesIdentityById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15CertificatesIdentityId** | **string** | Delete a trusted Datamover TLS Identity certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDatamoverv15CertificatesIdentityByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDatamoverv15DatamoverAccount

> DeleteDatamoverv15DatamoverAccount(ctx, v15DatamoverAccountId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverAccountId := "v15DatamoverAccountId_example" // string | Delete the account.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.DeleteDatamoverv15DatamoverAccount(context.Background(), v15DatamoverAccountId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.DeleteDatamoverv15DatamoverAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverAccountId** | **string** | Delete the account. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDatamoverv15DatamoverAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDatamoverv15DatamoverBasePolicy

> DeleteDatamoverv15DatamoverBasePolicy(ctx, v15DatamoverBasePolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverBasePolicyId := "v15DatamoverBasePolicyId_example" // string | Delete the base policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.DeleteDatamoverv15DatamoverBasePolicy(context.Background(), v15DatamoverBasePolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.DeleteDatamoverv15DatamoverBasePolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverBasePolicyId** | **string** | Delete the base policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDatamoverv15DatamoverBasePolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDatamoverv15DatamoverHistoricalJobs

> DeleteDatamoverv15DatamoverHistoricalJobs(ctx).AfterTime(afterTime).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    afterTime := "afterTime_example" // string | The time in '%Y-%m-%d %H:%M:%S' format. The year range is 2001-2099. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.DeleteDatamoverv15DatamoverHistoricalJobs(context.Background()).AfterTime(afterTime).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.DeleteDatamoverv15DatamoverHistoricalJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDatamoverv15DatamoverHistoricalJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **afterTime** | **string** | The time in &#39;%Y-%m-%d %H:%M:%S&#39; format. The year range is 2001-2099. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDatamoverv15DatamoverPolicy

> DeleteDatamoverv15DatamoverPolicy(ctx, v15DatamoverPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverPolicyId := "v15DatamoverPolicyId_example" // string | Delete the policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.DeleteDatamoverv15DatamoverPolicy(context.Background(), v15DatamoverPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.DeleteDatamoverv15DatamoverPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverPolicyId** | **string** | Delete the policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDatamoverv15DatamoverPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteDatamoverv15ThrottlingBwRule

> DeleteDatamoverv15ThrottlingBwRule(ctx, v15ThrottlingBwRuleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15ThrottlingBwRuleId := "v15ThrottlingBwRuleId_example" // string | Delete a bandwidth throttling rule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.DeleteDatamoverv15ThrottlingBwRule(context.Background(), v15ThrottlingBwRuleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.DeleteDatamoverv15ThrottlingBwRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15ThrottlingBwRuleId** | **string** | Delete a bandwidth throttling rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteDatamoverv15ThrottlingBwRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15CertificatesCaById

> V7CertificateAuthorityExtended GetDatamoverv15CertificatesCaById(ctx, v15CertificatesCaId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15CertificatesCaId := "v15CertificatesCaId_example" // string | Retrieve a single trusted Datamover TLS CA certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15CertificatesCaById(context.Background(), v15CertificatesCaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15CertificatesCaById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15CertificatesCaById`: V7CertificateAuthorityExtended
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15CertificatesCaById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15CertificatesCaId** | **string** | Retrieve a single trusted Datamover TLS CA certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15CertificatesCaByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7CertificateAuthorityExtended**](V7CertificateAuthorityExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15CertificatesIdentityById

> V4CertificateServerExtended GetDatamoverv15CertificatesIdentityById(ctx, v15CertificatesIdentityId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15CertificatesIdentityId := "v15CertificatesIdentityId_example" // string | Retrieve a single trusted Datamover TLS Identity certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15CertificatesIdentityById(context.Background(), v15CertificatesIdentityId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15CertificatesIdentityById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15CertificatesIdentityById`: V4CertificateServerExtended
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15CertificatesIdentityById`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15CertificatesIdentityId** | **string** | Retrieve a single trusted Datamover TLS Identity certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15CertificatesIdentityByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4CertificateServerExtended**](V4CertificateServerExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15DatamoverAccount

> V15DatamoverAccountsExtended GetDatamoverv15DatamoverAccount(ctx, v15DatamoverAccountId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverAccountId := "v15DatamoverAccountId_example" // string | Retrieve account information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15DatamoverAccount(context.Background(), v15DatamoverAccountId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15DatamoverAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15DatamoverAccount`: V15DatamoverAccountsExtended
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15DatamoverAccount`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverAccountId** | **string** | Retrieve account information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15DatamoverAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V15DatamoverAccountsExtended**](V15DatamoverAccountsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15DatamoverBasePolicy

> V15DatamoverBasePoliciesExtended GetDatamoverv15DatamoverBasePolicy(ctx, v15DatamoverBasePolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverBasePolicyId := "v15DatamoverBasePolicyId_example" // string | Retrieve base policy information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15DatamoverBasePolicy(context.Background(), v15DatamoverBasePolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15DatamoverBasePolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15DatamoverBasePolicy`: V15DatamoverBasePoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15DatamoverBasePolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverBasePolicyId** | **string** | Retrieve base policy information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15DatamoverBasePolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V15DatamoverBasePoliciesExtended**](V15DatamoverBasePoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15DatamoverDataset

> V15DatamoverDatasetsExtended GetDatamoverv15DatamoverDataset(ctx, v15DatamoverDatasetId).AccountId(accountId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverDatasetId := "v15DatamoverDatasetId_example" // string | Retrieve dataset information.
    accountId := "accountId_example" // string | Unique account ID (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15DatamoverDataset(context.Background(), v15DatamoverDatasetId).AccountId(accountId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15DatamoverDataset``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15DatamoverDataset`: V15DatamoverDatasetsExtended
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15DatamoverDataset`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverDatasetId** | **string** | Retrieve dataset information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15DatamoverDatasetRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **accountId** | **string** | Unique account ID | 

### Return type

[**V15DatamoverDatasetsExtended**](V15DatamoverDatasetsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15DatamoverDatasets

> V15DatamoverDatasets GetDatamoverv15DatamoverDatasets(ctx).Limit(limit).AccountId(accountId).BasePath(basePath).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    accountId := "accountId_example" // string | Unique account ID (optional)
    basePath := "basePath_example" // string |  (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15DatamoverDatasets(context.Background()).Limit(limit).AccountId(accountId).BasePath(basePath).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15DatamoverDatasets``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15DatamoverDatasets`: V15DatamoverDatasets
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15DatamoverDatasets`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15DatamoverDatasetsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **accountId** | **string** | Unique account ID | 
 **basePath** | **string** |  | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V15DatamoverDatasets**](V15DatamoverDatasets.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15DatamoverHistoricalJobs

> V15DatamoverHistoricalJobs GetDatamoverv15DatamoverHistoricalJobs(ctx).AfterTime(afterTime).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    afterTime := "afterTime_example" // string | The time in '%Y-%m-%d %H:%M:%S' format. The year range is 2001-2099. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15DatamoverHistoricalJobs(context.Background()).AfterTime(afterTime).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15DatamoverHistoricalJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15DatamoverHistoricalJobs`: V15DatamoverHistoricalJobs
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15DatamoverHistoricalJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15DatamoverHistoricalJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **afterTime** | **string** | The time in &#39;%Y-%m-%d %H:%M:%S&#39; format. The year range is 2001-2099. | 

### Return type

[**V15DatamoverHistoricalJobs**](V15DatamoverHistoricalJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15DatamoverJob

> V15DatamoverJobsExtended GetDatamoverv15DatamoverJob(ctx, v15DatamoverJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverJobId := "v15DatamoverJobId_example" // string | Retrieve job information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15DatamoverJob(context.Background(), v15DatamoverJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15DatamoverJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15DatamoverJob`: V15DatamoverJobsExtended
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15DatamoverJob`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverJobId** | **string** | Retrieve job information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15DatamoverJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V15DatamoverJobsExtended**](V15DatamoverJobsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15DatamoverJobs

> V15DatamoverJobs GetDatamoverv15DatamoverJobs(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15DatamoverJobs(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15DatamoverJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15DatamoverJobs`: V15DatamoverJobs
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15DatamoverJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15DatamoverJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V15DatamoverJobs**](V15DatamoverJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15DatamoverPolicy

> V15DatamoverPoliciesExtended GetDatamoverv15DatamoverPolicy(ctx, v15DatamoverPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverPolicyId := "v15DatamoverPolicyId_example" // string | Retrieve policy information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15DatamoverPolicy(context.Background(), v15DatamoverPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15DatamoverPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15DatamoverPolicy`: V15DatamoverPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15DatamoverPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverPolicyId** | **string** | Retrieve policy information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15DatamoverPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V15DatamoverPoliciesExtended**](V15DatamoverPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15ThrottlingBwRule

> V15ThrottlingBwRulesExtended GetDatamoverv15ThrottlingBwRule(ctx, v15ThrottlingBwRuleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15ThrottlingBwRuleId := "v15ThrottlingBwRuleId_example" // string | Retrieve a bandwidth throttling rule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15ThrottlingBwRule(context.Background(), v15ThrottlingBwRuleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15ThrottlingBwRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15ThrottlingBwRule`: V15ThrottlingBwRulesExtended
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15ThrottlingBwRule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15ThrottlingBwRuleId** | **string** | Retrieve a bandwidth throttling rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15ThrottlingBwRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V15ThrottlingBwRulesExtended**](V15ThrottlingBwRulesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetDatamoverv15ThrottlingSettings

> V15ThrottlingSettings GetDatamoverv15ThrottlingSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.GetDatamoverv15ThrottlingSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.GetDatamoverv15ThrottlingSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetDatamoverv15ThrottlingSettings`: V15ThrottlingSettings
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.GetDatamoverv15ThrottlingSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetDatamoverv15ThrottlingSettingsRequest struct via the builder pattern


### Return type

[**V15ThrottlingSettings**](V15ThrottlingSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListDatamoverv15CertificatesCa

> V7CertificateAuthority ListDatamoverv15CertificatesCa(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.ListDatamoverv15CertificatesCa(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.ListDatamoverv15CertificatesCa``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListDatamoverv15CertificatesCa`: V7CertificateAuthority
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.ListDatamoverv15CertificatesCa`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListDatamoverv15CertificatesCaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7CertificateAuthority**](V7CertificateAuthority.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListDatamoverv15CertificatesIdentity

> V4CertificateServer ListDatamoverv15CertificatesIdentity(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.ListDatamoverv15CertificatesIdentity(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.ListDatamoverv15CertificatesIdentity``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListDatamoverv15CertificatesIdentity`: V4CertificateServer
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.ListDatamoverv15CertificatesIdentity`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListDatamoverv15CertificatesIdentityRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V4CertificateServer**](V4CertificateServer.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListDatamoverv15DatamoverAccounts

> V15DatamoverAccounts ListDatamoverv15DatamoverAccounts(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.ListDatamoverv15DatamoverAccounts(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.ListDatamoverv15DatamoverAccounts``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListDatamoverv15DatamoverAccounts`: V15DatamoverAccounts
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.ListDatamoverv15DatamoverAccounts`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListDatamoverv15DatamoverAccountsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V15DatamoverAccounts**](V15DatamoverAccounts.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListDatamoverv15DatamoverBasePolicies

> V15DatamoverBasePolicies ListDatamoverv15DatamoverBasePolicies(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.ListDatamoverv15DatamoverBasePolicies(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.ListDatamoverv15DatamoverBasePolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListDatamoverv15DatamoverBasePolicies`: V15DatamoverBasePolicies
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.ListDatamoverv15DatamoverBasePolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListDatamoverv15DatamoverBasePoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V15DatamoverBasePolicies**](V15DatamoverBasePolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListDatamoverv15DatamoverPolicies

> V15DatamoverPolicies ListDatamoverv15DatamoverPolicies(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.ListDatamoverv15DatamoverPolicies(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.ListDatamoverv15DatamoverPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListDatamoverv15DatamoverPolicies`: V15DatamoverPolicies
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.ListDatamoverv15DatamoverPolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListDatamoverv15DatamoverPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V15DatamoverPolicies**](V15DatamoverPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListDatamoverv15ThrottlingBwRules

> V15ThrottlingBwRules ListDatamoverv15ThrottlingBwRules(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.DatamoverApi.ListDatamoverv15ThrottlingBwRules(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.ListDatamoverv15ThrottlingBwRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListDatamoverv15ThrottlingBwRules`: V15ThrottlingBwRules
    fmt.Fprintf(os.Stdout, "Response from `DatamoverApi.ListDatamoverv15ThrottlingBwRules`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListDatamoverv15ThrottlingBwRulesRequest struct via the builder pattern


### Return type

[**V15ThrottlingBwRules**](V15ThrottlingBwRules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDatamoverv15CertificatesCaById

> UpdateDatamoverv15CertificatesCaById(ctx, v15CertificatesCaId).V15CertificatesCaIdParams(v15CertificatesCaIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15CertificatesCaId := "v15CertificatesCaId_example" // string | Modify a trusted Datamover TLS CA certificate.
    v15CertificatesCaIdParams := *openapiclient.NewV15CertificatesCaIdParams() // V15CertificatesCaIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.UpdateDatamoverv15CertificatesCaById(context.Background(), v15CertificatesCaId).V15CertificatesCaIdParams(v15CertificatesCaIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.UpdateDatamoverv15CertificatesCaById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15CertificatesCaId** | **string** | Modify a trusted Datamover TLS CA certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateDatamoverv15CertificatesCaByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v15CertificatesCaIdParams** | [**V15CertificatesCaIdParams**](V15CertificatesCaIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDatamoverv15CertificatesIdentityById

> UpdateDatamoverv15CertificatesIdentityById(ctx, v15CertificatesIdentityId).V15CertificatesIdentityIdParams(v15CertificatesIdentityIdParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15CertificatesIdentityId := "v15CertificatesIdentityId_example" // string | Modify a trusted Datamover TLS Identity certificate.
    v15CertificatesIdentityIdParams := *openapiclient.NewV15CertificatesCaIdParams() // V15CertificatesCaIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.UpdateDatamoverv15CertificatesIdentityById(context.Background(), v15CertificatesIdentityId).V15CertificatesIdentityIdParams(v15CertificatesIdentityIdParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.UpdateDatamoverv15CertificatesIdentityById``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15CertificatesIdentityId** | **string** | Modify a trusted Datamover TLS Identity certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateDatamoverv15CertificatesIdentityByIdRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v15CertificatesIdentityIdParams** | [**V15CertificatesCaIdParams**](V15CertificatesCaIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDatamoverv15DatamoverAccount

> UpdateDatamoverv15DatamoverAccount(ctx, v15DatamoverAccountId).V15DatamoverAccount(v15DatamoverAccount).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverAccountId := "v15DatamoverAccountId_example" // string | Modify account information.
    v15DatamoverAccount := *openapiclient.NewV15DatamoverAccountExtendedExtended() // V15DatamoverAccountExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.UpdateDatamoverv15DatamoverAccount(context.Background(), v15DatamoverAccountId).V15DatamoverAccount(v15DatamoverAccount).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.UpdateDatamoverv15DatamoverAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverAccountId** | **string** | Modify account information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateDatamoverv15DatamoverAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v15DatamoverAccount** | [**V15DatamoverAccountExtendedExtended**](V15DatamoverAccountExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDatamoverv15DatamoverBasePolicy

> UpdateDatamoverv15DatamoverBasePolicy(ctx, v15DatamoverBasePolicyId).V15DatamoverBasePolicy(v15DatamoverBasePolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverBasePolicyId := "v15DatamoverBasePolicyId_example" // string | Modify base policy information.
    v15DatamoverBasePolicy := *openapiclient.NewV15DatamoverBasePolicyExtended() // V15DatamoverBasePolicyExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.UpdateDatamoverv15DatamoverBasePolicy(context.Background(), v15DatamoverBasePolicyId).V15DatamoverBasePolicy(v15DatamoverBasePolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.UpdateDatamoverv15DatamoverBasePolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverBasePolicyId** | **string** | Modify base policy information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateDatamoverv15DatamoverBasePolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v15DatamoverBasePolicy** | [**V15DatamoverBasePolicyExtended**](V15DatamoverBasePolicyExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDatamoverv15DatamoverJob

> UpdateDatamoverv15DatamoverJob(ctx, v15DatamoverJobId).Action(action).V15DatamoverJob(v15DatamoverJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    action := "action_example" // string | Job control request.
    v15DatamoverJobId := "v15DatamoverJobId_example" // string | Modify job state.
    v15DatamoverJob := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.UpdateDatamoverv15DatamoverJob(context.Background(), v15DatamoverJobId).Action(action).V15DatamoverJob(v15DatamoverJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.UpdateDatamoverv15DatamoverJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverJobId** | **string** | Modify job state. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateDatamoverv15DatamoverJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **action** | **string** | Job control request. | 

 **v15DatamoverJob** | **map[string]interface{}** |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDatamoverv15DatamoverPolicy

> UpdateDatamoverv15DatamoverPolicy(ctx, v15DatamoverPolicyId).V15DatamoverPolicy(v15DatamoverPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15DatamoverPolicyId := "v15DatamoverPolicyId_example" // string | Modify policy information.
    v15DatamoverPolicy := *openapiclient.NewV15DatamoverPolicyExtendedExtended() // V15DatamoverPolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.UpdateDatamoverv15DatamoverPolicy(context.Background(), v15DatamoverPolicyId).V15DatamoverPolicy(v15DatamoverPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.UpdateDatamoverv15DatamoverPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15DatamoverPolicyId** | **string** | Modify policy information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateDatamoverv15DatamoverPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v15DatamoverPolicy** | [**V15DatamoverPolicyExtendedExtended**](V15DatamoverPolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDatamoverv15ThrottlingBwRule

> UpdateDatamoverv15ThrottlingBwRule(ctx, v15ThrottlingBwRuleId).V15ThrottlingBwRule(v15ThrottlingBwRule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15ThrottlingBwRuleId := "v15ThrottlingBwRuleId_example" // string | Modify a bandwidth throttling rule.
    v15ThrottlingBwRule := *openapiclient.NewV15ThrottlingBwRuleExtended() // V15ThrottlingBwRuleExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.UpdateDatamoverv15ThrottlingBwRule(context.Background(), v15ThrottlingBwRuleId).V15ThrottlingBwRule(v15ThrottlingBwRule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.UpdateDatamoverv15ThrottlingBwRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v15ThrottlingBwRuleId** | **string** | Modify a bandwidth throttling rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateDatamoverv15ThrottlingBwRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v15ThrottlingBwRule** | [**V15ThrottlingBwRuleExtended**](V15ThrottlingBwRuleExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateDatamoverv15ThrottlingSettings

> UpdateDatamoverv15ThrottlingSettings(ctx).V15ThrottlingSettings(v15ThrottlingSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15ThrottlingSettings := *openapiclient.NewV15ThrottlingSettingsSettings() // V15ThrottlingSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.DatamoverApi.UpdateDatamoverv15ThrottlingSettings(context.Background()).V15ThrottlingSettings(v15ThrottlingSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `DatamoverApi.UpdateDatamoverv15ThrottlingSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateDatamoverv15ThrottlingSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15ThrottlingSettings** | [**V15ThrottlingSettingsSettings**](V15ThrottlingSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

