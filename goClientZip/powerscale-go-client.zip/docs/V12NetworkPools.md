# V12NetworkPools

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Pools** | Pointer to [**[]V12NetworkPool**](V12NetworkPool.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV12NetworkPools

`func NewV12NetworkPools() *V12NetworkPools`

NewV12NetworkPools instantiates a new V12NetworkPools object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NetworkPoolsWithDefaults

`func NewV12NetworkPoolsWithDefaults() *V12NetworkPools`

NewV12NetworkPoolsWithDefaults instantiates a new V12NetworkPools object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPools

`func (o *V12NetworkPools) GetPools() []V12NetworkPool`

GetPools returns the Pools field if non-nil, zero value otherwise.

### GetPoolsOk

`func (o *V12NetworkPools) GetPoolsOk() (*[]V12NetworkPool, bool)`

GetPoolsOk returns a tuple with the Pools field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPools

`func (o *V12NetworkPools) SetPools(v []V12NetworkPool)`

SetPools sets Pools field to given value.

### HasPools

`func (o *V12NetworkPools) HasPools() bool`

HasPools returns a boolean if a field has been set.

### GetResume

`func (o *V12NetworkPools) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12NetworkPools) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12NetworkPools) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12NetworkPools) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V12NetworkPools) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12NetworkPools) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12NetworkPools) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12NetworkPools) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


