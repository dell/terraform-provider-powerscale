# V10DatasetWorkloadExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreationTime** | Pointer to **int32** | Timestamp of when the workload was pinned. | [optional] 
**DatasetId** | Pointer to **int32** | Unique identifier of the associated dataset. | [optional] 
**Error** | Pointer to **string** | If this field is present, then there was an error fetching the workload configuration. | [optional] 
**Id** | **int32** | The workload ID. Unique and automatically assigned. | 
**MetricValues** | Pointer to [**V10DatasetFilterMetricValuesExtended**](V10DatasetFilterMetricValuesExtended.md) |  | [optional] 
**Name** | Pointer to **string** | The name of the workload. User specified. | [optional] 

## Methods

### NewV10DatasetWorkloadExtended

`func NewV10DatasetWorkloadExtended(id int32, ) *V10DatasetWorkloadExtended`

NewV10DatasetWorkloadExtended instantiates a new V10DatasetWorkloadExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10DatasetWorkloadExtendedWithDefaults

`func NewV10DatasetWorkloadExtendedWithDefaults() *V10DatasetWorkloadExtended`

NewV10DatasetWorkloadExtendedWithDefaults instantiates a new V10DatasetWorkloadExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCreationTime

`func (o *V10DatasetWorkloadExtended) GetCreationTime() int32`

GetCreationTime returns the CreationTime field if non-nil, zero value otherwise.

### GetCreationTimeOk

`func (o *V10DatasetWorkloadExtended) GetCreationTimeOk() (*int32, bool)`

GetCreationTimeOk returns a tuple with the CreationTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreationTime

`func (o *V10DatasetWorkloadExtended) SetCreationTime(v int32)`

SetCreationTime sets CreationTime field to given value.

### HasCreationTime

`func (o *V10DatasetWorkloadExtended) HasCreationTime() bool`

HasCreationTime returns a boolean if a field has been set.

### GetDatasetId

`func (o *V10DatasetWorkloadExtended) GetDatasetId() int32`

GetDatasetId returns the DatasetId field if non-nil, zero value otherwise.

### GetDatasetIdOk

`func (o *V10DatasetWorkloadExtended) GetDatasetIdOk() (*int32, bool)`

GetDatasetIdOk returns a tuple with the DatasetId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDatasetId

`func (o *V10DatasetWorkloadExtended) SetDatasetId(v int32)`

SetDatasetId sets DatasetId field to given value.

### HasDatasetId

`func (o *V10DatasetWorkloadExtended) HasDatasetId() bool`

HasDatasetId returns a boolean if a field has been set.

### GetError

`func (o *V10DatasetWorkloadExtended) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V10DatasetWorkloadExtended) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V10DatasetWorkloadExtended) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V10DatasetWorkloadExtended) HasError() bool`

HasError returns a boolean if a field has been set.

### GetId

`func (o *V10DatasetWorkloadExtended) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10DatasetWorkloadExtended) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10DatasetWorkloadExtended) SetId(v int32)`

SetId sets Id field to given value.


### GetMetricValues

`func (o *V10DatasetWorkloadExtended) GetMetricValues() V10DatasetFilterMetricValuesExtended`

GetMetricValues returns the MetricValues field if non-nil, zero value otherwise.

### GetMetricValuesOk

`func (o *V10DatasetWorkloadExtended) GetMetricValuesOk() (*V10DatasetFilterMetricValuesExtended, bool)`

GetMetricValuesOk returns a tuple with the MetricValues field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetricValues

`func (o *V10DatasetWorkloadExtended) SetMetricValues(v V10DatasetFilterMetricValuesExtended)`

SetMetricValues sets MetricValues field to given value.

### HasMetricValues

`func (o *V10DatasetWorkloadExtended) HasMetricValues() bool`

HasMetricValues returns a boolean if a field has been set.

### GetName

`func (o *V10DatasetWorkloadExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10DatasetWorkloadExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10DatasetWorkloadExtended) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V10DatasetWorkloadExtended) HasName() bool`

HasName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


