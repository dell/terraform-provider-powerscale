# \ApiApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateApiv14SessionsInvalidation**](ApiApi.md#CreateApiv14SessionsInvalidation) | **Post** /platform/14/api/sessions/invalidations | 
[**CreateApiv14SessionsRekeyItem**](ApiApi.md#CreateApiv14SessionsRekeyItem) | **Post** /platform/14/api/sessions/rekey | 
[**DeleteApiv14SessionsInvalidation**](ApiApi.md#DeleteApiv14SessionsInvalidation) | **Delete** /platform/14/api/sessions/invalidations/{v14SessionsInvalidationId} | 
[**GetApiv14SessionsInvalidation**](ApiApi.md#GetApiv14SessionsInvalidation) | **Get** /platform/14/api/sessions/invalidations/{v14SessionsInvalidationId} | 
[**GetApiv14SettingsSessions**](ApiApi.md#GetApiv14SettingsSessions) | **Get** /platform/14/api/settings/sessions | 
[**ListApiv14SessionsInvalidations**](ApiApi.md#ListApiv14SessionsInvalidations) | **Get** /platform/14/api/sessions/invalidations | 
[**UpdateApiv14SessionsInvalidation**](ApiApi.md#UpdateApiv14SessionsInvalidation) | **Put** /platform/14/api/sessions/invalidations/{v14SessionsInvalidationId} | 
[**UpdateApiv14SettingsSessions**](ApiApi.md#UpdateApiv14SettingsSessions) | **Put** /platform/14/api/settings/sessions | 



## CreateApiv14SessionsInvalidation

> CreateResponse CreateApiv14SessionsInvalidation(ctx).V14SessionsInvalidation(v14SessionsInvalidation).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SessionsInvalidation := *openapiclient.NewV14SessionsInvalidation("Id_example") // V14SessionsInvalidation | 
    zone := "zone_example" // string | The zone to create the invalidation in. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ApiApi.CreateApiv14SessionsInvalidation(context.Background()).V14SessionsInvalidation(v14SessionsInvalidation).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ApiApi.CreateApiv14SessionsInvalidation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateApiv14SessionsInvalidation`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `ApiApi.CreateApiv14SessionsInvalidation`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateApiv14SessionsInvalidationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14SessionsInvalidation** | [**V14SessionsInvalidation**](V14SessionsInvalidation.md) |  | 
 **zone** | **string** | The zone to create the invalidation in. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateApiv14SessionsRekeyItem

> map[string]interface{} CreateApiv14SessionsRekeyItem(ctx).V14SessionsRekeyItem(v14SessionsRekeyItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SessionsRekeyItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ApiApi.CreateApiv14SessionsRekeyItem(context.Background()).V14SessionsRekeyItem(v14SessionsRekeyItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ApiApi.CreateApiv14SessionsRekeyItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateApiv14SessionsRekeyItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ApiApi.CreateApiv14SessionsRekeyItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateApiv14SessionsRekeyItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14SessionsRekeyItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteApiv14SessionsInvalidation

> DeleteApiv14SessionsInvalidation(ctx, v14SessionsInvalidationId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SessionsInvalidationId := "v14SessionsInvalidationId_example" // string | Delete a user's Platform API session invalidation.
    zone := "zone_example" // string | The zone to delete an invalidation from. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ApiApi.DeleteApiv14SessionsInvalidation(context.Background(), v14SessionsInvalidationId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ApiApi.DeleteApiv14SessionsInvalidation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v14SessionsInvalidationId** | **string** | Delete a user&#39;s Platform API session invalidation. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteApiv14SessionsInvalidationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | The zone to delete an invalidation from. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetApiv14SessionsInvalidation

> V14SessionsInvalidations GetApiv14SessionsInvalidation(ctx, v14SessionsInvalidationId).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SessionsInvalidationId := "v14SessionsInvalidationId_example" // string | Get user Platform API session invalidation information.
    zone := "zone_example" // string | The zone to get the invalidation from. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ApiApi.GetApiv14SessionsInvalidation(context.Background(), v14SessionsInvalidationId).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ApiApi.GetApiv14SessionsInvalidation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetApiv14SessionsInvalidation`: V14SessionsInvalidations
    fmt.Fprintf(os.Stdout, "Response from `ApiApi.GetApiv14SessionsInvalidation`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v14SessionsInvalidationId** | **string** | Get user Platform API session invalidation information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetApiv14SessionsInvalidationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | The zone to get the invalidation from. | 

### Return type

[**V14SessionsInvalidations**](V14SessionsInvalidations.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetApiv14SettingsSessions

> V14SettingsSessions GetApiv14SettingsSessions(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ApiApi.GetApiv14SettingsSessions(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ApiApi.GetApiv14SettingsSessions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetApiv14SettingsSessions`: V14SettingsSessions
    fmt.Fprintf(os.Stdout, "Response from `ApiApi.GetApiv14SettingsSessions`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetApiv14SettingsSessionsRequest struct via the builder pattern


### Return type

[**V14SettingsSessions**](V14SettingsSessions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListApiv14SessionsInvalidations

> V14SessionsInvalidations ListApiv14SessionsInvalidations(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | The zone to get invalidations from. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ApiApi.ListApiv14SessionsInvalidations(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ApiApi.ListApiv14SessionsInvalidations``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListApiv14SessionsInvalidations`: V14SessionsInvalidations
    fmt.Fprintf(os.Stdout, "Response from `ApiApi.ListApiv14SessionsInvalidations`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListApiv14SessionsInvalidationsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | The zone to get invalidations from. | 

### Return type

[**V14SessionsInvalidations**](V14SessionsInvalidations.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateApiv14SessionsInvalidation

> UpdateApiv14SessionsInvalidation(ctx, v14SessionsInvalidationId).V14SessionsInvalidation(v14SessionsInvalidation).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SessionsInvalidationId := "v14SessionsInvalidationId_example" // string | Modify a user's Platform API session invalidation.
    v14SessionsInvalidation := *openapiclient.NewV14SessionsInvalidationExtendedExtended() // V14SessionsInvalidationExtendedExtended | 
    zone := "zone_example" // string | The zone to modify an invalidation in. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ApiApi.UpdateApiv14SessionsInvalidation(context.Background(), v14SessionsInvalidationId).V14SessionsInvalidation(v14SessionsInvalidation).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ApiApi.UpdateApiv14SessionsInvalidation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v14SessionsInvalidationId** | **string** | Modify a user&#39;s Platform API session invalidation. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateApiv14SessionsInvalidationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v14SessionsInvalidation** | [**V14SessionsInvalidationExtendedExtended**](V14SessionsInvalidationExtendedExtended.md) |  | 
 **zone** | **string** | The zone to modify an invalidation in. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateApiv14SettingsSessions

> UpdateApiv14SettingsSessions(ctx).V14SettingsSessions(v14SettingsSessions).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SettingsSessions := *openapiclient.NewV14SettingsSessionsSettings() // V14SettingsSessionsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ApiApi.UpdateApiv14SettingsSessions(context.Background()).V14SettingsSessions(v14SettingsSessions).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ApiApi.UpdateApiv14SettingsSessions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateApiv14SettingsSessionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14SettingsSessions** | [**V14SettingsSessionsSettings**](V14SettingsSessionsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

