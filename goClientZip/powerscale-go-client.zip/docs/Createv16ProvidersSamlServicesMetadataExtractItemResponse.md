# Createv16ProvidersSamlServicesMetadataExtractItemResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EntityId** | Pointer to **string** | The SAML entity ID the rest of this object&#39;s properties are within. | [optional] 
**LoginEndpoints** | Pointer to [**[]Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint**](Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint.md) | A list of endpoints from the metadata that can be used as the login URL when creating an IDP on PowerScale. | [optional] 
**LogoutEndpoints** | Pointer to [**[]Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint**](Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint.md) | A list of endpoints from the metadata that can be used as the logout URL when creating an IDP on PowerScale. | [optional] 
**SigningCertificates** | Pointer to [**[]Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate**](Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate.md) | A list of signing certificates from the metadata&#39;s IDP. Only signing certificates with a status property of valid can be used to create an IDP on PowerScale. | [optional] 

## Methods

### NewCreatev16ProvidersSamlServicesMetadataExtractItemResponse

`func NewCreatev16ProvidersSamlServicesMetadataExtractItemResponse() *Createv16ProvidersSamlServicesMetadataExtractItemResponse`

NewCreatev16ProvidersSamlServicesMetadataExtractItemResponse instantiates a new Createv16ProvidersSamlServicesMetadataExtractItemResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseWithDefaults

`func NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseWithDefaults() *Createv16ProvidersSamlServicesMetadataExtractItemResponse`

NewCreatev16ProvidersSamlServicesMetadataExtractItemResponseWithDefaults instantiates a new Createv16ProvidersSamlServicesMetadataExtractItemResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEntityId

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) GetEntityId() string`

GetEntityId returns the EntityId field if non-nil, zero value otherwise.

### GetEntityIdOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) GetEntityIdOk() (*string, bool)`

GetEntityIdOk returns a tuple with the EntityId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEntityId

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) SetEntityId(v string)`

SetEntityId sets EntityId field to given value.

### HasEntityId

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) HasEntityId() bool`

HasEntityId returns a boolean if a field has been set.

### GetLoginEndpoints

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) GetLoginEndpoints() []Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint`

GetLoginEndpoints returns the LoginEndpoints field if non-nil, zero value otherwise.

### GetLoginEndpointsOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) GetLoginEndpointsOk() (*[]Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint, bool)`

GetLoginEndpointsOk returns a tuple with the LoginEndpoints field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLoginEndpoints

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) SetLoginEndpoints(v []Createv16ProvidersSamlServicesMetadataExtractItemResponseLoginEndpoint)`

SetLoginEndpoints sets LoginEndpoints field to given value.

### HasLoginEndpoints

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) HasLoginEndpoints() bool`

HasLoginEndpoints returns a boolean if a field has been set.

### GetLogoutEndpoints

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) GetLogoutEndpoints() []Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint`

GetLogoutEndpoints returns the LogoutEndpoints field if non-nil, zero value otherwise.

### GetLogoutEndpointsOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) GetLogoutEndpointsOk() (*[]Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint, bool)`

GetLogoutEndpointsOk returns a tuple with the LogoutEndpoints field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLogoutEndpoints

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) SetLogoutEndpoints(v []Createv16ProvidersSamlServicesMetadataExtractItemResponseLogoutEndpoint)`

SetLogoutEndpoints sets LogoutEndpoints field to given value.

### HasLogoutEndpoints

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) HasLogoutEndpoints() bool`

HasLogoutEndpoints returns a boolean if a field has been set.

### GetSigningCertificates

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) GetSigningCertificates() []Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate`

GetSigningCertificates returns the SigningCertificates field if non-nil, zero value otherwise.

### GetSigningCertificatesOk

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) GetSigningCertificatesOk() (*[]Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate, bool)`

GetSigningCertificatesOk returns a tuple with the SigningCertificates field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSigningCertificates

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) SetSigningCertificates(v []Createv16ProvidersSamlServicesMetadataExtractItemResponseSigningCertificate)`

SetSigningCertificates sets SigningCertificates field to given value.

### HasSigningCertificates

`func (o *Createv16ProvidersSamlServicesMetadataExtractItemResponse) HasSigningCertificates() bool`

HasSigningCertificates returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


