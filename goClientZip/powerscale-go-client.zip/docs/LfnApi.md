# \LfnApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateLfnv12LfnItem**](LfnApi.md#CreateLfnv12LfnItem) | **Post** /platform/12/lfn | 
[**DeleteLfnv12Lfn**](LfnApi.md#DeleteLfnv12Lfn) | **Delete** /platform/12/lfn | 
[**DeleteLfnv12LfnPath**](LfnApi.md#DeleteLfnv12LfnPath) | **Delete** /platform/12/lfn/{v12LfnPath} | 
[**GetLfnv12LfnPath**](LfnApi.md#GetLfnv12LfnPath) | **Get** /platform/12/lfn/{v12LfnPath} | 
[**ListLfnv12Lfn**](LfnApi.md#ListLfnv12Lfn) | **Get** /platform/12/lfn | 
[**UpdateLfnv12LfnPath**](LfnApi.md#UpdateLfnv12LfnPath) | **Put** /platform/12/lfn/{v12LfnPath} | 



## CreateLfnv12LfnItem

> Createv12LfnItemResponse CreateLfnv12LfnItem(ctx).V12LfnItem(v12LfnItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12LfnItem := *openapiclient.NewV12LfnItem("Path_example") // V12LfnItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.LfnApi.CreateLfnv12LfnItem(context.Background()).V12LfnItem(v12LfnItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LfnApi.CreateLfnv12LfnItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateLfnv12LfnItem`: Createv12LfnItemResponse
    fmt.Fprintf(os.Stdout, "Response from `LfnApi.CreateLfnv12LfnItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateLfnv12LfnItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12LfnItem** | [**V12LfnItem**](V12LfnItem.md) |  | 

### Return type

[**Createv12LfnItemResponse**](Createv12LfnItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteLfnv12Lfn

> DeleteLfnv12Lfn(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.LfnApi.DeleteLfnv12Lfn(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LfnApi.DeleteLfnv12Lfn``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteLfnv12LfnRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteLfnv12LfnPath

> DeleteLfnv12LfnPath(ctx, v12LfnPath).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12LfnPath := "v12LfnPath_example" // string | Delete the file name length configuration domain that originates at the specified path.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.LfnApi.DeleteLfnv12LfnPath(context.Background(), v12LfnPath).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LfnApi.DeleteLfnv12LfnPath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12LfnPath** | **string** | Delete the file name length configuration domain that originates at the specified path. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteLfnv12LfnPathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetLfnv12LfnPath

> V12LfnExtended GetLfnv12LfnPath(ctx, v12LfnPath).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12LfnPath := "v12LfnPath_example" // string | Retrieve file name length configuration information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.LfnApi.GetLfnv12LfnPath(context.Background(), v12LfnPath).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LfnApi.GetLfnv12LfnPath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetLfnv12LfnPath`: V12LfnExtended
    fmt.Fprintf(os.Stdout, "Response from `LfnApi.GetLfnv12LfnPath`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12LfnPath** | **string** | Retrieve file name length configuration information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetLfnv12LfnPathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12LfnExtended**](V12LfnExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListLfnv12Lfn

> V12Lfn ListLfnv12Lfn(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.LfnApi.ListLfnv12Lfn(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LfnApi.ListLfnv12Lfn``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListLfnv12Lfn`: V12Lfn
    fmt.Fprintf(os.Stdout, "Response from `LfnApi.ListLfnv12Lfn`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListLfnv12LfnRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V12Lfn**](V12Lfn.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateLfnv12LfnPath

> UpdateLfnv12LfnPath(ctx, v12LfnPath).V12LfnPathParams(v12LfnPathParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12LfnPath := "v12LfnPath_example" // string | Modify file name length settings if specified path is the root of the configuration. All input fields are optional, but one or more must be supplied.
    v12LfnPathParams := *openapiclient.NewV12LfnPathParams() // V12LfnPathParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.LfnApi.UpdateLfnv12LfnPath(context.Background(), v12LfnPath).V12LfnPathParams(v12LfnPathParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `LfnApi.UpdateLfnv12LfnPath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12LfnPath** | **string** | Modify file name length settings if specified path is the root of the configuration. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateLfnv12LfnPathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12LfnPathParams** | [**V12LfnPathParams**](V12LfnPathParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

