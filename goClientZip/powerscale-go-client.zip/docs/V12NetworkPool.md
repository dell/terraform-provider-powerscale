# V12NetworkPool

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessZone** | Pointer to **string** | Name of a valid access zone to map IP address pool to the zone. | [optional] 
**AddrFamily** | Pointer to **string** | IP address format. | [optional] 
**AggregationMode** | Pointer to **string** | OneFS supports the following NIC aggregation modes. | [optional] 
**AllocMethod** | Pointer to **string** | Specifies how IP address allocation is done among pool members. | [optional] 
**Description** | Pointer to **string** | A description of the pool. | [optional] 
**Groupnet** | Pointer to **string** | Name of the groupnet this pool belongs to. | [optional] 
**Id** | Pointer to **string** | Unique Pool ID. | [optional] 
**Ifaces** | Pointer to [**[]V12SubnetsSubnetPoolIface**](V12SubnetsSubnetPoolIface.md) | List of interface members in this pool. | [optional] 
**Name** | Pointer to **string** | The name of the pool. It must be unique throughout the given subnet.It&#39;s a required field with POST method. | [optional] 
**Nfsv3RroceOnly** | Pointer to **bool** | Indicates that pool contains only RDMA RRoCE capable interfaces. | [optional] 
**Ranges** | Pointer to [**[]V12GroupnetSubnetScServiceAddr**](V12GroupnetSubnetScServiceAddr.md) | List of IP address ranges in this pool. | [optional] 
**RebalancePolicy** | Pointer to **string** | Rebalance policy.. | [optional] 
**Rules** | Pointer to **[]string** | Names of the rules in this pool. | [optional] 
**ScAutoUnsuspendDelay** | Pointer to **int32** | Time delay in seconds before a node which has been                 automatically unsuspended becomes usable in SmartConnect                responses for pool zones. | [optional] 
**ScConnectPolicy** | Pointer to **string** | SmartConnect client connection balancing policy. | [optional] 
**ScDnsZone** | Pointer to **string** | SmartConnect zone name for the pool. | [optional] 
**ScDnsZoneAliases** | Pointer to **[]string** | List of SmartConnect zone aliases (DNS names) to the pool. | [optional] 
**ScFailoverPolicy** | Pointer to **string** | SmartConnect IP failover policy. | [optional] 
**ScSubnet** | Pointer to **string** | Name of SmartConnect service subnet for this pool. | [optional] 
**ScSuspendedNodes** | Pointer to **[]int32** | List of LNNs showing currently suspended nodes in SmartConnect. | [optional] 
**ScTtl** | Pointer to **int32** | Time to live value for SmartConnect DNS query responses in seconds. | [optional] 
**StaticRoutes** | Pointer to [**[]V12SubnetsSubnetPoolStaticRoute**](V12SubnetsSubnetPoolStaticRoute.md) | List of interface members in this pool. | [optional] 
**Subnet** | Pointer to **string** | The name of the subnet. | [optional] 

## Methods

### NewV12NetworkPool

`func NewV12NetworkPool() *V12NetworkPool`

NewV12NetworkPool instantiates a new V12NetworkPool object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NetworkPoolWithDefaults

`func NewV12NetworkPoolWithDefaults() *V12NetworkPool`

NewV12NetworkPoolWithDefaults instantiates a new V12NetworkPool object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAccessZone

`func (o *V12NetworkPool) GetAccessZone() string`

GetAccessZone returns the AccessZone field if non-nil, zero value otherwise.

### GetAccessZoneOk

`func (o *V12NetworkPool) GetAccessZoneOk() (*string, bool)`

GetAccessZoneOk returns a tuple with the AccessZone field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessZone

`func (o *V12NetworkPool) SetAccessZone(v string)`

SetAccessZone sets AccessZone field to given value.

### HasAccessZone

`func (o *V12NetworkPool) HasAccessZone() bool`

HasAccessZone returns a boolean if a field has been set.

### GetAddrFamily

`func (o *V12NetworkPool) GetAddrFamily() string`

GetAddrFamily returns the AddrFamily field if non-nil, zero value otherwise.

### GetAddrFamilyOk

`func (o *V12NetworkPool) GetAddrFamilyOk() (*string, bool)`

GetAddrFamilyOk returns a tuple with the AddrFamily field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddrFamily

`func (o *V12NetworkPool) SetAddrFamily(v string)`

SetAddrFamily sets AddrFamily field to given value.

### HasAddrFamily

`func (o *V12NetworkPool) HasAddrFamily() bool`

HasAddrFamily returns a boolean if a field has been set.

### GetAggregationMode

`func (o *V12NetworkPool) GetAggregationMode() string`

GetAggregationMode returns the AggregationMode field if non-nil, zero value otherwise.

### GetAggregationModeOk

`func (o *V12NetworkPool) GetAggregationModeOk() (*string, bool)`

GetAggregationModeOk returns a tuple with the AggregationMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAggregationMode

`func (o *V12NetworkPool) SetAggregationMode(v string)`

SetAggregationMode sets AggregationMode field to given value.

### HasAggregationMode

`func (o *V12NetworkPool) HasAggregationMode() bool`

HasAggregationMode returns a boolean if a field has been set.

### GetAllocMethod

`func (o *V12NetworkPool) GetAllocMethod() string`

GetAllocMethod returns the AllocMethod field if non-nil, zero value otherwise.

### GetAllocMethodOk

`func (o *V12NetworkPool) GetAllocMethodOk() (*string, bool)`

GetAllocMethodOk returns a tuple with the AllocMethod field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllocMethod

`func (o *V12NetworkPool) SetAllocMethod(v string)`

SetAllocMethod sets AllocMethod field to given value.

### HasAllocMethod

`func (o *V12NetworkPool) HasAllocMethod() bool`

HasAllocMethod returns a boolean if a field has been set.

### GetDescription

`func (o *V12NetworkPool) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V12NetworkPool) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V12NetworkPool) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V12NetworkPool) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetGroupnet

`func (o *V12NetworkPool) GetGroupnet() string`

GetGroupnet returns the Groupnet field if non-nil, zero value otherwise.

### GetGroupnetOk

`func (o *V12NetworkPool) GetGroupnetOk() (*string, bool)`

GetGroupnetOk returns a tuple with the Groupnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupnet

`func (o *V12NetworkPool) SetGroupnet(v string)`

SetGroupnet sets Groupnet field to given value.

### HasGroupnet

`func (o *V12NetworkPool) HasGroupnet() bool`

HasGroupnet returns a boolean if a field has been set.

### GetId

`func (o *V12NetworkPool) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12NetworkPool) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12NetworkPool) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V12NetworkPool) HasId() bool`

HasId returns a boolean if a field has been set.

### GetIfaces

`func (o *V12NetworkPool) GetIfaces() []V12SubnetsSubnetPoolIface`

GetIfaces returns the Ifaces field if non-nil, zero value otherwise.

### GetIfacesOk

`func (o *V12NetworkPool) GetIfacesOk() (*[]V12SubnetsSubnetPoolIface, bool)`

GetIfacesOk returns a tuple with the Ifaces field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIfaces

`func (o *V12NetworkPool) SetIfaces(v []V12SubnetsSubnetPoolIface)`

SetIfaces sets Ifaces field to given value.

### HasIfaces

`func (o *V12NetworkPool) HasIfaces() bool`

HasIfaces returns a boolean if a field has been set.

### GetName

`func (o *V12NetworkPool) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12NetworkPool) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12NetworkPool) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V12NetworkPool) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNfsv3RroceOnly

`func (o *V12NetworkPool) GetNfsv3RroceOnly() bool`

GetNfsv3RroceOnly returns the Nfsv3RroceOnly field if non-nil, zero value otherwise.

### GetNfsv3RroceOnlyOk

`func (o *V12NetworkPool) GetNfsv3RroceOnlyOk() (*bool, bool)`

GetNfsv3RroceOnlyOk returns a tuple with the Nfsv3RroceOnly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv3RroceOnly

`func (o *V12NetworkPool) SetNfsv3RroceOnly(v bool)`

SetNfsv3RroceOnly sets Nfsv3RroceOnly field to given value.

### HasNfsv3RroceOnly

`func (o *V12NetworkPool) HasNfsv3RroceOnly() bool`

HasNfsv3RroceOnly returns a boolean if a field has been set.

### GetRanges

`func (o *V12NetworkPool) GetRanges() []V12GroupnetSubnetScServiceAddr`

GetRanges returns the Ranges field if non-nil, zero value otherwise.

### GetRangesOk

`func (o *V12NetworkPool) GetRangesOk() (*[]V12GroupnetSubnetScServiceAddr, bool)`

GetRangesOk returns a tuple with the Ranges field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRanges

`func (o *V12NetworkPool) SetRanges(v []V12GroupnetSubnetScServiceAddr)`

SetRanges sets Ranges field to given value.

### HasRanges

`func (o *V12NetworkPool) HasRanges() bool`

HasRanges returns a boolean if a field has been set.

### GetRebalancePolicy

`func (o *V12NetworkPool) GetRebalancePolicy() string`

GetRebalancePolicy returns the RebalancePolicy field if non-nil, zero value otherwise.

### GetRebalancePolicyOk

`func (o *V12NetworkPool) GetRebalancePolicyOk() (*string, bool)`

GetRebalancePolicyOk returns a tuple with the RebalancePolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRebalancePolicy

`func (o *V12NetworkPool) SetRebalancePolicy(v string)`

SetRebalancePolicy sets RebalancePolicy field to given value.

### HasRebalancePolicy

`func (o *V12NetworkPool) HasRebalancePolicy() bool`

HasRebalancePolicy returns a boolean if a field has been set.

### GetRules

`func (o *V12NetworkPool) GetRules() []string`

GetRules returns the Rules field if non-nil, zero value otherwise.

### GetRulesOk

`func (o *V12NetworkPool) GetRulesOk() (*[]string, bool)`

GetRulesOk returns a tuple with the Rules field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRules

`func (o *V12NetworkPool) SetRules(v []string)`

SetRules sets Rules field to given value.

### HasRules

`func (o *V12NetworkPool) HasRules() bool`

HasRules returns a boolean if a field has been set.

### GetScAutoUnsuspendDelay

`func (o *V12NetworkPool) GetScAutoUnsuspendDelay() int32`

GetScAutoUnsuspendDelay returns the ScAutoUnsuspendDelay field if non-nil, zero value otherwise.

### GetScAutoUnsuspendDelayOk

`func (o *V12NetworkPool) GetScAutoUnsuspendDelayOk() (*int32, bool)`

GetScAutoUnsuspendDelayOk returns a tuple with the ScAutoUnsuspendDelay field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScAutoUnsuspendDelay

`func (o *V12NetworkPool) SetScAutoUnsuspendDelay(v int32)`

SetScAutoUnsuspendDelay sets ScAutoUnsuspendDelay field to given value.

### HasScAutoUnsuspendDelay

`func (o *V12NetworkPool) HasScAutoUnsuspendDelay() bool`

HasScAutoUnsuspendDelay returns a boolean if a field has been set.

### GetScConnectPolicy

`func (o *V12NetworkPool) GetScConnectPolicy() string`

GetScConnectPolicy returns the ScConnectPolicy field if non-nil, zero value otherwise.

### GetScConnectPolicyOk

`func (o *V12NetworkPool) GetScConnectPolicyOk() (*string, bool)`

GetScConnectPolicyOk returns a tuple with the ScConnectPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScConnectPolicy

`func (o *V12NetworkPool) SetScConnectPolicy(v string)`

SetScConnectPolicy sets ScConnectPolicy field to given value.

### HasScConnectPolicy

`func (o *V12NetworkPool) HasScConnectPolicy() bool`

HasScConnectPolicy returns a boolean if a field has been set.

### GetScDnsZone

`func (o *V12NetworkPool) GetScDnsZone() string`

GetScDnsZone returns the ScDnsZone field if non-nil, zero value otherwise.

### GetScDnsZoneOk

`func (o *V12NetworkPool) GetScDnsZoneOk() (*string, bool)`

GetScDnsZoneOk returns a tuple with the ScDnsZone field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScDnsZone

`func (o *V12NetworkPool) SetScDnsZone(v string)`

SetScDnsZone sets ScDnsZone field to given value.

### HasScDnsZone

`func (o *V12NetworkPool) HasScDnsZone() bool`

HasScDnsZone returns a boolean if a field has been set.

### GetScDnsZoneAliases

`func (o *V12NetworkPool) GetScDnsZoneAliases() []string`

GetScDnsZoneAliases returns the ScDnsZoneAliases field if non-nil, zero value otherwise.

### GetScDnsZoneAliasesOk

`func (o *V12NetworkPool) GetScDnsZoneAliasesOk() (*[]string, bool)`

GetScDnsZoneAliasesOk returns a tuple with the ScDnsZoneAliases field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScDnsZoneAliases

`func (o *V12NetworkPool) SetScDnsZoneAliases(v []string)`

SetScDnsZoneAliases sets ScDnsZoneAliases field to given value.

### HasScDnsZoneAliases

`func (o *V12NetworkPool) HasScDnsZoneAliases() bool`

HasScDnsZoneAliases returns a boolean if a field has been set.

### GetScFailoverPolicy

`func (o *V12NetworkPool) GetScFailoverPolicy() string`

GetScFailoverPolicy returns the ScFailoverPolicy field if non-nil, zero value otherwise.

### GetScFailoverPolicyOk

`func (o *V12NetworkPool) GetScFailoverPolicyOk() (*string, bool)`

GetScFailoverPolicyOk returns a tuple with the ScFailoverPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScFailoverPolicy

`func (o *V12NetworkPool) SetScFailoverPolicy(v string)`

SetScFailoverPolicy sets ScFailoverPolicy field to given value.

### HasScFailoverPolicy

`func (o *V12NetworkPool) HasScFailoverPolicy() bool`

HasScFailoverPolicy returns a boolean if a field has been set.

### GetScSubnet

`func (o *V12NetworkPool) GetScSubnet() string`

GetScSubnet returns the ScSubnet field if non-nil, zero value otherwise.

### GetScSubnetOk

`func (o *V12NetworkPool) GetScSubnetOk() (*string, bool)`

GetScSubnetOk returns a tuple with the ScSubnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScSubnet

`func (o *V12NetworkPool) SetScSubnet(v string)`

SetScSubnet sets ScSubnet field to given value.

### HasScSubnet

`func (o *V12NetworkPool) HasScSubnet() bool`

HasScSubnet returns a boolean if a field has been set.

### GetScSuspendedNodes

`func (o *V12NetworkPool) GetScSuspendedNodes() []int32`

GetScSuspendedNodes returns the ScSuspendedNodes field if non-nil, zero value otherwise.

### GetScSuspendedNodesOk

`func (o *V12NetworkPool) GetScSuspendedNodesOk() (*[]int32, bool)`

GetScSuspendedNodesOk returns a tuple with the ScSuspendedNodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScSuspendedNodes

`func (o *V12NetworkPool) SetScSuspendedNodes(v []int32)`

SetScSuspendedNodes sets ScSuspendedNodes field to given value.

### HasScSuspendedNodes

`func (o *V12NetworkPool) HasScSuspendedNodes() bool`

HasScSuspendedNodes returns a boolean if a field has been set.

### GetScTtl

`func (o *V12NetworkPool) GetScTtl() int32`

GetScTtl returns the ScTtl field if non-nil, zero value otherwise.

### GetScTtlOk

`func (o *V12NetworkPool) GetScTtlOk() (*int32, bool)`

GetScTtlOk returns a tuple with the ScTtl field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScTtl

`func (o *V12NetworkPool) SetScTtl(v int32)`

SetScTtl sets ScTtl field to given value.

### HasScTtl

`func (o *V12NetworkPool) HasScTtl() bool`

HasScTtl returns a boolean if a field has been set.

### GetStaticRoutes

`func (o *V12NetworkPool) GetStaticRoutes() []V12SubnetsSubnetPoolStaticRoute`

GetStaticRoutes returns the StaticRoutes field if non-nil, zero value otherwise.

### GetStaticRoutesOk

`func (o *V12NetworkPool) GetStaticRoutesOk() (*[]V12SubnetsSubnetPoolStaticRoute, bool)`

GetStaticRoutesOk returns a tuple with the StaticRoutes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStaticRoutes

`func (o *V12NetworkPool) SetStaticRoutes(v []V12SubnetsSubnetPoolStaticRoute)`

SetStaticRoutes sets StaticRoutes field to given value.

### HasStaticRoutes

`func (o *V12NetworkPool) HasStaticRoutes() bool`

HasStaticRoutes returns a boolean if a field has been set.

### GetSubnet

`func (o *V12NetworkPool) GetSubnet() string`

GetSubnet returns the Subnet field if non-nil, zero value otherwise.

### GetSubnetOk

`func (o *V12NetworkPool) GetSubnetOk() (*string, bool)`

GetSubnetOk returns a tuple with the Subnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubnet

`func (o *V12NetworkPool) SetSubnet(v string)`

SetSubnet sets Subnet field to given value.

### HasSubnet

`func (o *V12NetworkPool) HasSubnet() bool`

HasSubnet returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


