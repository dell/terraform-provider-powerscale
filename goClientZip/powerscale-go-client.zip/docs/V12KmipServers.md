# V12KmipServers

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Servers** | Pointer to [**[]V12KmipServerExtended**](V12KmipServerExtended.md) |  | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV12KmipServers

`func NewV12KmipServers() *V12KmipServers`

NewV12KmipServers instantiates a new V12KmipServers object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12KmipServersWithDefaults

`func NewV12KmipServersWithDefaults() *V12KmipServers`

NewV12KmipServersWithDefaults instantiates a new V12KmipServers object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetResume

`func (o *V12KmipServers) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12KmipServers) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12KmipServers) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12KmipServers) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetServers

`func (o *V12KmipServers) GetServers() []V12KmipServerExtended`

GetServers returns the Servers field if non-nil, zero value otherwise.

### GetServersOk

`func (o *V12KmipServers) GetServersOk() (*[]V12KmipServerExtended, bool)`

GetServersOk returns a tuple with the Servers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServers

`func (o *V12KmipServers) SetServers(v []V12KmipServerExtended)`

SetServers sets Servers field to given value.

### HasServers

`func (o *V12KmipServers) HasServers() bool`

HasServers returns a boolean if a field has been set.

### GetTotal

`func (o *V12KmipServers) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12KmipServers) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12KmipServers) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12KmipServers) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


