# V14CatalogVerify

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Artifacts** | Pointer to [**[]V14CatalogVerifyArtifact**](V14CatalogVerifyArtifact.md) | List of verified packages | [optional] 

## Methods

### NewV14CatalogVerify

`func NewV14CatalogVerify() *V14CatalogVerify`

NewV14CatalogVerify instantiates a new V14CatalogVerify object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14CatalogVerifyWithDefaults

`func NewV14CatalogVerifyWithDefaults() *V14CatalogVerify`

NewV14CatalogVerifyWithDefaults instantiates a new V14CatalogVerify object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetArtifacts

`func (o *V14CatalogVerify) GetArtifacts() []V14CatalogVerifyArtifact`

GetArtifacts returns the Artifacts field if non-nil, zero value otherwise.

### GetArtifactsOk

`func (o *V14CatalogVerify) GetArtifactsOk() (*[]V14CatalogVerifyArtifact, bool)`

GetArtifactsOk returns a tuple with the Artifacts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetArtifacts

`func (o *V14CatalogVerify) SetArtifacts(v []V14CatalogVerifyArtifact)`

SetArtifacts sets Artifacts field to given value.

### HasArtifacts

`func (o *V14CatalogVerify) HasArtifacts() bool`

HasArtifacts returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


