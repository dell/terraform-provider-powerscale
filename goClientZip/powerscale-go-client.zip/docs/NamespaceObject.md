# NamespaceObject

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessTime** | Pointer to **string** | Specifies the date when the object was last accessed in HTTP date/time format. | [optional] 
**AtimeVal** | Pointer to **int32** | Specifies the time when the object was last accessed in UNIX Epoch format. | [optional] 
**BlockSize** | Pointer to **int32** | Specifies the block size of the object. | [optional] 
**Blocks** | Pointer to **int32** | Specifies the number of blocks that compose the object. | [optional] 
**BtimeVal** | Pointer to **int32** | Specifies the time when the object data was created in UNIX Epoch format. | [optional] 
**ChangeTime** | Pointer to **string** | Specifies the date when the object was last changed (including data and metadata changes) in HTTP date/time format. | [optional] 
**Container** | Pointer to **string** | Specifies the name of the queried container. | [optional] 
**ContainerPath** | Pointer to **string** | Specifies the container path on the file system. | [optional] 
**CreateTime** | Pointer to **string** | Specifies the date when the object data was created in HTTP date/time format. | [optional] 
**CtimeVal** | Pointer to **int32** | Specifies the time when the object was last changed (including data and metadata changes) in UNIX Epoch format. | [optional] 
**Gid** | Pointer to **int32** | Specifies the GID for the owner. | [optional] 
**Group** | Pointer to **string** | Specifies the group name for the owner of the object. | [optional] 
**Id** | Pointer to **int32** | Specifies the object ID, which is also the INODE number. | [optional] 
**IsHidden** | Pointer to **bool** | Specifies whether the file is hidden or not. | [optional] 
**LastModified** | Pointer to **string** | Specifies the time when the object data was last modified in HTTP date/time format. | [optional] 
**Mode** | Pointer to **string** | Specifies the UNIX mode octal number. | [optional] 
**MtimeVal** | Pointer to **int32** | Specifies the time when the object data was last modified in UNIX Epoch format. | [optional] 
**Name** | Pointer to **string** | Specifies the name of the object. | [optional] 
**Nlink** | Pointer to **int32** | Specifies the number of hard links to the object. | [optional] 
**Owner** | Pointer to **string** | Specifies the user name for the owner of the object. | [optional] 
**Size** | Pointer to **int32** | Specifies the size of the object in bytes. | [optional] 
**Stub** | Pointer to **bool** | Specifies whether the file is a stub or not. | [optional] 
**Type** | Pointer to **string** | Specifies the object type, which can be one of the following values: container, object, pipe, character_device, block_device, symbolic_link, socket, or whiteout_file. | [optional] 
**Uid** | Pointer to **int32** | Specifies the UID for the owner. | [optional] 

## Methods

### NewNamespaceObject

`func NewNamespaceObject() *NamespaceObject`

NewNamespaceObject instantiates a new NamespaceObject object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewNamespaceObjectWithDefaults

`func NewNamespaceObjectWithDefaults() *NamespaceObject`

NewNamespaceObjectWithDefaults instantiates a new NamespaceObject object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAccessTime

`func (o *NamespaceObject) GetAccessTime() string`

GetAccessTime returns the AccessTime field if non-nil, zero value otherwise.

### GetAccessTimeOk

`func (o *NamespaceObject) GetAccessTimeOk() (*string, bool)`

GetAccessTimeOk returns a tuple with the AccessTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessTime

`func (o *NamespaceObject) SetAccessTime(v string)`

SetAccessTime sets AccessTime field to given value.

### HasAccessTime

`func (o *NamespaceObject) HasAccessTime() bool`

HasAccessTime returns a boolean if a field has been set.

### GetAtimeVal

`func (o *NamespaceObject) GetAtimeVal() int32`

GetAtimeVal returns the AtimeVal field if non-nil, zero value otherwise.

### GetAtimeValOk

`func (o *NamespaceObject) GetAtimeValOk() (*int32, bool)`

GetAtimeValOk returns a tuple with the AtimeVal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAtimeVal

`func (o *NamespaceObject) SetAtimeVal(v int32)`

SetAtimeVal sets AtimeVal field to given value.

### HasAtimeVal

`func (o *NamespaceObject) HasAtimeVal() bool`

HasAtimeVal returns a boolean if a field has been set.

### GetBlockSize

`func (o *NamespaceObject) GetBlockSize() int32`

GetBlockSize returns the BlockSize field if non-nil, zero value otherwise.

### GetBlockSizeOk

`func (o *NamespaceObject) GetBlockSizeOk() (*int32, bool)`

GetBlockSizeOk returns a tuple with the BlockSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBlockSize

`func (o *NamespaceObject) SetBlockSize(v int32)`

SetBlockSize sets BlockSize field to given value.

### HasBlockSize

`func (o *NamespaceObject) HasBlockSize() bool`

HasBlockSize returns a boolean if a field has been set.

### GetBlocks

`func (o *NamespaceObject) GetBlocks() int32`

GetBlocks returns the Blocks field if non-nil, zero value otherwise.

### GetBlocksOk

`func (o *NamespaceObject) GetBlocksOk() (*int32, bool)`

GetBlocksOk returns a tuple with the Blocks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBlocks

`func (o *NamespaceObject) SetBlocks(v int32)`

SetBlocks sets Blocks field to given value.

### HasBlocks

`func (o *NamespaceObject) HasBlocks() bool`

HasBlocks returns a boolean if a field has been set.

### GetBtimeVal

`func (o *NamespaceObject) GetBtimeVal() int32`

GetBtimeVal returns the BtimeVal field if non-nil, zero value otherwise.

### GetBtimeValOk

`func (o *NamespaceObject) GetBtimeValOk() (*int32, bool)`

GetBtimeValOk returns a tuple with the BtimeVal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBtimeVal

`func (o *NamespaceObject) SetBtimeVal(v int32)`

SetBtimeVal sets BtimeVal field to given value.

### HasBtimeVal

`func (o *NamespaceObject) HasBtimeVal() bool`

HasBtimeVal returns a boolean if a field has been set.

### GetChangeTime

`func (o *NamespaceObject) GetChangeTime() string`

GetChangeTime returns the ChangeTime field if non-nil, zero value otherwise.

### GetChangeTimeOk

`func (o *NamespaceObject) GetChangeTimeOk() (*string, bool)`

GetChangeTimeOk returns a tuple with the ChangeTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChangeTime

`func (o *NamespaceObject) SetChangeTime(v string)`

SetChangeTime sets ChangeTime field to given value.

### HasChangeTime

`func (o *NamespaceObject) HasChangeTime() bool`

HasChangeTime returns a boolean if a field has been set.

### GetContainer

`func (o *NamespaceObject) GetContainer() string`

GetContainer returns the Container field if non-nil, zero value otherwise.

### GetContainerOk

`func (o *NamespaceObject) GetContainerOk() (*string, bool)`

GetContainerOk returns a tuple with the Container field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetContainer

`func (o *NamespaceObject) SetContainer(v string)`

SetContainer sets Container field to given value.

### HasContainer

`func (o *NamespaceObject) HasContainer() bool`

HasContainer returns a boolean if a field has been set.

### GetContainerPath

`func (o *NamespaceObject) GetContainerPath() string`

GetContainerPath returns the ContainerPath field if non-nil, zero value otherwise.

### GetContainerPathOk

`func (o *NamespaceObject) GetContainerPathOk() (*string, bool)`

GetContainerPathOk returns a tuple with the ContainerPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetContainerPath

`func (o *NamespaceObject) SetContainerPath(v string)`

SetContainerPath sets ContainerPath field to given value.

### HasContainerPath

`func (o *NamespaceObject) HasContainerPath() bool`

HasContainerPath returns a boolean if a field has been set.

### GetCreateTime

`func (o *NamespaceObject) GetCreateTime() string`

GetCreateTime returns the CreateTime field if non-nil, zero value otherwise.

### GetCreateTimeOk

`func (o *NamespaceObject) GetCreateTimeOk() (*string, bool)`

GetCreateTimeOk returns a tuple with the CreateTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateTime

`func (o *NamespaceObject) SetCreateTime(v string)`

SetCreateTime sets CreateTime field to given value.

### HasCreateTime

`func (o *NamespaceObject) HasCreateTime() bool`

HasCreateTime returns a boolean if a field has been set.

### GetCtimeVal

`func (o *NamespaceObject) GetCtimeVal() int32`

GetCtimeVal returns the CtimeVal field if non-nil, zero value otherwise.

### GetCtimeValOk

`func (o *NamespaceObject) GetCtimeValOk() (*int32, bool)`

GetCtimeValOk returns a tuple with the CtimeVal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCtimeVal

`func (o *NamespaceObject) SetCtimeVal(v int32)`

SetCtimeVal sets CtimeVal field to given value.

### HasCtimeVal

`func (o *NamespaceObject) HasCtimeVal() bool`

HasCtimeVal returns a boolean if a field has been set.

### GetGid

`func (o *NamespaceObject) GetGid() int32`

GetGid returns the Gid field if non-nil, zero value otherwise.

### GetGidOk

`func (o *NamespaceObject) GetGidOk() (*int32, bool)`

GetGidOk returns a tuple with the Gid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGid

`func (o *NamespaceObject) SetGid(v int32)`

SetGid sets Gid field to given value.

### HasGid

`func (o *NamespaceObject) HasGid() bool`

HasGid returns a boolean if a field has been set.

### GetGroup

`func (o *NamespaceObject) GetGroup() string`

GetGroup returns the Group field if non-nil, zero value otherwise.

### GetGroupOk

`func (o *NamespaceObject) GetGroupOk() (*string, bool)`

GetGroupOk returns a tuple with the Group field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroup

`func (o *NamespaceObject) SetGroup(v string)`

SetGroup sets Group field to given value.

### HasGroup

`func (o *NamespaceObject) HasGroup() bool`

HasGroup returns a boolean if a field has been set.

### GetId

`func (o *NamespaceObject) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *NamespaceObject) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *NamespaceObject) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *NamespaceObject) HasId() bool`

HasId returns a boolean if a field has been set.

### GetIsHidden

`func (o *NamespaceObject) GetIsHidden() bool`

GetIsHidden returns the IsHidden field if non-nil, zero value otherwise.

### GetIsHiddenOk

`func (o *NamespaceObject) GetIsHiddenOk() (*bool, bool)`

GetIsHiddenOk returns a tuple with the IsHidden field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIsHidden

`func (o *NamespaceObject) SetIsHidden(v bool)`

SetIsHidden sets IsHidden field to given value.

### HasIsHidden

`func (o *NamespaceObject) HasIsHidden() bool`

HasIsHidden returns a boolean if a field has been set.

### GetLastModified

`func (o *NamespaceObject) GetLastModified() string`

GetLastModified returns the LastModified field if non-nil, zero value otherwise.

### GetLastModifiedOk

`func (o *NamespaceObject) GetLastModifiedOk() (*string, bool)`

GetLastModifiedOk returns a tuple with the LastModified field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastModified

`func (o *NamespaceObject) SetLastModified(v string)`

SetLastModified sets LastModified field to given value.

### HasLastModified

`func (o *NamespaceObject) HasLastModified() bool`

HasLastModified returns a boolean if a field has been set.

### GetMode

`func (o *NamespaceObject) GetMode() string`

GetMode returns the Mode field if non-nil, zero value otherwise.

### GetModeOk

`func (o *NamespaceObject) GetModeOk() (*string, bool)`

GetModeOk returns a tuple with the Mode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMode

`func (o *NamespaceObject) SetMode(v string)`

SetMode sets Mode field to given value.

### HasMode

`func (o *NamespaceObject) HasMode() bool`

HasMode returns a boolean if a field has been set.

### GetMtimeVal

`func (o *NamespaceObject) GetMtimeVal() int32`

GetMtimeVal returns the MtimeVal field if non-nil, zero value otherwise.

### GetMtimeValOk

`func (o *NamespaceObject) GetMtimeValOk() (*int32, bool)`

GetMtimeValOk returns a tuple with the MtimeVal field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtimeVal

`func (o *NamespaceObject) SetMtimeVal(v int32)`

SetMtimeVal sets MtimeVal field to given value.

### HasMtimeVal

`func (o *NamespaceObject) HasMtimeVal() bool`

HasMtimeVal returns a boolean if a field has been set.

### GetName

`func (o *NamespaceObject) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *NamespaceObject) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *NamespaceObject) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *NamespaceObject) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNlink

`func (o *NamespaceObject) GetNlink() int32`

GetNlink returns the Nlink field if non-nil, zero value otherwise.

### GetNlinkOk

`func (o *NamespaceObject) GetNlinkOk() (*int32, bool)`

GetNlinkOk returns a tuple with the Nlink field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNlink

`func (o *NamespaceObject) SetNlink(v int32)`

SetNlink sets Nlink field to given value.

### HasNlink

`func (o *NamespaceObject) HasNlink() bool`

HasNlink returns a boolean if a field has been set.

### GetOwner

`func (o *NamespaceObject) GetOwner() string`

GetOwner returns the Owner field if non-nil, zero value otherwise.

### GetOwnerOk

`func (o *NamespaceObject) GetOwnerOk() (*string, bool)`

GetOwnerOk returns a tuple with the Owner field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOwner

`func (o *NamespaceObject) SetOwner(v string)`

SetOwner sets Owner field to given value.

### HasOwner

`func (o *NamespaceObject) HasOwner() bool`

HasOwner returns a boolean if a field has been set.

### GetSize

`func (o *NamespaceObject) GetSize() int32`

GetSize returns the Size field if non-nil, zero value otherwise.

### GetSizeOk

`func (o *NamespaceObject) GetSizeOk() (*int32, bool)`

GetSizeOk returns a tuple with the Size field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSize

`func (o *NamespaceObject) SetSize(v int32)`

SetSize sets Size field to given value.

### HasSize

`func (o *NamespaceObject) HasSize() bool`

HasSize returns a boolean if a field has been set.

### GetStub

`func (o *NamespaceObject) GetStub() bool`

GetStub returns the Stub field if non-nil, zero value otherwise.

### GetStubOk

`func (o *NamespaceObject) GetStubOk() (*bool, bool)`

GetStubOk returns a tuple with the Stub field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStub

`func (o *NamespaceObject) SetStub(v bool)`

SetStub sets Stub field to given value.

### HasStub

`func (o *NamespaceObject) HasStub() bool`

HasStub returns a boolean if a field has been set.

### GetType

`func (o *NamespaceObject) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *NamespaceObject) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *NamespaceObject) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *NamespaceObject) HasType() bool`

HasType returns a boolean if a field has been set.

### GetUid

`func (o *NamespaceObject) GetUid() int32`

GetUid returns the Uid field if non-nil, zero value otherwise.

### GetUidOk

`func (o *NamespaceObject) GetUidOk() (*int32, bool)`

GetUidOk returns a tuple with the Uid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUid

`func (o *NamespaceObject) SetUid(v int32)`

SetUid sets Uid field to given value.

### HasUid

`func (o *NamespaceObject) HasUid() bool`

HasUid returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


