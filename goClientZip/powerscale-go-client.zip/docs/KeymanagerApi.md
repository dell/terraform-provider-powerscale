# \KeymanagerApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateKeymanagerv12KmipServer**](KeymanagerApi.md#CreateKeymanagerv12KmipServer) | **Post** /platform/12/keymanager/kmip/servers | 
[**CreateKeymanagerv12KmipServerVerifyItem**](KeymanagerApi.md#CreateKeymanagerv12KmipServerVerifyItem) | **Post** /platform/12/keymanager/kmip/server/verify | 
[**CreateKeymanagerv12SedMigrateItem**](KeymanagerApi.md#CreateKeymanagerv12SedMigrateItem) | **Post** /platform/12/keymanager/sed/migrate | 
[**CreateKeymanagerv16ClusterRekeyItem**](KeymanagerApi.md#CreateKeymanagerv16ClusterRekeyItem) | **Post** /platform/16/keymanager/cluster/rekey | 
[**CreateKeymanagerv16SedRekeyItem**](KeymanagerApi.md#CreateKeymanagerv16SedRekeyItem) | **Post** /platform/16/keymanager/sed/rekey | 
[**DeleteKeymanagerv12KmipServer**](KeymanagerApi.md#DeleteKeymanagerv12KmipServer) | **Delete** /platform/12/keymanager/kmip/servers/{v12KmipServerId} | 
[**GetKeymanagerv12KmipServer**](KeymanagerApi.md#GetKeymanagerv12KmipServer) | **Get** /platform/12/keymanager/kmip/servers/{v12KmipServerId} | 
[**GetKeymanagerv12SedSettings**](KeymanagerApi.md#GetKeymanagerv12SedSettings) | **Get** /platform/12/keymanager/sed/settings | 
[**GetKeymanagerv12SedStatus**](KeymanagerApi.md#GetKeymanagerv12SedStatus) | **Get** /platform/12/keymanager/sed/status | 
[**GetKeymanagerv12SedStatusLnn**](KeymanagerApi.md#GetKeymanagerv12SedStatusLnn) | **Get** /platform/12/keymanager/sed/status/{v12SedStatusLnn} | 
[**GetKeymanagerv16ClusterStatus**](KeymanagerApi.md#GetKeymanagerv16ClusterStatus) | **Get** /platform/16/keymanager/cluster/status | 
[**GetKeymanagerv16KeymanagerCluster**](KeymanagerApi.md#GetKeymanagerv16KeymanagerCluster) | **Get** /platform/16/keymanager/cluster | 
[**GetKeymanagerv16SedStatus**](KeymanagerApi.md#GetKeymanagerv16SedStatus) | **Get** /platform/16/keymanager/sed/status | 
[**GetKeymanagerv16SedStatusLnn**](KeymanagerApi.md#GetKeymanagerv16SedStatusLnn) | **Get** /platform/16/keymanager/sed/status/{v16SedStatusLnn} | 
[**ListKeymanagerv12KmipServers**](KeymanagerApi.md#ListKeymanagerv12KmipServers) | **Get** /platform/12/keymanager/kmip/servers | 
[**ListKeymanagerv16ClusterRekey**](KeymanagerApi.md#ListKeymanagerv16ClusterRekey) | **Get** /platform/16/keymanager/cluster/rekey | 
[**ListKeymanagerv16SedRekey**](KeymanagerApi.md#ListKeymanagerv16SedRekey) | **Get** /platform/16/keymanager/sed/rekey | 
[**UpdateKeymanagerv12KmipServer**](KeymanagerApi.md#UpdateKeymanagerv12KmipServer) | **Put** /platform/12/keymanager/kmip/servers/{v12KmipServerId} | 
[**UpdateKeymanagerv12SedSettings**](KeymanagerApi.md#UpdateKeymanagerv12SedSettings) | **Put** /platform/12/keymanager/sed/settings | 
[**UpdateKeymanagerv16ClusterRekey**](KeymanagerApi.md#UpdateKeymanagerv16ClusterRekey) | **Put** /platform/16/keymanager/cluster/rekey | 
[**UpdateKeymanagerv16SedRekey**](KeymanagerApi.md#UpdateKeymanagerv16SedRekey) | **Put** /platform/16/keymanager/sed/rekey | 



## CreateKeymanagerv12KmipServer

> CreateResponse CreateKeymanagerv12KmipServer(ctx).V12KmipServer(v12KmipServer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12KmipServer := *openapiclient.NewV12KmipServer("CaCertPath_example", "ClientCertPath_example", "Host_example", "Id_example") // V12KmipServer | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.CreateKeymanagerv12KmipServer(context.Background()).V12KmipServer(v12KmipServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.CreateKeymanagerv12KmipServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateKeymanagerv12KmipServer`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.CreateKeymanagerv12KmipServer`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateKeymanagerv12KmipServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12KmipServer** | [**V12KmipServer**](V12KmipServer.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateKeymanagerv12KmipServerVerifyItem

> Createv12KmipServerVerifyItemResponse CreateKeymanagerv12KmipServerVerifyItem(ctx).V12KmipServerVerifyItem(v12KmipServerVerifyItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12KmipServerVerifyItem := *openapiclient.NewV12KmipServerVerifyItem("CaCertPath_example", "ClientCertPath_example", "Host_example") // V12KmipServerVerifyItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.CreateKeymanagerv12KmipServerVerifyItem(context.Background()).V12KmipServerVerifyItem(v12KmipServerVerifyItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.CreateKeymanagerv12KmipServerVerifyItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateKeymanagerv12KmipServerVerifyItem`: Createv12KmipServerVerifyItemResponse
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.CreateKeymanagerv12KmipServerVerifyItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateKeymanagerv12KmipServerVerifyItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12KmipServerVerifyItem** | [**V12KmipServerVerifyItem**](V12KmipServerVerifyItem.md) |  | 

### Return type

[**Createv12KmipServerVerifyItemResponse**](Createv12KmipServerVerifyItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateKeymanagerv12SedMigrateItem

> Createv12SedMigrateItemResponse CreateKeymanagerv12SedMigrateItem(ctx).V12SedMigrateItem(v12SedMigrateItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SedMigrateItem := *openapiclient.NewV12SedMigrateItem() // V12SedMigrateItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.CreateKeymanagerv12SedMigrateItem(context.Background()).V12SedMigrateItem(v12SedMigrateItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.CreateKeymanagerv12SedMigrateItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateKeymanagerv12SedMigrateItem`: Createv12SedMigrateItemResponse
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.CreateKeymanagerv12SedMigrateItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateKeymanagerv12SedMigrateItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12SedMigrateItem** | [**V12SedMigrateItem**](V12SedMigrateItem.md) |  | 

### Return type

[**Createv12SedMigrateItemResponse**](Createv12SedMigrateItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateKeymanagerv16ClusterRekeyItem

> Createv16ClusterRekeyItemResponse CreateKeymanagerv16ClusterRekeyItem(ctx).V16ClusterRekeyItem(v16ClusterRekeyItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16ClusterRekeyItem := *openapiclient.NewV16ClusterRekeyItem() // V16ClusterRekeyItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.CreateKeymanagerv16ClusterRekeyItem(context.Background()).V16ClusterRekeyItem(v16ClusterRekeyItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.CreateKeymanagerv16ClusterRekeyItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateKeymanagerv16ClusterRekeyItem`: Createv16ClusterRekeyItemResponse
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.CreateKeymanagerv16ClusterRekeyItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateKeymanagerv16ClusterRekeyItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16ClusterRekeyItem** | [**V16ClusterRekeyItem**](V16ClusterRekeyItem.md) |  | 

### Return type

[**Createv16ClusterRekeyItemResponse**](Createv16ClusterRekeyItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateKeymanagerv16SedRekeyItem

> Createv16ClusterRekeyItemResponse CreateKeymanagerv16SedRekeyItem(ctx).V16SedRekeyItem(v16SedRekeyItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SedRekeyItem := *openapiclient.NewV16ClusterRekeyItem() // V16ClusterRekeyItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.CreateKeymanagerv16SedRekeyItem(context.Background()).V16SedRekeyItem(v16SedRekeyItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.CreateKeymanagerv16SedRekeyItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateKeymanagerv16SedRekeyItem`: Createv16ClusterRekeyItemResponse
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.CreateKeymanagerv16SedRekeyItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateKeymanagerv16SedRekeyItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16SedRekeyItem** | [**V16ClusterRekeyItem**](V16ClusterRekeyItem.md) |  | 

### Return type

[**Createv16ClusterRekeyItemResponse**](Createv16ClusterRekeyItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteKeymanagerv12KmipServer

> DeleteKeymanagerv12KmipServer(ctx, v12KmipServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12KmipServerId := "v12KmipServerId_example" // string | Delete a KMIP server entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.KeymanagerApi.DeleteKeymanagerv12KmipServer(context.Background(), v12KmipServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.DeleteKeymanagerv12KmipServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12KmipServerId** | **string** | Delete a KMIP server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteKeymanagerv12KmipServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv12KmipServer

> V12KmipServersExtended GetKeymanagerv12KmipServer(ctx, v12KmipServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12KmipServerId := "v12KmipServerId_example" // string | Retrieve a specific KMIP server entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv12KmipServer(context.Background(), v12KmipServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv12KmipServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv12KmipServer`: V12KmipServersExtended
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv12KmipServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12KmipServerId** | **string** | Retrieve a specific KMIP server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv12KmipServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12KmipServersExtended**](V12KmipServersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv12SedSettings

> V12SedSettings GetKeymanagerv12SedSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv12SedSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv12SedSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv12SedSettings`: V12SedSettings
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv12SedSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv12SedSettingsRequest struct via the builder pattern


### Return type

[**V12SedSettings**](V12SedSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv12SedStatus

> V12SedStatus GetKeymanagerv12SedStatus(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv12SedStatus(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv12SedStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv12SedStatus`: V12SedStatus
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv12SedStatus`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv12SedStatusRequest struct via the builder pattern


### Return type

[**V12SedStatus**](V12SedStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv12SedStatusLnn

> V12SedStatusExtended GetKeymanagerv12SedStatusLnn(ctx, v12SedStatusLnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SedStatusLnn := int32(56) // int32 | Retrieve SED status on a node in this cluster.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv12SedStatusLnn(context.Background(), v12SedStatusLnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv12SedStatusLnn``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv12SedStatusLnn`: V12SedStatusExtended
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv12SedStatusLnn`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12SedStatusLnn** | **int32** | Retrieve SED status on a node in this cluster. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv12SedStatusLnnRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12SedStatusExtended**](V12SedStatusExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv16ClusterStatus

> V16ClusterStatus GetKeymanagerv16ClusterStatus(ctx).Limit(limit).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv16ClusterStatus(context.Background()).Limit(limit).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv16ClusterStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv16ClusterStatus`: V16ClusterStatus
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv16ClusterStatus`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv16ClusterStatusRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 

### Return type

[**V16ClusterStatus**](V16ClusterStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv16KeymanagerCluster

> V16KeymanagerCluster GetKeymanagerv16KeymanagerCluster(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv16KeymanagerCluster(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv16KeymanagerCluster``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv16KeymanagerCluster`: V16KeymanagerCluster
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv16KeymanagerCluster`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv16KeymanagerClusterRequest struct via the builder pattern


### Return type

[**V16KeymanagerCluster**](V16KeymanagerCluster.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv16SedStatus

> V16SedStatus GetKeymanagerv16SedStatus(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv16SedStatus(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv16SedStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv16SedStatus`: V16SedStatus
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv16SedStatus`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv16SedStatusRequest struct via the builder pattern


### Return type

[**V16SedStatus**](V16SedStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv16SedStatusLnn

> V16SedStatusExtended GetKeymanagerv16SedStatusLnn(ctx, v16SedStatusLnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SedStatusLnn := int32(56) // int32 | Retrieve SED status on a node in this cluster.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv16SedStatusLnn(context.Background(), v16SedStatusLnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv16SedStatusLnn``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv16SedStatusLnn`: V16SedStatusExtended
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv16SedStatusLnn`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v16SedStatusLnn** | **int32** | Retrieve SED status on a node in this cluster. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv16SedStatusLnnRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V16SedStatusExtended**](V16SedStatusExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListKeymanagerv12KmipServers

> V12KmipServers ListKeymanagerv12KmipServers(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.ListKeymanagerv12KmipServers(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.ListKeymanagerv12KmipServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListKeymanagerv12KmipServers`: V12KmipServers
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.ListKeymanagerv12KmipServers`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListKeymanagerv12KmipServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V12KmipServers**](V12KmipServers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListKeymanagerv16ClusterRekey

> V16ClusterRekey ListKeymanagerv16ClusterRekey(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.ListKeymanagerv16ClusterRekey(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.ListKeymanagerv16ClusterRekey``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListKeymanagerv16ClusterRekey`: V16ClusterRekey
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.ListKeymanagerv16ClusterRekey`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListKeymanagerv16ClusterRekeyRequest struct via the builder pattern


### Return type

[**V16ClusterRekey**](V16ClusterRekey.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListKeymanagerv16SedRekey

> V16ClusterRekey ListKeymanagerv16SedRekey(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.ListKeymanagerv16SedRekey(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.ListKeymanagerv16SedRekey``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListKeymanagerv16SedRekey`: V16ClusterRekey
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.ListKeymanagerv16SedRekey`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListKeymanagerv16SedRekeyRequest struct via the builder pattern


### Return type

[**V16ClusterRekey**](V16ClusterRekey.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateKeymanagerv12KmipServer

> UpdateKeymanagerv12KmipServer(ctx, v12KmipServerId).V12KmipServer(v12KmipServer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12KmipServerId := "v12KmipServerId_example" // string | Modify a KMIP server entry.
    v12KmipServer := *openapiclient.NewV12KmipServerExtendedExtended() // V12KmipServerExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.KeymanagerApi.UpdateKeymanagerv12KmipServer(context.Background(), v12KmipServerId).V12KmipServer(v12KmipServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.UpdateKeymanagerv12KmipServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12KmipServerId** | **string** | Modify a KMIP server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateKeymanagerv12KmipServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12KmipServer** | [**V12KmipServerExtendedExtended**](V12KmipServerExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateKeymanagerv12SedSettings

> UpdateKeymanagerv12SedSettings(ctx).V12SedSettings(v12SedSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SedSettings := *openapiclient.NewV12SedSettingsExtended() // V12SedSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.KeymanagerApi.UpdateKeymanagerv12SedSettings(context.Background()).V12SedSettings(v12SedSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.UpdateKeymanagerv12SedSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateKeymanagerv12SedSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12SedSettings** | [**V12SedSettingsExtended**](V12SedSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateKeymanagerv16ClusterRekey

> UpdateKeymanagerv16ClusterRekey(ctx).V16ClusterRekey(v16ClusterRekey).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16ClusterRekey := *openapiclient.NewV16ClusterRekeyExtended() // V16ClusterRekeyExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.KeymanagerApi.UpdateKeymanagerv16ClusterRekey(context.Background()).V16ClusterRekey(v16ClusterRekey).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.UpdateKeymanagerv16ClusterRekey``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateKeymanagerv16ClusterRekeyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16ClusterRekey** | [**V16ClusterRekeyExtended**](V16ClusterRekeyExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateKeymanagerv16SedRekey

> UpdateKeymanagerv16SedRekey(ctx).V16SedRekey(v16SedRekey).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v16SedRekey := *openapiclient.NewV16ClusterRekeyExtended() // V16ClusterRekeyExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.KeymanagerApi.UpdateKeymanagerv16SedRekey(context.Background()).V16SedRekey(v16SedRekey).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.UpdateKeymanagerv16SedRekey``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateKeymanagerv16SedRekeyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v16SedRekey** | [**V16ClusterRekeyExtended**](V16ClusterRekeyExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

