# \KeymanagerApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateKeymanagerv12KmipServer**](KeymanagerApi.md#CreateKeymanagerv12KmipServer) | **Post** /platform/12/keymanager/kmip/servers | 
[**CreateKeymanagerv12SedMigrateItem**](KeymanagerApi.md#CreateKeymanagerv12SedMigrateItem) | **Post** /platform/12/keymanager/sed/migrate | 
[**DeleteKeymanagerv12KmipServer**](KeymanagerApi.md#DeleteKeymanagerv12KmipServer) | **Delete** /platform/12/keymanager/kmip/servers/{v12KmipServerId} | 
[**GetKeymanagerv12KmipServer**](KeymanagerApi.md#GetKeymanagerv12KmipServer) | **Get** /platform/12/keymanager/kmip/servers/{v12KmipServerId} | 
[**GetKeymanagerv12SedSettings**](KeymanagerApi.md#GetKeymanagerv12SedSettings) | **Get** /platform/12/keymanager/sed/settings | 
[**GetKeymanagerv12SedStatus**](KeymanagerApi.md#GetKeymanagerv12SedStatus) | **Get** /platform/12/keymanager/sed/status | 
[**GetKeymanagerv12SedStatusLnn**](KeymanagerApi.md#GetKeymanagerv12SedStatusLnn) | **Get** /platform/12/keymanager/sed/status/{v12SedStatusLnn} | 
[**ListKeymanagerv12KmipServers**](KeymanagerApi.md#ListKeymanagerv12KmipServers) | **Get** /platform/12/keymanager/kmip/servers | 
[**UpdateKeymanagerv12KmipServer**](KeymanagerApi.md#UpdateKeymanagerv12KmipServer) | **Put** /platform/12/keymanager/kmip/servers/{v12KmipServerId} | 
[**UpdateKeymanagerv12SedSettings**](KeymanagerApi.md#UpdateKeymanagerv12SedSettings) | **Put** /platform/12/keymanager/sed/settings | 



## CreateKeymanagerv12KmipServer

> CreateResponse CreateKeymanagerv12KmipServer(ctx).V12KmipServer(v12KmipServer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12KmipServer := *openapiclient.NewV12KmipServer("CaCertPath_example", "ClientCertPath_example", "Host_example", "Id_example") // V12KmipServer | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.CreateKeymanagerv12KmipServer(context.Background()).V12KmipServer(v12KmipServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.CreateKeymanagerv12KmipServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateKeymanagerv12KmipServer`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.CreateKeymanagerv12KmipServer`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateKeymanagerv12KmipServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12KmipServer** | [**V12KmipServer**](V12KmipServer.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateKeymanagerv12SedMigrateItem

> Createv12SedMigrateItemResponse CreateKeymanagerv12SedMigrateItem(ctx).V12SedMigrateItem(v12SedMigrateItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SedMigrateItem := *openapiclient.NewV12SedMigrateItem() // V12SedMigrateItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.CreateKeymanagerv12SedMigrateItem(context.Background()).V12SedMigrateItem(v12SedMigrateItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.CreateKeymanagerv12SedMigrateItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateKeymanagerv12SedMigrateItem`: Createv12SedMigrateItemResponse
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.CreateKeymanagerv12SedMigrateItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateKeymanagerv12SedMigrateItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12SedMigrateItem** | [**V12SedMigrateItem**](V12SedMigrateItem.md) |  | 

### Return type

[**Createv12SedMigrateItemResponse**](Createv12SedMigrateItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteKeymanagerv12KmipServer

> DeleteKeymanagerv12KmipServer(ctx, v12KmipServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12KmipServerId := "v12KmipServerId_example" // string | Delete a KMIP server entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.KeymanagerApi.DeleteKeymanagerv12KmipServer(context.Background(), v12KmipServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.DeleteKeymanagerv12KmipServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12KmipServerId** | **string** | Delete a KMIP server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteKeymanagerv12KmipServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv12KmipServer

> V12KmipServersExtended GetKeymanagerv12KmipServer(ctx, v12KmipServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12KmipServerId := "v12KmipServerId_example" // string | Retrieve a specific KMIP server entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv12KmipServer(context.Background(), v12KmipServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv12KmipServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv12KmipServer`: V12KmipServersExtended
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv12KmipServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12KmipServerId** | **string** | Retrieve a specific KMIP server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv12KmipServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12KmipServersExtended**](V12KmipServersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv12SedSettings

> V12SedSettings GetKeymanagerv12SedSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv12SedSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv12SedSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv12SedSettings`: V12SedSettings
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv12SedSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv12SedSettingsRequest struct via the builder pattern


### Return type

[**V12SedSettings**](V12SedSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv12SedStatus

> V12SedStatus GetKeymanagerv12SedStatus(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv12SedStatus(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv12SedStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv12SedStatus`: V12SedStatus
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv12SedStatus`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv12SedStatusRequest struct via the builder pattern


### Return type

[**V12SedStatus**](V12SedStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetKeymanagerv12SedStatusLnn

> V12SedStatusExtended GetKeymanagerv12SedStatusLnn(ctx, v12SedStatusLnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SedStatusLnn := int32(56) // int32 | Retrieve SED status on a node in this cluster.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.GetKeymanagerv12SedStatusLnn(context.Background(), v12SedStatusLnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.GetKeymanagerv12SedStatusLnn``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetKeymanagerv12SedStatusLnn`: V12SedStatusExtended
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.GetKeymanagerv12SedStatusLnn`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12SedStatusLnn** | **int32** | Retrieve SED status on a node in this cluster. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetKeymanagerv12SedStatusLnnRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12SedStatusExtended**](V12SedStatusExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListKeymanagerv12KmipServers

> V12KmipServers ListKeymanagerv12KmipServers(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.KeymanagerApi.ListKeymanagerv12KmipServers(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.ListKeymanagerv12KmipServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListKeymanagerv12KmipServers`: V12KmipServers
    fmt.Fprintf(os.Stdout, "Response from `KeymanagerApi.ListKeymanagerv12KmipServers`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListKeymanagerv12KmipServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V12KmipServers**](V12KmipServers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateKeymanagerv12KmipServer

> UpdateKeymanagerv12KmipServer(ctx, v12KmipServerId).V12KmipServer(v12KmipServer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12KmipServerId := "v12KmipServerId_example" // string | Modify a KMIP server entry.
    v12KmipServer := *openapiclient.NewV12KmipServerExtendedExtended() // V12KmipServerExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.KeymanagerApi.UpdateKeymanagerv12KmipServer(context.Background(), v12KmipServerId).V12KmipServer(v12KmipServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.UpdateKeymanagerv12KmipServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12KmipServerId** | **string** | Modify a KMIP server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateKeymanagerv12KmipServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12KmipServer** | [**V12KmipServerExtendedExtended**](V12KmipServerExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateKeymanagerv12SedSettings

> UpdateKeymanagerv12SedSettings(ctx).V12SedSettings(v12SedSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12SedSettings := *openapiclient.NewV12SedSettingsExtended() // V12SedSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.KeymanagerApi.UpdateKeymanagerv12SedSettings(context.Background()).V12SedSettings(v12SedSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `KeymanagerApi.UpdateKeymanagerv12SedSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateKeymanagerv12SedSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12SedSettings** | [**V12SedSettingsExtended**](V12SedSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

