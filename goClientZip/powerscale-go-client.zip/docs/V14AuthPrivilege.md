# V14AuthPrivilege

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Category** | **string** | Specifies the general categorization of the privilege. | 
**Description** | **string** | Specifies a short description of the privilege. | 
**Id** | **string** | Specifies the ID of the privilege. | 
**Name** | Pointer to **string** | Specifies the name of the privilege. | [optional] 
**ParentId** | Pointer to **string** | Specifies the parent ID of the privilege. | [optional] 
**Permission** | Pointer to **string** | Permissions the privilege has r&#x3D;read , x&#x3D;read-execute, w&#x3D;read-execute-write. | [optional] 
**Privilegelevel** | Pointer to **string** | Specifies the level of the privilege. | [optional] 
**Uri** | Pointer to **string** | Specifies the associated uri for the privilege. | [optional] 

## Methods

### NewV14AuthPrivilege

`func NewV14AuthPrivilege(category string, description string, id string, ) *V14AuthPrivilege`

NewV14AuthPrivilege instantiates a new V14AuthPrivilege object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14AuthPrivilegeWithDefaults

`func NewV14AuthPrivilegeWithDefaults() *V14AuthPrivilege`

NewV14AuthPrivilegeWithDefaults instantiates a new V14AuthPrivilege object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCategory

`func (o *V14AuthPrivilege) GetCategory() string`

GetCategory returns the Category field if non-nil, zero value otherwise.

### GetCategoryOk

`func (o *V14AuthPrivilege) GetCategoryOk() (*string, bool)`

GetCategoryOk returns a tuple with the Category field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCategory

`func (o *V14AuthPrivilege) SetCategory(v string)`

SetCategory sets Category field to given value.


### GetDescription

`func (o *V14AuthPrivilege) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V14AuthPrivilege) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V14AuthPrivilege) SetDescription(v string)`

SetDescription sets Description field to given value.


### GetId

`func (o *V14AuthPrivilege) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V14AuthPrivilege) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V14AuthPrivilege) SetId(v string)`

SetId sets Id field to given value.


### GetName

`func (o *V14AuthPrivilege) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V14AuthPrivilege) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V14AuthPrivilege) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V14AuthPrivilege) HasName() bool`

HasName returns a boolean if a field has been set.

### GetParentId

`func (o *V14AuthPrivilege) GetParentId() string`

GetParentId returns the ParentId field if non-nil, zero value otherwise.

### GetParentIdOk

`func (o *V14AuthPrivilege) GetParentIdOk() (*string, bool)`

GetParentIdOk returns a tuple with the ParentId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParentId

`func (o *V14AuthPrivilege) SetParentId(v string)`

SetParentId sets ParentId field to given value.

### HasParentId

`func (o *V14AuthPrivilege) HasParentId() bool`

HasParentId returns a boolean if a field has been set.

### GetPermission

`func (o *V14AuthPrivilege) GetPermission() string`

GetPermission returns the Permission field if non-nil, zero value otherwise.

### GetPermissionOk

`func (o *V14AuthPrivilege) GetPermissionOk() (*string, bool)`

GetPermissionOk returns a tuple with the Permission field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPermission

`func (o *V14AuthPrivilege) SetPermission(v string)`

SetPermission sets Permission field to given value.

### HasPermission

`func (o *V14AuthPrivilege) HasPermission() bool`

HasPermission returns a boolean if a field has been set.

### GetPrivilegelevel

`func (o *V14AuthPrivilege) GetPrivilegelevel() string`

GetPrivilegelevel returns the Privilegelevel field if non-nil, zero value otherwise.

### GetPrivilegelevelOk

`func (o *V14AuthPrivilege) GetPrivilegelevelOk() (*string, bool)`

GetPrivilegelevelOk returns a tuple with the Privilegelevel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrivilegelevel

`func (o *V14AuthPrivilege) SetPrivilegelevel(v string)`

SetPrivilegelevel sets Privilegelevel field to given value.

### HasPrivilegelevel

`func (o *V14AuthPrivilege) HasPrivilegelevel() bool`

HasPrivilegelevel returns a boolean if a field has been set.

### GetUri

`func (o *V14AuthPrivilege) GetUri() string`

GetUri returns the Uri field if non-nil, zero value otherwise.

### GetUriOk

`func (o *V14AuthPrivilege) GetUriOk() (*string, bool)`

GetUriOk returns a tuple with the Uri field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUri

`func (o *V14AuthPrivilege) SetUri(v string)`

SetUri sets Uri field to given value.

### HasUri

`func (o *V14AuthPrivilege) HasUri() bool`

HasUri returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


