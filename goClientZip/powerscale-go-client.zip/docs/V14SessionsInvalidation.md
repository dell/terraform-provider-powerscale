# V14SessionsInvalidation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Expiration** | Pointer to **int32** | The time in seconds since the UNIX epoc when this invalidation expires. | [optional] 
**Id** | **string** | Specifies the serialized form of the user persona, which can be &#39;UID:0&#39;, &#39;USER:name&#39; or &#39;SID:S-1-1&#39;. | 
**NotBefore** | Pointer to **int32** | The time in seconds since the UNIX epoch, before which sessions for a user are disallowed. | [optional] 

## Methods

### NewV14SessionsInvalidation

`func NewV14SessionsInvalidation(id string, ) *V14SessionsInvalidation`

NewV14SessionsInvalidation instantiates a new V14SessionsInvalidation object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SessionsInvalidationWithDefaults

`func NewV14SessionsInvalidationWithDefaults() *V14SessionsInvalidation`

NewV14SessionsInvalidationWithDefaults instantiates a new V14SessionsInvalidation object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExpiration

`func (o *V14SessionsInvalidation) GetExpiration() int32`

GetExpiration returns the Expiration field if non-nil, zero value otherwise.

### GetExpirationOk

`func (o *V14SessionsInvalidation) GetExpirationOk() (*int32, bool)`

GetExpirationOk returns a tuple with the Expiration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpiration

`func (o *V14SessionsInvalidation) SetExpiration(v int32)`

SetExpiration sets Expiration field to given value.

### HasExpiration

`func (o *V14SessionsInvalidation) HasExpiration() bool`

HasExpiration returns a boolean if a field has been set.

### GetId

`func (o *V14SessionsInvalidation) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V14SessionsInvalidation) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V14SessionsInvalidation) SetId(v string)`

SetId sets Id field to given value.


### GetNotBefore

`func (o *V14SessionsInvalidation) GetNotBefore() int32`

GetNotBefore returns the NotBefore field if non-nil, zero value otherwise.

### GetNotBeforeOk

`func (o *V14SessionsInvalidation) GetNotBeforeOk() (*int32, bool)`

GetNotBeforeOk returns a tuple with the NotBefore field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNotBefore

`func (o *V14SessionsInvalidation) SetNotBefore(v int32)`

SetNotBefore sets NotBefore field to given value.

### HasNotBefore

`func (o *V14SessionsInvalidation) HasNotBefore() bool`

HasNotBefore returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


