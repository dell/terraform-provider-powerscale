# V10ChangelistsChangelistDiffRegions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DiffRegions** | Pointer to [**[]V10ChangelistsChangelistDiffRegionsDiffRegion**](V10ChangelistsChangelistDiffRegionsDiffRegion.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 

## Methods

### NewV10ChangelistsChangelistDiffRegions

`func NewV10ChangelistsChangelistDiffRegions() *V10ChangelistsChangelistDiffRegions`

NewV10ChangelistsChangelistDiffRegions instantiates a new V10ChangelistsChangelistDiffRegions object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ChangelistsChangelistDiffRegionsWithDefaults

`func NewV10ChangelistsChangelistDiffRegionsWithDefaults() *V10ChangelistsChangelistDiffRegions`

NewV10ChangelistsChangelistDiffRegionsWithDefaults instantiates a new V10ChangelistsChangelistDiffRegions object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDiffRegions

`func (o *V10ChangelistsChangelistDiffRegions) GetDiffRegions() []V10ChangelistsChangelistDiffRegionsDiffRegion`

GetDiffRegions returns the DiffRegions field if non-nil, zero value otherwise.

### GetDiffRegionsOk

`func (o *V10ChangelistsChangelistDiffRegions) GetDiffRegionsOk() (*[]V10ChangelistsChangelistDiffRegionsDiffRegion, bool)`

GetDiffRegionsOk returns a tuple with the DiffRegions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiffRegions

`func (o *V10ChangelistsChangelistDiffRegions) SetDiffRegions(v []V10ChangelistsChangelistDiffRegionsDiffRegion)`

SetDiffRegions sets DiffRegions field to given value.

### HasDiffRegions

`func (o *V10ChangelistsChangelistDiffRegions) HasDiffRegions() bool`

HasDiffRegions returns a boolean if a field has been set.

### GetResume

`func (o *V10ChangelistsChangelistDiffRegions) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V10ChangelistsChangelistDiffRegions) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V10ChangelistsChangelistDiffRegions) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V10ChangelistsChangelistDiffRegions) HasResume() bool`

HasResume returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


