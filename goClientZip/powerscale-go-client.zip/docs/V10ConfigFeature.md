# V10ConfigFeature

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | Pointer to **bool** | A True value indicates the BMC LAN feature is currently enabled on the cluster. | [optional] 
**FeatureDescription** | Pointer to **string** | A longer more formal description of the feature. | [optional] 
**Id** | Pointer to **string** | A string used to identify the feature, such as sol for Serial-Over-LAN or power-control for Power Control. | [optional] 

## Methods

### NewV10ConfigFeature

`func NewV10ConfigFeature() *V10ConfigFeature`

NewV10ConfigFeature instantiates a new V10ConfigFeature object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ConfigFeatureWithDefaults

`func NewV10ConfigFeatureWithDefaults() *V10ConfigFeature`

NewV10ConfigFeatureWithDefaults instantiates a new V10ConfigFeature object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *V10ConfigFeature) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V10ConfigFeature) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V10ConfigFeature) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V10ConfigFeature) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetFeatureDescription

`func (o *V10ConfigFeature) GetFeatureDescription() string`

GetFeatureDescription returns the FeatureDescription field if non-nil, zero value otherwise.

### GetFeatureDescriptionOk

`func (o *V10ConfigFeature) GetFeatureDescriptionOk() (*string, bool)`

GetFeatureDescriptionOk returns a tuple with the FeatureDescription field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFeatureDescription

`func (o *V10ConfigFeature) SetFeatureDescription(v string)`

SetFeatureDescription sets FeatureDescription field to given value.

### HasFeatureDescription

`func (o *V10ConfigFeature) HasFeatureDescription() bool`

HasFeatureDescription returns a boolean if a field has been set.

### GetId

`func (o *V10ConfigFeature) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10ConfigFeature) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10ConfigFeature) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V10ConfigFeature) HasId() bool`

HasId returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


