# V12NodeStateServicelightNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | **bool** | The node service light state (True &#x3D; on). | 
**Error** | Pointer to **string** | Error message, if the HTTP status returned from this node was not 200. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Status** | Pointer to **int32** | Status of the HTTP response from this node if not 200.  If 200, this field does not appear. | [optional] 
**Supported** | Pointer to **bool** | This node supports a service light. | [optional] 
**Valid** | Pointer to **bool** | The node service light state is valid (False &#x3D; Error). | [optional] 

## Methods

### NewV12NodeStateServicelightNode

`func NewV12NodeStateServicelightNode(enabled bool, ) *V12NodeStateServicelightNode`

NewV12NodeStateServicelightNode instantiates a new V12NodeStateServicelightNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NodeStateServicelightNodeWithDefaults

`func NewV12NodeStateServicelightNodeWithDefaults() *V12NodeStateServicelightNode`

NewV12NodeStateServicelightNodeWithDefaults instantiates a new V12NodeStateServicelightNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *V12NodeStateServicelightNode) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V12NodeStateServicelightNode) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V12NodeStateServicelightNode) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.


### GetError

`func (o *V12NodeStateServicelightNode) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V12NodeStateServicelightNode) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V12NodeStateServicelightNode) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V12NodeStateServicelightNode) HasError() bool`

HasError returns a boolean if a field has been set.

### GetId

`func (o *V12NodeStateServicelightNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12NodeStateServicelightNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12NodeStateServicelightNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V12NodeStateServicelightNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V12NodeStateServicelightNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12NodeStateServicelightNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12NodeStateServicelightNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V12NodeStateServicelightNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetStatus

`func (o *V12NodeStateServicelightNode) GetStatus() int32`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12NodeStateServicelightNode) GetStatusOk() (*int32, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12NodeStateServicelightNode) SetStatus(v int32)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V12NodeStateServicelightNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetSupported

`func (o *V12NodeStateServicelightNode) GetSupported() bool`

GetSupported returns the Supported field if non-nil, zero value otherwise.

### GetSupportedOk

`func (o *V12NodeStateServicelightNode) GetSupportedOk() (*bool, bool)`

GetSupportedOk returns a tuple with the Supported field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupported

`func (o *V12NodeStateServicelightNode) SetSupported(v bool)`

SetSupported sets Supported field to given value.

### HasSupported

`func (o *V12NodeStateServicelightNode) HasSupported() bool`

HasSupported returns a boolean if a field has been set.

### GetValid

`func (o *V12NodeStateServicelightNode) GetValid() bool`

GetValid returns the Valid field if non-nil, zero value otherwise.

### GetValidOk

`func (o *V12NodeStateServicelightNode) GetValidOk() (*bool, bool)`

GetValidOk returns a tuple with the Valid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValid

`func (o *V12NodeStateServicelightNode) SetValid(v bool)`

SetValid sets Valid field to given value.

### HasValid

`func (o *V12NodeStateServicelightNode) HasValid() bool`

HasValid returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


