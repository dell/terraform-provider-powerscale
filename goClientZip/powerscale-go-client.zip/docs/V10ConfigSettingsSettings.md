# V10ConfigSettingsSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AllocationType** | Pointer to **string** | Identifies the current network type (dhcp or static) being used for this BMC LAN interface. | [optional] 
**Enabled** | Pointer to **bool** | A True value indicates the Remote IPMI Management feature is currently enabled on the cluster. | [optional] 

## Methods

### NewV10ConfigSettingsSettings

`func NewV10ConfigSettingsSettings() *V10ConfigSettingsSettings`

NewV10ConfigSettingsSettings instantiates a new V10ConfigSettingsSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ConfigSettingsSettingsWithDefaults

`func NewV10ConfigSettingsSettingsWithDefaults() *V10ConfigSettingsSettings`

NewV10ConfigSettingsSettingsWithDefaults instantiates a new V10ConfigSettingsSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllocationType

`func (o *V10ConfigSettingsSettings) GetAllocationType() string`

GetAllocationType returns the AllocationType field if non-nil, zero value otherwise.

### GetAllocationTypeOk

`func (o *V10ConfigSettingsSettings) GetAllocationTypeOk() (*string, bool)`

GetAllocationTypeOk returns a tuple with the AllocationType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllocationType

`func (o *V10ConfigSettingsSettings) SetAllocationType(v string)`

SetAllocationType sets AllocationType field to given value.

### HasAllocationType

`func (o *V10ConfigSettingsSettings) HasAllocationType() bool`

HasAllocationType returns a boolean if a field has been set.

### GetEnabled

`func (o *V10ConfigSettingsSettings) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V10ConfigSettingsSettings) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V10ConfigSettingsSettings) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V10ConfigSettingsSettings) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


