# DirectoryQuery

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Result** | Pointer to **[]string** |  | [optional] 
**Scope** | Pointer to [**DirectoryQueryScope**](DirectoryQueryScope.md) |  | [optional] 

## Methods

### NewDirectoryQuery

`func NewDirectoryQuery() *DirectoryQuery`

NewDirectoryQuery instantiates a new DirectoryQuery object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDirectoryQueryWithDefaults

`func NewDirectoryQueryWithDefaults() *DirectoryQuery`

NewDirectoryQueryWithDefaults instantiates a new DirectoryQuery object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetResult

`func (o *DirectoryQuery) GetResult() []string`

GetResult returns the Result field if non-nil, zero value otherwise.

### GetResultOk

`func (o *DirectoryQuery) GetResultOk() (*[]string, bool)`

GetResultOk returns a tuple with the Result field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResult

`func (o *DirectoryQuery) SetResult(v []string)`

SetResult sets Result field to given value.

### HasResult

`func (o *DirectoryQuery) HasResult() bool`

HasResult returns a boolean if a field has been set.

### GetScope

`func (o *DirectoryQuery) GetScope() DirectoryQueryScope`

GetScope returns the Scope field if non-nil, zero value otherwise.

### GetScopeOk

`func (o *DirectoryQuery) GetScopeOk() (*DirectoryQueryScope, bool)`

GetScopeOk returns a tuple with the Scope field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScope

`func (o *DirectoryQuery) SetScope(v DirectoryQueryScope)`

SetScope sets Scope field to given value.

### HasScope

`func (o *DirectoryQuery) HasScope() bool`

HasScope returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


