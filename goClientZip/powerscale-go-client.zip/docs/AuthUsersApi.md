# \AuthUsersApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateAuthUsersv3UserMemberOfItem**](AuthUsersApi.md#CreateAuthUsersv3UserMemberOfItem) | **Post** /platform/3/auth/users/{User}/member-of | 
[**ListAuthUsersv3UserMemberOf**](AuthUsersApi.md#ListAuthUsersv3UserMemberOf) | **Get** /platform/3/auth/users/{User}/member-of | 
[**UpdateAuthUsersv3UserChangePassword**](AuthUsersApi.md#UpdateAuthUsersv3UserChangePassword) | **Put** /platform/3/auth/users/{User}/change-password | 



## CreateAuthUsersv3UserMemberOfItem

> CreateResponse CreateAuthUsersv3UserMemberOfItem(ctx, user).V3UserMemberOfItem(v3UserMemberOfItem).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    user := "user_example" // string | 
    v3UserMemberOfItem := *openapiclient.NewV1AuthAccessAccessItemFileGroup() // V1AuthAccessAccessItemFileGroup | 
    zone := "zone_example" // string | Filter groups by zone. (optional)
    provider := "provider_example" // string | Filter groups by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthUsersApi.CreateAuthUsersv3UserMemberOfItem(context.Background(), user).V3UserMemberOfItem(v3UserMemberOfItem).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthUsersApi.CreateAuthUsersv3UserMemberOfItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthUsersv3UserMemberOfItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthUsersApi.CreateAuthUsersv3UserMemberOfItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**user** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthUsersv3UserMemberOfItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3UserMemberOfItem** | [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | 
 **zone** | **string** | Filter groups by zone. | 
 **provider** | **string** | Filter groups by provider. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthUsersv3UserMemberOf

> V3UserMemberOf ListAuthUsersv3UserMemberOf(ctx, user).ResolveNames(resolveNames).Zone(zone).Provider(provider).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    user := "user_example" // string | 
    resolveNames := true // bool | Resolve names of personas. (optional)
    zone := "zone_example" // string | Filter groups by zone. (optional)
    provider := "provider_example" // string | Filter groups by provider. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthUsersApi.ListAuthUsersv3UserMemberOf(context.Background(), user).ResolveNames(resolveNames).Zone(zone).Provider(provider).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthUsersApi.ListAuthUsersv3UserMemberOf``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthUsersv3UserMemberOf`: V3UserMemberOf
    fmt.Fprintf(os.Stdout, "Response from `AuthUsersApi.ListAuthUsersv3UserMemberOf`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**user** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListAuthUsersv3UserMemberOfRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **resolveNames** | **bool** | Resolve names of personas. | 
 **zone** | **string** | Filter groups by zone. | 
 **provider** | **string** | Filter groups by provider. | 

### Return type

[**V3UserMemberOf**](V3UserMemberOf.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuthUsersv3UserChangePassword

> UpdateAuthUsersv3UserChangePassword(ctx, user).V3UserChangePassword(v3UserChangePassword).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    user := "user_example" // string | 
    v3UserChangePassword := *openapiclient.NewV3UserChangePassword("NewPassword_example", "OldPassword_example") // V3UserChangePassword | 
    zone := "zone_example" // string | Specifies access zone containing user. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuthUsersApi.UpdateAuthUsersv3UserChangePassword(context.Background(), user).V3UserChangePassword(v3UserChangePassword).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthUsersApi.UpdateAuthUsersv3UserChangePassword``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**user** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuthUsersv3UserChangePasswordRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3UserChangePassword** | [**V3UserChangePassword**](V3UserChangePassword.md) |  | 
 **zone** | **string** | Specifies access zone containing user. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

