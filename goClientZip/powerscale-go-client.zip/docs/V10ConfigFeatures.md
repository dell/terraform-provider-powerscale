# V10ConfigFeatures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Features** | Pointer to [**[]V10ConfigFeature**](V10ConfigFeature.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV10ConfigFeatures

`func NewV10ConfigFeatures() *V10ConfigFeatures`

NewV10ConfigFeatures instantiates a new V10ConfigFeatures object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ConfigFeaturesWithDefaults

`func NewV10ConfigFeaturesWithDefaults() *V10ConfigFeatures`

NewV10ConfigFeaturesWithDefaults instantiates a new V10ConfigFeatures object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFeatures

`func (o *V10ConfigFeatures) GetFeatures() []V10ConfigFeature`

GetFeatures returns the Features field if non-nil, zero value otherwise.

### GetFeaturesOk

`func (o *V10ConfigFeatures) GetFeaturesOk() (*[]V10ConfigFeature, bool)`

GetFeaturesOk returns a tuple with the Features field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFeatures

`func (o *V10ConfigFeatures) SetFeatures(v []V10ConfigFeature)`

SetFeatures sets Features field to given value.

### HasFeatures

`func (o *V10ConfigFeatures) HasFeatures() bool`

HasFeatures returns a boolean if a field has been set.

### GetResume

`func (o *V10ConfigFeatures) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V10ConfigFeatures) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V10ConfigFeatures) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V10ConfigFeatures) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V10ConfigFeatures) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10ConfigFeatures) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10ConfigFeatures) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10ConfigFeatures) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


