# V14InternalNetworksSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**InternalNetworksSettings** | Pointer to [**V14InternalNetworksSettingsInternalNetworksSettings**](V14InternalNetworksSettingsInternalNetworksSettings.md) |  | [optional] 

## Methods

### NewV14InternalNetworksSettings

`func NewV14InternalNetworksSettings() *V14InternalNetworksSettings`

NewV14InternalNetworksSettings instantiates a new V14InternalNetworksSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14InternalNetworksSettingsWithDefaults

`func NewV14InternalNetworksSettingsWithDefaults() *V14InternalNetworksSettings`

NewV14InternalNetworksSettingsWithDefaults instantiates a new V14InternalNetworksSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInternalNetworksSettings

`func (o *V14InternalNetworksSettings) GetInternalNetworksSettings() V14InternalNetworksSettingsInternalNetworksSettings`

GetInternalNetworksSettings returns the InternalNetworksSettings field if non-nil, zero value otherwise.

### GetInternalNetworksSettingsOk

`func (o *V14InternalNetworksSettings) GetInternalNetworksSettingsOk() (*V14InternalNetworksSettingsInternalNetworksSettings, bool)`

GetInternalNetworksSettingsOk returns a tuple with the InternalNetworksSettings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInternalNetworksSettings

`func (o *V14InternalNetworksSettings) SetInternalNetworksSettings(v V14InternalNetworksSettingsInternalNetworksSettings)`

SetInternalNetworksSettings sets InternalNetworksSettings field to given value.

### HasInternalNetworksSettings

`func (o *V14InternalNetworksSettings) HasInternalNetworksSettings() bool`

HasInternalNetworksSettings returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


