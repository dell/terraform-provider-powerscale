# V10S3BucketsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Buckets** | [**[]V10S3BucketExtended**](V10S3BucketExtended.md) |  | 

## Methods

### NewV10S3BucketsExtended

`func NewV10S3BucketsExtended(buckets []V10S3BucketExtended, ) *V10S3BucketsExtended`

NewV10S3BucketsExtended instantiates a new V10S3BucketsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10S3BucketsExtendedWithDefaults

`func NewV10S3BucketsExtendedWithDefaults() *V10S3BucketsExtended`

NewV10S3BucketsExtendedWithDefaults instantiates a new V10S3BucketsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBuckets

`func (o *V10S3BucketsExtended) GetBuckets() []V10S3BucketExtended`

GetBuckets returns the Buckets field if non-nil, zero value otherwise.

### GetBucketsOk

`func (o *V10S3BucketsExtended) GetBucketsOk() (*[]V10S3BucketExtended, bool)`

GetBucketsOk returns a tuple with the Buckets field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBuckets

`func (o *V10S3BucketsExtended) SetBuckets(v []V10S3BucketExtended)`

SetBuckets sets Buckets field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


