# Createv12KmipServerVerifyItemResponseNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Node ID (Device Number) of a node. | 
**Lnn** | **int32** | Logical Node Number (LNN) of a node. | 
**Message** | **string** | Response message. | 
**Status** | **bool** | True if the KMIP configuration was verified, otherwise false. | 

## Methods

### NewCreatev12KmipServerVerifyItemResponseNode

`func NewCreatev12KmipServerVerifyItemResponseNode(id int32, lnn int32, message string, status bool, ) *Createv12KmipServerVerifyItemResponseNode`

NewCreatev12KmipServerVerifyItemResponseNode instantiates a new Createv12KmipServerVerifyItemResponseNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev12KmipServerVerifyItemResponseNodeWithDefaults

`func NewCreatev12KmipServerVerifyItemResponseNodeWithDefaults() *Createv12KmipServerVerifyItemResponseNode`

NewCreatev12KmipServerVerifyItemResponseNodeWithDefaults instantiates a new Createv12KmipServerVerifyItemResponseNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *Createv12KmipServerVerifyItemResponseNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv12KmipServerVerifyItemResponseNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv12KmipServerVerifyItemResponseNode) SetId(v int32)`

SetId sets Id field to given value.


### GetLnn

`func (o *Createv12KmipServerVerifyItemResponseNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *Createv12KmipServerVerifyItemResponseNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *Createv12KmipServerVerifyItemResponseNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.


### GetMessage

`func (o *Createv12KmipServerVerifyItemResponseNode) GetMessage() string`

GetMessage returns the Message field if non-nil, zero value otherwise.

### GetMessageOk

`func (o *Createv12KmipServerVerifyItemResponseNode) GetMessageOk() (*string, bool)`

GetMessageOk returns a tuple with the Message field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMessage

`func (o *Createv12KmipServerVerifyItemResponseNode) SetMessage(v string)`

SetMessage sets Message field to given value.


### GetStatus

`func (o *Createv12KmipServerVerifyItemResponseNode) GetStatus() bool`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *Createv12KmipServerVerifyItemResponseNode) GetStatusOk() (*bool, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *Createv12KmipServerVerifyItemResponseNode) SetStatus(v bool)`

SetStatus sets Status field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


