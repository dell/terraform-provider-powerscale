# V10DatasetWorkloads

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 
**Workloads** | [**[]V10DatasetWorkloadExtended**](V10DatasetWorkloadExtended.md) |  | 

## Methods

### NewV10DatasetWorkloads

`func NewV10DatasetWorkloads(workloads []V10DatasetWorkloadExtended, ) *V10DatasetWorkloads`

NewV10DatasetWorkloads instantiates a new V10DatasetWorkloads object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10DatasetWorkloadsWithDefaults

`func NewV10DatasetWorkloadsWithDefaults() *V10DatasetWorkloads`

NewV10DatasetWorkloadsWithDefaults instantiates a new V10DatasetWorkloads object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetResume

`func (o *V10DatasetWorkloads) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V10DatasetWorkloads) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V10DatasetWorkloads) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V10DatasetWorkloads) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V10DatasetWorkloads) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10DatasetWorkloads) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10DatasetWorkloads) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10DatasetWorkloads) HasTotal() bool`

HasTotal returns a boolean if a field has been set.

### GetWorkloads

`func (o *V10DatasetWorkloads) GetWorkloads() []V10DatasetWorkloadExtended`

GetWorkloads returns the Workloads field if non-nil, zero value otherwise.

### GetWorkloadsOk

`func (o *V10DatasetWorkloads) GetWorkloadsOk() (*[]V10DatasetWorkloadExtended, bool)`

GetWorkloadsOk returns a tuple with the Workloads field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWorkloads

`func (o *V10DatasetWorkloads) SetWorkloads(v []V10DatasetWorkloadExtended)`

SetWorkloads sets Workloads field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


