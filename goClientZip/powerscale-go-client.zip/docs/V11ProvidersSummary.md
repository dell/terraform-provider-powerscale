# V11ProvidersSummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ProviderInstances** | Pointer to [**[]V11ProvidersSummaryProviderInstance**](V11ProvidersSummaryProviderInstance.md) |  | [optional] 

## Methods

### NewV11ProvidersSummary

`func NewV11ProvidersSummary() *V11ProvidersSummary`

NewV11ProvidersSummary instantiates a new V11ProvidersSummary object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ProvidersSummaryWithDefaults

`func NewV11ProvidersSummaryWithDefaults() *V11ProvidersSummary`

NewV11ProvidersSummaryWithDefaults instantiates a new V11ProvidersSummary object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetProviderInstances

`func (o *V11ProvidersSummary) GetProviderInstances() []V11ProvidersSummaryProviderInstance`

GetProviderInstances returns the ProviderInstances field if non-nil, zero value otherwise.

### GetProviderInstancesOk

`func (o *V11ProvidersSummary) GetProviderInstancesOk() (*[]V11ProvidersSummaryProviderInstance, bool)`

GetProviderInstancesOk returns a tuple with the ProviderInstances field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProviderInstances

`func (o *V11ProvidersSummary) SetProviderInstances(v []V11ProvidersSummaryProviderInstance)`

SetProviderInstances sets ProviderInstances field to given value.

### HasProviderInstances

`func (o *V11ProvidersSummary) HasProviderInstances() bool`

HasProviderInstances returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


