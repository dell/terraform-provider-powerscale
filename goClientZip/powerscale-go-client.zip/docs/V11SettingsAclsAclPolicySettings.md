# V11SettingsAclsAclPolicySettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Access** | Pointer to **string** | Access checks (chmod, chown). | [optional] 
**Calcmode** | Pointer to **string** | Displayed mode bits. | [optional] 
**CalcmodeGroup** | Pointer to **string** | Approximate group mode bits when ACL exists. | [optional] 
**CalcmodeOwner** | Pointer to **string** | Approximate owner mode bits when ACL exists. | [optional] 
**CalcmodeTraverse** | Pointer to **string** | Require traverse rights in order to traverse directories with existing ACLs. | [optional] 
**Chmod** | Pointer to **string** | chmod on files with existing ACLs. | [optional] 
**Chmod007** | Pointer to **string** | chmod (007) on files with existing ACLs. | [optional] 
**ChmodInheritable** | Pointer to **string** | ACLs created on directories by UNIX chmod. | [optional] 
**Chown** | Pointer to **string** | chown/chgrp on files with existing ACLs. | [optional] 
**CreateOverSmb** | Pointer to **string** | ACL creation over SMB. | [optional] 
**DosAttr** | Pointer to **string** |  Read only DOS attribute. | [optional] 
**GroupOwnerInheritance** | Pointer to **string** | Group owner inheritance. | [optional] 
**Rwx** | Pointer to **string** | Treatment of &#39;rwx&#39; permissions. | [optional] 
**SyntheticDenies** | Pointer to **string** | Synthetic &#39;deny&#39; ACEs. | [optional] 
**Utimes** | Pointer to **string** | Access check (utimes) | [optional] 

## Methods

### NewV11SettingsAclsAclPolicySettings

`func NewV11SettingsAclsAclPolicySettings() *V11SettingsAclsAclPolicySettings`

NewV11SettingsAclsAclPolicySettings instantiates a new V11SettingsAclsAclPolicySettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11SettingsAclsAclPolicySettingsWithDefaults

`func NewV11SettingsAclsAclPolicySettingsWithDefaults() *V11SettingsAclsAclPolicySettings`

NewV11SettingsAclsAclPolicySettingsWithDefaults instantiates a new V11SettingsAclsAclPolicySettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAccess

`func (o *V11SettingsAclsAclPolicySettings) GetAccess() string`

GetAccess returns the Access field if non-nil, zero value otherwise.

### GetAccessOk

`func (o *V11SettingsAclsAclPolicySettings) GetAccessOk() (*string, bool)`

GetAccessOk returns a tuple with the Access field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccess

`func (o *V11SettingsAclsAclPolicySettings) SetAccess(v string)`

SetAccess sets Access field to given value.

### HasAccess

`func (o *V11SettingsAclsAclPolicySettings) HasAccess() bool`

HasAccess returns a boolean if a field has been set.

### GetCalcmode

`func (o *V11SettingsAclsAclPolicySettings) GetCalcmode() string`

GetCalcmode returns the Calcmode field if non-nil, zero value otherwise.

### GetCalcmodeOk

`func (o *V11SettingsAclsAclPolicySettings) GetCalcmodeOk() (*string, bool)`

GetCalcmodeOk returns a tuple with the Calcmode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCalcmode

`func (o *V11SettingsAclsAclPolicySettings) SetCalcmode(v string)`

SetCalcmode sets Calcmode field to given value.

### HasCalcmode

`func (o *V11SettingsAclsAclPolicySettings) HasCalcmode() bool`

HasCalcmode returns a boolean if a field has been set.

### GetCalcmodeGroup

`func (o *V11SettingsAclsAclPolicySettings) GetCalcmodeGroup() string`

GetCalcmodeGroup returns the CalcmodeGroup field if non-nil, zero value otherwise.

### GetCalcmodeGroupOk

`func (o *V11SettingsAclsAclPolicySettings) GetCalcmodeGroupOk() (*string, bool)`

GetCalcmodeGroupOk returns a tuple with the CalcmodeGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCalcmodeGroup

`func (o *V11SettingsAclsAclPolicySettings) SetCalcmodeGroup(v string)`

SetCalcmodeGroup sets CalcmodeGroup field to given value.

### HasCalcmodeGroup

`func (o *V11SettingsAclsAclPolicySettings) HasCalcmodeGroup() bool`

HasCalcmodeGroup returns a boolean if a field has been set.

### GetCalcmodeOwner

`func (o *V11SettingsAclsAclPolicySettings) GetCalcmodeOwner() string`

GetCalcmodeOwner returns the CalcmodeOwner field if non-nil, zero value otherwise.

### GetCalcmodeOwnerOk

`func (o *V11SettingsAclsAclPolicySettings) GetCalcmodeOwnerOk() (*string, bool)`

GetCalcmodeOwnerOk returns a tuple with the CalcmodeOwner field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCalcmodeOwner

`func (o *V11SettingsAclsAclPolicySettings) SetCalcmodeOwner(v string)`

SetCalcmodeOwner sets CalcmodeOwner field to given value.

### HasCalcmodeOwner

`func (o *V11SettingsAclsAclPolicySettings) HasCalcmodeOwner() bool`

HasCalcmodeOwner returns a boolean if a field has been set.

### GetCalcmodeTraverse

`func (o *V11SettingsAclsAclPolicySettings) GetCalcmodeTraverse() string`

GetCalcmodeTraverse returns the CalcmodeTraverse field if non-nil, zero value otherwise.

### GetCalcmodeTraverseOk

`func (o *V11SettingsAclsAclPolicySettings) GetCalcmodeTraverseOk() (*string, bool)`

GetCalcmodeTraverseOk returns a tuple with the CalcmodeTraverse field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCalcmodeTraverse

`func (o *V11SettingsAclsAclPolicySettings) SetCalcmodeTraverse(v string)`

SetCalcmodeTraverse sets CalcmodeTraverse field to given value.

### HasCalcmodeTraverse

`func (o *V11SettingsAclsAclPolicySettings) HasCalcmodeTraverse() bool`

HasCalcmodeTraverse returns a boolean if a field has been set.

### GetChmod

`func (o *V11SettingsAclsAclPolicySettings) GetChmod() string`

GetChmod returns the Chmod field if non-nil, zero value otherwise.

### GetChmodOk

`func (o *V11SettingsAclsAclPolicySettings) GetChmodOk() (*string, bool)`

GetChmodOk returns a tuple with the Chmod field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChmod

`func (o *V11SettingsAclsAclPolicySettings) SetChmod(v string)`

SetChmod sets Chmod field to given value.

### HasChmod

`func (o *V11SettingsAclsAclPolicySettings) HasChmod() bool`

HasChmod returns a boolean if a field has been set.

### GetChmod007

`func (o *V11SettingsAclsAclPolicySettings) GetChmod007() string`

GetChmod007 returns the Chmod007 field if non-nil, zero value otherwise.

### GetChmod007Ok

`func (o *V11SettingsAclsAclPolicySettings) GetChmod007Ok() (*string, bool)`

GetChmod007Ok returns a tuple with the Chmod007 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChmod007

`func (o *V11SettingsAclsAclPolicySettings) SetChmod007(v string)`

SetChmod007 sets Chmod007 field to given value.

### HasChmod007

`func (o *V11SettingsAclsAclPolicySettings) HasChmod007() bool`

HasChmod007 returns a boolean if a field has been set.

### GetChmodInheritable

`func (o *V11SettingsAclsAclPolicySettings) GetChmodInheritable() string`

GetChmodInheritable returns the ChmodInheritable field if non-nil, zero value otherwise.

### GetChmodInheritableOk

`func (o *V11SettingsAclsAclPolicySettings) GetChmodInheritableOk() (*string, bool)`

GetChmodInheritableOk returns a tuple with the ChmodInheritable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChmodInheritable

`func (o *V11SettingsAclsAclPolicySettings) SetChmodInheritable(v string)`

SetChmodInheritable sets ChmodInheritable field to given value.

### HasChmodInheritable

`func (o *V11SettingsAclsAclPolicySettings) HasChmodInheritable() bool`

HasChmodInheritable returns a boolean if a field has been set.

### GetChown

`func (o *V11SettingsAclsAclPolicySettings) GetChown() string`

GetChown returns the Chown field if non-nil, zero value otherwise.

### GetChownOk

`func (o *V11SettingsAclsAclPolicySettings) GetChownOk() (*string, bool)`

GetChownOk returns a tuple with the Chown field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChown

`func (o *V11SettingsAclsAclPolicySettings) SetChown(v string)`

SetChown sets Chown field to given value.

### HasChown

`func (o *V11SettingsAclsAclPolicySettings) HasChown() bool`

HasChown returns a boolean if a field has been set.

### GetCreateOverSmb

`func (o *V11SettingsAclsAclPolicySettings) GetCreateOverSmb() string`

GetCreateOverSmb returns the CreateOverSmb field if non-nil, zero value otherwise.

### GetCreateOverSmbOk

`func (o *V11SettingsAclsAclPolicySettings) GetCreateOverSmbOk() (*string, bool)`

GetCreateOverSmbOk returns a tuple with the CreateOverSmb field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateOverSmb

`func (o *V11SettingsAclsAclPolicySettings) SetCreateOverSmb(v string)`

SetCreateOverSmb sets CreateOverSmb field to given value.

### HasCreateOverSmb

`func (o *V11SettingsAclsAclPolicySettings) HasCreateOverSmb() bool`

HasCreateOverSmb returns a boolean if a field has been set.

### GetDosAttr

`func (o *V11SettingsAclsAclPolicySettings) GetDosAttr() string`

GetDosAttr returns the DosAttr field if non-nil, zero value otherwise.

### GetDosAttrOk

`func (o *V11SettingsAclsAclPolicySettings) GetDosAttrOk() (*string, bool)`

GetDosAttrOk returns a tuple with the DosAttr field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDosAttr

`func (o *V11SettingsAclsAclPolicySettings) SetDosAttr(v string)`

SetDosAttr sets DosAttr field to given value.

### HasDosAttr

`func (o *V11SettingsAclsAclPolicySettings) HasDosAttr() bool`

HasDosAttr returns a boolean if a field has been set.

### GetGroupOwnerInheritance

`func (o *V11SettingsAclsAclPolicySettings) GetGroupOwnerInheritance() string`

GetGroupOwnerInheritance returns the GroupOwnerInheritance field if non-nil, zero value otherwise.

### GetGroupOwnerInheritanceOk

`func (o *V11SettingsAclsAclPolicySettings) GetGroupOwnerInheritanceOk() (*string, bool)`

GetGroupOwnerInheritanceOk returns a tuple with the GroupOwnerInheritance field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupOwnerInheritance

`func (o *V11SettingsAclsAclPolicySettings) SetGroupOwnerInheritance(v string)`

SetGroupOwnerInheritance sets GroupOwnerInheritance field to given value.

### HasGroupOwnerInheritance

`func (o *V11SettingsAclsAclPolicySettings) HasGroupOwnerInheritance() bool`

HasGroupOwnerInheritance returns a boolean if a field has been set.

### GetRwx

`func (o *V11SettingsAclsAclPolicySettings) GetRwx() string`

GetRwx returns the Rwx field if non-nil, zero value otherwise.

### GetRwxOk

`func (o *V11SettingsAclsAclPolicySettings) GetRwxOk() (*string, bool)`

GetRwxOk returns a tuple with the Rwx field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRwx

`func (o *V11SettingsAclsAclPolicySettings) SetRwx(v string)`

SetRwx sets Rwx field to given value.

### HasRwx

`func (o *V11SettingsAclsAclPolicySettings) HasRwx() bool`

HasRwx returns a boolean if a field has been set.

### GetSyntheticDenies

`func (o *V11SettingsAclsAclPolicySettings) GetSyntheticDenies() string`

GetSyntheticDenies returns the SyntheticDenies field if non-nil, zero value otherwise.

### GetSyntheticDeniesOk

`func (o *V11SettingsAclsAclPolicySettings) GetSyntheticDeniesOk() (*string, bool)`

GetSyntheticDeniesOk returns a tuple with the SyntheticDenies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSyntheticDenies

`func (o *V11SettingsAclsAclPolicySettings) SetSyntheticDenies(v string)`

SetSyntheticDenies sets SyntheticDenies field to given value.

### HasSyntheticDenies

`func (o *V11SettingsAclsAclPolicySettings) HasSyntheticDenies() bool`

HasSyntheticDenies returns a boolean if a field has been set.

### GetUtimes

`func (o *V11SettingsAclsAclPolicySettings) GetUtimes() string`

GetUtimes returns the Utimes field if non-nil, zero value otherwise.

### GetUtimesOk

`func (o *V11SettingsAclsAclPolicySettings) GetUtimesOk() (*string, bool)`

GetUtimesOk returns a tuple with the Utimes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUtimes

`func (o *V11SettingsAclsAclPolicySettings) SetUtimes(v string)`

SetUtimes sets Utimes field to given value.

### HasUtimes

`func (o *V11SettingsAclsAclPolicySettings) HasUtimes() bool`

HasUtimes returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


