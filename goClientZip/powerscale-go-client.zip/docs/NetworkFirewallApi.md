# \NetworkFirewallApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateNetworkFirewallv16PoliciesPolicyRule**](NetworkFirewallApi.md#CreateNetworkFirewallv16PoliciesPolicyRule) | **Post** /platform/16/network/firewall/policies/{Policy}/rules | 
[**ListNetworkFirewallv16PoliciesPolicyRules**](NetworkFirewallApi.md#ListNetworkFirewallv16PoliciesPolicyRules) | **Get** /platform/16/network/firewall/policies/{Policy}/rules | 



## CreateNetworkFirewallv16PoliciesPolicyRule

> CreateResponse CreateNetworkFirewallv16PoliciesPolicyRule(ctx, policy).V16PoliciesPolicyRule(v16PoliciesPolicyRule).Live(live).AllowRenumbering(allowRenumbering).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    policy := "policy_example" // string | 
    v16PoliciesPolicyRule := *openapiclient.NewV16PoliciesPolicyRule("Name_example") // V16PoliciesPolicyRule | 
    live := true // bool | Live flag can only be used with active rules. Update will take effect immediately on all related network pools. (optional)
    allowRenumbering := true // bool | Indicates whether to allow renumbering of other rules when an index already exists (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkFirewallApi.CreateNetworkFirewallv16PoliciesPolicyRule(context.Background(), policy).V16PoliciesPolicyRule(v16PoliciesPolicyRule).Live(live).AllowRenumbering(allowRenumbering).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkFirewallApi.CreateNetworkFirewallv16PoliciesPolicyRule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateNetworkFirewallv16PoliciesPolicyRule`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `NetworkFirewallApi.CreateNetworkFirewallv16PoliciesPolicyRule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policy** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateNetworkFirewallv16PoliciesPolicyRuleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v16PoliciesPolicyRule** | [**V16PoliciesPolicyRule**](V16PoliciesPolicyRule.md) |  | 
 **live** | **bool** | Live flag can only be used with active rules. Update will take effect immediately on all related network pools. | 
 **allowRenumbering** | **bool** | Indicates whether to allow renumbering of other rules when an index already exists | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListNetworkFirewallv16PoliciesPolicyRules

> V16PoliciesPolicyRules ListNetworkFirewallv16PoliciesPolicyRules(ctx, policy).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    policy := "policy_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.NetworkFirewallApi.ListNetworkFirewallv16PoliciesPolicyRules(context.Background(), policy).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `NetworkFirewallApi.ListNetworkFirewallv16PoliciesPolicyRules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListNetworkFirewallv16PoliciesPolicyRules`: V16PoliciesPolicyRules
    fmt.Fprintf(os.Stdout, "Response from `NetworkFirewallApi.ListNetworkFirewallv16PoliciesPolicyRules`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policy** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListNetworkFirewallv16PoliciesPolicyRulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V16PoliciesPolicyRules**](V16PoliciesPolicyRules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

