# V12ClusterUpgradeItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AlertTimeout** | Pointer to **int32** | The duration in seconds after drain begins that an alert will be raised. An alert timeout must be set to a smaller value than the drain timeout to be used. If not specified, an alert will not be raised (legacy behavior). | [optional] 
**DrainTimeout** | Pointer to **int32** | The duration in seconds that upgrade waits for all SMB clients to disconnect from a node before rebooting it. A value of 0 means wait indefinitely. If not specified, upgrade proceeds with reboots regardless of SMB client connections (legacy behavior). | [optional] 
**ExcludeDevice** | Pointer to **string** | Exclude the specified devices in the firmware upgrade. | [optional] 
**ExcludeType** | Pointer to **string** | Exclude the specified device type in the firmware upgrade. | [optional] 
**FwPkg** | Pointer to **string** | The location (path) of the firmware package which must be within /ifs. | [optional] 
**FwPkgId** | Pointer to **string** | The ID of the signed artifact stored in the catalog. | [optional] 
**IncludeDevice** | Pointer to **string** | Include the specified devices in the firmware upgrade. | [optional] 
**IncludeType** | Pointer to **string** | Include the specified device type in the firmware upgrade. | [optional] 
**InstallImageId** | Pointer to **string** | The ID of the signed artifact stored in the catalog. | [optional] 
**InstallImagePath** | Pointer to **string** | The location (path) of the upgrade image which must be within /ifs. | [optional] 
**NoBurn** | Pointer to **bool** | Do not burn the firmware. | [optional] 
**NodesToRollingUpgrade** | Pointer to **[]int32** | The nodes (to be) scheduled for upgrade ordered by queue position number. Null if the cluster_state is &#39;partially upgraded&#39; or upgrade_type is &#39;simultaneous&#39;. One of the following values: [&lt;lnn-1&gt;, &lt;lnn-2&gt;, ... ], &#39;all&#39;, null | [optional] 
**PatchPaths** | Pointer to **[]string** | List of additional patches to install during the upgrade. | [optional] 
**SkipOptional** | Pointer to **bool** | Used to indicate that the pre-upgrade check should be skipped. | [optional] 
**UpgradeType** | **string** | The type of upgrade to perform. One of the following values: &#39;rolling&#39;, &#39;simultaneous, parallel&#39; | 

## Methods

### NewV12ClusterUpgradeItem

`func NewV12ClusterUpgradeItem(upgradeType string, ) *V12ClusterUpgradeItem`

NewV12ClusterUpgradeItem instantiates a new V12ClusterUpgradeItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterUpgradeItemWithDefaults

`func NewV12ClusterUpgradeItemWithDefaults() *V12ClusterUpgradeItem`

NewV12ClusterUpgradeItemWithDefaults instantiates a new V12ClusterUpgradeItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlertTimeout

`func (o *V12ClusterUpgradeItem) GetAlertTimeout() int32`

GetAlertTimeout returns the AlertTimeout field if non-nil, zero value otherwise.

### GetAlertTimeoutOk

`func (o *V12ClusterUpgradeItem) GetAlertTimeoutOk() (*int32, bool)`

GetAlertTimeoutOk returns a tuple with the AlertTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlertTimeout

`func (o *V12ClusterUpgradeItem) SetAlertTimeout(v int32)`

SetAlertTimeout sets AlertTimeout field to given value.

### HasAlertTimeout

`func (o *V12ClusterUpgradeItem) HasAlertTimeout() bool`

HasAlertTimeout returns a boolean if a field has been set.

### GetDrainTimeout

`func (o *V12ClusterUpgradeItem) GetDrainTimeout() int32`

GetDrainTimeout returns the DrainTimeout field if non-nil, zero value otherwise.

### GetDrainTimeoutOk

`func (o *V12ClusterUpgradeItem) GetDrainTimeoutOk() (*int32, bool)`

GetDrainTimeoutOk returns a tuple with the DrainTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrainTimeout

`func (o *V12ClusterUpgradeItem) SetDrainTimeout(v int32)`

SetDrainTimeout sets DrainTimeout field to given value.

### HasDrainTimeout

`func (o *V12ClusterUpgradeItem) HasDrainTimeout() bool`

HasDrainTimeout returns a boolean if a field has been set.

### GetExcludeDevice

`func (o *V12ClusterUpgradeItem) GetExcludeDevice() string`

GetExcludeDevice returns the ExcludeDevice field if non-nil, zero value otherwise.

### GetExcludeDeviceOk

`func (o *V12ClusterUpgradeItem) GetExcludeDeviceOk() (*string, bool)`

GetExcludeDeviceOk returns a tuple with the ExcludeDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeDevice

`func (o *V12ClusterUpgradeItem) SetExcludeDevice(v string)`

SetExcludeDevice sets ExcludeDevice field to given value.

### HasExcludeDevice

`func (o *V12ClusterUpgradeItem) HasExcludeDevice() bool`

HasExcludeDevice returns a boolean if a field has been set.

### GetExcludeType

`func (o *V12ClusterUpgradeItem) GetExcludeType() string`

GetExcludeType returns the ExcludeType field if non-nil, zero value otherwise.

### GetExcludeTypeOk

`func (o *V12ClusterUpgradeItem) GetExcludeTypeOk() (*string, bool)`

GetExcludeTypeOk returns a tuple with the ExcludeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeType

`func (o *V12ClusterUpgradeItem) SetExcludeType(v string)`

SetExcludeType sets ExcludeType field to given value.

### HasExcludeType

`func (o *V12ClusterUpgradeItem) HasExcludeType() bool`

HasExcludeType returns a boolean if a field has been set.

### GetFwPkg

`func (o *V12ClusterUpgradeItem) GetFwPkg() string`

GetFwPkg returns the FwPkg field if non-nil, zero value otherwise.

### GetFwPkgOk

`func (o *V12ClusterUpgradeItem) GetFwPkgOk() (*string, bool)`

GetFwPkgOk returns a tuple with the FwPkg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFwPkg

`func (o *V12ClusterUpgradeItem) SetFwPkg(v string)`

SetFwPkg sets FwPkg field to given value.

### HasFwPkg

`func (o *V12ClusterUpgradeItem) HasFwPkg() bool`

HasFwPkg returns a boolean if a field has been set.

### GetFwPkgId

`func (o *V12ClusterUpgradeItem) GetFwPkgId() string`

GetFwPkgId returns the FwPkgId field if non-nil, zero value otherwise.

### GetFwPkgIdOk

`func (o *V12ClusterUpgradeItem) GetFwPkgIdOk() (*string, bool)`

GetFwPkgIdOk returns a tuple with the FwPkgId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFwPkgId

`func (o *V12ClusterUpgradeItem) SetFwPkgId(v string)`

SetFwPkgId sets FwPkgId field to given value.

### HasFwPkgId

`func (o *V12ClusterUpgradeItem) HasFwPkgId() bool`

HasFwPkgId returns a boolean if a field has been set.

### GetIncludeDevice

`func (o *V12ClusterUpgradeItem) GetIncludeDevice() string`

GetIncludeDevice returns the IncludeDevice field if non-nil, zero value otherwise.

### GetIncludeDeviceOk

`func (o *V12ClusterUpgradeItem) GetIncludeDeviceOk() (*string, bool)`

GetIncludeDeviceOk returns a tuple with the IncludeDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeDevice

`func (o *V12ClusterUpgradeItem) SetIncludeDevice(v string)`

SetIncludeDevice sets IncludeDevice field to given value.

### HasIncludeDevice

`func (o *V12ClusterUpgradeItem) HasIncludeDevice() bool`

HasIncludeDevice returns a boolean if a field has been set.

### GetIncludeType

`func (o *V12ClusterUpgradeItem) GetIncludeType() string`

GetIncludeType returns the IncludeType field if non-nil, zero value otherwise.

### GetIncludeTypeOk

`func (o *V12ClusterUpgradeItem) GetIncludeTypeOk() (*string, bool)`

GetIncludeTypeOk returns a tuple with the IncludeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeType

`func (o *V12ClusterUpgradeItem) SetIncludeType(v string)`

SetIncludeType sets IncludeType field to given value.

### HasIncludeType

`func (o *V12ClusterUpgradeItem) HasIncludeType() bool`

HasIncludeType returns a boolean if a field has been set.

### GetInstallImageId

`func (o *V12ClusterUpgradeItem) GetInstallImageId() string`

GetInstallImageId returns the InstallImageId field if non-nil, zero value otherwise.

### GetInstallImageIdOk

`func (o *V12ClusterUpgradeItem) GetInstallImageIdOk() (*string, bool)`

GetInstallImageIdOk returns a tuple with the InstallImageId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstallImageId

`func (o *V12ClusterUpgradeItem) SetInstallImageId(v string)`

SetInstallImageId sets InstallImageId field to given value.

### HasInstallImageId

`func (o *V12ClusterUpgradeItem) HasInstallImageId() bool`

HasInstallImageId returns a boolean if a field has been set.

### GetInstallImagePath

`func (o *V12ClusterUpgradeItem) GetInstallImagePath() string`

GetInstallImagePath returns the InstallImagePath field if non-nil, zero value otherwise.

### GetInstallImagePathOk

`func (o *V12ClusterUpgradeItem) GetInstallImagePathOk() (*string, bool)`

GetInstallImagePathOk returns a tuple with the InstallImagePath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstallImagePath

`func (o *V12ClusterUpgradeItem) SetInstallImagePath(v string)`

SetInstallImagePath sets InstallImagePath field to given value.

### HasInstallImagePath

`func (o *V12ClusterUpgradeItem) HasInstallImagePath() bool`

HasInstallImagePath returns a boolean if a field has been set.

### GetNoBurn

`func (o *V12ClusterUpgradeItem) GetNoBurn() bool`

GetNoBurn returns the NoBurn field if non-nil, zero value otherwise.

### GetNoBurnOk

`func (o *V12ClusterUpgradeItem) GetNoBurnOk() (*bool, bool)`

GetNoBurnOk returns a tuple with the NoBurn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNoBurn

`func (o *V12ClusterUpgradeItem) SetNoBurn(v bool)`

SetNoBurn sets NoBurn field to given value.

### HasNoBurn

`func (o *V12ClusterUpgradeItem) HasNoBurn() bool`

HasNoBurn returns a boolean if a field has been set.

### GetNodesToRollingUpgrade

`func (o *V12ClusterUpgradeItem) GetNodesToRollingUpgrade() []int32`

GetNodesToRollingUpgrade returns the NodesToRollingUpgrade field if non-nil, zero value otherwise.

### GetNodesToRollingUpgradeOk

`func (o *V12ClusterUpgradeItem) GetNodesToRollingUpgradeOk() (*[]int32, bool)`

GetNodesToRollingUpgradeOk returns a tuple with the NodesToRollingUpgrade field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodesToRollingUpgrade

`func (o *V12ClusterUpgradeItem) SetNodesToRollingUpgrade(v []int32)`

SetNodesToRollingUpgrade sets NodesToRollingUpgrade field to given value.

### HasNodesToRollingUpgrade

`func (o *V12ClusterUpgradeItem) HasNodesToRollingUpgrade() bool`

HasNodesToRollingUpgrade returns a boolean if a field has been set.

### GetPatchPaths

`func (o *V12ClusterUpgradeItem) GetPatchPaths() []string`

GetPatchPaths returns the PatchPaths field if non-nil, zero value otherwise.

### GetPatchPathsOk

`func (o *V12ClusterUpgradeItem) GetPatchPathsOk() (*[]string, bool)`

GetPatchPathsOk returns a tuple with the PatchPaths field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPatchPaths

`func (o *V12ClusterUpgradeItem) SetPatchPaths(v []string)`

SetPatchPaths sets PatchPaths field to given value.

### HasPatchPaths

`func (o *V12ClusterUpgradeItem) HasPatchPaths() bool`

HasPatchPaths returns a boolean if a field has been set.

### GetSkipOptional

`func (o *V12ClusterUpgradeItem) GetSkipOptional() bool`

GetSkipOptional returns the SkipOptional field if non-nil, zero value otherwise.

### GetSkipOptionalOk

`func (o *V12ClusterUpgradeItem) GetSkipOptionalOk() (*bool, bool)`

GetSkipOptionalOk returns a tuple with the SkipOptional field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSkipOptional

`func (o *V12ClusterUpgradeItem) SetSkipOptional(v bool)`

SetSkipOptional sets SkipOptional field to given value.

### HasSkipOptional

`func (o *V12ClusterUpgradeItem) HasSkipOptional() bool`

HasSkipOptional returns a boolean if a field has been set.

### GetUpgradeType

`func (o *V12ClusterUpgradeItem) GetUpgradeType() string`

GetUpgradeType returns the UpgradeType field if non-nil, zero value otherwise.

### GetUpgradeTypeOk

`func (o *V12ClusterUpgradeItem) GetUpgradeTypeOk() (*string, bool)`

GetUpgradeTypeOk returns a tuple with the UpgradeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpgradeType

`func (o *V12ClusterUpgradeItem) SetUpgradeType(v string)`

SetUpgradeType sets UpgradeType field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


