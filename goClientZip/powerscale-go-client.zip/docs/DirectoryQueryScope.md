# DirectoryQueryScope

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Conditions** | Pointer to [**[]DirectoryQueryScopeConditionsInner**](DirectoryQueryScopeConditionsInner.md) |  | [optional] 
**Logic** | Pointer to **string** |  | [optional] 

## Methods

### NewDirectoryQueryScope

`func NewDirectoryQueryScope() *DirectoryQueryScope`

NewDirectoryQueryScope instantiates a new DirectoryQueryScope object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDirectoryQueryScopeWithDefaults

`func NewDirectoryQueryScopeWithDefaults() *DirectoryQueryScope`

NewDirectoryQueryScopeWithDefaults instantiates a new DirectoryQueryScope object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetConditions

`func (o *DirectoryQueryScope) GetConditions() []DirectoryQueryScopeConditionsInner`

GetConditions returns the Conditions field if non-nil, zero value otherwise.

### GetConditionsOk

`func (o *DirectoryQueryScope) GetConditionsOk() (*[]DirectoryQueryScopeConditionsInner, bool)`

GetConditionsOk returns a tuple with the Conditions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConditions

`func (o *DirectoryQueryScope) SetConditions(v []DirectoryQueryScopeConditionsInner)`

SetConditions sets Conditions field to given value.

### HasConditions

`func (o *DirectoryQueryScope) HasConditions() bool`

HasConditions returns a boolean if a field has been set.

### GetLogic

`func (o *DirectoryQueryScope) GetLogic() string`

GetLogic returns the Logic field if non-nil, zero value otherwise.

### GetLogicOk

`func (o *DirectoryQueryScope) GetLogicOk() (*string, bool)`

GetLogicOk returns a tuple with the Logic field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLogic

`func (o *DirectoryQueryScope) SetLogic(v string)`

SetLogic sets Logic field to given value.

### HasLogic

`func (o *DirectoryQueryScope) HasLogic() bool`

HasLogic returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


