# V14ClusterNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DriveDConfig** | Pointer to [**V14ClusterNodeDriveDConfig**](V14ClusterNodeDriveDConfig.md) |  | [optional] 
**Drives** | Pointer to [**[]V10ClusterNodeDrive**](V10ClusterNodeDrive.md) | List of the drives in this node. | [optional] 
**Hardware** | Pointer to [**V12ClusterNodeHardware**](V12ClusterNodeHardware.md) |  | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**InternalIpAddress** | **string** | IPv4 address in the format: xxx.xxx.xxx.xxx | 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Partitions** | Pointer to [**V10ClusterNodePartitions**](V10ClusterNodePartitions.md) |  | [optional] 
**Sensors** | Pointer to [**V10ClusterNodeSensors**](V10ClusterNodeSensors.md) |  | [optional] 
**Sleds** | Pointer to [**[]V10ClusterNodeSled**](V10ClusterNodeSled.md) | List of the sleds in this node. | [optional] 
**State** | Pointer to [**V12ClusterNodeState**](V12ClusterNodeState.md) |  | [optional] 
**Status** | Pointer to [**V12ClusterNodeStatus**](V12ClusterNodeStatus.md) |  | [optional] 

## Methods

### NewV14ClusterNode

`func NewV14ClusterNode(internalIpAddress string, ) *V14ClusterNode`

NewV14ClusterNode instantiates a new V14ClusterNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ClusterNodeWithDefaults

`func NewV14ClusterNodeWithDefaults() *V14ClusterNode`

NewV14ClusterNodeWithDefaults instantiates a new V14ClusterNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDriveDConfig

`func (o *V14ClusterNode) GetDriveDConfig() V14ClusterNodeDriveDConfig`

GetDriveDConfig returns the DriveDConfig field if non-nil, zero value otherwise.

### GetDriveDConfigOk

`func (o *V14ClusterNode) GetDriveDConfigOk() (*V14ClusterNodeDriveDConfig, bool)`

GetDriveDConfigOk returns a tuple with the DriveDConfig field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDriveDConfig

`func (o *V14ClusterNode) SetDriveDConfig(v V14ClusterNodeDriveDConfig)`

SetDriveDConfig sets DriveDConfig field to given value.

### HasDriveDConfig

`func (o *V14ClusterNode) HasDriveDConfig() bool`

HasDriveDConfig returns a boolean if a field has been set.

### GetDrives

`func (o *V14ClusterNode) GetDrives() []V10ClusterNodeDrive`

GetDrives returns the Drives field if non-nil, zero value otherwise.

### GetDrivesOk

`func (o *V14ClusterNode) GetDrivesOk() (*[]V10ClusterNodeDrive, bool)`

GetDrivesOk returns a tuple with the Drives field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrives

`func (o *V14ClusterNode) SetDrives(v []V10ClusterNodeDrive)`

SetDrives sets Drives field to given value.

### HasDrives

`func (o *V14ClusterNode) HasDrives() bool`

HasDrives returns a boolean if a field has been set.

### GetHardware

`func (o *V14ClusterNode) GetHardware() V12ClusterNodeHardware`

GetHardware returns the Hardware field if non-nil, zero value otherwise.

### GetHardwareOk

`func (o *V14ClusterNode) GetHardwareOk() (*V12ClusterNodeHardware, bool)`

GetHardwareOk returns a tuple with the Hardware field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHardware

`func (o *V14ClusterNode) SetHardware(v V12ClusterNodeHardware)`

SetHardware sets Hardware field to given value.

### HasHardware

`func (o *V14ClusterNode) HasHardware() bool`

HasHardware returns a boolean if a field has been set.

### GetId

`func (o *V14ClusterNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V14ClusterNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V14ClusterNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V14ClusterNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetInternalIpAddress

`func (o *V14ClusterNode) GetInternalIpAddress() string`

GetInternalIpAddress returns the InternalIpAddress field if non-nil, zero value otherwise.

### GetInternalIpAddressOk

`func (o *V14ClusterNode) GetInternalIpAddressOk() (*string, bool)`

GetInternalIpAddressOk returns a tuple with the InternalIpAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInternalIpAddress

`func (o *V14ClusterNode) SetInternalIpAddress(v string)`

SetInternalIpAddress sets InternalIpAddress field to given value.


### GetLnn

`func (o *V14ClusterNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V14ClusterNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V14ClusterNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V14ClusterNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetPartitions

`func (o *V14ClusterNode) GetPartitions() V10ClusterNodePartitions`

GetPartitions returns the Partitions field if non-nil, zero value otherwise.

### GetPartitionsOk

`func (o *V14ClusterNode) GetPartitionsOk() (*V10ClusterNodePartitions, bool)`

GetPartitionsOk returns a tuple with the Partitions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPartitions

`func (o *V14ClusterNode) SetPartitions(v V10ClusterNodePartitions)`

SetPartitions sets Partitions field to given value.

### HasPartitions

`func (o *V14ClusterNode) HasPartitions() bool`

HasPartitions returns a boolean if a field has been set.

### GetSensors

`func (o *V14ClusterNode) GetSensors() V10ClusterNodeSensors`

GetSensors returns the Sensors field if non-nil, zero value otherwise.

### GetSensorsOk

`func (o *V14ClusterNode) GetSensorsOk() (*V10ClusterNodeSensors, bool)`

GetSensorsOk returns a tuple with the Sensors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSensors

`func (o *V14ClusterNode) SetSensors(v V10ClusterNodeSensors)`

SetSensors sets Sensors field to given value.

### HasSensors

`func (o *V14ClusterNode) HasSensors() bool`

HasSensors returns a boolean if a field has been set.

### GetSleds

`func (o *V14ClusterNode) GetSleds() []V10ClusterNodeSled`

GetSleds returns the Sleds field if non-nil, zero value otherwise.

### GetSledsOk

`func (o *V14ClusterNode) GetSledsOk() (*[]V10ClusterNodeSled, bool)`

GetSledsOk returns a tuple with the Sleds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSleds

`func (o *V14ClusterNode) SetSleds(v []V10ClusterNodeSled)`

SetSleds sets Sleds field to given value.

### HasSleds

`func (o *V14ClusterNode) HasSleds() bool`

HasSleds returns a boolean if a field has been set.

### GetState

`func (o *V14ClusterNode) GetState() V12ClusterNodeState`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *V14ClusterNode) GetStateOk() (*V12ClusterNodeState, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *V14ClusterNode) SetState(v V12ClusterNodeState)`

SetState sets State field to given value.

### HasState

`func (o *V14ClusterNode) HasState() bool`

HasState returns a boolean if a field has been set.

### GetStatus

`func (o *V14ClusterNode) GetStatus() V12ClusterNodeStatus`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V14ClusterNode) GetStatusOk() (*V12ClusterNodeStatus, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V14ClusterNode) SetStatus(v V12ClusterNodeStatus)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V14ClusterNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


