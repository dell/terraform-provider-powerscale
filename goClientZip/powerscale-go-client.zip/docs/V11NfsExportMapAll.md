# V11NfsExportMapAll

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | Pointer to **bool** | True if the user mapping is applied. | [optional] 
**PrimaryGroup** | Pointer to [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | [optional] 
**SecondaryGroups** | Pointer to [**[]V11NfsExportMapAllSecondaryGroupsInner**](V11NfsExportMapAllSecondaryGroupsInner.md) | Specifies persona properties for the secondary user group. A persona consists of either a type and name, or an ID. | [optional] 
**User** | Pointer to [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | [optional] 

## Methods

### NewV11NfsExportMapAll

`func NewV11NfsExportMapAll() *V11NfsExportMapAll`

NewV11NfsExportMapAll instantiates a new V11NfsExportMapAll object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11NfsExportMapAllWithDefaults

`func NewV11NfsExportMapAllWithDefaults() *V11NfsExportMapAll`

NewV11NfsExportMapAllWithDefaults instantiates a new V11NfsExportMapAll object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *V11NfsExportMapAll) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V11NfsExportMapAll) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V11NfsExportMapAll) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V11NfsExportMapAll) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetPrimaryGroup

`func (o *V11NfsExportMapAll) GetPrimaryGroup() V1AuthAccessAccessItemFileGroup`

GetPrimaryGroup returns the PrimaryGroup field if non-nil, zero value otherwise.

### GetPrimaryGroupOk

`func (o *V11NfsExportMapAll) GetPrimaryGroupOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetPrimaryGroupOk returns a tuple with the PrimaryGroup field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPrimaryGroup

`func (o *V11NfsExportMapAll) SetPrimaryGroup(v V1AuthAccessAccessItemFileGroup)`

SetPrimaryGroup sets PrimaryGroup field to given value.

### HasPrimaryGroup

`func (o *V11NfsExportMapAll) HasPrimaryGroup() bool`

HasPrimaryGroup returns a boolean if a field has been set.

### GetSecondaryGroups

`func (o *V11NfsExportMapAll) GetSecondaryGroups() []V11NfsExportMapAllSecondaryGroupsInner`

GetSecondaryGroups returns the SecondaryGroups field if non-nil, zero value otherwise.

### GetSecondaryGroupsOk

`func (o *V11NfsExportMapAll) GetSecondaryGroupsOk() (*[]V11NfsExportMapAllSecondaryGroupsInner, bool)`

GetSecondaryGroupsOk returns a tuple with the SecondaryGroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSecondaryGroups

`func (o *V11NfsExportMapAll) SetSecondaryGroups(v []V11NfsExportMapAllSecondaryGroupsInner)`

SetSecondaryGroups sets SecondaryGroups field to given value.

### HasSecondaryGroups

`func (o *V11NfsExportMapAll) HasSecondaryGroups() bool`

HasSecondaryGroups returns a boolean if a field has been set.

### GetUser

`func (o *V11NfsExportMapAll) GetUser() V1AuthAccessAccessItemFileGroup`

GetUser returns the User field if non-nil, zero value otherwise.

### GetUserOk

`func (o *V11NfsExportMapAll) GetUserOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetUserOk returns a tuple with the User field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUser

`func (o *V11NfsExportMapAll) SetUser(v V1AuthAccessAccessItemFileGroup)`

SetUser sets User field to given value.

### HasUser

`func (o *V11NfsExportMapAll) HasUser() bool`

HasUser returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


