# V10S3Key

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExistingKeyExpiryTime** | Pointer to **int32** | Time from now in minutes that previous secret key will expire. | [optional] 

## Methods

### NewV10S3Key

`func NewV10S3Key() *V10S3Key`

NewV10S3Key instantiates a new V10S3Key object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10S3KeyWithDefaults

`func NewV10S3KeyWithDefaults() *V10S3Key`

NewV10S3KeyWithDefaults instantiates a new V10S3Key object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExistingKeyExpiryTime

`func (o *V10S3Key) GetExistingKeyExpiryTime() int32`

GetExistingKeyExpiryTime returns the ExistingKeyExpiryTime field if non-nil, zero value otherwise.

### GetExistingKeyExpiryTimeOk

`func (o *V10S3Key) GetExistingKeyExpiryTimeOk() (*int32, bool)`

GetExistingKeyExpiryTimeOk returns a tuple with the ExistingKeyExpiryTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExistingKeyExpiryTime

`func (o *V10S3Key) SetExistingKeyExpiryTime(v int32)`

SetExistingKeyExpiryTime sets ExistingKeyExpiryTime field to given value.

### HasExistingKeyExpiryTime

`func (o *V10S3Key) HasExistingKeyExpiryTime() bool`

HasExistingKeyExpiryTime returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


