# \ClusterModeApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetClusterModev14ClusterModeSettings**](ClusterModeApi.md#GetClusterModev14ClusterModeSettings) | **Get** /platform/14/cluster-mode/settings | 
[**UpdateClusterModev14ClusterModeSettings**](ClusterModeApi.md#UpdateClusterModev14ClusterModeSettings) | **Put** /platform/14/cluster-mode/settings | 



## GetClusterModev14ClusterModeSettings

> V14ClusterModeSettings GetClusterModev14ClusterModeSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterModeApi.GetClusterModev14ClusterModeSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterModeApi.GetClusterModev14ClusterModeSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterModev14ClusterModeSettings`: V14ClusterModeSettings
    fmt.Fprintf(os.Stdout, "Response from `ClusterModeApi.GetClusterModev14ClusterModeSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterModev14ClusterModeSettingsRequest struct via the builder pattern


### Return type

[**V14ClusterModeSettings**](V14ClusterModeSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterModev14ClusterModeSettings

> UpdateClusterModev14ClusterModeSettings(ctx).V14ClusterModeSettings(v14ClusterModeSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14ClusterModeSettings := *openapiclient.NewV14ClusterModeSettingsExtended() // V14ClusterModeSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterModeApi.UpdateClusterModev14ClusterModeSettings(context.Background()).V14ClusterModeSettings(v14ClusterModeSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterModeApi.UpdateClusterModev14ClusterModeSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterModev14ClusterModeSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14ClusterModeSettings** | [**V14ClusterModeSettingsExtended**](V14ClusterModeSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

