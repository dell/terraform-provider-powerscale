# V14SnapshotWritable

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 
**Writable** | Pointer to [**[]Createv14SnapshotWritableItemResponse**](Createv14SnapshotWritableItemResponse.md) |  | [optional] 

## Methods

### NewV14SnapshotWritable

`func NewV14SnapshotWritable() *V14SnapshotWritable`

NewV14SnapshotWritable instantiates a new V14SnapshotWritable object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SnapshotWritableWithDefaults

`func NewV14SnapshotWritableWithDefaults() *V14SnapshotWritable`

NewV14SnapshotWritableWithDefaults instantiates a new V14SnapshotWritable object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetResume

`func (o *V14SnapshotWritable) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V14SnapshotWritable) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V14SnapshotWritable) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V14SnapshotWritable) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V14SnapshotWritable) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V14SnapshotWritable) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V14SnapshotWritable) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V14SnapshotWritable) HasTotal() bool`

HasTotal returns a boolean if a field has been set.

### GetWritable

`func (o *V14SnapshotWritable) GetWritable() []Createv14SnapshotWritableItemResponse`

GetWritable returns the Writable field if non-nil, zero value otherwise.

### GetWritableOk

`func (o *V14SnapshotWritable) GetWritableOk() (*[]Createv14SnapshotWritableItemResponse, bool)`

GetWritableOk returns a tuple with the Writable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWritable

`func (o *V14SnapshotWritable) SetWritable(v []Createv14SnapshotWritableItemResponse)`

SetWritable sets Writable field to given value.

### HasWritable

`func (o *V14SnapshotWritable) HasWritable() bool`

HasWritable returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


