# V14ClusterNodeDriveDConfig

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alert** | Pointer to [**V10ClusterNodeDriveDConfigAlert**](V10ClusterNodeDriveDConfigAlert.md) |  | [optional] 
**Allow** | Pointer to [**V10ClusterNodeDriveDConfigAllow**](V10ClusterNodeDriveDConfigAllow.md) |  | [optional] 
**AutomaticReplacementRecognition** | Pointer to [**V10ClusterNodeDriveDConfigAutomaticReplacementRecognition**](V10ClusterNodeDriveDConfigAutomaticReplacementRecognition.md) |  | [optional] 
**InstantSecureErase** | Pointer to [**V10ClusterNodeDriveDConfigInstantSecureErase**](V10ClusterNodeDriveDConfigInstantSecureErase.md) |  | [optional] 
**Log** | Pointer to [**V10ClusterNodeDriveDConfigLog**](V10ClusterNodeDriveDConfigLog.md) |  | [optional] 
**Reboot** | Pointer to [**V10ClusterNodeDriveDConfigReboot**](V10ClusterNodeDriveDConfigReboot.md) |  | [optional] 
**SpinWait** | Pointer to [**V10ClusterNodeDriveDConfigSpinWait**](V10ClusterNodeDriveDConfigSpinWait.md) |  | [optional] 
**Stall** | Pointer to [**V14ClusterNodeDriveDConfigStall**](V14ClusterNodeDriveDConfigStall.md) |  | [optional] 

## Methods

### NewV14ClusterNodeDriveDConfig

`func NewV14ClusterNodeDriveDConfig() *V14ClusterNodeDriveDConfig`

NewV14ClusterNodeDriveDConfig instantiates a new V14ClusterNodeDriveDConfig object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ClusterNodeDriveDConfigWithDefaults

`func NewV14ClusterNodeDriveDConfigWithDefaults() *V14ClusterNodeDriveDConfig`

NewV14ClusterNodeDriveDConfigWithDefaults instantiates a new V14ClusterNodeDriveDConfig object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlert

`func (o *V14ClusterNodeDriveDConfig) GetAlert() V10ClusterNodeDriveDConfigAlert`

GetAlert returns the Alert field if non-nil, zero value otherwise.

### GetAlertOk

`func (o *V14ClusterNodeDriveDConfig) GetAlertOk() (*V10ClusterNodeDriveDConfigAlert, bool)`

GetAlertOk returns a tuple with the Alert field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlert

`func (o *V14ClusterNodeDriveDConfig) SetAlert(v V10ClusterNodeDriveDConfigAlert)`

SetAlert sets Alert field to given value.

### HasAlert

`func (o *V14ClusterNodeDriveDConfig) HasAlert() bool`

HasAlert returns a boolean if a field has been set.

### GetAllow

`func (o *V14ClusterNodeDriveDConfig) GetAllow() V10ClusterNodeDriveDConfigAllow`

GetAllow returns the Allow field if non-nil, zero value otherwise.

### GetAllowOk

`func (o *V14ClusterNodeDriveDConfig) GetAllowOk() (*V10ClusterNodeDriveDConfigAllow, bool)`

GetAllowOk returns a tuple with the Allow field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllow

`func (o *V14ClusterNodeDriveDConfig) SetAllow(v V10ClusterNodeDriveDConfigAllow)`

SetAllow sets Allow field to given value.

### HasAllow

`func (o *V14ClusterNodeDriveDConfig) HasAllow() bool`

HasAllow returns a boolean if a field has been set.

### GetAutomaticReplacementRecognition

`func (o *V14ClusterNodeDriveDConfig) GetAutomaticReplacementRecognition() V10ClusterNodeDriveDConfigAutomaticReplacementRecognition`

GetAutomaticReplacementRecognition returns the AutomaticReplacementRecognition field if non-nil, zero value otherwise.

### GetAutomaticReplacementRecognitionOk

`func (o *V14ClusterNodeDriveDConfig) GetAutomaticReplacementRecognitionOk() (*V10ClusterNodeDriveDConfigAutomaticReplacementRecognition, bool)`

GetAutomaticReplacementRecognitionOk returns a tuple with the AutomaticReplacementRecognition field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutomaticReplacementRecognition

`func (o *V14ClusterNodeDriveDConfig) SetAutomaticReplacementRecognition(v V10ClusterNodeDriveDConfigAutomaticReplacementRecognition)`

SetAutomaticReplacementRecognition sets AutomaticReplacementRecognition field to given value.

### HasAutomaticReplacementRecognition

`func (o *V14ClusterNodeDriveDConfig) HasAutomaticReplacementRecognition() bool`

HasAutomaticReplacementRecognition returns a boolean if a field has been set.

### GetInstantSecureErase

`func (o *V14ClusterNodeDriveDConfig) GetInstantSecureErase() V10ClusterNodeDriveDConfigInstantSecureErase`

GetInstantSecureErase returns the InstantSecureErase field if non-nil, zero value otherwise.

### GetInstantSecureEraseOk

`func (o *V14ClusterNodeDriveDConfig) GetInstantSecureEraseOk() (*V10ClusterNodeDriveDConfigInstantSecureErase, bool)`

GetInstantSecureEraseOk returns a tuple with the InstantSecureErase field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstantSecureErase

`func (o *V14ClusterNodeDriveDConfig) SetInstantSecureErase(v V10ClusterNodeDriveDConfigInstantSecureErase)`

SetInstantSecureErase sets InstantSecureErase field to given value.

### HasInstantSecureErase

`func (o *V14ClusterNodeDriveDConfig) HasInstantSecureErase() bool`

HasInstantSecureErase returns a boolean if a field has been set.

### GetLog

`func (o *V14ClusterNodeDriveDConfig) GetLog() V10ClusterNodeDriveDConfigLog`

GetLog returns the Log field if non-nil, zero value otherwise.

### GetLogOk

`func (o *V14ClusterNodeDriveDConfig) GetLogOk() (*V10ClusterNodeDriveDConfigLog, bool)`

GetLogOk returns a tuple with the Log field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLog

`func (o *V14ClusterNodeDriveDConfig) SetLog(v V10ClusterNodeDriveDConfigLog)`

SetLog sets Log field to given value.

### HasLog

`func (o *V14ClusterNodeDriveDConfig) HasLog() bool`

HasLog returns a boolean if a field has been set.

### GetReboot

`func (o *V14ClusterNodeDriveDConfig) GetReboot() V10ClusterNodeDriveDConfigReboot`

GetReboot returns the Reboot field if non-nil, zero value otherwise.

### GetRebootOk

`func (o *V14ClusterNodeDriveDConfig) GetRebootOk() (*V10ClusterNodeDriveDConfigReboot, bool)`

GetRebootOk returns a tuple with the Reboot field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReboot

`func (o *V14ClusterNodeDriveDConfig) SetReboot(v V10ClusterNodeDriveDConfigReboot)`

SetReboot sets Reboot field to given value.

### HasReboot

`func (o *V14ClusterNodeDriveDConfig) HasReboot() bool`

HasReboot returns a boolean if a field has been set.

### GetSpinWait

`func (o *V14ClusterNodeDriveDConfig) GetSpinWait() V10ClusterNodeDriveDConfigSpinWait`

GetSpinWait returns the SpinWait field if non-nil, zero value otherwise.

### GetSpinWaitOk

`func (o *V14ClusterNodeDriveDConfig) GetSpinWaitOk() (*V10ClusterNodeDriveDConfigSpinWait, bool)`

GetSpinWaitOk returns a tuple with the SpinWait field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpinWait

`func (o *V14ClusterNodeDriveDConfig) SetSpinWait(v V10ClusterNodeDriveDConfigSpinWait)`

SetSpinWait sets SpinWait field to given value.

### HasSpinWait

`func (o *V14ClusterNodeDriveDConfig) HasSpinWait() bool`

HasSpinWait returns a boolean if a field has been set.

### GetStall

`func (o *V14ClusterNodeDriveDConfig) GetStall() V14ClusterNodeDriveDConfigStall`

GetStall returns the Stall field if non-nil, zero value otherwise.

### GetStallOk

`func (o *V14ClusterNodeDriveDConfig) GetStallOk() (*V14ClusterNodeDriveDConfigStall, bool)`

GetStallOk returns a tuple with the Stall field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStall

`func (o *V14ClusterNodeDriveDConfig) SetStall(v V14ClusterNodeDriveDConfigStall)`

SetStall sets Stall field to given value.

### HasStall

`func (o *V14ClusterNodeDriveDConfig) HasStall() bool`

HasStall returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


