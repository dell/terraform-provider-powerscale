# V10NodetypeAssessNodetypeFromNodepoolItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HardRestrictions** | **[]string** | Hard restriction messages for joining the nodetype to the pool. | 
**Id** | **int32** | The system ID given to the pool. | 
**Name** | **string** | The pool name. | 
**SoftRestrictions** | **[]string** | Soft restriction messages for joining the nodetype to the pool. | 

## Methods

### NewV10NodetypeAssessNodetypeFromNodepoolItem

`func NewV10NodetypeAssessNodetypeFromNodepoolItem(hardRestrictions []string, id int32, name string, softRestrictions []string, ) *V10NodetypeAssessNodetypeFromNodepoolItem`

NewV10NodetypeAssessNodetypeFromNodepoolItem instantiates a new V10NodetypeAssessNodetypeFromNodepoolItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NodetypeAssessNodetypeFromNodepoolItemWithDefaults

`func NewV10NodetypeAssessNodetypeFromNodepoolItemWithDefaults() *V10NodetypeAssessNodetypeFromNodepoolItem`

NewV10NodetypeAssessNodetypeFromNodepoolItemWithDefaults instantiates a new V10NodetypeAssessNodetypeFromNodepoolItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHardRestrictions

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) GetHardRestrictions() []string`

GetHardRestrictions returns the HardRestrictions field if non-nil, zero value otherwise.

### GetHardRestrictionsOk

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) GetHardRestrictionsOk() (*[]string, bool)`

GetHardRestrictionsOk returns a tuple with the HardRestrictions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHardRestrictions

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) SetHardRestrictions(v []string)`

SetHardRestrictions sets HardRestrictions field to given value.


### GetId

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) SetId(v int32)`

SetId sets Id field to given value.


### GetName

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) SetName(v string)`

SetName sets Name field to given value.


### GetSoftRestrictions

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) GetSoftRestrictions() []string`

GetSoftRestrictions returns the SoftRestrictions field if non-nil, zero value otherwise.

### GetSoftRestrictionsOk

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) GetSoftRestrictionsOk() (*[]string, bool)`

GetSoftRestrictionsOk returns a tuple with the SoftRestrictions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSoftRestrictions

`func (o *V10NodetypeAssessNodetypeFromNodepoolItem) SetSoftRestrictions(v []string)`

SetSoftRestrictions sets SoftRestrictions field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


