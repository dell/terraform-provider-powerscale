# V14InternalNetworksSettingsNetworkBackendConfig

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FabricMonitoring** | **string** | Represents if backend fabric monitoring is enabled or disabled. | 

## Methods

### NewV14InternalNetworksSettingsNetworkBackendConfig

`func NewV14InternalNetworksSettingsNetworkBackendConfig(fabricMonitoring string, ) *V14InternalNetworksSettingsNetworkBackendConfig`

NewV14InternalNetworksSettingsNetworkBackendConfig instantiates a new V14InternalNetworksSettingsNetworkBackendConfig object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14InternalNetworksSettingsNetworkBackendConfigWithDefaults

`func NewV14InternalNetworksSettingsNetworkBackendConfigWithDefaults() *V14InternalNetworksSettingsNetworkBackendConfig`

NewV14InternalNetworksSettingsNetworkBackendConfigWithDefaults instantiates a new V14InternalNetworksSettingsNetworkBackendConfig object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFabricMonitoring

`func (o *V14InternalNetworksSettingsNetworkBackendConfig) GetFabricMonitoring() string`

GetFabricMonitoring returns the FabricMonitoring field if non-nil, zero value otherwise.

### GetFabricMonitoringOk

`func (o *V14InternalNetworksSettingsNetworkBackendConfig) GetFabricMonitoringOk() (*string, bool)`

GetFabricMonitoringOk returns a tuple with the FabricMonitoring field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFabricMonitoring

`func (o *V14InternalNetworksSettingsNetworkBackendConfig) SetFabricMonitoring(v string)`

SetFabricMonitoring sets FabricMonitoring field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


