# V14ClusterAc

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExcludeSn** | Pointer to **[]string** | List of the node serial number. | [optional] 
**IncludeSn** | Pointer to **[]string** | List of the node serial number. | [optional] 

## Methods

### NewV14ClusterAc

`func NewV14ClusterAc() *V14ClusterAc`

NewV14ClusterAc instantiates a new V14ClusterAc object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ClusterAcWithDefaults

`func NewV14ClusterAcWithDefaults() *V14ClusterAc`

NewV14ClusterAcWithDefaults instantiates a new V14ClusterAc object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExcludeSn

`func (o *V14ClusterAc) GetExcludeSn() []string`

GetExcludeSn returns the ExcludeSn field if non-nil, zero value otherwise.

### GetExcludeSnOk

`func (o *V14ClusterAc) GetExcludeSnOk() (*[]string, bool)`

GetExcludeSnOk returns a tuple with the ExcludeSn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeSn

`func (o *V14ClusterAc) SetExcludeSn(v []string)`

SetExcludeSn sets ExcludeSn field to given value.

### HasExcludeSn

`func (o *V14ClusterAc) HasExcludeSn() bool`

HasExcludeSn returns a boolean if a field has been set.

### GetIncludeSn

`func (o *V14ClusterAc) GetIncludeSn() []string`

GetIncludeSn returns the IncludeSn field if non-nil, zero value otherwise.

### GetIncludeSnOk

`func (o *V14ClusterAc) GetIncludeSnOk() (*[]string, bool)`

GetIncludeSnOk returns a tuple with the IncludeSn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeSn

`func (o *V14ClusterAc) SetIncludeSn(v []string)`

SetIncludeSn sets IncludeSn field to given value.

### HasIncludeSn

`func (o *V14ClusterAc) HasIncludeSn() bool`

HasIncludeSn returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


