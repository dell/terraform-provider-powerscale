# \AntivirusApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateAntivirusv11AntivirusScanItem**](AntivirusApi.md#CreateAntivirusv11AntivirusScanItem) | **Post** /platform/11/antivirus/scan | 
[**CreateAntivirusv3AntivirusPolicy**](AntivirusApi.md#CreateAntivirusv3AntivirusPolicy) | **Post** /platform/3/antivirus/policies | 
[**CreateAntivirusv3AntivirusScanItem**](AntivirusApi.md#CreateAntivirusv3AntivirusScanItem) | **Post** /platform/3/antivirus/scan | 
[**CreateAntivirusv3AntivirusServer**](AntivirusApi.md#CreateAntivirusv3AntivirusServer) | **Post** /platform/3/antivirus/servers | 
[**DeleteAntivirusv11ReportsScan**](AntivirusApi.md#DeleteAntivirusv11ReportsScan) | **Delete** /platform/11/antivirus/reports/scans/{v11ReportsScanId} | 
[**DeleteAntivirusv11ReportsScans**](AntivirusApi.md#DeleteAntivirusv11ReportsScans) | **Delete** /platform/11/antivirus/reports/scans | 
[**DeleteAntivirusv3AntivirusPolicies**](AntivirusApi.md#DeleteAntivirusv3AntivirusPolicies) | **Delete** /platform/3/antivirus/policies | 
[**DeleteAntivirusv3AntivirusPolicy**](AntivirusApi.md#DeleteAntivirusv3AntivirusPolicy) | **Delete** /platform/3/antivirus/policies/{v3AntivirusPolicyId} | 
[**DeleteAntivirusv3AntivirusServer**](AntivirusApi.md#DeleteAntivirusv3AntivirusServer) | **Delete** /platform/3/antivirus/servers/{v3AntivirusServerId} | 
[**DeleteAntivirusv3AntivirusServers**](AntivirusApi.md#DeleteAntivirusv3AntivirusServers) | **Delete** /platform/3/antivirus/servers | 
[**DeleteAntivirusv3ReportsScan**](AntivirusApi.md#DeleteAntivirusv3ReportsScan) | **Delete** /platform/3/antivirus/reports/scans/{v3ReportsScanId} | 
[**DeleteAntivirusv3ReportsScans**](AntivirusApi.md#DeleteAntivirusv3ReportsScans) | **Delete** /platform/3/antivirus/reports/scans | 
[**GetAntivirusv11ReportsScan**](AntivirusApi.md#GetAntivirusv11ReportsScan) | **Get** /platform/11/antivirus/reports/scans/{v11ReportsScanId} | 
[**GetAntivirusv11ReportsScans**](AntivirusApi.md#GetAntivirusv11ReportsScans) | **Get** /platform/11/antivirus/reports/scans | 
[**GetAntivirusv3AntivirusPolicy**](AntivirusApi.md#GetAntivirusv3AntivirusPolicy) | **Get** /platform/3/antivirus/policies/{v3AntivirusPolicyId} | 
[**GetAntivirusv3AntivirusQuarantinePath**](AntivirusApi.md#GetAntivirusv3AntivirusQuarantinePath) | **Get** /platform/3/antivirus/quarantine/{v3AntivirusQuarantinePath} | 
[**GetAntivirusv3AntivirusServer**](AntivirusApi.md#GetAntivirusv3AntivirusServer) | **Get** /platform/3/antivirus/servers/{v3AntivirusServerId} | 
[**GetAntivirusv3AntivirusSettings**](AntivirusApi.md#GetAntivirusv3AntivirusSettings) | **Get** /platform/3/antivirus/settings | 
[**GetAntivirusv3ReportsScan**](AntivirusApi.md#GetAntivirusv3ReportsScan) | **Get** /platform/3/antivirus/reports/scans/{v3ReportsScanId} | 
[**GetAntivirusv3ReportsScans**](AntivirusApi.md#GetAntivirusv3ReportsScans) | **Get** /platform/3/antivirus/reports/scans | 
[**GetAntivirusv3ReportsThreat**](AntivirusApi.md#GetAntivirusv3ReportsThreat) | **Get** /platform/3/antivirus/reports/threats/{v3ReportsThreatId} | 
[**GetAntivirusv3ReportsThreats**](AntivirusApi.md#GetAntivirusv3ReportsThreats) | **Get** /platform/3/antivirus/reports/threats | 
[**GetAntivirusv7AntivirusSettings**](AntivirusApi.md#GetAntivirusv7AntivirusSettings) | **Get** /platform/7/antivirus/settings | 
[**ListAntivirusv3AntivirusPolicies**](AntivirusApi.md#ListAntivirusv3AntivirusPolicies) | **Get** /platform/3/antivirus/policies | 
[**ListAntivirusv3AntivirusServers**](AntivirusApi.md#ListAntivirusv3AntivirusServers) | **Get** /platform/3/antivirus/servers | 
[**UpdateAntivirusv3AntivirusPolicy**](AntivirusApi.md#UpdateAntivirusv3AntivirusPolicy) | **Put** /platform/3/antivirus/policies/{v3AntivirusPolicyId} | 
[**UpdateAntivirusv3AntivirusQuarantinePath**](AntivirusApi.md#UpdateAntivirusv3AntivirusQuarantinePath) | **Put** /platform/3/antivirus/quarantine/{v3AntivirusQuarantinePath} | 
[**UpdateAntivirusv3AntivirusServer**](AntivirusApi.md#UpdateAntivirusv3AntivirusServer) | **Put** /platform/3/antivirus/servers/{v3AntivirusServerId} | 
[**UpdateAntivirusv3AntivirusSettings**](AntivirusApi.md#UpdateAntivirusv3AntivirusSettings) | **Put** /platform/3/antivirus/settings | 
[**UpdateAntivirusv7AntivirusSettings**](AntivirusApi.md#UpdateAntivirusv7AntivirusSettings) | **Put** /platform/7/antivirus/settings | 



## CreateAntivirusv11AntivirusScanItem

> Createv11AntivirusScanItemResponse CreateAntivirusv11AntivirusScanItem(ctx).V11AntivirusScanItem(v11AntivirusScanItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AntivirusScanItem := *openapiclient.NewV11AntivirusScanItem("File_example") // V11AntivirusScanItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.CreateAntivirusv11AntivirusScanItem(context.Background()).V11AntivirusScanItem(v11AntivirusScanItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.CreateAntivirusv11AntivirusScanItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAntivirusv11AntivirusScanItem`: Createv11AntivirusScanItemResponse
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.CreateAntivirusv11AntivirusScanItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAntivirusv11AntivirusScanItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v11AntivirusScanItem** | [**V11AntivirusScanItem**](V11AntivirusScanItem.md) |  | 

### Return type

[**Createv11AntivirusScanItemResponse**](Createv11AntivirusScanItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAntivirusv3AntivirusPolicy

> CreateResponse CreateAntivirusv3AntivirusPolicy(ctx).V3AntivirusPolicy(v3AntivirusPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusPolicy := *openapiclient.NewV3AntivirusPolicy("Name_example") // V3AntivirusPolicy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.CreateAntivirusv3AntivirusPolicy(context.Background()).V3AntivirusPolicy(v3AntivirusPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.CreateAntivirusv3AntivirusPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAntivirusv3AntivirusPolicy`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.CreateAntivirusv3AntivirusPolicy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAntivirusv3AntivirusPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3AntivirusPolicy** | [**V3AntivirusPolicy**](V3AntivirusPolicy.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAntivirusv3AntivirusScanItem

> Createv11AntivirusScanItemResponse CreateAntivirusv3AntivirusScanItem(ctx).V3AntivirusScanItem(v3AntivirusScanItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusScanItem := *openapiclient.NewV3AntivirusScanItem("File_example") // V3AntivirusScanItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.CreateAntivirusv3AntivirusScanItem(context.Background()).V3AntivirusScanItem(v3AntivirusScanItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.CreateAntivirusv3AntivirusScanItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAntivirusv3AntivirusScanItem`: Createv11AntivirusScanItemResponse
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.CreateAntivirusv3AntivirusScanItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAntivirusv3AntivirusScanItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3AntivirusScanItem** | [**V3AntivirusScanItem**](V3AntivirusScanItem.md) |  | 

### Return type

[**Createv11AntivirusScanItemResponse**](Createv11AntivirusScanItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAntivirusv3AntivirusServer

> CreateResponse CreateAntivirusv3AntivirusServer(ctx).V3AntivirusServer(v3AntivirusServer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusServer := *openapiclient.NewV3AntivirusServer("Url_example") // V3AntivirusServer | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.CreateAntivirusv3AntivirusServer(context.Background()).V3AntivirusServer(v3AntivirusServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.CreateAntivirusv3AntivirusServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAntivirusv3AntivirusServer`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.CreateAntivirusv3AntivirusServer`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAntivirusv3AntivirusServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3AntivirusServer** | [**V3AntivirusServer**](V3AntivirusServer.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAntivirusv11ReportsScan

> DeleteAntivirusv11ReportsScan(ctx, v11ReportsScanId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11ReportsScanId := "v11ReportsScanId_example" // string | Delete one antivirus scan report, and all of its associated threat reports.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.DeleteAntivirusv11ReportsScan(context.Background(), v11ReportsScanId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.DeleteAntivirusv11ReportsScan``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11ReportsScanId** | **string** | Delete one antivirus scan report, and all of its associated threat reports. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAntivirusv11ReportsScanRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAntivirusv11ReportsScans

> DeleteAntivirusv11ReportsScans(ctx).Age(age).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    age := int32(56) // int32 | An amount of time in seconds. If present, only reports older than this age are deleted. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.DeleteAntivirusv11ReportsScans(context.Background()).Age(age).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.DeleteAntivirusv11ReportsScans``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAntivirusv11ReportsScansRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **age** | **int32** | An amount of time in seconds. If present, only reports older than this age are deleted. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAntivirusv3AntivirusPolicies

> DeleteAntivirusv3AntivirusPolicies(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.DeleteAntivirusv3AntivirusPolicies(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.DeleteAntivirusv3AntivirusPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAntivirusv3AntivirusPoliciesRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAntivirusv3AntivirusPolicy

> DeleteAntivirusv3AntivirusPolicy(ctx, v3AntivirusPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusPolicyId := "v3AntivirusPolicyId_example" // string | Delete an antivirus scan policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.DeleteAntivirusv3AntivirusPolicy(context.Background(), v3AntivirusPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.DeleteAntivirusv3AntivirusPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3AntivirusPolicyId** | **string** | Delete an antivirus scan policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAntivirusv3AntivirusPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAntivirusv3AntivirusServer

> DeleteAntivirusv3AntivirusServer(ctx, v3AntivirusServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusServerId := "v3AntivirusServerId_example" // string | Delete an antivirus server entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.DeleteAntivirusv3AntivirusServer(context.Background(), v3AntivirusServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.DeleteAntivirusv3AntivirusServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3AntivirusServerId** | **string** | Delete an antivirus server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAntivirusv3AntivirusServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAntivirusv3AntivirusServers

> DeleteAntivirusv3AntivirusServers(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.DeleteAntivirusv3AntivirusServers(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.DeleteAntivirusv3AntivirusServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAntivirusv3AntivirusServersRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAntivirusv3ReportsScan

> DeleteAntivirusv3ReportsScan(ctx, v3ReportsScanId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ReportsScanId := "v3ReportsScanId_example" // string | Delete one antivirus scan report, and all of its associated threat reports.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.DeleteAntivirusv3ReportsScan(context.Background(), v3ReportsScanId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.DeleteAntivirusv3ReportsScan``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ReportsScanId** | **string** | Delete one antivirus scan report, and all of its associated threat reports. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAntivirusv3ReportsScanRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAntivirusv3ReportsScans

> DeleteAntivirusv3ReportsScans(ctx).Age(age).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    age := int32(56) // int32 | An amount of time in seconds. If present, only reports older than this age are deleted. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.DeleteAntivirusv3ReportsScans(context.Background()).Age(age).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.DeleteAntivirusv3ReportsScans``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAntivirusv3ReportsScansRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **age** | **int32** | An amount of time in seconds. If present, only reports older than this age are deleted. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv11ReportsScan

> V11ReportsScansExtended GetAntivirusv11ReportsScan(ctx, v11ReportsScanId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11ReportsScanId := "v11ReportsScanId_example" // string | Retrieve one antivirus scan report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv11ReportsScan(context.Background(), v11ReportsScanId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv11ReportsScan``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv11ReportsScan`: V11ReportsScansExtended
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv11ReportsScan`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11ReportsScanId** | **string** | Retrieve one antivirus scan report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv11ReportsScanRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V11ReportsScansExtended**](V11ReportsScansExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv11ReportsScans

> V11ReportsScans GetAntivirusv11ReportsScans(ctx).Sort(sort).Status(status).Resume(resume).Limit(limit).Offset(offset).Dir(dir).PolicyId(policyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    status := "status_example" // string | If present, only scan reports with this status will be returned. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    offset := int32(56) // int32 | The position of the first item returned for a paginated query within the full result set. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    policyId := "policyId_example" // string | If present, only reports for scans associated with this policy will be returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv11ReportsScans(context.Background()).Sort(sort).Status(status).Resume(resume).Limit(limit).Offset(offset).Dir(dir).PolicyId(policyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv11ReportsScans``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv11ReportsScans`: V11ReportsScans
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv11ReportsScans`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv11ReportsScansRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **status** | **string** | If present, only scan reports with this status will be returned. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **offset** | **int32** | The position of the first item returned for a paginated query within the full result set. | 
 **dir** | **string** | The direction of the sort. | 
 **policyId** | **string** | If present, only reports for scans associated with this policy will be returned. | 

### Return type

[**V11ReportsScans**](V11ReportsScans.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv3AntivirusPolicy

> V3AntivirusPoliciesExtended GetAntivirusv3AntivirusPolicy(ctx, v3AntivirusPolicyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusPolicyId := "v3AntivirusPolicyId_example" // string | Retrieve one antivirus scan policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv3AntivirusPolicy(context.Background(), v3AntivirusPolicyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv3AntivirusPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv3AntivirusPolicy`: V3AntivirusPoliciesExtended
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv3AntivirusPolicy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3AntivirusPolicyId** | **string** | Retrieve one antivirus scan policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv3AntivirusPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3AntivirusPoliciesExtended**](V3AntivirusPoliciesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv3AntivirusQuarantinePath

> V3AntivirusQuarantine GetAntivirusv3AntivirusQuarantinePath(ctx, v3AntivirusQuarantinePath).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusQuarantinePath := "v3AntivirusQuarantinePath_example" // string | Retrieve the quarantine status of the file at the specified path.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv3AntivirusQuarantinePath(context.Background(), v3AntivirusQuarantinePath).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv3AntivirusQuarantinePath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv3AntivirusQuarantinePath`: V3AntivirusQuarantine
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv3AntivirusQuarantinePath`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3AntivirusQuarantinePath** | **string** | Retrieve the quarantine status of the file at the specified path. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv3AntivirusQuarantinePathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3AntivirusQuarantine**](V3AntivirusQuarantine.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv3AntivirusServer

> V3AntivirusServersExtended GetAntivirusv3AntivirusServer(ctx, v3AntivirusServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusServerId := "v3AntivirusServerId_example" // string | Retrieve one antivirus server entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv3AntivirusServer(context.Background(), v3AntivirusServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv3AntivirusServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv3AntivirusServer`: V3AntivirusServersExtended
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv3AntivirusServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3AntivirusServerId** | **string** | Retrieve one antivirus server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv3AntivirusServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3AntivirusServersExtended**](V3AntivirusServersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv3AntivirusSettings

> V3AntivirusSettings GetAntivirusv3AntivirusSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv3AntivirusSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv3AntivirusSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv3AntivirusSettings`: V3AntivirusSettings
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv3AntivirusSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv3AntivirusSettingsRequest struct via the builder pattern


### Return type

[**V3AntivirusSettings**](V3AntivirusSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv3ReportsScan

> V3ReportsScansExtended GetAntivirusv3ReportsScan(ctx, v3ReportsScanId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ReportsScanId := "v3ReportsScanId_example" // string | Retrieve one antivirus scan report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv3ReportsScan(context.Background(), v3ReportsScanId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv3ReportsScan``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv3ReportsScan`: V3ReportsScansExtended
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv3ReportsScan`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ReportsScanId** | **string** | Retrieve one antivirus scan report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv3ReportsScanRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3ReportsScansExtended**](V3ReportsScansExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv3ReportsScans

> V3ReportsScans GetAntivirusv3ReportsScans(ctx).Sort(sort).Status(status).Resume(resume).Limit(limit).Offset(offset).Dir(dir).PolicyId(policyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    status := "status_example" // string | If present, only scan reports with this status will be returned. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    offset := int32(56) // int32 | The position of the first item returned for a paginated query within the full result set. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    policyId := "policyId_example" // string | If present, only reports for scans associated with this policy will be returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv3ReportsScans(context.Background()).Sort(sort).Status(status).Resume(resume).Limit(limit).Offset(offset).Dir(dir).PolicyId(policyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv3ReportsScans``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv3ReportsScans`: V3ReportsScans
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv3ReportsScans`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv3ReportsScansRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **status** | **string** | If present, only scan reports with this status will be returned. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **offset** | **int32** | The position of the first item returned for a paginated query within the full result set. | 
 **dir** | **string** | The direction of the sort. | 
 **policyId** | **string** | If present, only reports for scans associated with this policy will be returned. | 

### Return type

[**V3ReportsScans**](V3ReportsScans.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv3ReportsThreat

> V3ReportsThreatsExtended GetAntivirusv3ReportsThreat(ctx, v3ReportsThreatId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ReportsThreatId := "v3ReportsThreatId_example" // string | Retrieve one antivirus threat report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv3ReportsThreat(context.Background(), v3ReportsThreatId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv3ReportsThreat``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv3ReportsThreat`: V3ReportsThreatsExtended
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv3ReportsThreat`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ReportsThreatId** | **string** | Retrieve one antivirus threat report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv3ReportsThreatRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3ReportsThreatsExtended**](V3ReportsThreatsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv3ReportsThreats

> V3ReportsThreats GetAntivirusv3ReportsThreats(ctx).Sort(sort).ScanId(scanId).Resume(resume).Limit(limit).File(file).Offset(offset).Remediation(remediation).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    scanId := "scanId_example" // string | If present, only returns threat reports associated with the given scan report. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    file := "file_example" // string | If present, only returns threat reports for the given file. (optional)
    offset := int32(56) // int32 | The position of the first item returned for a paginated query within the full result set. (optional)
    remediation := "remediation_example" // string | If present, only returns threat reports with the given remediation. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv3ReportsThreats(context.Background()).Sort(sort).ScanId(scanId).Resume(resume).Limit(limit).File(file).Offset(offset).Remediation(remediation).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv3ReportsThreats``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv3ReportsThreats`: V3ReportsThreats
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv3ReportsThreats`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv3ReportsThreatsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **scanId** | **string** | If present, only returns threat reports associated with the given scan report. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **file** | **string** | If present, only returns threat reports for the given file. | 
 **offset** | **int32** | The position of the first item returned for a paginated query within the full result set. | 
 **remediation** | **string** | If present, only returns threat reports with the given remediation. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3ReportsThreats**](V3ReportsThreats.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAntivirusv7AntivirusSettings

> V7AntivirusSettings GetAntivirusv7AntivirusSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.GetAntivirusv7AntivirusSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.GetAntivirusv7AntivirusSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAntivirusv7AntivirusSettings`: V7AntivirusSettings
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.GetAntivirusv7AntivirusSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAntivirusv7AntivirusSettingsRequest struct via the builder pattern


### Return type

[**V7AntivirusSettings**](V7AntivirusSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAntivirusv3AntivirusPolicies

> V3AntivirusPolicies ListAntivirusv3AntivirusPolicies(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.ListAntivirusv3AntivirusPolicies(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.ListAntivirusv3AntivirusPolicies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAntivirusv3AntivirusPolicies`: V3AntivirusPolicies
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.ListAntivirusv3AntivirusPolicies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAntivirusv3AntivirusPoliciesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3AntivirusPolicies**](V3AntivirusPolicies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAntivirusv3AntivirusServers

> V3AntivirusServers ListAntivirusv3AntivirusServers(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AntivirusApi.ListAntivirusv3AntivirusServers(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.ListAntivirusv3AntivirusServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAntivirusv3AntivirusServers`: V3AntivirusServers
    fmt.Fprintf(os.Stdout, "Response from `AntivirusApi.ListAntivirusv3AntivirusServers`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAntivirusv3AntivirusServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3AntivirusServers**](V3AntivirusServers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAntivirusv3AntivirusPolicy

> UpdateAntivirusv3AntivirusPolicy(ctx, v3AntivirusPolicyId).V3AntivirusPolicy(v3AntivirusPolicy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusPolicyId := "v3AntivirusPolicyId_example" // string | Modify an antivirus scan policy.
    v3AntivirusPolicy := *openapiclient.NewV3AntivirusPolicyExtendedExtended() // V3AntivirusPolicyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.UpdateAntivirusv3AntivirusPolicy(context.Background(), v3AntivirusPolicyId).V3AntivirusPolicy(v3AntivirusPolicy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.UpdateAntivirusv3AntivirusPolicy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3AntivirusPolicyId** | **string** | Modify an antivirus scan policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAntivirusv3AntivirusPolicyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3AntivirusPolicy** | [**V3AntivirusPolicyExtendedExtended**](V3AntivirusPolicyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAntivirusv3AntivirusQuarantinePath

> UpdateAntivirusv3AntivirusQuarantinePath(ctx, v3AntivirusQuarantinePath).V3AntivirusQuarantinePathParams(v3AntivirusQuarantinePathParams).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusQuarantinePath := "v3AntivirusQuarantinePath_example" // string | Set the quarantine status of the file at the specified path.  Use either an empty object {} in the request body or {\"quarantined\":true} to quarantine the file, and {\"quarantined\":false} to unquarantine the file.
    v3AntivirusQuarantinePathParams := *openapiclient.NewV3AntivirusQuarantinePathParams() // V3AntivirusQuarantinePathParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.UpdateAntivirusv3AntivirusQuarantinePath(context.Background(), v3AntivirusQuarantinePath).V3AntivirusQuarantinePathParams(v3AntivirusQuarantinePathParams).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.UpdateAntivirusv3AntivirusQuarantinePath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3AntivirusQuarantinePath** | **string** | Set the quarantine status of the file at the specified path.  Use either an empty object {} in the request body or {\&quot;quarantined\&quot;:true} to quarantine the file, and {\&quot;quarantined\&quot;:false} to unquarantine the file. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAntivirusv3AntivirusQuarantinePathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3AntivirusQuarantinePathParams** | [**V3AntivirusQuarantinePathParams**](V3AntivirusQuarantinePathParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAntivirusv3AntivirusServer

> UpdateAntivirusv3AntivirusServer(ctx, v3AntivirusServerId).V3AntivirusServer(v3AntivirusServer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusServerId := "v3AntivirusServerId_example" // string | Modify an antivirus server entry.
    v3AntivirusServer := *openapiclient.NewV3AntivirusServerExtendedExtended() // V3AntivirusServerExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.UpdateAntivirusv3AntivirusServer(context.Background(), v3AntivirusServerId).V3AntivirusServer(v3AntivirusServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.UpdateAntivirusv3AntivirusServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3AntivirusServerId** | **string** | Modify an antivirus server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAntivirusv3AntivirusServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3AntivirusServer** | [**V3AntivirusServerExtendedExtended**](V3AntivirusServerExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAntivirusv3AntivirusSettings

> UpdateAntivirusv3AntivirusSettings(ctx).V3AntivirusSettings(v3AntivirusSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AntivirusSettings := *openapiclient.NewV3AntivirusSettingsSettings() // V3AntivirusSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.UpdateAntivirusv3AntivirusSettings(context.Background()).V3AntivirusSettings(v3AntivirusSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.UpdateAntivirusv3AntivirusSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAntivirusv3AntivirusSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3AntivirusSettings** | [**V3AntivirusSettingsSettings**](V3AntivirusSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAntivirusv7AntivirusSettings

> UpdateAntivirusv7AntivirusSettings(ctx).V7AntivirusSettings(v7AntivirusSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AntivirusSettings := *openapiclient.NewV7AntivirusSettingsExtended() // V7AntivirusSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AntivirusApi.UpdateAntivirusv7AntivirusSettings(context.Background()).V7AntivirusSettings(v7AntivirusSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AntivirusApi.UpdateAntivirusv7AntivirusSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAntivirusv7AntivirusSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7AntivirusSettings** | [**V7AntivirusSettingsExtended**](V7AntivirusSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

