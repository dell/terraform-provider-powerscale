# V12SubnetsSubnetPoolsPool

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessZone** | **string** | Name of a valid access zone to map IP address pool to the zone. | 
**AddrFamily** | **string** | IP address format. | 
**AggregationMode** | **string** | OneFS supports the following NIC aggregation modes. | 
**AllocMethod** | **string** | Specifies how IP address allocation is done among pool members. | 
**Description** | **string** | A description of the pool. | 
**Groupnet** | **string** | Name of the groupnet this pool belongs to. | 
**Id** | **string** | Unique Pool ID. | 
**Ifaces** | [**[]V12SubnetsSubnetPoolIface**](V12SubnetsSubnetPoolIface.md) | List of interface members in this pool. | 
**Name** | **string** | The name of the pool. It must be unique throughout the given subnet.It&#39;s a required field with POST method. | 
**Nfsv3RroceOnly** | **bool** | Indicates that pool contains only RDMA RRoCE capable interfaces. | 
**Ranges** | [**[]V12GroupnetSubnetScServiceAddr**](V12GroupnetSubnetScServiceAddr.md) | List of IP address ranges in this pool. | 
**RebalancePolicy** | **string** | Rebalance policy.. | 
**Rules** | **[]string** | Names of the rules in this pool. | 
**ScAutoUnsuspendDelay** | **int32** | Time delay in seconds before a node which has been                 automatically unsuspended becomes usable in SmartConnect                responses for pool zones. | 
**ScConnectPolicy** | **string** | SmartConnect client connection balancing policy. | 
**ScDnsZone** | **string** | SmartConnect zone name for the pool. | 
**ScDnsZoneAliases** | **[]string** | List of SmartConnect zone aliases (DNS names) to the pool. | 
**ScFailoverPolicy** | **string** | SmartConnect IP failover policy. | 
**ScSubnet** | **string** | Name of SmartConnect service subnet for this pool. | 
**ScSuspendedNodes** | **[]int32** | List of LNNs showing currently suspended nodes in SmartConnect. | 
**ScTtl** | **int32** | Time to live value for SmartConnect DNS query responses in seconds. | 
**StaticRoutes** | [**[]V12SubnetsSubnetPoolStaticRoute**](V12SubnetsSubnetPoolStaticRoute.md) | List of interface members in this pool. | 
**Subnet** | **string** | The name of the subnet. | 

## Methods

### NewV12SubnetsSubnetPoolsPool

`func NewV12SubnetsSubnetPoolsPool(accessZone string, addrFamily string, aggregationMode string, allocMethod string, description string, groupnet string, id string, ifaces []V12SubnetsSubnetPoolIface, name string, nfsv3RroceOnly bool, ranges []V12GroupnetSubnetScServiceAddr, rebalancePolicy string, rules []string, scAutoUnsuspendDelay int32, scConnectPolicy string, scDnsZone string, scDnsZoneAliases []string, scFailoverPolicy string, scSubnet string, scSuspendedNodes []int32, scTtl int32, staticRoutes []V12SubnetsSubnetPoolStaticRoute, subnet string, ) *V12SubnetsSubnetPoolsPool`

NewV12SubnetsSubnetPoolsPool instantiates a new V12SubnetsSubnetPoolsPool object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SubnetsSubnetPoolsPoolWithDefaults

`func NewV12SubnetsSubnetPoolsPoolWithDefaults() *V12SubnetsSubnetPoolsPool`

NewV12SubnetsSubnetPoolsPoolWithDefaults instantiates a new V12SubnetsSubnetPoolsPool object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAccessZone

`func (o *V12SubnetsSubnetPoolsPool) GetAccessZone() string`

GetAccessZone returns the AccessZone field if non-nil, zero value otherwise.

### GetAccessZoneOk

`func (o *V12SubnetsSubnetPoolsPool) GetAccessZoneOk() (*string, bool)`

GetAccessZoneOk returns a tuple with the AccessZone field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessZone

`func (o *V12SubnetsSubnetPoolsPool) SetAccessZone(v string)`

SetAccessZone sets AccessZone field to given value.


### GetAddrFamily

`func (o *V12SubnetsSubnetPoolsPool) GetAddrFamily() string`

GetAddrFamily returns the AddrFamily field if non-nil, zero value otherwise.

### GetAddrFamilyOk

`func (o *V12SubnetsSubnetPoolsPool) GetAddrFamilyOk() (*string, bool)`

GetAddrFamilyOk returns a tuple with the AddrFamily field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddrFamily

`func (o *V12SubnetsSubnetPoolsPool) SetAddrFamily(v string)`

SetAddrFamily sets AddrFamily field to given value.


### GetAggregationMode

`func (o *V12SubnetsSubnetPoolsPool) GetAggregationMode() string`

GetAggregationMode returns the AggregationMode field if non-nil, zero value otherwise.

### GetAggregationModeOk

`func (o *V12SubnetsSubnetPoolsPool) GetAggregationModeOk() (*string, bool)`

GetAggregationModeOk returns a tuple with the AggregationMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAggregationMode

`func (o *V12SubnetsSubnetPoolsPool) SetAggregationMode(v string)`

SetAggregationMode sets AggregationMode field to given value.


### GetAllocMethod

`func (o *V12SubnetsSubnetPoolsPool) GetAllocMethod() string`

GetAllocMethod returns the AllocMethod field if non-nil, zero value otherwise.

### GetAllocMethodOk

`func (o *V12SubnetsSubnetPoolsPool) GetAllocMethodOk() (*string, bool)`

GetAllocMethodOk returns a tuple with the AllocMethod field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllocMethod

`func (o *V12SubnetsSubnetPoolsPool) SetAllocMethod(v string)`

SetAllocMethod sets AllocMethod field to given value.


### GetDescription

`func (o *V12SubnetsSubnetPoolsPool) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V12SubnetsSubnetPoolsPool) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V12SubnetsSubnetPoolsPool) SetDescription(v string)`

SetDescription sets Description field to given value.


### GetGroupnet

`func (o *V12SubnetsSubnetPoolsPool) GetGroupnet() string`

GetGroupnet returns the Groupnet field if non-nil, zero value otherwise.

### GetGroupnetOk

`func (o *V12SubnetsSubnetPoolsPool) GetGroupnetOk() (*string, bool)`

GetGroupnetOk returns a tuple with the Groupnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupnet

`func (o *V12SubnetsSubnetPoolsPool) SetGroupnet(v string)`

SetGroupnet sets Groupnet field to given value.


### GetId

`func (o *V12SubnetsSubnetPoolsPool) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12SubnetsSubnetPoolsPool) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12SubnetsSubnetPoolsPool) SetId(v string)`

SetId sets Id field to given value.


### GetIfaces

`func (o *V12SubnetsSubnetPoolsPool) GetIfaces() []V12SubnetsSubnetPoolIface`

GetIfaces returns the Ifaces field if non-nil, zero value otherwise.

### GetIfacesOk

`func (o *V12SubnetsSubnetPoolsPool) GetIfacesOk() (*[]V12SubnetsSubnetPoolIface, bool)`

GetIfacesOk returns a tuple with the Ifaces field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIfaces

`func (o *V12SubnetsSubnetPoolsPool) SetIfaces(v []V12SubnetsSubnetPoolIface)`

SetIfaces sets Ifaces field to given value.


### GetName

`func (o *V12SubnetsSubnetPoolsPool) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12SubnetsSubnetPoolsPool) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12SubnetsSubnetPoolsPool) SetName(v string)`

SetName sets Name field to given value.


### GetNfsv3RroceOnly

`func (o *V12SubnetsSubnetPoolsPool) GetNfsv3RroceOnly() bool`

GetNfsv3RroceOnly returns the Nfsv3RroceOnly field if non-nil, zero value otherwise.

### GetNfsv3RroceOnlyOk

`func (o *V12SubnetsSubnetPoolsPool) GetNfsv3RroceOnlyOk() (*bool, bool)`

GetNfsv3RroceOnlyOk returns a tuple with the Nfsv3RroceOnly field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv3RroceOnly

`func (o *V12SubnetsSubnetPoolsPool) SetNfsv3RroceOnly(v bool)`

SetNfsv3RroceOnly sets Nfsv3RroceOnly field to given value.


### GetRanges

`func (o *V12SubnetsSubnetPoolsPool) GetRanges() []V12GroupnetSubnetScServiceAddr`

GetRanges returns the Ranges field if non-nil, zero value otherwise.

### GetRangesOk

`func (o *V12SubnetsSubnetPoolsPool) GetRangesOk() (*[]V12GroupnetSubnetScServiceAddr, bool)`

GetRangesOk returns a tuple with the Ranges field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRanges

`func (o *V12SubnetsSubnetPoolsPool) SetRanges(v []V12GroupnetSubnetScServiceAddr)`

SetRanges sets Ranges field to given value.


### GetRebalancePolicy

`func (o *V12SubnetsSubnetPoolsPool) GetRebalancePolicy() string`

GetRebalancePolicy returns the RebalancePolicy field if non-nil, zero value otherwise.

### GetRebalancePolicyOk

`func (o *V12SubnetsSubnetPoolsPool) GetRebalancePolicyOk() (*string, bool)`

GetRebalancePolicyOk returns a tuple with the RebalancePolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRebalancePolicy

`func (o *V12SubnetsSubnetPoolsPool) SetRebalancePolicy(v string)`

SetRebalancePolicy sets RebalancePolicy field to given value.


### GetRules

`func (o *V12SubnetsSubnetPoolsPool) GetRules() []string`

GetRules returns the Rules field if non-nil, zero value otherwise.

### GetRulesOk

`func (o *V12SubnetsSubnetPoolsPool) GetRulesOk() (*[]string, bool)`

GetRulesOk returns a tuple with the Rules field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRules

`func (o *V12SubnetsSubnetPoolsPool) SetRules(v []string)`

SetRules sets Rules field to given value.


### GetScAutoUnsuspendDelay

`func (o *V12SubnetsSubnetPoolsPool) GetScAutoUnsuspendDelay() int32`

GetScAutoUnsuspendDelay returns the ScAutoUnsuspendDelay field if non-nil, zero value otherwise.

### GetScAutoUnsuspendDelayOk

`func (o *V12SubnetsSubnetPoolsPool) GetScAutoUnsuspendDelayOk() (*int32, bool)`

GetScAutoUnsuspendDelayOk returns a tuple with the ScAutoUnsuspendDelay field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScAutoUnsuspendDelay

`func (o *V12SubnetsSubnetPoolsPool) SetScAutoUnsuspendDelay(v int32)`

SetScAutoUnsuspendDelay sets ScAutoUnsuspendDelay field to given value.


### GetScConnectPolicy

`func (o *V12SubnetsSubnetPoolsPool) GetScConnectPolicy() string`

GetScConnectPolicy returns the ScConnectPolicy field if non-nil, zero value otherwise.

### GetScConnectPolicyOk

`func (o *V12SubnetsSubnetPoolsPool) GetScConnectPolicyOk() (*string, bool)`

GetScConnectPolicyOk returns a tuple with the ScConnectPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScConnectPolicy

`func (o *V12SubnetsSubnetPoolsPool) SetScConnectPolicy(v string)`

SetScConnectPolicy sets ScConnectPolicy field to given value.


### GetScDnsZone

`func (o *V12SubnetsSubnetPoolsPool) GetScDnsZone() string`

GetScDnsZone returns the ScDnsZone field if non-nil, zero value otherwise.

### GetScDnsZoneOk

`func (o *V12SubnetsSubnetPoolsPool) GetScDnsZoneOk() (*string, bool)`

GetScDnsZoneOk returns a tuple with the ScDnsZone field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScDnsZone

`func (o *V12SubnetsSubnetPoolsPool) SetScDnsZone(v string)`

SetScDnsZone sets ScDnsZone field to given value.


### GetScDnsZoneAliases

`func (o *V12SubnetsSubnetPoolsPool) GetScDnsZoneAliases() []string`

GetScDnsZoneAliases returns the ScDnsZoneAliases field if non-nil, zero value otherwise.

### GetScDnsZoneAliasesOk

`func (o *V12SubnetsSubnetPoolsPool) GetScDnsZoneAliasesOk() (*[]string, bool)`

GetScDnsZoneAliasesOk returns a tuple with the ScDnsZoneAliases field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScDnsZoneAliases

`func (o *V12SubnetsSubnetPoolsPool) SetScDnsZoneAliases(v []string)`

SetScDnsZoneAliases sets ScDnsZoneAliases field to given value.


### GetScFailoverPolicy

`func (o *V12SubnetsSubnetPoolsPool) GetScFailoverPolicy() string`

GetScFailoverPolicy returns the ScFailoverPolicy field if non-nil, zero value otherwise.

### GetScFailoverPolicyOk

`func (o *V12SubnetsSubnetPoolsPool) GetScFailoverPolicyOk() (*string, bool)`

GetScFailoverPolicyOk returns a tuple with the ScFailoverPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScFailoverPolicy

`func (o *V12SubnetsSubnetPoolsPool) SetScFailoverPolicy(v string)`

SetScFailoverPolicy sets ScFailoverPolicy field to given value.


### GetScSubnet

`func (o *V12SubnetsSubnetPoolsPool) GetScSubnet() string`

GetScSubnet returns the ScSubnet field if non-nil, zero value otherwise.

### GetScSubnetOk

`func (o *V12SubnetsSubnetPoolsPool) GetScSubnetOk() (*string, bool)`

GetScSubnetOk returns a tuple with the ScSubnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScSubnet

`func (o *V12SubnetsSubnetPoolsPool) SetScSubnet(v string)`

SetScSubnet sets ScSubnet field to given value.


### GetScSuspendedNodes

`func (o *V12SubnetsSubnetPoolsPool) GetScSuspendedNodes() []int32`

GetScSuspendedNodes returns the ScSuspendedNodes field if non-nil, zero value otherwise.

### GetScSuspendedNodesOk

`func (o *V12SubnetsSubnetPoolsPool) GetScSuspendedNodesOk() (*[]int32, bool)`

GetScSuspendedNodesOk returns a tuple with the ScSuspendedNodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScSuspendedNodes

`func (o *V12SubnetsSubnetPoolsPool) SetScSuspendedNodes(v []int32)`

SetScSuspendedNodes sets ScSuspendedNodes field to given value.


### GetScTtl

`func (o *V12SubnetsSubnetPoolsPool) GetScTtl() int32`

GetScTtl returns the ScTtl field if non-nil, zero value otherwise.

### GetScTtlOk

`func (o *V12SubnetsSubnetPoolsPool) GetScTtlOk() (*int32, bool)`

GetScTtlOk returns a tuple with the ScTtl field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScTtl

`func (o *V12SubnetsSubnetPoolsPool) SetScTtl(v int32)`

SetScTtl sets ScTtl field to given value.


### GetStaticRoutes

`func (o *V12SubnetsSubnetPoolsPool) GetStaticRoutes() []V12SubnetsSubnetPoolStaticRoute`

GetStaticRoutes returns the StaticRoutes field if non-nil, zero value otherwise.

### GetStaticRoutesOk

`func (o *V12SubnetsSubnetPoolsPool) GetStaticRoutesOk() (*[]V12SubnetsSubnetPoolStaticRoute, bool)`

GetStaticRoutesOk returns a tuple with the StaticRoutes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStaticRoutes

`func (o *V12SubnetsSubnetPoolsPool) SetStaticRoutes(v []V12SubnetsSubnetPoolStaticRoute)`

SetStaticRoutes sets StaticRoutes field to given value.


### GetSubnet

`func (o *V12SubnetsSubnetPoolsPool) GetSubnet() string`

GetSubnet returns the Subnet field if non-nil, zero value otherwise.

### GetSubnetOk

`func (o *V12SubnetsSubnetPoolsPool) GetSubnetOk() (*string, bool)`

GetSubnetOk returns a tuple with the Subnet field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubnet

`func (o *V12SubnetsSubnetPoolsPool) SetSubnet(v string)`

SetSubnet sets Subnet field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


