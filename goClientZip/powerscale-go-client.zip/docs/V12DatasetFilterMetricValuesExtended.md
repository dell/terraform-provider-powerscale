# V12DatasetFilterMetricValuesExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExportId** | Pointer to **float32** | NFS export ID | [optional] 
**Groupname** | Pointer to **string** | groupname | [optional] 
**LocalAddress** | Pointer to **string** | Local IPv4, IPv6 address, address range, or subnet. | [optional] 
**Path** | Pointer to **string** | Path of tracked directory | [optional] 
**Protocol** | Pointer to **string** | The protocol used for the request | [optional] 
**RemoteAddress** | Pointer to **string** | Client IPv4 or IPv6 address, address range, or subnet. | [optional] 
**ShareName** | Pointer to **string** | SMB share name | [optional] 
**Username** | Pointer to **string** | username | [optional] 
**ZoneName** | Pointer to **string** | The zone name | [optional] 
**JobType** | Pointer to **string** | The job type. | [optional] 
**SystemName** | Pointer to **string** | The system name | [optional] 

## Methods

### NewV12DatasetFilterMetricValuesExtended

`func NewV12DatasetFilterMetricValuesExtended() *V12DatasetFilterMetricValuesExtended`

NewV12DatasetFilterMetricValuesExtended instantiates a new V12DatasetFilterMetricValuesExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12DatasetFilterMetricValuesExtendedWithDefaults

`func NewV12DatasetFilterMetricValuesExtendedWithDefaults() *V12DatasetFilterMetricValuesExtended`

NewV12DatasetFilterMetricValuesExtendedWithDefaults instantiates a new V12DatasetFilterMetricValuesExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExportId

`func (o *V12DatasetFilterMetricValuesExtended) GetExportId() float32`

GetExportId returns the ExportId field if non-nil, zero value otherwise.

### GetExportIdOk

`func (o *V12DatasetFilterMetricValuesExtended) GetExportIdOk() (*float32, bool)`

GetExportIdOk returns a tuple with the ExportId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExportId

`func (o *V12DatasetFilterMetricValuesExtended) SetExportId(v float32)`

SetExportId sets ExportId field to given value.

### HasExportId

`func (o *V12DatasetFilterMetricValuesExtended) HasExportId() bool`

HasExportId returns a boolean if a field has been set.

### GetGroupname

`func (o *V12DatasetFilterMetricValuesExtended) GetGroupname() string`

GetGroupname returns the Groupname field if non-nil, zero value otherwise.

### GetGroupnameOk

`func (o *V12DatasetFilterMetricValuesExtended) GetGroupnameOk() (*string, bool)`

GetGroupnameOk returns a tuple with the Groupname field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupname

`func (o *V12DatasetFilterMetricValuesExtended) SetGroupname(v string)`

SetGroupname sets Groupname field to given value.

### HasGroupname

`func (o *V12DatasetFilterMetricValuesExtended) HasGroupname() bool`

HasGroupname returns a boolean if a field has been set.

### GetLocalAddress

`func (o *V12DatasetFilterMetricValuesExtended) GetLocalAddress() string`

GetLocalAddress returns the LocalAddress field if non-nil, zero value otherwise.

### GetLocalAddressOk

`func (o *V12DatasetFilterMetricValuesExtended) GetLocalAddressOk() (*string, bool)`

GetLocalAddressOk returns a tuple with the LocalAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocalAddress

`func (o *V12DatasetFilterMetricValuesExtended) SetLocalAddress(v string)`

SetLocalAddress sets LocalAddress field to given value.

### HasLocalAddress

`func (o *V12DatasetFilterMetricValuesExtended) HasLocalAddress() bool`

HasLocalAddress returns a boolean if a field has been set.

### GetPath

`func (o *V12DatasetFilterMetricValuesExtended) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V12DatasetFilterMetricValuesExtended) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V12DatasetFilterMetricValuesExtended) SetPath(v string)`

SetPath sets Path field to given value.

### HasPath

`func (o *V12DatasetFilterMetricValuesExtended) HasPath() bool`

HasPath returns a boolean if a field has been set.

### GetProtocol

`func (o *V12DatasetFilterMetricValuesExtended) GetProtocol() string`

GetProtocol returns the Protocol field if non-nil, zero value otherwise.

### GetProtocolOk

`func (o *V12DatasetFilterMetricValuesExtended) GetProtocolOk() (*string, bool)`

GetProtocolOk returns a tuple with the Protocol field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProtocol

`func (o *V12DatasetFilterMetricValuesExtended) SetProtocol(v string)`

SetProtocol sets Protocol field to given value.

### HasProtocol

`func (o *V12DatasetFilterMetricValuesExtended) HasProtocol() bool`

HasProtocol returns a boolean if a field has been set.

### GetRemoteAddress

`func (o *V12DatasetFilterMetricValuesExtended) GetRemoteAddress() string`

GetRemoteAddress returns the RemoteAddress field if non-nil, zero value otherwise.

### GetRemoteAddressOk

`func (o *V12DatasetFilterMetricValuesExtended) GetRemoteAddressOk() (*string, bool)`

GetRemoteAddressOk returns a tuple with the RemoteAddress field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteAddress

`func (o *V12DatasetFilterMetricValuesExtended) SetRemoteAddress(v string)`

SetRemoteAddress sets RemoteAddress field to given value.

### HasRemoteAddress

`func (o *V12DatasetFilterMetricValuesExtended) HasRemoteAddress() bool`

HasRemoteAddress returns a boolean if a field has been set.

### GetShareName

`func (o *V12DatasetFilterMetricValuesExtended) GetShareName() string`

GetShareName returns the ShareName field if non-nil, zero value otherwise.

### GetShareNameOk

`func (o *V12DatasetFilterMetricValuesExtended) GetShareNameOk() (*string, bool)`

GetShareNameOk returns a tuple with the ShareName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShareName

`func (o *V12DatasetFilterMetricValuesExtended) SetShareName(v string)`

SetShareName sets ShareName field to given value.

### HasShareName

`func (o *V12DatasetFilterMetricValuesExtended) HasShareName() bool`

HasShareName returns a boolean if a field has been set.

### GetUsername

`func (o *V12DatasetFilterMetricValuesExtended) GetUsername() string`

GetUsername returns the Username field if non-nil, zero value otherwise.

### GetUsernameOk

`func (o *V12DatasetFilterMetricValuesExtended) GetUsernameOk() (*string, bool)`

GetUsernameOk returns a tuple with the Username field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsername

`func (o *V12DatasetFilterMetricValuesExtended) SetUsername(v string)`

SetUsername sets Username field to given value.

### HasUsername

`func (o *V12DatasetFilterMetricValuesExtended) HasUsername() bool`

HasUsername returns a boolean if a field has been set.

### GetZoneName

`func (o *V12DatasetFilterMetricValuesExtended) GetZoneName() string`

GetZoneName returns the ZoneName field if non-nil, zero value otherwise.

### GetZoneNameOk

`func (o *V12DatasetFilterMetricValuesExtended) GetZoneNameOk() (*string, bool)`

GetZoneNameOk returns a tuple with the ZoneName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZoneName

`func (o *V12DatasetFilterMetricValuesExtended) SetZoneName(v string)`

SetZoneName sets ZoneName field to given value.

### HasZoneName

`func (o *V12DatasetFilterMetricValuesExtended) HasZoneName() bool`

HasZoneName returns a boolean if a field has been set.

### GetJobType

`func (o *V12DatasetFilterMetricValuesExtended) GetJobType() string`

GetJobType returns the JobType field if non-nil, zero value otherwise.

### GetJobTypeOk

`func (o *V12DatasetFilterMetricValuesExtended) GetJobTypeOk() (*string, bool)`

GetJobTypeOk returns a tuple with the JobType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJobType

`func (o *V12DatasetFilterMetricValuesExtended) SetJobType(v string)`

SetJobType sets JobType field to given value.

### HasJobType

`func (o *V12DatasetFilterMetricValuesExtended) HasJobType() bool`

HasJobType returns a boolean if a field has been set.

### GetSystemName

`func (o *V12DatasetFilterMetricValuesExtended) GetSystemName() string`

GetSystemName returns the SystemName field if non-nil, zero value otherwise.

### GetSystemNameOk

`func (o *V12DatasetFilterMetricValuesExtended) GetSystemNameOk() (*string, bool)`

GetSystemNameOk returns a tuple with the SystemName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemName

`func (o *V12DatasetFilterMetricValuesExtended) SetSystemName(v string)`

SetSystemName sets SystemName field to given value.

### HasSystemName

`func (o *V12DatasetFilterMetricValuesExtended) HasSystemName() bool`

HasSystemName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


