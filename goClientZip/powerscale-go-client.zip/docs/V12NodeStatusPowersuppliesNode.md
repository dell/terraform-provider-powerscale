# V12NodeStatusPowersuppliesNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Count** | Pointer to **int32** | Count of how many power supplies are supported. | [optional] 
**Error** | Pointer to **string** | Error message, if the HTTP status returned from this node was not 200. | [optional] 
**Failures** | Pointer to **int32** | Count of how many power supplies have failed. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Status** | Pointer to **string** | A descriptive status string for this node&#39;s power supplies. | [optional] 
**Supplies** | Pointer to [**[]V10ClusterNodeStatusPowersuppliesSupply**](V10ClusterNodeStatusPowersuppliesSupply.md) | List of this node&#39;s power supplies. | [optional] 

## Methods

### NewV12NodeStatusPowersuppliesNode

`func NewV12NodeStatusPowersuppliesNode() *V12NodeStatusPowersuppliesNode`

NewV12NodeStatusPowersuppliesNode instantiates a new V12NodeStatusPowersuppliesNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NodeStatusPowersuppliesNodeWithDefaults

`func NewV12NodeStatusPowersuppliesNodeWithDefaults() *V12NodeStatusPowersuppliesNode`

NewV12NodeStatusPowersuppliesNodeWithDefaults instantiates a new V12NodeStatusPowersuppliesNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCount

`func (o *V12NodeStatusPowersuppliesNode) GetCount() int32`

GetCount returns the Count field if non-nil, zero value otherwise.

### GetCountOk

`func (o *V12NodeStatusPowersuppliesNode) GetCountOk() (*int32, bool)`

GetCountOk returns a tuple with the Count field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCount

`func (o *V12NodeStatusPowersuppliesNode) SetCount(v int32)`

SetCount sets Count field to given value.

### HasCount

`func (o *V12NodeStatusPowersuppliesNode) HasCount() bool`

HasCount returns a boolean if a field has been set.

### GetError

`func (o *V12NodeStatusPowersuppliesNode) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V12NodeStatusPowersuppliesNode) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V12NodeStatusPowersuppliesNode) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V12NodeStatusPowersuppliesNode) HasError() bool`

HasError returns a boolean if a field has been set.

### GetFailures

`func (o *V12NodeStatusPowersuppliesNode) GetFailures() int32`

GetFailures returns the Failures field if non-nil, zero value otherwise.

### GetFailuresOk

`func (o *V12NodeStatusPowersuppliesNode) GetFailuresOk() (*int32, bool)`

GetFailuresOk returns a tuple with the Failures field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFailures

`func (o *V12NodeStatusPowersuppliesNode) SetFailures(v int32)`

SetFailures sets Failures field to given value.

### HasFailures

`func (o *V12NodeStatusPowersuppliesNode) HasFailures() bool`

HasFailures returns a boolean if a field has been set.

### GetId

`func (o *V12NodeStatusPowersuppliesNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12NodeStatusPowersuppliesNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12NodeStatusPowersuppliesNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V12NodeStatusPowersuppliesNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V12NodeStatusPowersuppliesNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12NodeStatusPowersuppliesNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12NodeStatusPowersuppliesNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V12NodeStatusPowersuppliesNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetStatus

`func (o *V12NodeStatusPowersuppliesNode) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12NodeStatusPowersuppliesNode) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12NodeStatusPowersuppliesNode) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V12NodeStatusPowersuppliesNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetSupplies

`func (o *V12NodeStatusPowersuppliesNode) GetSupplies() []V10ClusterNodeStatusPowersuppliesSupply`

GetSupplies returns the Supplies field if non-nil, zero value otherwise.

### GetSuppliesOk

`func (o *V12NodeStatusPowersuppliesNode) GetSuppliesOk() (*[]V10ClusterNodeStatusPowersuppliesSupply, bool)`

GetSuppliesOk returns a tuple with the Supplies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupplies

`func (o *V12NodeStatusPowersuppliesNode) SetSupplies(v []V10ClusterNodeStatusPowersuppliesSupply)`

SetSupplies sets Supplies field to given value.

### HasSupplies

`func (o *V12NodeStatusPowersuppliesNode) HasSupplies() bool`

HasSupplies returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


