# V11AvscanServerExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | Pointer to **bool** | Whether the server is enabled. | [optional] 
**Id** | Pointer to **string** | A unique identifier for the server. | [optional] 
**ServerName** | Pointer to **string** | Unique short name of the server. | [optional] 
**ServerType** | Pointer to **string** | The type of server. | [optional] 
**ServerUri** | Pointer to **string** | URI of the server. Typical format is: domain:port/path | [optional] 

## Methods

### NewV11AvscanServerExtended

`func NewV11AvscanServerExtended() *V11AvscanServerExtended`

NewV11AvscanServerExtended instantiates a new V11AvscanServerExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanServerExtendedWithDefaults

`func NewV11AvscanServerExtendedWithDefaults() *V11AvscanServerExtended`

NewV11AvscanServerExtendedWithDefaults instantiates a new V11AvscanServerExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *V11AvscanServerExtended) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V11AvscanServerExtended) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V11AvscanServerExtended) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V11AvscanServerExtended) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetId

`func (o *V11AvscanServerExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11AvscanServerExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11AvscanServerExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11AvscanServerExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetServerName

`func (o *V11AvscanServerExtended) GetServerName() string`

GetServerName returns the ServerName field if non-nil, zero value otherwise.

### GetServerNameOk

`func (o *V11AvscanServerExtended) GetServerNameOk() (*string, bool)`

GetServerNameOk returns a tuple with the ServerName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerName

`func (o *V11AvscanServerExtended) SetServerName(v string)`

SetServerName sets ServerName field to given value.

### HasServerName

`func (o *V11AvscanServerExtended) HasServerName() bool`

HasServerName returns a boolean if a field has been set.

### GetServerType

`func (o *V11AvscanServerExtended) GetServerType() string`

GetServerType returns the ServerType field if non-nil, zero value otherwise.

### GetServerTypeOk

`func (o *V11AvscanServerExtended) GetServerTypeOk() (*string, bool)`

GetServerTypeOk returns a tuple with the ServerType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerType

`func (o *V11AvscanServerExtended) SetServerType(v string)`

SetServerType sets ServerType field to given value.

### HasServerType

`func (o *V11AvscanServerExtended) HasServerType() bool`

HasServerType returns a boolean if a field has been set.

### GetServerUri

`func (o *V11AvscanServerExtended) GetServerUri() string`

GetServerUri returns the ServerUri field if non-nil, zero value otherwise.

### GetServerUriOk

`func (o *V11AvscanServerExtended) GetServerUriOk() (*string, bool)`

GetServerUriOk returns a tuple with the ServerUri field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerUri

`func (o *V11AvscanServerExtended) SetServerUri(v string)`

SetServerUri sets ServerUri field to given value.

### HasServerUri

`func (o *V11AvscanServerExtended) HasServerUri() bool`

HasServerUri returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


