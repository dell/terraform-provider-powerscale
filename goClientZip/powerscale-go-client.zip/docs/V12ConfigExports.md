# V12ConfigExports

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Exports** | Pointer to [**[]V12ConfigExportExtended**](V12ConfigExportExtended.md) |  | [optional] 

## Methods

### NewV12ConfigExports

`func NewV12ConfigExports() *V12ConfigExports`

NewV12ConfigExports instantiates a new V12ConfigExports object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ConfigExportsWithDefaults

`func NewV12ConfigExportsWithDefaults() *V12ConfigExports`

NewV12ConfigExportsWithDefaults instantiates a new V12ConfigExports object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExports

`func (o *V12ConfigExports) GetExports() []V12ConfigExportExtended`

GetExports returns the Exports field if non-nil, zero value otherwise.

### GetExportsOk

`func (o *V12ConfigExports) GetExportsOk() (*[]V12ConfigExportExtended, bool)`

GetExportsOk returns a tuple with the Exports field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExports

`func (o *V12ConfigExports) SetExports(v []V12ConfigExportExtended)`

SetExports sets Exports field to given value.

### HasExports

`func (o *V12ConfigExports) HasExports() bool`

HasExports returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


