# \SnapshotApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateSnapshotv14SnapshotWritableItem**](SnapshotApi.md#CreateSnapshotv14SnapshotWritableItem) | **Post** /platform/14/snapshot/writable | 
[**CreateSnapshotv1SnapshotAlias**](SnapshotApi.md#CreateSnapshotv1SnapshotAlias) | **Post** /platform/1/snapshot/aliases | 
[**CreateSnapshotv1SnapshotSchedule**](SnapshotApi.md#CreateSnapshotv1SnapshotSchedule) | **Post** /platform/1/snapshot/schedules | 
[**CreateSnapshotv1SnapshotSnapshot**](SnapshotApi.md#CreateSnapshotv1SnapshotSnapshot) | **Post** /platform/1/snapshot/snapshots | 
[**CreateSnapshotv3SnapshotSchedule**](SnapshotApi.md#CreateSnapshotv3SnapshotSchedule) | **Post** /platform/3/snapshot/schedules | 
[**DeleteSnapshotv14SnapshotWritable**](SnapshotApi.md#DeleteSnapshotv14SnapshotWritable) | **Delete** /platform/14/snapshot/writable | 
[**DeleteSnapshotv14SnapshotWritableWspath**](SnapshotApi.md#DeleteSnapshotv14SnapshotWritableWspath) | **Delete** /platform/14/snapshot/writable/{v14SnapshotWritableWspath} | 
[**DeleteSnapshotv1SnapshotAlias**](SnapshotApi.md#DeleteSnapshotv1SnapshotAlias) | **Delete** /platform/1/snapshot/aliases/{v1SnapshotAliasId} | 
[**DeleteSnapshotv1SnapshotAliases**](SnapshotApi.md#DeleteSnapshotv1SnapshotAliases) | **Delete** /platform/1/snapshot/aliases | 
[**DeleteSnapshotv1SnapshotChangelist**](SnapshotApi.md#DeleteSnapshotv1SnapshotChangelist) | **Delete** /platform/1/snapshot/changelists/{v1SnapshotChangelistId} | 
[**DeleteSnapshotv1SnapshotRepstate**](SnapshotApi.md#DeleteSnapshotv1SnapshotRepstate) | **Delete** /platform/1/snapshot/repstates/{v1SnapshotRepstateId} | 
[**DeleteSnapshotv1SnapshotSchedule**](SnapshotApi.md#DeleteSnapshotv1SnapshotSchedule) | **Delete** /platform/1/snapshot/schedules/{v1SnapshotScheduleId} | 
[**DeleteSnapshotv1SnapshotSnapshot**](SnapshotApi.md#DeleteSnapshotv1SnapshotSnapshot) | **Delete** /platform/1/snapshot/snapshots/{v1SnapshotSnapshotId} | 
[**DeleteSnapshotv1SnapshotSnapshots**](SnapshotApi.md#DeleteSnapshotv1SnapshotSnapshots) | **Delete** /platform/1/snapshot/snapshots | 
[**DeleteSnapshotv1SnapshotsSidLock**](SnapshotApi.md#DeleteSnapshotv1SnapshotsSidLock) | **Delete** /platform/1/snapshot/snapshots/{Sid}/locks/{v1SnapshotsSidLockId} | 
[**DeleteSnapshotv3SnapshotSchedules**](SnapshotApi.md#DeleteSnapshotv3SnapshotSchedules) | **Delete** /platform/3/snapshot/schedules | 
[**GetSnapshotv10ChangelistsChangelistDiffRegion**](SnapshotApi.md#GetSnapshotv10ChangelistsChangelistDiffRegion) | **Get** /platform/10/snapshot/changelists/{Changelist}/diff-regions/{v10ChangelistsChangelistDiffRegionId} | 
[**GetSnapshotv10ChangelistsChangelistEntry**](SnapshotApi.md#GetSnapshotv10ChangelistsChangelistEntry) | **Get** /platform/10/snapshot/changelists/{Changelist}/entries/{v10ChangelistsChangelistEntryId} | 
[**GetSnapshotv14SnapshotWritableSnapshotSummary**](SnapshotApi.md#GetSnapshotv14SnapshotWritableSnapshotSummary) | **Get** /platform/14/snapshot/writable-snapshot-summary | 
[**GetSnapshotv14SnapshotWritableWspath**](SnapshotApi.md#GetSnapshotv14SnapshotWritableWspath) | **Get** /platform/14/snapshot/writable/{v14SnapshotWritableWspath} | 
[**GetSnapshotv1ChangelistsChangelistLin**](SnapshotApi.md#GetSnapshotv1ChangelistsChangelistLin) | **Get** /platform/1/snapshot/changelists/{Changelist}/lins/{v1ChangelistsChangelistLinId} | 
[**GetSnapshotv1SnapshotAlias**](SnapshotApi.md#GetSnapshotv1SnapshotAlias) | **Get** /platform/1/snapshot/aliases/{v1SnapshotAliasId} | 
[**GetSnapshotv1SnapshotChangelist**](SnapshotApi.md#GetSnapshotv1SnapshotChangelist) | **Get** /platform/1/snapshot/changelists/{v1SnapshotChangelistId} | 
[**GetSnapshotv1SnapshotChangelists**](SnapshotApi.md#GetSnapshotv1SnapshotChangelists) | **Get** /platform/1/snapshot/changelists | 
[**GetSnapshotv1SnapshotLicense**](SnapshotApi.md#GetSnapshotv1SnapshotLicense) | **Get** /platform/1/snapshot/license | 
[**GetSnapshotv1SnapshotPending**](SnapshotApi.md#GetSnapshotv1SnapshotPending) | **Get** /platform/1/snapshot/pending | 
[**GetSnapshotv1SnapshotRepstate**](SnapshotApi.md#GetSnapshotv1SnapshotRepstate) | **Get** /platform/1/snapshot/repstates/{v1SnapshotRepstateId} | 
[**GetSnapshotv1SnapshotRepstates**](SnapshotApi.md#GetSnapshotv1SnapshotRepstates) | **Get** /platform/1/snapshot/repstates | 
[**GetSnapshotv1SnapshotSchedule**](SnapshotApi.md#GetSnapshotv1SnapshotSchedule) | **Get** /platform/1/snapshot/schedules/{v1SnapshotScheduleId} | 
[**GetSnapshotv1SnapshotSettings**](SnapshotApi.md#GetSnapshotv1SnapshotSettings) | **Get** /platform/1/snapshot/settings | 
[**GetSnapshotv1SnapshotSnapshot**](SnapshotApi.md#GetSnapshotv1SnapshotSnapshot) | **Get** /platform/1/snapshot/snapshots/{v1SnapshotSnapshotId} | 
[**GetSnapshotv1SnapshotSnapshotsSummary**](SnapshotApi.md#GetSnapshotv1SnapshotSnapshotsSummary) | **Get** /platform/1/snapshot/snapshots-summary | 
[**GetSnapshotv1SnapshotsSidLock**](SnapshotApi.md#GetSnapshotv1SnapshotsSidLock) | **Get** /platform/1/snapshot/snapshots/{Sid}/locks/{v1SnapshotsSidLockId} | 
[**GetSnapshotv5SnapshotLicense**](SnapshotApi.md#GetSnapshotv5SnapshotLicense) | **Get** /platform/5/snapshot/license | 
[**GetSnapshotv8ChangelistsChangelistEntry**](SnapshotApi.md#GetSnapshotv8ChangelistsChangelistEntry) | **Get** /platform/8/snapshot/changelists/{Changelist}/entries/{v8ChangelistsChangelistEntryId} | 
[**ListSnapshotv14SnapshotWritable**](SnapshotApi.md#ListSnapshotv14SnapshotWritable) | **Get** /platform/14/snapshot/writable | 
[**ListSnapshotv1SnapshotAliases**](SnapshotApi.md#ListSnapshotv1SnapshotAliases) | **Get** /platform/1/snapshot/aliases | 
[**ListSnapshotv1SnapshotSchedules**](SnapshotApi.md#ListSnapshotv1SnapshotSchedules) | **Get** /platform/1/snapshot/schedules | 
[**ListSnapshotv1SnapshotSnapshots**](SnapshotApi.md#ListSnapshotv1SnapshotSnapshots) | **Get** /platform/1/snapshot/snapshots | 
[**ListSnapshotv3SnapshotSchedules**](SnapshotApi.md#ListSnapshotv3SnapshotSchedules) | **Get** /platform/3/snapshot/schedules | 
[**UpdateSnapshotv1SnapshotAlias**](SnapshotApi.md#UpdateSnapshotv1SnapshotAlias) | **Put** /platform/1/snapshot/aliases/{v1SnapshotAliasId} | 
[**UpdateSnapshotv1SnapshotSchedule**](SnapshotApi.md#UpdateSnapshotv1SnapshotSchedule) | **Put** /platform/1/snapshot/schedules/{v1SnapshotScheduleId} | 
[**UpdateSnapshotv1SnapshotSettings**](SnapshotApi.md#UpdateSnapshotv1SnapshotSettings) | **Put** /platform/1/snapshot/settings | 
[**UpdateSnapshotv1SnapshotSnapshot**](SnapshotApi.md#UpdateSnapshotv1SnapshotSnapshot) | **Put** /platform/1/snapshot/snapshots/{v1SnapshotSnapshotId} | 
[**UpdateSnapshotv1SnapshotsSidLock**](SnapshotApi.md#UpdateSnapshotv1SnapshotsSidLock) | **Put** /platform/1/snapshot/snapshots/{Sid}/locks/{v1SnapshotsSidLockId} | 



## CreateSnapshotv14SnapshotWritableItem

> Createv14SnapshotWritableItemResponse CreateSnapshotv14SnapshotWritableItem(ctx).V14SnapshotWritableItem(v14SnapshotWritableItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SnapshotWritableItem := *openapiclient.NewV14SnapshotWritableItem("DstPath_example", "SrcSnap_example") // V14SnapshotWritableItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.CreateSnapshotv14SnapshotWritableItem(context.Background()).V14SnapshotWritableItem(v14SnapshotWritableItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.CreateSnapshotv14SnapshotWritableItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSnapshotv14SnapshotWritableItem`: Createv14SnapshotWritableItemResponse
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.CreateSnapshotv14SnapshotWritableItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSnapshotv14SnapshotWritableItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14SnapshotWritableItem** | [**V14SnapshotWritableItem**](V14SnapshotWritableItem.md) |  | 

### Return type

[**Createv14SnapshotWritableItemResponse**](Createv14SnapshotWritableItemResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSnapshotv1SnapshotAlias

> Createv1SnapshotAliasResponse CreateSnapshotv1SnapshotAlias(ctx).V1SnapshotAlias(v1SnapshotAlias).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotAlias := *openapiclient.NewV1SnapshotAlias("Name_example", "Target_example") // V1SnapshotAlias | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.CreateSnapshotv1SnapshotAlias(context.Background()).V1SnapshotAlias(v1SnapshotAlias).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.CreateSnapshotv1SnapshotAlias``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSnapshotv1SnapshotAlias`: Createv1SnapshotAliasResponse
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.CreateSnapshotv1SnapshotAlias`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSnapshotv1SnapshotAliasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SnapshotAlias** | [**V1SnapshotAlias**](V1SnapshotAlias.md) |  | 

### Return type

[**Createv1SnapshotAliasResponse**](Createv1SnapshotAliasResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSnapshotv1SnapshotSchedule

> Createv1SnapshotScheduleResponse CreateSnapshotv1SnapshotSchedule(ctx).V1SnapshotSchedule(v1SnapshotSchedule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotSchedule := *openapiclient.NewV1SnapshotSchedule("Name_example", "Path_example", "Pattern_example", "Schedule_example") // V1SnapshotSchedule | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.CreateSnapshotv1SnapshotSchedule(context.Background()).V1SnapshotSchedule(v1SnapshotSchedule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.CreateSnapshotv1SnapshotSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSnapshotv1SnapshotSchedule`: Createv1SnapshotScheduleResponse
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.CreateSnapshotv1SnapshotSchedule`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSnapshotv1SnapshotScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SnapshotSchedule** | [**V1SnapshotSchedule**](V1SnapshotSchedule.md) |  | 

### Return type

[**Createv1SnapshotScheduleResponse**](Createv1SnapshotScheduleResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSnapshotv1SnapshotSnapshot

> Createv1SnapshotSnapshotResponse CreateSnapshotv1SnapshotSnapshot(ctx).V1SnapshotSnapshot(v1SnapshotSnapshot).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotSnapshot := *openapiclient.NewV1SnapshotSnapshot("Path_example") // V1SnapshotSnapshot | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.CreateSnapshotv1SnapshotSnapshot(context.Background()).V1SnapshotSnapshot(v1SnapshotSnapshot).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.CreateSnapshotv1SnapshotSnapshot``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSnapshotv1SnapshotSnapshot`: Createv1SnapshotSnapshotResponse
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.CreateSnapshotv1SnapshotSnapshot`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSnapshotv1SnapshotSnapshotRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SnapshotSnapshot** | [**V1SnapshotSnapshot**](V1SnapshotSnapshot.md) |  | 

### Return type

[**Createv1SnapshotSnapshotResponse**](Createv1SnapshotSnapshotResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateSnapshotv3SnapshotSchedule

> Createv1SnapshotScheduleResponse CreateSnapshotv3SnapshotSchedule(ctx).V3SnapshotSchedule(v3SnapshotSchedule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SnapshotSchedule := *openapiclient.NewV1SnapshotSchedule("Name_example", "Path_example", "Pattern_example", "Schedule_example") // V1SnapshotSchedule | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.CreateSnapshotv3SnapshotSchedule(context.Background()).V3SnapshotSchedule(v3SnapshotSchedule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.CreateSnapshotv3SnapshotSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSnapshotv3SnapshotSchedule`: Createv1SnapshotScheduleResponse
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.CreateSnapshotv3SnapshotSchedule`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSnapshotv3SnapshotScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SnapshotSchedule** | [**V1SnapshotSchedule**](V1SnapshotSchedule.md) |  | 

### Return type

[**Createv1SnapshotScheduleResponse**](Createv1SnapshotScheduleResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv14SnapshotWritable

> DeleteSnapshotv14SnapshotWritable(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv14SnapshotWritable(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv14SnapshotWritable``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv14SnapshotWritableRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv14SnapshotWritableWspath

> DeleteSnapshotv14SnapshotWritableWspath(ctx, v14SnapshotWritableWspath).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SnapshotWritableWspath := "v14SnapshotWritableWspath_example" // string | Delete the writable snapshot. Deleted writable snapshots    will be placed into a deleting state until the system can reclaim the    space used by the writable snapshot.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv14SnapshotWritableWspath(context.Background(), v14SnapshotWritableWspath).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv14SnapshotWritableWspath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v14SnapshotWritableWspath** | **string** | Delete the writable snapshot. Deleted writable snapshots    will be placed into a deleting state until the system can reclaim the    space used by the writable snapshot. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv14SnapshotWritableWspathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv1SnapshotAlias

> DeleteSnapshotv1SnapshotAlias(ctx, v1SnapshotAliasId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotAliasId := "v1SnapshotAliasId_example" // string | Delete the snapshot alias

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv1SnapshotAlias(context.Background(), v1SnapshotAliasId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv1SnapshotAlias``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotAliasId** | **string** | Delete the snapshot alias | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv1SnapshotAliasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv1SnapshotAliases

> DeleteSnapshotv1SnapshotAliases(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv1SnapshotAliases(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv1SnapshotAliases``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv1SnapshotAliasesRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv1SnapshotChangelist

> DeleteSnapshotv1SnapshotChangelist(ctx, v1SnapshotChangelistId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotChangelistId := "v1SnapshotChangelistId_example" // string | Delete the specified changelist.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv1SnapshotChangelist(context.Background(), v1SnapshotChangelistId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv1SnapshotChangelist``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotChangelistId** | **string** | Delete the specified changelist. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv1SnapshotChangelistRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv1SnapshotRepstate

> DeleteSnapshotv1SnapshotRepstate(ctx, v1SnapshotRepstateId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotRepstateId := "v1SnapshotRepstateId_example" // string | Delete the specified repstate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv1SnapshotRepstate(context.Background(), v1SnapshotRepstateId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv1SnapshotRepstate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotRepstateId** | **string** | Delete the specified repstate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv1SnapshotRepstateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv1SnapshotSchedule

> DeleteSnapshotv1SnapshotSchedule(ctx, v1SnapshotScheduleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotScheduleId := "v1SnapshotScheduleId_example" // string | Delete the schedule. This does not affect already created snapshots.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv1SnapshotSchedule(context.Background(), v1SnapshotScheduleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv1SnapshotSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotScheduleId** | **string** | Delete the schedule. This does not affect already created snapshots. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv1SnapshotScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv1SnapshotSnapshot

> DeleteSnapshotv1SnapshotSnapshot(ctx, v1SnapshotSnapshotId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotSnapshotId := "v1SnapshotSnapshotId_example" // string | Delete the snapshot. Deleted snapshots will be placed into a deleting state until the system can reclaim the space used by the snapshot.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv1SnapshotSnapshot(context.Background(), v1SnapshotSnapshotId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv1SnapshotSnapshot``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotSnapshotId** | **string** | Delete the snapshot. Deleted snapshots will be placed into a deleting state until the system can reclaim the space used by the snapshot. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv1SnapshotSnapshotRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv1SnapshotSnapshots

> DeleteSnapshotv1SnapshotSnapshots(ctx).Type_(type_).Schedule(schedule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    type_ := "type__example" // string | Only list snapshots matching this type. (optional)
    schedule := "schedule_example" // string | Only list snapshots created by this schedule. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv1SnapshotSnapshots(context.Background()).Type_(type_).Schedule(schedule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv1SnapshotSnapshots``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv1SnapshotSnapshotsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **type_** | **string** | Only list snapshots matching this type. | 
 **schedule** | **string** | Only list snapshots created by this schedule. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv1SnapshotsSidLock

> DeleteSnapshotv1SnapshotsSidLock(ctx, v1SnapshotsSidLockId, sid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotsSidLockId := "v1SnapshotsSidLockId_example" // string | Delete the snapshot lock.
    sid := "sid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv1SnapshotsSidLock(context.Background(), v1SnapshotsSidLockId, sid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv1SnapshotsSidLock``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotsSidLockId** | **string** | Delete the snapshot lock. | 
**sid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv1SnapshotsSidLockRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotv3SnapshotSchedules

> DeleteSnapshotv3SnapshotSchedules(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.DeleteSnapshotv3SnapshotSchedules(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.DeleteSnapshotv3SnapshotSchedules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotv3SnapshotSchedulesRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv10ChangelistsChangelistDiffRegion

> V10ChangelistsChangelistDiffRegions GetSnapshotv10ChangelistsChangelistDiffRegion(ctx, v10ChangelistsChangelistDiffRegionId, changelist).Resume(resume).Limit(limit).Offset(offset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ChangelistsChangelistDiffRegionId := int32(56) // int32 | Get snap diff regions of a file.
    changelist := "changelist_example" // string | 
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    offset := int32(56) // int32 |  (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv10ChangelistsChangelistDiffRegion(context.Background(), v10ChangelistsChangelistDiffRegionId, changelist).Resume(resume).Limit(limit).Offset(offset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv10ChangelistsChangelistDiffRegion``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv10ChangelistsChangelistDiffRegion`: V10ChangelistsChangelistDiffRegions
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv10ChangelistsChangelistDiffRegion`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10ChangelistsChangelistDiffRegionId** | **int32** | Get snap diff regions of a file. | 
**changelist** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv10ChangelistsChangelistDiffRegionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **offset** | **int32** |  | 

### Return type

[**V10ChangelistsChangelistDiffRegions**](V10ChangelistsChangelistDiffRegions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv10ChangelistsChangelistEntry

> V10ChangelistsChangelistEntries GetSnapshotv10ChangelistsChangelistEntry(ctx, v10ChangelistsChangelistEntryId, changelist).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10ChangelistsChangelistEntryId := "v10ChangelistsChangelistEntryId_example" // string | Get a single entry from the changelist.
    changelist := "changelist_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv10ChangelistsChangelistEntry(context.Background(), v10ChangelistsChangelistEntryId, changelist).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv10ChangelistsChangelistEntry``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv10ChangelistsChangelistEntry`: V10ChangelistsChangelistEntries
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv10ChangelistsChangelistEntry`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10ChangelistsChangelistEntryId** | **string** | Get a single entry from the changelist. | 
**changelist** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv10ChangelistsChangelistEntryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V10ChangelistsChangelistEntries**](V10ChangelistsChangelistEntries.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv14SnapshotWritableSnapshotSummary

> V14SnapshotWritableSnapshotSummary GetSnapshotv14SnapshotWritableSnapshotSummary(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv14SnapshotWritableSnapshotSummary(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv14SnapshotWritableSnapshotSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv14SnapshotWritableSnapshotSummary`: V14SnapshotWritableSnapshotSummary
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv14SnapshotWritableSnapshotSummary`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv14SnapshotWritableSnapshotSummaryRequest struct via the builder pattern


### Return type

[**V14SnapshotWritableSnapshotSummary**](V14SnapshotWritableSnapshotSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv14SnapshotWritableWspath

> V14SnapshotWritableExtended GetSnapshotv14SnapshotWritableWspath(ctx, v14SnapshotWritableWspath).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14SnapshotWritableWspath := "v14SnapshotWritableWspath_example" // string | Retrieve writable snapshot information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv14SnapshotWritableWspath(context.Background(), v14SnapshotWritableWspath).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv14SnapshotWritableWspath``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv14SnapshotWritableWspath`: V14SnapshotWritableExtended
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv14SnapshotWritableWspath`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v14SnapshotWritableWspath** | **string** | Retrieve writable snapshot information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv14SnapshotWritableWspathRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V14SnapshotWritableExtended**](V14SnapshotWritableExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1ChangelistsChangelistLin

> V1ChangelistLin GetSnapshotv1ChangelistsChangelistLin(ctx, v1ChangelistsChangelistLinId, changelist).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1ChangelistsChangelistLinId := int32(56) // int32 | Get a single entry from the changelist.
    changelist := "changelist_example" // string | 
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1ChangelistsChangelistLin(context.Background(), v1ChangelistsChangelistLinId, changelist).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1ChangelistsChangelistLin``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1ChangelistsChangelistLin`: V1ChangelistLin
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1ChangelistsChangelistLin`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1ChangelistsChangelistLinId** | **int32** | Get a single entry from the changelist. | 
**changelist** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1ChangelistsChangelistLinRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1ChangelistLin**](V1ChangelistLin.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotAlias

> V1SnapshotAliasesExtended GetSnapshotv1SnapshotAlias(ctx, v1SnapshotAliasId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotAliasId := "v1SnapshotAliasId_example" // string | Retrieve snapshot alias information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotAlias(context.Background(), v1SnapshotAliasId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotAlias``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotAlias`: V1SnapshotAliasesExtended
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotAlias`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotAliasId** | **string** | Retrieve snapshot alias information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotAliasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1SnapshotAliasesExtended**](V1SnapshotAliasesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotChangelist

> V1SnapshotChangelist GetSnapshotv1SnapshotChangelist(ctx, v1SnapshotChangelistId).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotChangelistId := "v1SnapshotChangelistId_example" // string | Retrieve basic information on a changelist.
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotChangelist(context.Background(), v1SnapshotChangelistId).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotChangelist``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotChangelist`: V1SnapshotChangelist
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotChangelist`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotChangelistId** | **string** | Retrieve basic information on a changelist. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotChangelistRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SnapshotChangelist**](V1SnapshotChangelist.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotChangelists

> V1SnapshotChangelists GetSnapshotv1SnapshotChangelists(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotChangelists(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotChangelists``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotChangelists`: V1SnapshotChangelists
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotChangelists`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotChangelistsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SnapshotChangelists**](V1SnapshotChangelists.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotLicense

> V1LicenseLicenseExtended GetSnapshotv1SnapshotLicense(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotLicense(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotLicense`: V1LicenseLicenseExtended
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotLicense`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotLicenseRequest struct via the builder pattern


### Return type

[**V1LicenseLicenseExtended**](V1LicenseLicenseExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotPending

> V1SnapshotPending GetSnapshotv1SnapshotPending(ctx).Limit(limit).Begin(begin).Schedule(schedule).End(end).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many result at once (see resume). (optional)
    begin := int32(56) // int32 | Unix Epoch time to start generating matches. Default is now. (optional)
    schedule := "schedule_example" // string | Limit output only to the named schedule. (optional)
    end := int32(56) // int32 | Unix Epoch time to end generating matches. Default is forever. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotPending(context.Background()).Limit(limit).Begin(begin).Schedule(schedule).End(end).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotPending``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotPending`: V1SnapshotPending
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotPending`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotPendingRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many result at once (see resume). | 
 **begin** | **int32** | Unix Epoch time to start generating matches. Default is now. | 
 **schedule** | **string** | Limit output only to the named schedule. | 
 **end** | **int32** | Unix Epoch time to end generating matches. Default is forever. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SnapshotPending**](V1SnapshotPending.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotRepstate

> V1SnapshotRepstate GetSnapshotv1SnapshotRepstate(ctx, v1SnapshotRepstateId).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotRepstateId := "v1SnapshotRepstateId_example" // string | Retrieve basic information on a repstate.
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotRepstate(context.Background(), v1SnapshotRepstateId).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotRepstate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotRepstate`: V1SnapshotRepstate
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotRepstate`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotRepstateId** | **string** | Retrieve basic information on a repstate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotRepstateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SnapshotRepstate**](V1SnapshotRepstate.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotRepstates

> V1SnapshotRepstates GetSnapshotv1SnapshotRepstates(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotRepstates(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotRepstates``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotRepstates`: V1SnapshotRepstates
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotRepstates`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotRepstatesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SnapshotRepstates**](V1SnapshotRepstates.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotSchedule

> V1SnapshotSchedulesExtended GetSnapshotv1SnapshotSchedule(ctx, v1SnapshotScheduleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotScheduleId := "v1SnapshotScheduleId_example" // string | Retrieve the schedule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotSchedule(context.Background(), v1SnapshotScheduleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotSchedule`: V1SnapshotSchedulesExtended
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotSchedule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotScheduleId** | **string** | Retrieve the schedule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1SnapshotSchedulesExtended**](V1SnapshotSchedulesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotSettings

> V1SnapshotSettings GetSnapshotv1SnapshotSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotSettings`: V1SnapshotSettings
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotSettingsRequest struct via the builder pattern


### Return type

[**V1SnapshotSettings**](V1SnapshotSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotSnapshot

> V1SnapshotSnapshotsExtended GetSnapshotv1SnapshotSnapshot(ctx, v1SnapshotSnapshotId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotSnapshotId := "v1SnapshotSnapshotId_example" // string | Retrieve snapshot information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotSnapshot(context.Background(), v1SnapshotSnapshotId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotSnapshot``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotSnapshot`: V1SnapshotSnapshotsExtended
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotSnapshot`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotSnapshotId** | **string** | Retrieve snapshot information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotSnapshotRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1SnapshotSnapshotsExtended**](V1SnapshotSnapshotsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotSnapshotsSummary

> V1SnapshotSnapshotsSummary GetSnapshotv1SnapshotSnapshotsSummary(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotSnapshotsSummary(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotSnapshotsSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotSnapshotsSummary`: V1SnapshotSnapshotsSummary
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotSnapshotsSummary`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotSnapshotsSummaryRequest struct via the builder pattern


### Return type

[**V1SnapshotSnapshotsSummary**](V1SnapshotSnapshotsSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv1SnapshotsSidLock

> V1SnapshotsSidLocks GetSnapshotv1SnapshotsSidLock(ctx, v1SnapshotsSidLockId, sid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotsSidLockId := "v1SnapshotsSidLockId_example" // string | Retrieve lock information.
    sid := "sid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv1SnapshotsSidLock(context.Background(), v1SnapshotsSidLockId, sid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv1SnapshotsSidLock``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv1SnapshotsSidLock`: V1SnapshotsSidLocks
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv1SnapshotsSidLock`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotsSidLockId** | **string** | Retrieve lock information. | 
**sid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv1SnapshotsSidLockRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V1SnapshotsSidLocks**](V1SnapshotsSidLocks.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv5SnapshotLicense

> V5LicenseLicenseExtended GetSnapshotv5SnapshotLicense(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv5SnapshotLicense(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv5SnapshotLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv5SnapshotLicense`: V5LicenseLicenseExtended
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv5SnapshotLicense`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv5SnapshotLicenseRequest struct via the builder pattern


### Return type

[**V5LicenseLicenseExtended**](V5LicenseLicenseExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSnapshotv8ChangelistsChangelistEntry

> V8ChangelistsChangelistEntries GetSnapshotv8ChangelistsChangelistEntry(ctx, v8ChangelistsChangelistEntryId, changelist).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v8ChangelistsChangelistEntryId := "v8ChangelistsChangelistEntryId_example" // string | Get a single entry from the changelist.
    changelist := "changelist_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.GetSnapshotv8ChangelistsChangelistEntry(context.Background(), v8ChangelistsChangelistEntryId, changelist).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.GetSnapshotv8ChangelistsChangelistEntry``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSnapshotv8ChangelistsChangelistEntry`: V8ChangelistsChangelistEntries
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.GetSnapshotv8ChangelistsChangelistEntry`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v8ChangelistsChangelistEntryId** | **string** | Get a single entry from the changelist. | 
**changelist** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSnapshotv8ChangelistsChangelistEntryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V8ChangelistsChangelistEntries**](V8ChangelistsChangelistEntries.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSnapshotv14SnapshotWritable

> V14SnapshotWritable ListSnapshotv14SnapshotWritable(ctx).Sort(sort).State(state).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting.  Choices are path, src name, src path, created, size and state. Default is created. (optional)
    state := "state_example" // string | Only list writable snapshots matching this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.ListSnapshotv14SnapshotWritable(context.Background()).Sort(sort).State(state).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.ListSnapshotv14SnapshotWritable``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSnapshotv14SnapshotWritable`: V14SnapshotWritable
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.ListSnapshotv14SnapshotWritable`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSnapshotv14SnapshotWritableRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting.  Choices are path, src name, src path, created, size and state. Default is created. | 
 **state** | **string** | Only list writable snapshots matching this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V14SnapshotWritable**](V14SnapshotWritable.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSnapshotv1SnapshotAliases

> V1SnapshotAliases ListSnapshotv1SnapshotAliases(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting.  Choices are id, name, snapshot, and created.  Default is id. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.ListSnapshotv1SnapshotAliases(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.ListSnapshotv1SnapshotAliases``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSnapshotv1SnapshotAliases`: V1SnapshotAliases
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.ListSnapshotv1SnapshotAliases`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSnapshotv1SnapshotAliasesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting.  Choices are id, name, snapshot, and created.  Default is id. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SnapshotAliases**](V1SnapshotAliases.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSnapshotv1SnapshotSchedules

> V1SnapshotSchedules ListSnapshotv1SnapshotSchedules(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting.  Choices are id, name, path, pattern, schedule, duration, alias, next_run, and next_snapshot.  Default is id. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.ListSnapshotv1SnapshotSchedules(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.ListSnapshotv1SnapshotSchedules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSnapshotv1SnapshotSchedules`: V1SnapshotSchedules
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.ListSnapshotv1SnapshotSchedules`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSnapshotv1SnapshotSchedulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting.  Choices are id, name, path, pattern, schedule, duration, alias, next_run, and next_snapshot.  Default is id. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SnapshotSchedules**](V1SnapshotSchedules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSnapshotv1SnapshotSnapshots

> V1SnapshotSnapshots ListSnapshotv1SnapshotSnapshots(ctx).Sort(sort).Schedule(schedule).Resume(resume).State(state).Limit(limit).Type_(type_).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting.  Choices are id, name, path, created, expires, size, has_locks, schedule, alias_target, alias_target_name, pct_filesystem, pct_reserve, and state.  Default is id. (optional)
    schedule := "schedule_example" // string | Only list snapshots created by this schedule. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    state := "state_example" // string | Only list snapshots matching this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    type_ := "type__example" // string | Only list snapshots matching this type. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.ListSnapshotv1SnapshotSnapshots(context.Background()).Sort(sort).Schedule(schedule).Resume(resume).State(state).Limit(limit).Type_(type_).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.ListSnapshotv1SnapshotSnapshots``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSnapshotv1SnapshotSnapshots`: V1SnapshotSnapshots
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.ListSnapshotv1SnapshotSnapshots`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSnapshotv1SnapshotSnapshotsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting.  Choices are id, name, path, created, expires, size, has_locks, schedule, alias_target, alias_target_name, pct_filesystem, pct_reserve, and state.  Default is id. | 
 **schedule** | **string** | Only list snapshots created by this schedule. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **state** | **string** | Only list snapshots matching this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **type_** | **string** | Only list snapshots matching this type. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1SnapshotSnapshots**](V1SnapshotSnapshots.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSnapshotv3SnapshotSchedules

> V1SnapshotSchedules ListSnapshotv3SnapshotSchedules(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting.  Choices are id, name, path, pattern, schedule, duration, alias, next_run, and next_snapshot.  Default is id. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotApi.ListSnapshotv3SnapshotSchedules(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.ListSnapshotv3SnapshotSchedules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSnapshotv3SnapshotSchedules`: V1SnapshotSchedules
    fmt.Fprintf(os.Stdout, "Response from `SnapshotApi.ListSnapshotv3SnapshotSchedules`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListSnapshotv3SnapshotSchedulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting.  Choices are id, name, path, pattern, schedule, duration, alias, next_run, and next_snapshot.  Default is id. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SnapshotSchedules**](V1SnapshotSchedules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSnapshotv1SnapshotAlias

> UpdateSnapshotv1SnapshotAlias(ctx, v1SnapshotAliasId).V1SnapshotAlias(v1SnapshotAlias).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotAliasId := "v1SnapshotAliasId_example" // string | Modify snapshot alias. All input fields are optional, but one or more must be supplied.
    v1SnapshotAlias := *openapiclient.NewV1SnapshotAliasExtendedExtended() // V1SnapshotAliasExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.UpdateSnapshotv1SnapshotAlias(context.Background(), v1SnapshotAliasId).V1SnapshotAlias(v1SnapshotAlias).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.UpdateSnapshotv1SnapshotAlias``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotAliasId** | **string** | Modify snapshot alias. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSnapshotv1SnapshotAliasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SnapshotAlias** | [**V1SnapshotAliasExtendedExtended**](V1SnapshotAliasExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSnapshotv1SnapshotSchedule

> UpdateSnapshotv1SnapshotSchedule(ctx, v1SnapshotScheduleId).V1SnapshotSchedule(v1SnapshotSchedule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotScheduleId := "v1SnapshotScheduleId_example" // string | Modify the schedule. All input fields are optional, but one or more must be supplied.
    v1SnapshotSchedule := *openapiclient.NewV1SnapshotScheduleExtendedExtended() // V1SnapshotScheduleExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.UpdateSnapshotv1SnapshotSchedule(context.Background(), v1SnapshotScheduleId).V1SnapshotSchedule(v1SnapshotSchedule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.UpdateSnapshotv1SnapshotSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotScheduleId** | **string** | Modify the schedule. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSnapshotv1SnapshotScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SnapshotSchedule** | [**V1SnapshotScheduleExtendedExtended**](V1SnapshotScheduleExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSnapshotv1SnapshotSettings

> UpdateSnapshotv1SnapshotSettings(ctx).V1SnapshotSettings(v1SnapshotSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotSettings := *openapiclient.NewV1SnapshotSettingsExtended() // V1SnapshotSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.UpdateSnapshotv1SnapshotSettings(context.Background()).V1SnapshotSettings(v1SnapshotSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.UpdateSnapshotv1SnapshotSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSnapshotv1SnapshotSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SnapshotSettings** | [**V1SnapshotSettingsExtended**](V1SnapshotSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSnapshotv1SnapshotSnapshot

> UpdateSnapshotv1SnapshotSnapshot(ctx, v1SnapshotSnapshotId).V1SnapshotSnapshot(v1SnapshotSnapshot).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotSnapshotId := "v1SnapshotSnapshotId_example" // string | Modify snapshot. All input fields are optional, but one or more must be supplied.
    v1SnapshotSnapshot := *openapiclient.NewV1SnapshotSnapshotExtendedExtended() // V1SnapshotSnapshotExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.UpdateSnapshotv1SnapshotSnapshot(context.Background(), v1SnapshotSnapshotId).V1SnapshotSnapshot(v1SnapshotSnapshot).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.UpdateSnapshotv1SnapshotSnapshot``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotSnapshotId** | **string** | Modify snapshot. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSnapshotv1SnapshotSnapshotRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SnapshotSnapshot** | [**V1SnapshotSnapshotExtendedExtended**](V1SnapshotSnapshotExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSnapshotv1SnapshotsSidLock

> UpdateSnapshotv1SnapshotsSidLock(ctx, v1SnapshotsSidLockId, sid).V1SnapshotsSidLock(v1SnapshotsSidLock).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SnapshotsSidLockId := "v1SnapshotsSidLockId_example" // string | Modify lock. All input fields are optional, but one or more must be supplied.
    sid := "sid_example" // string | 
    v1SnapshotsSidLock := *openapiclient.NewV1SnapshotsSidLock() // V1SnapshotsSidLock | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotApi.UpdateSnapshotv1SnapshotsSidLock(context.Background(), v1SnapshotsSidLockId, sid).V1SnapshotsSidLock(v1SnapshotsSidLock).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotApi.UpdateSnapshotv1SnapshotsSidLock``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SnapshotsSidLockId** | **string** | Modify lock. All input fields are optional, but one or more must be supplied. | 
**sid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSnapshotv1SnapshotsSidLockRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v1SnapshotsSidLock** | [**V1SnapshotsSidLock**](V1SnapshotsSidLock.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

