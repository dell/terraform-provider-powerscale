# V14NetworkInterface

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Flags** | **[]string** | List of interface flags | 
**Id** | **string** | Id is a concatenation of lnn and name in the format &#39;lnn:name&#39; e.g. 3:ext-2. | 
**IpAddrs** | **[]string** | List of IP addresses | 
**Ipv4Gateway** | **string** | Address of the default IPv4 gateway | 
**Ipv6Gateway** | **string** | Address of the default IPv6 gateway | 
**Lnn** | **int32** | Logical Node Number (LNN) of a node. | 
**Mtu** | **int32** | The mtu the interface. | 
**Name** | **string** | The name of the interface. | 
**NicName** | **string** | NIC name | 
**Owners** | [**[]V12NetworkInterfaceOwner**](V12NetworkInterfaceOwner.md) | List of owners (membership) | 
**Speed** | **int32** | The negotiated speed of the interface, in Mbps. | 
**Status** | **string** | Status of the interface | 
**Type** | **string** | The type of network interface | 
**Vlans** | [**[]V12NetworkInterfaceVlan**](V12NetworkInterfaceVlan.md) | List of VLANs | 

## Methods

### NewV14NetworkInterface

`func NewV14NetworkInterface(flags []string, id string, ipAddrs []string, ipv4Gateway string, ipv6Gateway string, lnn int32, mtu int32, name string, nicName string, owners []V12NetworkInterfaceOwner, speed int32, status string, type_ string, vlans []V12NetworkInterfaceVlan, ) *V14NetworkInterface`

NewV14NetworkInterface instantiates a new V14NetworkInterface object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14NetworkInterfaceWithDefaults

`func NewV14NetworkInterfaceWithDefaults() *V14NetworkInterface`

NewV14NetworkInterfaceWithDefaults instantiates a new V14NetworkInterface object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFlags

`func (o *V14NetworkInterface) GetFlags() []string`

GetFlags returns the Flags field if non-nil, zero value otherwise.

### GetFlagsOk

`func (o *V14NetworkInterface) GetFlagsOk() (*[]string, bool)`

GetFlagsOk returns a tuple with the Flags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlags

`func (o *V14NetworkInterface) SetFlags(v []string)`

SetFlags sets Flags field to given value.


### GetId

`func (o *V14NetworkInterface) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V14NetworkInterface) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V14NetworkInterface) SetId(v string)`

SetId sets Id field to given value.


### GetIpAddrs

`func (o *V14NetworkInterface) GetIpAddrs() []string`

GetIpAddrs returns the IpAddrs field if non-nil, zero value otherwise.

### GetIpAddrsOk

`func (o *V14NetworkInterface) GetIpAddrsOk() (*[]string, bool)`

GetIpAddrsOk returns a tuple with the IpAddrs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddrs

`func (o *V14NetworkInterface) SetIpAddrs(v []string)`

SetIpAddrs sets IpAddrs field to given value.


### GetIpv4Gateway

`func (o *V14NetworkInterface) GetIpv4Gateway() string`

GetIpv4Gateway returns the Ipv4Gateway field if non-nil, zero value otherwise.

### GetIpv4GatewayOk

`func (o *V14NetworkInterface) GetIpv4GatewayOk() (*string, bool)`

GetIpv4GatewayOk returns a tuple with the Ipv4Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpv4Gateway

`func (o *V14NetworkInterface) SetIpv4Gateway(v string)`

SetIpv4Gateway sets Ipv4Gateway field to given value.


### GetIpv6Gateway

`func (o *V14NetworkInterface) GetIpv6Gateway() string`

GetIpv6Gateway returns the Ipv6Gateway field if non-nil, zero value otherwise.

### GetIpv6GatewayOk

`func (o *V14NetworkInterface) GetIpv6GatewayOk() (*string, bool)`

GetIpv6GatewayOk returns a tuple with the Ipv6Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpv6Gateway

`func (o *V14NetworkInterface) SetIpv6Gateway(v string)`

SetIpv6Gateway sets Ipv6Gateway field to given value.


### GetLnn

`func (o *V14NetworkInterface) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V14NetworkInterface) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V14NetworkInterface) SetLnn(v int32)`

SetLnn sets Lnn field to given value.


### GetMtu

`func (o *V14NetworkInterface) GetMtu() int32`

GetMtu returns the Mtu field if non-nil, zero value otherwise.

### GetMtuOk

`func (o *V14NetworkInterface) GetMtuOk() (*int32, bool)`

GetMtuOk returns a tuple with the Mtu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtu

`func (o *V14NetworkInterface) SetMtu(v int32)`

SetMtu sets Mtu field to given value.


### GetName

`func (o *V14NetworkInterface) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V14NetworkInterface) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V14NetworkInterface) SetName(v string)`

SetName sets Name field to given value.


### GetNicName

`func (o *V14NetworkInterface) GetNicName() string`

GetNicName returns the NicName field if non-nil, zero value otherwise.

### GetNicNameOk

`func (o *V14NetworkInterface) GetNicNameOk() (*string, bool)`

GetNicNameOk returns a tuple with the NicName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNicName

`func (o *V14NetworkInterface) SetNicName(v string)`

SetNicName sets NicName field to given value.


### GetOwners

`func (o *V14NetworkInterface) GetOwners() []V12NetworkInterfaceOwner`

GetOwners returns the Owners field if non-nil, zero value otherwise.

### GetOwnersOk

`func (o *V14NetworkInterface) GetOwnersOk() (*[]V12NetworkInterfaceOwner, bool)`

GetOwnersOk returns a tuple with the Owners field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOwners

`func (o *V14NetworkInterface) SetOwners(v []V12NetworkInterfaceOwner)`

SetOwners sets Owners field to given value.


### GetSpeed

`func (o *V14NetworkInterface) GetSpeed() int32`

GetSpeed returns the Speed field if non-nil, zero value otherwise.

### GetSpeedOk

`func (o *V14NetworkInterface) GetSpeedOk() (*int32, bool)`

GetSpeedOk returns a tuple with the Speed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpeed

`func (o *V14NetworkInterface) SetSpeed(v int32)`

SetSpeed sets Speed field to given value.


### GetStatus

`func (o *V14NetworkInterface) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V14NetworkInterface) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V14NetworkInterface) SetStatus(v string)`

SetStatus sets Status field to given value.


### GetType

`func (o *V14NetworkInterface) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V14NetworkInterface) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V14NetworkInterface) SetType(v string)`

SetType sets Type field to given value.


### GetVlans

`func (o *V14NetworkInterface) GetVlans() []V12NetworkInterfaceVlan`

GetVlans returns the Vlans field if non-nil, zero value otherwise.

### GetVlansOk

`func (o *V14NetworkInterface) GetVlansOk() (*[]V12NetworkInterfaceVlan, bool)`

GetVlansOk returns a tuple with the Vlans field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlans

`func (o *V14NetworkInterface) SetVlans(v []V12NetworkInterfaceVlan)`

SetVlans sets Vlans field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


