# V10ChangelistEntry

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Atime** | Pointer to [**V10ChangelistEntryCtime**](V10ChangelistEntryCtime.md) |  | [optional] 
**Btime** | Pointer to [**V10ChangelistEntryCtime**](V10ChangelistEntryCtime.md) |  | [optional] 
**ChangeTypes** | Pointer to **[]string** | The types of change for this entry. | [optional] 
**Ctime** | Pointer to [**V10ChangelistEntryCtime**](V10ChangelistEntryCtime.md) |  | [optional] 
**DataPool** | **int32** | The data disk pool ID of the file associated with the entry. | 
**DiffRegions** | Pointer to [**[]V10ChangelistsChangelistDiffRegionsDiffRegion**](V10ChangelistsChangelistDiffRegionsDiffRegion.md) | Changed regions of the file | [optional] 
**FileType** | **string** | Type of file. | 
**Gid** | **int32** | The Group ID defined flags of the file associated with the entry. | 
**Id** | **string** | The ID of the changelist entry. | 
**Lin** | **int32** | The LIN number of the file associated with the entry. | 
**MetadataPool** | **int32** | The metadata disk pool ID of the file associated with the entry. | 
**Mtime** | Pointer to [**V10ChangelistEntryCtime**](V10ChangelistEntryCtime.md) |  | [optional] 
**NumDiffRegions** | Pointer to **int32** | Number of changed regions stored in the diff_regions array. A value of 4294967295 indicates that diff_regions contains a truncated list of changed regions, and a full list must be obtained from another handler. | [optional] 
**ParentLin** | **int32** | The Parent LIN number of the file associated with the entry. | 
**Path** | **string** | The relative path to the file associated with the entry. | 
**PhysicalSize** | **int32** | The physical size of the file associated with the entry. | 
**Size** | **int32** | The size of the file associated with the entry. | 
**Uid** | **int32** | The User ID flags of the file associated with the entry. | 
**UserFlags** | Pointer to **[]string** | The user defined flags of the file associated with the entry. | [optional] 

## Methods

### NewV10ChangelistEntry

`func NewV10ChangelistEntry(dataPool int32, fileType string, gid int32, id string, lin int32, metadataPool int32, parentLin int32, path string, physicalSize int32, size int32, uid int32, ) *V10ChangelistEntry`

NewV10ChangelistEntry instantiates a new V10ChangelistEntry object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ChangelistEntryWithDefaults

`func NewV10ChangelistEntryWithDefaults() *V10ChangelistEntry`

NewV10ChangelistEntryWithDefaults instantiates a new V10ChangelistEntry object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAtime

`func (o *V10ChangelistEntry) GetAtime() V10ChangelistEntryCtime`

GetAtime returns the Atime field if non-nil, zero value otherwise.

### GetAtimeOk

`func (o *V10ChangelistEntry) GetAtimeOk() (*V10ChangelistEntryCtime, bool)`

GetAtimeOk returns a tuple with the Atime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAtime

`func (o *V10ChangelistEntry) SetAtime(v V10ChangelistEntryCtime)`

SetAtime sets Atime field to given value.

### HasAtime

`func (o *V10ChangelistEntry) HasAtime() bool`

HasAtime returns a boolean if a field has been set.

### GetBtime

`func (o *V10ChangelistEntry) GetBtime() V10ChangelistEntryCtime`

GetBtime returns the Btime field if non-nil, zero value otherwise.

### GetBtimeOk

`func (o *V10ChangelistEntry) GetBtimeOk() (*V10ChangelistEntryCtime, bool)`

GetBtimeOk returns a tuple with the Btime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBtime

`func (o *V10ChangelistEntry) SetBtime(v V10ChangelistEntryCtime)`

SetBtime sets Btime field to given value.

### HasBtime

`func (o *V10ChangelistEntry) HasBtime() bool`

HasBtime returns a boolean if a field has been set.

### GetChangeTypes

`func (o *V10ChangelistEntry) GetChangeTypes() []string`

GetChangeTypes returns the ChangeTypes field if non-nil, zero value otherwise.

### GetChangeTypesOk

`func (o *V10ChangelistEntry) GetChangeTypesOk() (*[]string, bool)`

GetChangeTypesOk returns a tuple with the ChangeTypes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChangeTypes

`func (o *V10ChangelistEntry) SetChangeTypes(v []string)`

SetChangeTypes sets ChangeTypes field to given value.

### HasChangeTypes

`func (o *V10ChangelistEntry) HasChangeTypes() bool`

HasChangeTypes returns a boolean if a field has been set.

### GetCtime

`func (o *V10ChangelistEntry) GetCtime() V10ChangelistEntryCtime`

GetCtime returns the Ctime field if non-nil, zero value otherwise.

### GetCtimeOk

`func (o *V10ChangelistEntry) GetCtimeOk() (*V10ChangelistEntryCtime, bool)`

GetCtimeOk returns a tuple with the Ctime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCtime

`func (o *V10ChangelistEntry) SetCtime(v V10ChangelistEntryCtime)`

SetCtime sets Ctime field to given value.

### HasCtime

`func (o *V10ChangelistEntry) HasCtime() bool`

HasCtime returns a boolean if a field has been set.

### GetDataPool

`func (o *V10ChangelistEntry) GetDataPool() int32`

GetDataPool returns the DataPool field if non-nil, zero value otherwise.

### GetDataPoolOk

`func (o *V10ChangelistEntry) GetDataPoolOk() (*int32, bool)`

GetDataPoolOk returns a tuple with the DataPool field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDataPool

`func (o *V10ChangelistEntry) SetDataPool(v int32)`

SetDataPool sets DataPool field to given value.


### GetDiffRegions

`func (o *V10ChangelistEntry) GetDiffRegions() []V10ChangelistsChangelistDiffRegionsDiffRegion`

GetDiffRegions returns the DiffRegions field if non-nil, zero value otherwise.

### GetDiffRegionsOk

`func (o *V10ChangelistEntry) GetDiffRegionsOk() (*[]V10ChangelistsChangelistDiffRegionsDiffRegion, bool)`

GetDiffRegionsOk returns a tuple with the DiffRegions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiffRegions

`func (o *V10ChangelistEntry) SetDiffRegions(v []V10ChangelistsChangelistDiffRegionsDiffRegion)`

SetDiffRegions sets DiffRegions field to given value.

### HasDiffRegions

`func (o *V10ChangelistEntry) HasDiffRegions() bool`

HasDiffRegions returns a boolean if a field has been set.

### GetFileType

`func (o *V10ChangelistEntry) GetFileType() string`

GetFileType returns the FileType field if non-nil, zero value otherwise.

### GetFileTypeOk

`func (o *V10ChangelistEntry) GetFileTypeOk() (*string, bool)`

GetFileTypeOk returns a tuple with the FileType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileType

`func (o *V10ChangelistEntry) SetFileType(v string)`

SetFileType sets FileType field to given value.


### GetGid

`func (o *V10ChangelistEntry) GetGid() int32`

GetGid returns the Gid field if non-nil, zero value otherwise.

### GetGidOk

`func (o *V10ChangelistEntry) GetGidOk() (*int32, bool)`

GetGidOk returns a tuple with the Gid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGid

`func (o *V10ChangelistEntry) SetGid(v int32)`

SetGid sets Gid field to given value.


### GetId

`func (o *V10ChangelistEntry) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10ChangelistEntry) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10ChangelistEntry) SetId(v string)`

SetId sets Id field to given value.


### GetLin

`func (o *V10ChangelistEntry) GetLin() int32`

GetLin returns the Lin field if non-nil, zero value otherwise.

### GetLinOk

`func (o *V10ChangelistEntry) GetLinOk() (*int32, bool)`

GetLinOk returns a tuple with the Lin field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLin

`func (o *V10ChangelistEntry) SetLin(v int32)`

SetLin sets Lin field to given value.


### GetMetadataPool

`func (o *V10ChangelistEntry) GetMetadataPool() int32`

GetMetadataPool returns the MetadataPool field if non-nil, zero value otherwise.

### GetMetadataPoolOk

`func (o *V10ChangelistEntry) GetMetadataPoolOk() (*int32, bool)`

GetMetadataPoolOk returns a tuple with the MetadataPool field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetadataPool

`func (o *V10ChangelistEntry) SetMetadataPool(v int32)`

SetMetadataPool sets MetadataPool field to given value.


### GetMtime

`func (o *V10ChangelistEntry) GetMtime() V10ChangelistEntryCtime`

GetMtime returns the Mtime field if non-nil, zero value otherwise.

### GetMtimeOk

`func (o *V10ChangelistEntry) GetMtimeOk() (*V10ChangelistEntryCtime, bool)`

GetMtimeOk returns a tuple with the Mtime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtime

`func (o *V10ChangelistEntry) SetMtime(v V10ChangelistEntryCtime)`

SetMtime sets Mtime field to given value.

### HasMtime

`func (o *V10ChangelistEntry) HasMtime() bool`

HasMtime returns a boolean if a field has been set.

### GetNumDiffRegions

`func (o *V10ChangelistEntry) GetNumDiffRegions() int32`

GetNumDiffRegions returns the NumDiffRegions field if non-nil, zero value otherwise.

### GetNumDiffRegionsOk

`func (o *V10ChangelistEntry) GetNumDiffRegionsOk() (*int32, bool)`

GetNumDiffRegionsOk returns a tuple with the NumDiffRegions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumDiffRegions

`func (o *V10ChangelistEntry) SetNumDiffRegions(v int32)`

SetNumDiffRegions sets NumDiffRegions field to given value.

### HasNumDiffRegions

`func (o *V10ChangelistEntry) HasNumDiffRegions() bool`

HasNumDiffRegions returns a boolean if a field has been set.

### GetParentLin

`func (o *V10ChangelistEntry) GetParentLin() int32`

GetParentLin returns the ParentLin field if non-nil, zero value otherwise.

### GetParentLinOk

`func (o *V10ChangelistEntry) GetParentLinOk() (*int32, bool)`

GetParentLinOk returns a tuple with the ParentLin field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParentLin

`func (o *V10ChangelistEntry) SetParentLin(v int32)`

SetParentLin sets ParentLin field to given value.


### GetPath

`func (o *V10ChangelistEntry) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V10ChangelistEntry) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V10ChangelistEntry) SetPath(v string)`

SetPath sets Path field to given value.


### GetPhysicalSize

`func (o *V10ChangelistEntry) GetPhysicalSize() int32`

GetPhysicalSize returns the PhysicalSize field if non-nil, zero value otherwise.

### GetPhysicalSizeOk

`func (o *V10ChangelistEntry) GetPhysicalSizeOk() (*int32, bool)`

GetPhysicalSizeOk returns a tuple with the PhysicalSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysicalSize

`func (o *V10ChangelistEntry) SetPhysicalSize(v int32)`

SetPhysicalSize sets PhysicalSize field to given value.


### GetSize

`func (o *V10ChangelistEntry) GetSize() int32`

GetSize returns the Size field if non-nil, zero value otherwise.

### GetSizeOk

`func (o *V10ChangelistEntry) GetSizeOk() (*int32, bool)`

GetSizeOk returns a tuple with the Size field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSize

`func (o *V10ChangelistEntry) SetSize(v int32)`

SetSize sets Size field to given value.


### GetUid

`func (o *V10ChangelistEntry) GetUid() int32`

GetUid returns the Uid field if non-nil, zero value otherwise.

### GetUidOk

`func (o *V10ChangelistEntry) GetUidOk() (*int32, bool)`

GetUidOk returns a tuple with the Uid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUid

`func (o *V10ChangelistEntry) SetUid(v int32)`

SetUid sets Uid field to given value.


### GetUserFlags

`func (o *V10ChangelistEntry) GetUserFlags() []string`

GetUserFlags returns the UserFlags field if non-nil, zero value otherwise.

### GetUserFlagsOk

`func (o *V10ChangelistEntry) GetUserFlagsOk() (*[]string, bool)`

GetUserFlagsOk returns a tuple with the UserFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUserFlags

`func (o *V10ChangelistEntry) SetUserFlags(v []string)`

SetUserFlags sets UserFlags field to given value.

### HasUserFlags

`func (o *V10ChangelistEntry) HasUserFlags() bool`

HasUserFlags returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


