# V10NodetypeAssessNodetype

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FromNodepool** | [**[]V10NodetypeAssessNodetypeFromNodepoolItem**](V10NodetypeAssessNodetypeFromNodepoolItem.md) | Pools assessed for removing nodetype. | 
**ToNodepool** | [**[]V10NodetypeAssessNodetypeFromNodepoolItem**](V10NodetypeAssessNodetypeFromNodepoolItem.md) | Pools assessed for adding nodetype. | 

## Methods

### NewV10NodetypeAssessNodetype

`func NewV10NodetypeAssessNodetype(fromNodepool []V10NodetypeAssessNodetypeFromNodepoolItem, toNodepool []V10NodetypeAssessNodetypeFromNodepoolItem, ) *V10NodetypeAssessNodetype`

NewV10NodetypeAssessNodetype instantiates a new V10NodetypeAssessNodetype object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NodetypeAssessNodetypeWithDefaults

`func NewV10NodetypeAssessNodetypeWithDefaults() *V10NodetypeAssessNodetype`

NewV10NodetypeAssessNodetypeWithDefaults instantiates a new V10NodetypeAssessNodetype object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFromNodepool

`func (o *V10NodetypeAssessNodetype) GetFromNodepool() []V10NodetypeAssessNodetypeFromNodepoolItem`

GetFromNodepool returns the FromNodepool field if non-nil, zero value otherwise.

### GetFromNodepoolOk

`func (o *V10NodetypeAssessNodetype) GetFromNodepoolOk() (*[]V10NodetypeAssessNodetypeFromNodepoolItem, bool)`

GetFromNodepoolOk returns a tuple with the FromNodepool field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFromNodepool

`func (o *V10NodetypeAssessNodetype) SetFromNodepool(v []V10NodetypeAssessNodetypeFromNodepoolItem)`

SetFromNodepool sets FromNodepool field to given value.


### GetToNodepool

`func (o *V10NodetypeAssessNodetype) GetToNodepool() []V10NodetypeAssessNodetypeFromNodepoolItem`

GetToNodepool returns the ToNodepool field if non-nil, zero value otherwise.

### GetToNodepoolOk

`func (o *V10NodetypeAssessNodetype) GetToNodepoolOk() (*[]V10NodetypeAssessNodetypeFromNodepoolItem, bool)`

GetToNodepoolOk returns a tuple with the ToNodepool field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetToNodepool

`func (o *V10NodetypeAssessNodetype) SetToNodepool(v []V10NodetypeAssessNodetypeFromNodepoolItem)`

SetToNodepool sets ToNodepool field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


