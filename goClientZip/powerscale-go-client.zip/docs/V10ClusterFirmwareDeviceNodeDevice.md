# V10ClusterFirmwareDeviceNodeDevice

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Device** | Pointer to **string** | The name of the device. | [optional] 
**Mismatch** | Pointer to **bool** | Is the firmware up-to-date for this component. | [optional] 
**TargetVersion** | Pointer to **string** | The target firmware version. | [optional] 
**Type** | Pointer to **string** | The device type. | [optional] 
**UpgradeStatus** | Pointer to **string** | The current state of the firmware upgrade for this component. One of the following values: &#39;queued&#39;, &#39;upgrading&#39;, &#39;upgraded&#39;, &#39;error&#39; or &#39;null&#39;.&#39;null&#39; indicates that the upgrade status is unknown. | [optional] 
**Version** | Pointer to **string** | The current firmware version. | [optional] 

## Methods

### NewV10ClusterFirmwareDeviceNodeDevice

`func NewV10ClusterFirmwareDeviceNodeDevice() *V10ClusterFirmwareDeviceNodeDevice`

NewV10ClusterFirmwareDeviceNodeDevice instantiates a new V10ClusterFirmwareDeviceNodeDevice object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterFirmwareDeviceNodeDeviceWithDefaults

`func NewV10ClusterFirmwareDeviceNodeDeviceWithDefaults() *V10ClusterFirmwareDeviceNodeDevice`

NewV10ClusterFirmwareDeviceNodeDeviceWithDefaults instantiates a new V10ClusterFirmwareDeviceNodeDevice object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDevice

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetDevice() string`

GetDevice returns the Device field if non-nil, zero value otherwise.

### GetDeviceOk

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetDeviceOk() (*string, bool)`

GetDeviceOk returns a tuple with the Device field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDevice

`func (o *V10ClusterFirmwareDeviceNodeDevice) SetDevice(v string)`

SetDevice sets Device field to given value.

### HasDevice

`func (o *V10ClusterFirmwareDeviceNodeDevice) HasDevice() bool`

HasDevice returns a boolean if a field has been set.

### GetMismatch

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetMismatch() bool`

GetMismatch returns the Mismatch field if non-nil, zero value otherwise.

### GetMismatchOk

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetMismatchOk() (*bool, bool)`

GetMismatchOk returns a tuple with the Mismatch field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMismatch

`func (o *V10ClusterFirmwareDeviceNodeDevice) SetMismatch(v bool)`

SetMismatch sets Mismatch field to given value.

### HasMismatch

`func (o *V10ClusterFirmwareDeviceNodeDevice) HasMismatch() bool`

HasMismatch returns a boolean if a field has been set.

### GetTargetVersion

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetTargetVersion() string`

GetTargetVersion returns the TargetVersion field if non-nil, zero value otherwise.

### GetTargetVersionOk

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetTargetVersionOk() (*string, bool)`

GetTargetVersionOk returns a tuple with the TargetVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetVersion

`func (o *V10ClusterFirmwareDeviceNodeDevice) SetTargetVersion(v string)`

SetTargetVersion sets TargetVersion field to given value.

### HasTargetVersion

`func (o *V10ClusterFirmwareDeviceNodeDevice) HasTargetVersion() bool`

HasTargetVersion returns a boolean if a field has been set.

### GetType

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V10ClusterFirmwareDeviceNodeDevice) SetType(v string)`

SetType sets Type field to given value.

### HasType

`func (o *V10ClusterFirmwareDeviceNodeDevice) HasType() bool`

HasType returns a boolean if a field has been set.

### GetUpgradeStatus

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetUpgradeStatus() string`

GetUpgradeStatus returns the UpgradeStatus field if non-nil, zero value otherwise.

### GetUpgradeStatusOk

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetUpgradeStatusOk() (*string, bool)`

GetUpgradeStatusOk returns a tuple with the UpgradeStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpgradeStatus

`func (o *V10ClusterFirmwareDeviceNodeDevice) SetUpgradeStatus(v string)`

SetUpgradeStatus sets UpgradeStatus field to given value.

### HasUpgradeStatus

`func (o *V10ClusterFirmwareDeviceNodeDevice) HasUpgradeStatus() bool`

HasUpgradeStatus returns a boolean if a field has been set.

### GetVersion

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetVersion() string`

GetVersion returns the Version field if non-nil, zero value otherwise.

### GetVersionOk

`func (o *V10ClusterFirmwareDeviceNodeDevice) GetVersionOk() (*string, bool)`

GetVersionOk returns a tuple with the Version field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVersion

`func (o *V10ClusterFirmwareDeviceNodeDevice) SetVersion(v string)`

SetVersion sets Version field to given value.

### HasVersion

`func (o *V10ClusterFirmwareDeviceNodeDevice) HasVersion() bool`

HasVersion returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


