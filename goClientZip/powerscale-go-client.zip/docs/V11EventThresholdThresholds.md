# V11EventThresholdThresholds

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Crit** | Pointer to [**V11EventThresholdThresholdsCrit**](V11EventThresholdThresholdsCrit.md) |  | [optional] 
**Emerg** | Pointer to [**V11EventThresholdThresholdsCrit**](V11EventThresholdThresholdsCrit.md) |  | [optional] 
**Info** | Pointer to [**V11EventThresholdThresholdsCrit**](V11EventThresholdThresholdsCrit.md) |  | [optional] 
**Warn** | Pointer to [**V11EventThresholdThresholdsCrit**](V11EventThresholdThresholdsCrit.md) |  | [optional] 

## Methods

### NewV11EventThresholdThresholds

`func NewV11EventThresholdThresholds() *V11EventThresholdThresholds`

NewV11EventThresholdThresholds instantiates a new V11EventThresholdThresholds object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11EventThresholdThresholdsWithDefaults

`func NewV11EventThresholdThresholdsWithDefaults() *V11EventThresholdThresholds`

NewV11EventThresholdThresholdsWithDefaults instantiates a new V11EventThresholdThresholds object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCrit

`func (o *V11EventThresholdThresholds) GetCrit() V11EventThresholdThresholdsCrit`

GetCrit returns the Crit field if non-nil, zero value otherwise.

### GetCritOk

`func (o *V11EventThresholdThresholds) GetCritOk() (*V11EventThresholdThresholdsCrit, bool)`

GetCritOk returns a tuple with the Crit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCrit

`func (o *V11EventThresholdThresholds) SetCrit(v V11EventThresholdThresholdsCrit)`

SetCrit sets Crit field to given value.

### HasCrit

`func (o *V11EventThresholdThresholds) HasCrit() bool`

HasCrit returns a boolean if a field has been set.

### GetEmerg

`func (o *V11EventThresholdThresholds) GetEmerg() V11EventThresholdThresholdsCrit`

GetEmerg returns the Emerg field if non-nil, zero value otherwise.

### GetEmergOk

`func (o *V11EventThresholdThresholds) GetEmergOk() (*V11EventThresholdThresholdsCrit, bool)`

GetEmergOk returns a tuple with the Emerg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEmerg

`func (o *V11EventThresholdThresholds) SetEmerg(v V11EventThresholdThresholdsCrit)`

SetEmerg sets Emerg field to given value.

### HasEmerg

`func (o *V11EventThresholdThresholds) HasEmerg() bool`

HasEmerg returns a boolean if a field has been set.

### GetInfo

`func (o *V11EventThresholdThresholds) GetInfo() V11EventThresholdThresholdsCrit`

GetInfo returns the Info field if non-nil, zero value otherwise.

### GetInfoOk

`func (o *V11EventThresholdThresholds) GetInfoOk() (*V11EventThresholdThresholdsCrit, bool)`

GetInfoOk returns a tuple with the Info field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfo

`func (o *V11EventThresholdThresholds) SetInfo(v V11EventThresholdThresholdsCrit)`

SetInfo sets Info field to given value.

### HasInfo

`func (o *V11EventThresholdThresholds) HasInfo() bool`

HasInfo returns a boolean if a field has been set.

### GetWarn

`func (o *V11EventThresholdThresholds) GetWarn() V11EventThresholdThresholdsCrit`

GetWarn returns the Warn field if non-nil, zero value otherwise.

### GetWarnOk

`func (o *V11EventThresholdThresholds) GetWarnOk() (*V11EventThresholdThresholdsCrit, bool)`

GetWarnOk returns a tuple with the Warn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWarn

`func (o *V11EventThresholdThresholds) SetWarn(v V11EventThresholdThresholdsCrit)`

SetWarn sets Warn field to given value.

### HasWarn

`func (o *V11EventThresholdThresholds) HasWarn() bool`

HasWarn returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


