# V14AuthIdNtokenPrivilegeItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Specifies the ID of the privilege. | 
**Name** | Pointer to **string** | Specifies the name of the privilege. | [optional] 
**Permission** | Pointer to **string** | permission of the privilege, &#39;r&#39; &#x3D; read , &#39;x&#39; &#x3D; read-execute, &#39;w&#39; &#x3D; read-execute-write, &#39;-&#39; &#x3D; no permission | [optional] 

## Methods

### NewV14AuthIdNtokenPrivilegeItem

`func NewV14AuthIdNtokenPrivilegeItem(id string, ) *V14AuthIdNtokenPrivilegeItem`

NewV14AuthIdNtokenPrivilegeItem instantiates a new V14AuthIdNtokenPrivilegeItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14AuthIdNtokenPrivilegeItemWithDefaults

`func NewV14AuthIdNtokenPrivilegeItemWithDefaults() *V14AuthIdNtokenPrivilegeItem`

NewV14AuthIdNtokenPrivilegeItemWithDefaults instantiates a new V14AuthIdNtokenPrivilegeItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *V14AuthIdNtokenPrivilegeItem) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V14AuthIdNtokenPrivilegeItem) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V14AuthIdNtokenPrivilegeItem) SetId(v string)`

SetId sets Id field to given value.


### GetName

`func (o *V14AuthIdNtokenPrivilegeItem) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V14AuthIdNtokenPrivilegeItem) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V14AuthIdNtokenPrivilegeItem) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V14AuthIdNtokenPrivilegeItem) HasName() bool`

HasName returns a boolean if a field has been set.

### GetPermission

`func (o *V14AuthIdNtokenPrivilegeItem) GetPermission() string`

GetPermission returns the Permission field if non-nil, zero value otherwise.

### GetPermissionOk

`func (o *V14AuthIdNtokenPrivilegeItem) GetPermissionOk() (*string, bool)`

GetPermissionOk returns a tuple with the Permission field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPermission

`func (o *V14AuthIdNtokenPrivilegeItem) SetPermission(v string)`

SetPermission sets Permission field to given value.

### HasPermission

`func (o *V14AuthIdNtokenPrivilegeItem) HasPermission() bool`

HasPermission returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


