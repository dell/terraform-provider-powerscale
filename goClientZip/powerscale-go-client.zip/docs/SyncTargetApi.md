# \SyncTargetApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateSyncTargetv1PoliciesPolicyCancelItem**](SyncTargetApi.md#CreateSyncTargetv1PoliciesPolicyCancelItem) | **Post** /platform/1/sync/target/policies/{Policy}/cancel | 
[**GetSyncTargetv1ReportsReportSubreports**](SyncTargetApi.md#GetSyncTargetv1ReportsReportSubreports) | **Get** /platform/1/sync/target/reports/{Rid}/subreports | 
[**GetSyncTargetv4ReportsReportSubreports**](SyncTargetApi.md#GetSyncTargetv4ReportsReportSubreports) | **Get** /platform/4/sync/target/reports/{Rid}/subreports | 
[**GetSyncTargetv7ReportsReportSubreports**](SyncTargetApi.md#GetSyncTargetv7ReportsReportSubreports) | **Get** /platform/7/sync/target/reports/{Rid}/subreports | 



## CreateSyncTargetv1PoliciesPolicyCancelItem

> CreateResponse CreateSyncTargetv1PoliciesPolicyCancelItem(ctx, policy).V1PoliciesPolicyCancelItem(v1PoliciesPolicyCancelItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    policy := "policy_example" // string | 
    v1PoliciesPolicyCancelItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncTargetApi.CreateSyncTargetv1PoliciesPolicyCancelItem(context.Background(), policy).V1PoliciesPolicyCancelItem(v1PoliciesPolicyCancelItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncTargetApi.CreateSyncTargetv1PoliciesPolicyCancelItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSyncTargetv1PoliciesPolicyCancelItem`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `SyncTargetApi.CreateSyncTargetv1PoliciesPolicyCancelItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**policy** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateSyncTargetv1PoliciesPolicyCancelItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1PoliciesPolicyCancelItem** | **map[string]interface{}** |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncTargetv1ReportsReportSubreports

> V1ReportsReportSubreports GetSyncTargetv1ReportsReportSubreports(ctx, rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    rid := "rid_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncTargetApi.GetSyncTargetv1ReportsReportSubreports(context.Background(), rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncTargetApi.GetSyncTargetv1ReportsReportSubreports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncTargetv1ReportsReportSubreports`: V1ReportsReportSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncTargetApi.GetSyncTargetv1ReportsReportSubreports`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncTargetv1ReportsReportSubreportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1ReportsReportSubreports**](V1ReportsReportSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncTargetv4ReportsReportSubreports

> V4ReportsReportSubreports GetSyncTargetv4ReportsReportSubreports(ctx, rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    rid := "rid_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncTargetApi.GetSyncTargetv4ReportsReportSubreports(context.Background(), rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncTargetApi.GetSyncTargetv4ReportsReportSubreports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncTargetv4ReportsReportSubreports`: V4ReportsReportSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncTargetApi.GetSyncTargetv4ReportsReportSubreports`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncTargetv4ReportsReportSubreportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V4ReportsReportSubreports**](V4ReportsReportSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSyncTargetv7ReportsReportSubreports

> V7ReportsReportSubreports GetSyncTargetv7ReportsReportSubreports(ctx, rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    rid := "rid_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    newerThan := int32(56) // int32 | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. (optional)
    state := "state_example" // string | Filter the returned reports to include only those whose jobs are in this state. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SyncTargetApi.GetSyncTargetv7ReportsReportSubreports(context.Background(), rid).Sort(sort).Resume(resume).NewerThan(newerThan).State(state).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SyncTargetApi.GetSyncTargetv7ReportsReportSubreports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSyncTargetv7ReportsReportSubreports`: V7ReportsReportSubreports
    fmt.Fprintf(os.Stdout, "Response from `SyncTargetApi.GetSyncTargetv7ReportsReportSubreports`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**rid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetSyncTargetv7ReportsReportSubreportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **newerThan** | **int32** | Filter the returned reports to include only those whose jobs started more recently than the specified number of days ago. | 
 **state** | **string** | Filter the returned reports to include only those whose jobs are in this state. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7ReportsReportSubreports**](V7ReportsReportSubreports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

