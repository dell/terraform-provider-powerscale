# V10ClusterNodeDriveDConfigReboot

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ChassisLoss** | Pointer to **bool** | Indicates whether or not to reboot the node due to a lost chassis. | [optional] [default to true]
**NonePresent** | Pointer to **bool** | Indicates whether or not to reboot the node if no drives are present. | [optional] [default to true]

## Methods

### NewV10ClusterNodeDriveDConfigReboot

`func NewV10ClusterNodeDriveDConfigReboot() *V10ClusterNodeDriveDConfigReboot`

NewV10ClusterNodeDriveDConfigReboot instantiates a new V10ClusterNodeDriveDConfigReboot object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeDriveDConfigRebootWithDefaults

`func NewV10ClusterNodeDriveDConfigRebootWithDefaults() *V10ClusterNodeDriveDConfigReboot`

NewV10ClusterNodeDriveDConfigRebootWithDefaults instantiates a new V10ClusterNodeDriveDConfigReboot object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChassisLoss

`func (o *V10ClusterNodeDriveDConfigReboot) GetChassisLoss() bool`

GetChassisLoss returns the ChassisLoss field if non-nil, zero value otherwise.

### GetChassisLossOk

`func (o *V10ClusterNodeDriveDConfigReboot) GetChassisLossOk() (*bool, bool)`

GetChassisLossOk returns a tuple with the ChassisLoss field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChassisLoss

`func (o *V10ClusterNodeDriveDConfigReboot) SetChassisLoss(v bool)`

SetChassisLoss sets ChassisLoss field to given value.

### HasChassisLoss

`func (o *V10ClusterNodeDriveDConfigReboot) HasChassisLoss() bool`

HasChassisLoss returns a boolean if a field has been set.

### GetNonePresent

`func (o *V10ClusterNodeDriveDConfigReboot) GetNonePresent() bool`

GetNonePresent returns the NonePresent field if non-nil, zero value otherwise.

### GetNonePresentOk

`func (o *V10ClusterNodeDriveDConfigReboot) GetNonePresentOk() (*bool, bool)`

GetNonePresentOk returns a tuple with the NonePresent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNonePresent

`func (o *V10ClusterNodeDriveDConfigReboot) SetNonePresent(v bool)`

SetNonePresent sets NonePresent field to given value.

### HasNonePresent

`func (o *V10ClusterNodeDriveDConfigReboot) HasNonePresent() bool`

HasNonePresent returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


