# V10ClusterFirmwareAssessItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ExcludeDevice** | Pointer to **string** | Exclude the specified devices in the firmware upgrade. | [optional] 
**ExcludeType** | Pointer to **string** | Exclude the specified device type in the firmware upgrade. | [optional] 
**FwPkg** | Pointer to **string** | The location (path) of the firmware package which must be within /ifs. | [optional] 
**FwPkgId** | Pointer to **string** | The ID of the signed artifact stored in the catalog. | [optional] 
**IncludeDevice** | Pointer to **string** | Include the specified devices in the firmware upgrade. | [optional] 
**IncludeType** | Pointer to **string** | Include the specified device type in the firmware upgrade. | [optional] 

## Methods

### NewV10ClusterFirmwareAssessItem

`func NewV10ClusterFirmwareAssessItem() *V10ClusterFirmwareAssessItem`

NewV10ClusterFirmwareAssessItem instantiates a new V10ClusterFirmwareAssessItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterFirmwareAssessItemWithDefaults

`func NewV10ClusterFirmwareAssessItemWithDefaults() *V10ClusterFirmwareAssessItem`

NewV10ClusterFirmwareAssessItemWithDefaults instantiates a new V10ClusterFirmwareAssessItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExcludeDevice

`func (o *V10ClusterFirmwareAssessItem) GetExcludeDevice() string`

GetExcludeDevice returns the ExcludeDevice field if non-nil, zero value otherwise.

### GetExcludeDeviceOk

`func (o *V10ClusterFirmwareAssessItem) GetExcludeDeviceOk() (*string, bool)`

GetExcludeDeviceOk returns a tuple with the ExcludeDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeDevice

`func (o *V10ClusterFirmwareAssessItem) SetExcludeDevice(v string)`

SetExcludeDevice sets ExcludeDevice field to given value.

### HasExcludeDevice

`func (o *V10ClusterFirmwareAssessItem) HasExcludeDevice() bool`

HasExcludeDevice returns a boolean if a field has been set.

### GetExcludeType

`func (o *V10ClusterFirmwareAssessItem) GetExcludeType() string`

GetExcludeType returns the ExcludeType field if non-nil, zero value otherwise.

### GetExcludeTypeOk

`func (o *V10ClusterFirmwareAssessItem) GetExcludeTypeOk() (*string, bool)`

GetExcludeTypeOk returns a tuple with the ExcludeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExcludeType

`func (o *V10ClusterFirmwareAssessItem) SetExcludeType(v string)`

SetExcludeType sets ExcludeType field to given value.

### HasExcludeType

`func (o *V10ClusterFirmwareAssessItem) HasExcludeType() bool`

HasExcludeType returns a boolean if a field has been set.

### GetFwPkg

`func (o *V10ClusterFirmwareAssessItem) GetFwPkg() string`

GetFwPkg returns the FwPkg field if non-nil, zero value otherwise.

### GetFwPkgOk

`func (o *V10ClusterFirmwareAssessItem) GetFwPkgOk() (*string, bool)`

GetFwPkgOk returns a tuple with the FwPkg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFwPkg

`func (o *V10ClusterFirmwareAssessItem) SetFwPkg(v string)`

SetFwPkg sets FwPkg field to given value.

### HasFwPkg

`func (o *V10ClusterFirmwareAssessItem) HasFwPkg() bool`

HasFwPkg returns a boolean if a field has been set.

### GetFwPkgId

`func (o *V10ClusterFirmwareAssessItem) GetFwPkgId() string`

GetFwPkgId returns the FwPkgId field if non-nil, zero value otherwise.

### GetFwPkgIdOk

`func (o *V10ClusterFirmwareAssessItem) GetFwPkgIdOk() (*string, bool)`

GetFwPkgIdOk returns a tuple with the FwPkgId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFwPkgId

`func (o *V10ClusterFirmwareAssessItem) SetFwPkgId(v string)`

SetFwPkgId sets FwPkgId field to given value.

### HasFwPkgId

`func (o *V10ClusterFirmwareAssessItem) HasFwPkgId() bool`

HasFwPkgId returns a boolean if a field has been set.

### GetIncludeDevice

`func (o *V10ClusterFirmwareAssessItem) GetIncludeDevice() string`

GetIncludeDevice returns the IncludeDevice field if non-nil, zero value otherwise.

### GetIncludeDeviceOk

`func (o *V10ClusterFirmwareAssessItem) GetIncludeDeviceOk() (*string, bool)`

GetIncludeDeviceOk returns a tuple with the IncludeDevice field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeDevice

`func (o *V10ClusterFirmwareAssessItem) SetIncludeDevice(v string)`

SetIncludeDevice sets IncludeDevice field to given value.

### HasIncludeDevice

`func (o *V10ClusterFirmwareAssessItem) HasIncludeDevice() bool`

HasIncludeDevice returns a boolean if a field has been set.

### GetIncludeType

`func (o *V10ClusterFirmwareAssessItem) GetIncludeType() string`

GetIncludeType returns the IncludeType field if non-nil, zero value otherwise.

### GetIncludeTypeOk

`func (o *V10ClusterFirmwareAssessItem) GetIncludeTypeOk() (*string, bool)`

GetIncludeTypeOk returns a tuple with the IncludeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeType

`func (o *V10ClusterFirmwareAssessItem) SetIncludeType(v string)`

SetIncludeType sets IncludeType field to given value.

### HasIncludeType

`func (o *V10ClusterFirmwareAssessItem) HasIncludeType() bool`

HasIncludeType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


