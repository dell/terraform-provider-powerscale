# V11AvscanFilters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filters** | Pointer to [**[]V11AvscanFilter**](V11AvscanFilter.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV11AvscanFilters

`func NewV11AvscanFilters() *V11AvscanFilters`

NewV11AvscanFilters instantiates a new V11AvscanFilters object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanFiltersWithDefaults

`func NewV11AvscanFiltersWithDefaults() *V11AvscanFilters`

NewV11AvscanFiltersWithDefaults instantiates a new V11AvscanFilters object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFilters

`func (o *V11AvscanFilters) GetFilters() []V11AvscanFilter`

GetFilters returns the Filters field if non-nil, zero value otherwise.

### GetFiltersOk

`func (o *V11AvscanFilters) GetFiltersOk() (*[]V11AvscanFilter, bool)`

GetFiltersOk returns a tuple with the Filters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilters

`func (o *V11AvscanFilters) SetFilters(v []V11AvscanFilter)`

SetFilters sets Filters field to given value.

### HasFilters

`func (o *V11AvscanFilters) HasFilters() bool`

HasFilters returns a boolean if a field has been set.

### GetResume

`func (o *V11AvscanFilters) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V11AvscanFilters) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V11AvscanFilters) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V11AvscanFilters) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V11AvscanFilters) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V11AvscanFilters) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V11AvscanFilters) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V11AvscanFilters) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


