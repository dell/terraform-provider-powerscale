# \AvscanApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateAvscanv11AvscanJob**](AvscanApi.md#CreateAvscanv11AvscanJob) | **Post** /platform/11/avscan/jobs | 
[**CreateAvscanv11AvscanServer**](AvscanApi.md#CreateAvscanv11AvscanServer) | **Post** /platform/11/avscan/servers | 
[**DeleteAvscanv11AvscanJob**](AvscanApi.md#DeleteAvscanv11AvscanJob) | **Delete** /platform/11/avscan/jobs/{v11AvscanJobId} | 
[**DeleteAvscanv11AvscanJobs**](AvscanApi.md#DeleteAvscanv11AvscanJobs) | **Delete** /platform/11/avscan/jobs | 
[**DeleteAvscanv11AvscanServer**](AvscanApi.md#DeleteAvscanv11AvscanServer) | **Delete** /platform/11/avscan/servers/{v11AvscanServerId} | 
[**DeleteAvscanv11AvscanServers**](AvscanApi.md#DeleteAvscanv11AvscanServers) | **Delete** /platform/11/avscan/servers | 
[**GetAvscanv11AvscanFilter**](AvscanApi.md#GetAvscanv11AvscanFilter) | **Get** /platform/11/avscan/filters/{v11AvscanFilterId} | 
[**GetAvscanv11AvscanFilters**](AvscanApi.md#GetAvscanv11AvscanFilters) | **Get** /platform/11/avscan/filters | 
[**GetAvscanv11AvscanJob**](AvscanApi.md#GetAvscanv11AvscanJob) | **Get** /platform/11/avscan/jobs/{v11AvscanJobId} | 
[**GetAvscanv11AvscanServer**](AvscanApi.md#GetAvscanv11AvscanServer) | **Get** /platform/11/avscan/servers/{v11AvscanServerId} | 
[**GetAvscanv11AvscanSettings**](AvscanApi.md#GetAvscanv11AvscanSettings) | **Get** /platform/11/avscan/settings | 
[**ListAvscanv11AvscanJobs**](AvscanApi.md#ListAvscanv11AvscanJobs) | **Get** /platform/11/avscan/jobs | 
[**ListAvscanv11AvscanServers**](AvscanApi.md#ListAvscanv11AvscanServers) | **Get** /platform/11/avscan/servers | 
[**UpdateAvscanv11AvscanFilter**](AvscanApi.md#UpdateAvscanv11AvscanFilter) | **Put** /platform/11/avscan/filters/{v11AvscanFilterId} | 
[**UpdateAvscanv11AvscanJob**](AvscanApi.md#UpdateAvscanv11AvscanJob) | **Put** /platform/11/avscan/jobs/{v11AvscanJobId} | 
[**UpdateAvscanv11AvscanServer**](AvscanApi.md#UpdateAvscanv11AvscanServer) | **Put** /platform/11/avscan/servers/{v11AvscanServerId} | 
[**UpdateAvscanv11AvscanSettings**](AvscanApi.md#UpdateAvscanv11AvscanSettings) | **Put** /platform/11/avscan/settings | 



## CreateAvscanv11AvscanJob

> CreateResponse CreateAvscanv11AvscanJob(ctx).V11AvscanJob(v11AvscanJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanJob := *openapiclient.NewV11AvscanJob("JobName_example") // V11AvscanJob | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AvscanApi.CreateAvscanv11AvscanJob(context.Background()).V11AvscanJob(v11AvscanJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.CreateAvscanv11AvscanJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAvscanv11AvscanJob`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AvscanApi.CreateAvscanv11AvscanJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAvscanv11AvscanJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v11AvscanJob** | [**V11AvscanJob**](V11AvscanJob.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAvscanv11AvscanServer

> CreateResponse CreateAvscanv11AvscanServer(ctx).V11AvscanServer(v11AvscanServer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanServer := *openapiclient.NewV11AvscanServer("ServerName_example", "ServerUri_example") // V11AvscanServer | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AvscanApi.CreateAvscanv11AvscanServer(context.Background()).V11AvscanServer(v11AvscanServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.CreateAvscanv11AvscanServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAvscanv11AvscanServer`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AvscanApi.CreateAvscanv11AvscanServer`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAvscanv11AvscanServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v11AvscanServer** | [**V11AvscanServer**](V11AvscanServer.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAvscanv11AvscanJob

> DeleteAvscanv11AvscanJob(ctx, v11AvscanJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanJobId := "v11AvscanJobId_example" // string | Delete an antivirus job entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AvscanApi.DeleteAvscanv11AvscanJob(context.Background(), v11AvscanJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.DeleteAvscanv11AvscanJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11AvscanJobId** | **string** | Delete an antivirus job entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAvscanv11AvscanJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAvscanv11AvscanJobs

> DeleteAvscanv11AvscanJobs(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AvscanApi.DeleteAvscanv11AvscanJobs(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.DeleteAvscanv11AvscanJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAvscanv11AvscanJobsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAvscanv11AvscanServer

> DeleteAvscanv11AvscanServer(ctx, v11AvscanServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanServerId := "v11AvscanServerId_example" // string | Delete an antivirus server entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AvscanApi.DeleteAvscanv11AvscanServer(context.Background(), v11AvscanServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.DeleteAvscanv11AvscanServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11AvscanServerId** | **string** | Delete an antivirus server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAvscanv11AvscanServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAvscanv11AvscanServers

> DeleteAvscanv11AvscanServers(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AvscanApi.DeleteAvscanv11AvscanServers(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.DeleteAvscanv11AvscanServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAvscanv11AvscanServersRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAvscanv11AvscanFilter

> V11AvscanFiltersExtended GetAvscanv11AvscanFilter(ctx, v11AvscanFilterId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanFilterId := int32(56) // int32 | Retrieve one antivirus filter setting.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AvscanApi.GetAvscanv11AvscanFilter(context.Background(), v11AvscanFilterId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.GetAvscanv11AvscanFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAvscanv11AvscanFilter`: V11AvscanFiltersExtended
    fmt.Fprintf(os.Stdout, "Response from `AvscanApi.GetAvscanv11AvscanFilter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11AvscanFilterId** | **int32** | Retrieve one antivirus filter setting. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAvscanv11AvscanFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V11AvscanFiltersExtended**](V11AvscanFiltersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAvscanv11AvscanFilters

> V11AvscanFilters GetAvscanv11AvscanFilters(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AvscanApi.GetAvscanv11AvscanFilters(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.GetAvscanv11AvscanFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAvscanv11AvscanFilters`: V11AvscanFilters
    fmt.Fprintf(os.Stdout, "Response from `AvscanApi.GetAvscanv11AvscanFilters`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAvscanv11AvscanFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V11AvscanFilters**](V11AvscanFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAvscanv11AvscanJob

> V11AvscanJobsExtended GetAvscanv11AvscanJob(ctx, v11AvscanJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanJobId := "v11AvscanJobId_example" // string | Retrieve one antivirus job entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AvscanApi.GetAvscanv11AvscanJob(context.Background(), v11AvscanJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.GetAvscanv11AvscanJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAvscanv11AvscanJob`: V11AvscanJobsExtended
    fmt.Fprintf(os.Stdout, "Response from `AvscanApi.GetAvscanv11AvscanJob`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11AvscanJobId** | **string** | Retrieve one antivirus job entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAvscanv11AvscanJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V11AvscanJobsExtended**](V11AvscanJobsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAvscanv11AvscanServer

> V11AvscanServersExtended GetAvscanv11AvscanServer(ctx, v11AvscanServerId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanServerId := "v11AvscanServerId_example" // string | Retrieve one antivirus server entry.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AvscanApi.GetAvscanv11AvscanServer(context.Background(), v11AvscanServerId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.GetAvscanv11AvscanServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAvscanv11AvscanServer`: V11AvscanServersExtended
    fmt.Fprintf(os.Stdout, "Response from `AvscanApi.GetAvscanv11AvscanServer`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11AvscanServerId** | **string** | Retrieve one antivirus server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAvscanv11AvscanServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V11AvscanServersExtended**](V11AvscanServersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAvscanv11AvscanSettings

> V11AvscanSettings GetAvscanv11AvscanSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AvscanApi.GetAvscanv11AvscanSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.GetAvscanv11AvscanSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAvscanv11AvscanSettings`: V11AvscanSettings
    fmt.Fprintf(os.Stdout, "Response from `AvscanApi.GetAvscanv11AvscanSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAvscanv11AvscanSettingsRequest struct via the builder pattern


### Return type

[**V11AvscanSettings**](V11AvscanSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAvscanv11AvscanJobs

> V11AvscanJobs ListAvscanv11AvscanJobs(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AvscanApi.ListAvscanv11AvscanJobs(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.ListAvscanv11AvscanJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAvscanv11AvscanJobs`: V11AvscanJobs
    fmt.Fprintf(os.Stdout, "Response from `AvscanApi.ListAvscanv11AvscanJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAvscanv11AvscanJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V11AvscanJobs**](V11AvscanJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAvscanv11AvscanServers

> V11AvscanServers ListAvscanv11AvscanServers(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AvscanApi.ListAvscanv11AvscanServers(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.ListAvscanv11AvscanServers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAvscanv11AvscanServers`: V11AvscanServers
    fmt.Fprintf(os.Stdout, "Response from `AvscanApi.ListAvscanv11AvscanServers`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListAvscanv11AvscanServersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V11AvscanServers**](V11AvscanServers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAvscanv11AvscanFilter

> UpdateAvscanv11AvscanFilter(ctx, v11AvscanFilterId).V11AvscanFilter(v11AvscanFilter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanFilterId := int32(56) // int32 | Modify an antivirus filter setting.
    v11AvscanFilter := *openapiclient.NewV11AvscanFilterExtended() // V11AvscanFilterExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AvscanApi.UpdateAvscanv11AvscanFilter(context.Background(), v11AvscanFilterId).V11AvscanFilter(v11AvscanFilter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.UpdateAvscanv11AvscanFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11AvscanFilterId** | **int32** | Modify an antivirus filter setting. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAvscanv11AvscanFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v11AvscanFilter** | [**V11AvscanFilterExtended**](V11AvscanFilterExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAvscanv11AvscanJob

> UpdateAvscanv11AvscanJob(ctx, v11AvscanJobId).V11AvscanJob(v11AvscanJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanJobId := "v11AvscanJobId_example" // string | Modify an antivirus job entry.
    v11AvscanJob := *openapiclient.NewV11AvscanJobExtendedExtended() // V11AvscanJobExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AvscanApi.UpdateAvscanv11AvscanJob(context.Background(), v11AvscanJobId).V11AvscanJob(v11AvscanJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.UpdateAvscanv11AvscanJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11AvscanJobId** | **string** | Modify an antivirus job entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAvscanv11AvscanJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v11AvscanJob** | [**V11AvscanJobExtendedExtended**](V11AvscanJobExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAvscanv11AvscanServer

> UpdateAvscanv11AvscanServer(ctx, v11AvscanServerId).V11AvscanServer(v11AvscanServer).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanServerId := "v11AvscanServerId_example" // string | Modify an antivirus server entry.
    v11AvscanServer := *openapiclient.NewV11AvscanServerExtendedExtended() // V11AvscanServerExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AvscanApi.UpdateAvscanv11AvscanServer(context.Background(), v11AvscanServerId).V11AvscanServer(v11AvscanServer).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.UpdateAvscanv11AvscanServer``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v11AvscanServerId** | **string** | Modify an antivirus server entry. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAvscanv11AvscanServerRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v11AvscanServer** | [**V11AvscanServerExtendedExtended**](V11AvscanServerExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAvscanv11AvscanSettings

> UpdateAvscanv11AvscanSettings(ctx).V11AvscanSettings(v11AvscanSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11AvscanSettings := *openapiclient.NewV11AvscanSettingsSettings() // V11AvscanSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AvscanApi.UpdateAvscanv11AvscanSettings(context.Background()).V11AvscanSettings(v11AvscanSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AvscanApi.UpdateAvscanv11AvscanSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAvscanv11AvscanSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v11AvscanSettings** | [**V11AvscanSettingsSettings**](V11AvscanSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

