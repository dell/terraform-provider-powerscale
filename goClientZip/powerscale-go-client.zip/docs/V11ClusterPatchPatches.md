# V11ClusterPatchPatches

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Patches** | Pointer to [**[]V11ClusterPatchPatchesPatch**](V11ClusterPatchPatchesPatch.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV11ClusterPatchPatches

`func NewV11ClusterPatchPatches() *V11ClusterPatchPatches`

NewV11ClusterPatchPatches instantiates a new V11ClusterPatchPatches object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ClusterPatchPatchesWithDefaults

`func NewV11ClusterPatchPatchesWithDefaults() *V11ClusterPatchPatches`

NewV11ClusterPatchPatchesWithDefaults instantiates a new V11ClusterPatchPatches object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetPatches

`func (o *V11ClusterPatchPatches) GetPatches() []V11ClusterPatchPatchesPatch`

GetPatches returns the Patches field if non-nil, zero value otherwise.

### GetPatchesOk

`func (o *V11ClusterPatchPatches) GetPatchesOk() (*[]V11ClusterPatchPatchesPatch, bool)`

GetPatchesOk returns a tuple with the Patches field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPatches

`func (o *V11ClusterPatchPatches) SetPatches(v []V11ClusterPatchPatchesPatch)`

SetPatches sets Patches field to given value.

### HasPatches

`func (o *V11ClusterPatchPatches) HasPatches() bool`

HasPatches returns a boolean if a field has been set.

### GetResume

`func (o *V11ClusterPatchPatches) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V11ClusterPatchPatches) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V11ClusterPatchPatches) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V11ClusterPatchPatches) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V11ClusterPatchPatches) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V11ClusterPatchPatches) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V11ClusterPatchPatches) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V11ClusterPatchPatches) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


