# V12NodeStatusNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Batterystatus** | Pointer to [**V10ClusterNodeStatusBatterystatus**](V10ClusterNodeStatusBatterystatus.md) |  | [optional] 
**Capacity** | Pointer to [**[]V10ClusterNodeStatusCapacityItem**](V10ClusterNodeStatusCapacityItem.md) | Storage capacity of this node. | [optional] 
**Cpu** | Pointer to [**V10ClusterNodeStatusCpu**](V10ClusterNodeStatusCpu.md) |  | [optional] 
**Error** | Pointer to **string** | Error message, if the HTTP status returned from this node was not 200. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Nvram** | Pointer to [**V10ClusterNodeStatusNvram**](V10ClusterNodeStatusNvram.md) |  | [optional] 
**Powersupplies** | Pointer to [**V12ClusterNodeStatusPowersupplies**](V12ClusterNodeStatusPowersupplies.md) |  | [optional] 
**Release** | Pointer to **string** | OneFS release. | [optional] 
**Status** | Pointer to **int32** | Status of the HTTP response from this node if not 200.  If 200, this field does not appear. | [optional] 
**Uptime** | Pointer to **int32** | Seconds this node has been online. | [optional] 
**Version** | Pointer to **string** | OneFS version. | [optional] 

## Methods

### NewV12NodeStatusNode

`func NewV12NodeStatusNode() *V12NodeStatusNode`

NewV12NodeStatusNode instantiates a new V12NodeStatusNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NodeStatusNodeWithDefaults

`func NewV12NodeStatusNodeWithDefaults() *V12NodeStatusNode`

NewV12NodeStatusNodeWithDefaults instantiates a new V12NodeStatusNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBatterystatus

`func (o *V12NodeStatusNode) GetBatterystatus() V10ClusterNodeStatusBatterystatus`

GetBatterystatus returns the Batterystatus field if non-nil, zero value otherwise.

### GetBatterystatusOk

`func (o *V12NodeStatusNode) GetBatterystatusOk() (*V10ClusterNodeStatusBatterystatus, bool)`

GetBatterystatusOk returns a tuple with the Batterystatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBatterystatus

`func (o *V12NodeStatusNode) SetBatterystatus(v V10ClusterNodeStatusBatterystatus)`

SetBatterystatus sets Batterystatus field to given value.

### HasBatterystatus

`func (o *V12NodeStatusNode) HasBatterystatus() bool`

HasBatterystatus returns a boolean if a field has been set.

### GetCapacity

`func (o *V12NodeStatusNode) GetCapacity() []V10ClusterNodeStatusCapacityItem`

GetCapacity returns the Capacity field if non-nil, zero value otherwise.

### GetCapacityOk

`func (o *V12NodeStatusNode) GetCapacityOk() (*[]V10ClusterNodeStatusCapacityItem, bool)`

GetCapacityOk returns a tuple with the Capacity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCapacity

`func (o *V12NodeStatusNode) SetCapacity(v []V10ClusterNodeStatusCapacityItem)`

SetCapacity sets Capacity field to given value.

### HasCapacity

`func (o *V12NodeStatusNode) HasCapacity() bool`

HasCapacity returns a boolean if a field has been set.

### GetCpu

`func (o *V12NodeStatusNode) GetCpu() V10ClusterNodeStatusCpu`

GetCpu returns the Cpu field if non-nil, zero value otherwise.

### GetCpuOk

`func (o *V12NodeStatusNode) GetCpuOk() (*V10ClusterNodeStatusCpu, bool)`

GetCpuOk returns a tuple with the Cpu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCpu

`func (o *V12NodeStatusNode) SetCpu(v V10ClusterNodeStatusCpu)`

SetCpu sets Cpu field to given value.

### HasCpu

`func (o *V12NodeStatusNode) HasCpu() bool`

HasCpu returns a boolean if a field has been set.

### GetError

`func (o *V12NodeStatusNode) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V12NodeStatusNode) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V12NodeStatusNode) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V12NodeStatusNode) HasError() bool`

HasError returns a boolean if a field has been set.

### GetId

`func (o *V12NodeStatusNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12NodeStatusNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12NodeStatusNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V12NodeStatusNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V12NodeStatusNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12NodeStatusNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12NodeStatusNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V12NodeStatusNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetNvram

`func (o *V12NodeStatusNode) GetNvram() V10ClusterNodeStatusNvram`

GetNvram returns the Nvram field if non-nil, zero value otherwise.

### GetNvramOk

`func (o *V12NodeStatusNode) GetNvramOk() (*V10ClusterNodeStatusNvram, bool)`

GetNvramOk returns a tuple with the Nvram field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNvram

`func (o *V12NodeStatusNode) SetNvram(v V10ClusterNodeStatusNvram)`

SetNvram sets Nvram field to given value.

### HasNvram

`func (o *V12NodeStatusNode) HasNvram() bool`

HasNvram returns a boolean if a field has been set.

### GetPowersupplies

`func (o *V12NodeStatusNode) GetPowersupplies() V12ClusterNodeStatusPowersupplies`

GetPowersupplies returns the Powersupplies field if non-nil, zero value otherwise.

### GetPowersuppliesOk

`func (o *V12NodeStatusNode) GetPowersuppliesOk() (*V12ClusterNodeStatusPowersupplies, bool)`

GetPowersuppliesOk returns a tuple with the Powersupplies field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPowersupplies

`func (o *V12NodeStatusNode) SetPowersupplies(v V12ClusterNodeStatusPowersupplies)`

SetPowersupplies sets Powersupplies field to given value.

### HasPowersupplies

`func (o *V12NodeStatusNode) HasPowersupplies() bool`

HasPowersupplies returns a boolean if a field has been set.

### GetRelease

`func (o *V12NodeStatusNode) GetRelease() string`

GetRelease returns the Release field if non-nil, zero value otherwise.

### GetReleaseOk

`func (o *V12NodeStatusNode) GetReleaseOk() (*string, bool)`

GetReleaseOk returns a tuple with the Release field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRelease

`func (o *V12NodeStatusNode) SetRelease(v string)`

SetRelease sets Release field to given value.

### HasRelease

`func (o *V12NodeStatusNode) HasRelease() bool`

HasRelease returns a boolean if a field has been set.

### GetStatus

`func (o *V12NodeStatusNode) GetStatus() int32`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12NodeStatusNode) GetStatusOk() (*int32, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12NodeStatusNode) SetStatus(v int32)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V12NodeStatusNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetUptime

`func (o *V12NodeStatusNode) GetUptime() int32`

GetUptime returns the Uptime field if non-nil, zero value otherwise.

### GetUptimeOk

`func (o *V12NodeStatusNode) GetUptimeOk() (*int32, bool)`

GetUptimeOk returns a tuple with the Uptime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUptime

`func (o *V12NodeStatusNode) SetUptime(v int32)`

SetUptime sets Uptime field to given value.

### HasUptime

`func (o *V12NodeStatusNode) HasUptime() bool`

HasUptime returns a boolean if a field has been set.

### GetVersion

`func (o *V12NodeStatusNode) GetVersion() string`

GetVersion returns the Version field if non-nil, zero value otherwise.

### GetVersionOk

`func (o *V12NodeStatusNode) GetVersionOk() (*string, bool)`

GetVersionOk returns a tuple with the Version field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVersion

`func (o *V12NodeStatusNode) SetVersion(v string)`

SetVersion sets Version field to given value.

### HasVersion

`func (o *V12NodeStatusNode) HasVersion() bool`

HasVersion returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


