# V12EventEventgroupDefinitions

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EventgroupDefinitions** | Pointer to [**[]V12EventEventgroupDefinitionsEventgroupDefinition**](V12EventEventgroupDefinitionsEventgroupDefinition.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV12EventEventgroupDefinitions

`func NewV12EventEventgroupDefinitions() *V12EventEventgroupDefinitions`

NewV12EventEventgroupDefinitions instantiates a new V12EventEventgroupDefinitions object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventEventgroupDefinitionsWithDefaults

`func NewV12EventEventgroupDefinitionsWithDefaults() *V12EventEventgroupDefinitions`

NewV12EventEventgroupDefinitionsWithDefaults instantiates a new V12EventEventgroupDefinitions object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEventgroupDefinitions

`func (o *V12EventEventgroupDefinitions) GetEventgroupDefinitions() []V12EventEventgroupDefinitionsEventgroupDefinition`

GetEventgroupDefinitions returns the EventgroupDefinitions field if non-nil, zero value otherwise.

### GetEventgroupDefinitionsOk

`func (o *V12EventEventgroupDefinitions) GetEventgroupDefinitionsOk() (*[]V12EventEventgroupDefinitionsEventgroupDefinition, bool)`

GetEventgroupDefinitionsOk returns a tuple with the EventgroupDefinitions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventgroupDefinitions

`func (o *V12EventEventgroupDefinitions) SetEventgroupDefinitions(v []V12EventEventgroupDefinitionsEventgroupDefinition)`

SetEventgroupDefinitions sets EventgroupDefinitions field to given value.

### HasEventgroupDefinitions

`func (o *V12EventEventgroupDefinitions) HasEventgroupDefinitions() bool`

HasEventgroupDefinitions returns a boolean if a field has been set.

### GetResume

`func (o *V12EventEventgroupDefinitions) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12EventEventgroupDefinitions) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12EventEventgroupDefinitions) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12EventEventgroupDefinitions) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V12EventEventgroupDefinitions) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12EventEventgroupDefinitions) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12EventEventgroupDefinitions) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12EventEventgroupDefinitions) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


