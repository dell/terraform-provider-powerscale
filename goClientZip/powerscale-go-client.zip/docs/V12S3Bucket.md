# V12S3Bucket

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Acl** | Pointer to [**[]V10S3BucketAclItem**](V10S3BucketAclItem.md) | Specifies an ordered list of S3 permissions. | [optional] 
**Description** | **string** | Description for this S3 bucket. | 
**Id** | **string** | Bucket ID. | 
**Name** | **string** | Bucket name. | 
**ObjectAclPolicy** | **string** | Set behavior of modifying object acls | 
**Owner** | **string** | Specifies the name of the owner. | 
**Path** | **string** | Path of bucket within /ifs. | 
**Zid** | **int32** | Zone ID | 

## Methods

### NewV12S3Bucket

`func NewV12S3Bucket(description string, id string, name string, objectAclPolicy string, owner string, path string, zid int32, ) *V12S3Bucket`

NewV12S3Bucket instantiates a new V12S3Bucket object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12S3BucketWithDefaults

`func NewV12S3BucketWithDefaults() *V12S3Bucket`

NewV12S3BucketWithDefaults instantiates a new V12S3Bucket object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAcl

`func (o *V12S3Bucket) GetAcl() []V10S3BucketAclItem`

GetAcl returns the Acl field if non-nil, zero value otherwise.

### GetAclOk

`func (o *V12S3Bucket) GetAclOk() (*[]V10S3BucketAclItem, bool)`

GetAclOk returns a tuple with the Acl field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAcl

`func (o *V12S3Bucket) SetAcl(v []V10S3BucketAclItem)`

SetAcl sets Acl field to given value.

### HasAcl

`func (o *V12S3Bucket) HasAcl() bool`

HasAcl returns a boolean if a field has been set.

### GetDescription

`func (o *V12S3Bucket) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V12S3Bucket) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V12S3Bucket) SetDescription(v string)`

SetDescription sets Description field to given value.


### GetId

`func (o *V12S3Bucket) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12S3Bucket) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12S3Bucket) SetId(v string)`

SetId sets Id field to given value.


### GetName

`func (o *V12S3Bucket) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12S3Bucket) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12S3Bucket) SetName(v string)`

SetName sets Name field to given value.


### GetObjectAclPolicy

`func (o *V12S3Bucket) GetObjectAclPolicy() string`

GetObjectAclPolicy returns the ObjectAclPolicy field if non-nil, zero value otherwise.

### GetObjectAclPolicyOk

`func (o *V12S3Bucket) GetObjectAclPolicyOk() (*string, bool)`

GetObjectAclPolicyOk returns a tuple with the ObjectAclPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetObjectAclPolicy

`func (o *V12S3Bucket) SetObjectAclPolicy(v string)`

SetObjectAclPolicy sets ObjectAclPolicy field to given value.


### GetOwner

`func (o *V12S3Bucket) GetOwner() string`

GetOwner returns the Owner field if non-nil, zero value otherwise.

### GetOwnerOk

`func (o *V12S3Bucket) GetOwnerOk() (*string, bool)`

GetOwnerOk returns a tuple with the Owner field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOwner

`func (o *V12S3Bucket) SetOwner(v string)`

SetOwner sets Owner field to given value.


### GetPath

`func (o *V12S3Bucket) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V12S3Bucket) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V12S3Bucket) SetPath(v string)`

SetPath sets Path field to given value.


### GetZid

`func (o *V12S3Bucket) GetZid() int32`

GetZid returns the Zid field if non-nil, zero value otherwise.

### GetZidOk

`func (o *V12S3Bucket) GetZidOk() (*int32, bool)`

GetZidOk returns a tuple with the Zid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetZid

`func (o *V12S3Bucket) SetZid(v int32)`

SetZid sets Zid field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


