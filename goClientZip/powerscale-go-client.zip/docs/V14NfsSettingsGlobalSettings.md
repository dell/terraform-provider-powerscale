# V14NfsSettingsGlobalSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nfsv3Enabled** | Pointer to **bool** | True if NFSv3 is enabled. | [optional] 
**Nfsv3RdmaEnabled** | Pointer to **bool** | True if the RDMA is enabled for NFSv3. | [optional] 
**Nfsv40Enabled** | Pointer to **bool** | Enable/disable minor version 0 of NFSv4 protocol. | [optional] 
**Nfsv41Enabled** | Pointer to **bool** | Enable/disable minor version 1 of NFSv4 protocol. | [optional] 
**Nfsv42Enabled** | Pointer to **bool** | Enable/disable minor version 2 of NFSv4 protocol. | [optional] 
**Nfsv4Enabled** | Pointer to **bool** | Enable/disable all minor versions of NFSv4 protocol. | [optional] 
**RpcMaxthreads** | Pointer to **int32** | Specifies the maximum number of threads in the nfsd thread pool. | [optional] 
**RpcMinthreads** | Pointer to **int32** | Specifies the minimum number of threads in the nfsd thread pool. | [optional] 
**RquotaEnabled** | Pointer to **bool** | True if the rquota protocol is enabled. | [optional] 
**Service** | Pointer to **bool** | True if the NFS service is enabled. When set to false, the NFS service is disabled. | [optional] 

## Methods

### NewV14NfsSettingsGlobalSettings

`func NewV14NfsSettingsGlobalSettings() *V14NfsSettingsGlobalSettings`

NewV14NfsSettingsGlobalSettings instantiates a new V14NfsSettingsGlobalSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14NfsSettingsGlobalSettingsWithDefaults

`func NewV14NfsSettingsGlobalSettingsWithDefaults() *V14NfsSettingsGlobalSettings`

NewV14NfsSettingsGlobalSettingsWithDefaults instantiates a new V14NfsSettingsGlobalSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNfsv3Enabled

`func (o *V14NfsSettingsGlobalSettings) GetNfsv3Enabled() bool`

GetNfsv3Enabled returns the Nfsv3Enabled field if non-nil, zero value otherwise.

### GetNfsv3EnabledOk

`func (o *V14NfsSettingsGlobalSettings) GetNfsv3EnabledOk() (*bool, bool)`

GetNfsv3EnabledOk returns a tuple with the Nfsv3Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv3Enabled

`func (o *V14NfsSettingsGlobalSettings) SetNfsv3Enabled(v bool)`

SetNfsv3Enabled sets Nfsv3Enabled field to given value.

### HasNfsv3Enabled

`func (o *V14NfsSettingsGlobalSettings) HasNfsv3Enabled() bool`

HasNfsv3Enabled returns a boolean if a field has been set.

### GetNfsv3RdmaEnabled

`func (o *V14NfsSettingsGlobalSettings) GetNfsv3RdmaEnabled() bool`

GetNfsv3RdmaEnabled returns the Nfsv3RdmaEnabled field if non-nil, zero value otherwise.

### GetNfsv3RdmaEnabledOk

`func (o *V14NfsSettingsGlobalSettings) GetNfsv3RdmaEnabledOk() (*bool, bool)`

GetNfsv3RdmaEnabledOk returns a tuple with the Nfsv3RdmaEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv3RdmaEnabled

`func (o *V14NfsSettingsGlobalSettings) SetNfsv3RdmaEnabled(v bool)`

SetNfsv3RdmaEnabled sets Nfsv3RdmaEnabled field to given value.

### HasNfsv3RdmaEnabled

`func (o *V14NfsSettingsGlobalSettings) HasNfsv3RdmaEnabled() bool`

HasNfsv3RdmaEnabled returns a boolean if a field has been set.

### GetNfsv40Enabled

`func (o *V14NfsSettingsGlobalSettings) GetNfsv40Enabled() bool`

GetNfsv40Enabled returns the Nfsv40Enabled field if non-nil, zero value otherwise.

### GetNfsv40EnabledOk

`func (o *V14NfsSettingsGlobalSettings) GetNfsv40EnabledOk() (*bool, bool)`

GetNfsv40EnabledOk returns a tuple with the Nfsv40Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv40Enabled

`func (o *V14NfsSettingsGlobalSettings) SetNfsv40Enabled(v bool)`

SetNfsv40Enabled sets Nfsv40Enabled field to given value.

### HasNfsv40Enabled

`func (o *V14NfsSettingsGlobalSettings) HasNfsv40Enabled() bool`

HasNfsv40Enabled returns a boolean if a field has been set.

### GetNfsv41Enabled

`func (o *V14NfsSettingsGlobalSettings) GetNfsv41Enabled() bool`

GetNfsv41Enabled returns the Nfsv41Enabled field if non-nil, zero value otherwise.

### GetNfsv41EnabledOk

`func (o *V14NfsSettingsGlobalSettings) GetNfsv41EnabledOk() (*bool, bool)`

GetNfsv41EnabledOk returns a tuple with the Nfsv41Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv41Enabled

`func (o *V14NfsSettingsGlobalSettings) SetNfsv41Enabled(v bool)`

SetNfsv41Enabled sets Nfsv41Enabled field to given value.

### HasNfsv41Enabled

`func (o *V14NfsSettingsGlobalSettings) HasNfsv41Enabled() bool`

HasNfsv41Enabled returns a boolean if a field has been set.

### GetNfsv42Enabled

`func (o *V14NfsSettingsGlobalSettings) GetNfsv42Enabled() bool`

GetNfsv42Enabled returns the Nfsv42Enabled field if non-nil, zero value otherwise.

### GetNfsv42EnabledOk

`func (o *V14NfsSettingsGlobalSettings) GetNfsv42EnabledOk() (*bool, bool)`

GetNfsv42EnabledOk returns a tuple with the Nfsv42Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv42Enabled

`func (o *V14NfsSettingsGlobalSettings) SetNfsv42Enabled(v bool)`

SetNfsv42Enabled sets Nfsv42Enabled field to given value.

### HasNfsv42Enabled

`func (o *V14NfsSettingsGlobalSettings) HasNfsv42Enabled() bool`

HasNfsv42Enabled returns a boolean if a field has been set.

### GetNfsv4Enabled

`func (o *V14NfsSettingsGlobalSettings) GetNfsv4Enabled() bool`

GetNfsv4Enabled returns the Nfsv4Enabled field if non-nil, zero value otherwise.

### GetNfsv4EnabledOk

`func (o *V14NfsSettingsGlobalSettings) GetNfsv4EnabledOk() (*bool, bool)`

GetNfsv4EnabledOk returns a tuple with the Nfsv4Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNfsv4Enabled

`func (o *V14NfsSettingsGlobalSettings) SetNfsv4Enabled(v bool)`

SetNfsv4Enabled sets Nfsv4Enabled field to given value.

### HasNfsv4Enabled

`func (o *V14NfsSettingsGlobalSettings) HasNfsv4Enabled() bool`

HasNfsv4Enabled returns a boolean if a field has been set.

### GetRpcMaxthreads

`func (o *V14NfsSettingsGlobalSettings) GetRpcMaxthreads() int32`

GetRpcMaxthreads returns the RpcMaxthreads field if non-nil, zero value otherwise.

### GetRpcMaxthreadsOk

`func (o *V14NfsSettingsGlobalSettings) GetRpcMaxthreadsOk() (*int32, bool)`

GetRpcMaxthreadsOk returns a tuple with the RpcMaxthreads field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRpcMaxthreads

`func (o *V14NfsSettingsGlobalSettings) SetRpcMaxthreads(v int32)`

SetRpcMaxthreads sets RpcMaxthreads field to given value.

### HasRpcMaxthreads

`func (o *V14NfsSettingsGlobalSettings) HasRpcMaxthreads() bool`

HasRpcMaxthreads returns a boolean if a field has been set.

### GetRpcMinthreads

`func (o *V14NfsSettingsGlobalSettings) GetRpcMinthreads() int32`

GetRpcMinthreads returns the RpcMinthreads field if non-nil, zero value otherwise.

### GetRpcMinthreadsOk

`func (o *V14NfsSettingsGlobalSettings) GetRpcMinthreadsOk() (*int32, bool)`

GetRpcMinthreadsOk returns a tuple with the RpcMinthreads field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRpcMinthreads

`func (o *V14NfsSettingsGlobalSettings) SetRpcMinthreads(v int32)`

SetRpcMinthreads sets RpcMinthreads field to given value.

### HasRpcMinthreads

`func (o *V14NfsSettingsGlobalSettings) HasRpcMinthreads() bool`

HasRpcMinthreads returns a boolean if a field has been set.

### GetRquotaEnabled

`func (o *V14NfsSettingsGlobalSettings) GetRquotaEnabled() bool`

GetRquotaEnabled returns the RquotaEnabled field if non-nil, zero value otherwise.

### GetRquotaEnabledOk

`func (o *V14NfsSettingsGlobalSettings) GetRquotaEnabledOk() (*bool, bool)`

GetRquotaEnabledOk returns a tuple with the RquotaEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRquotaEnabled

`func (o *V14NfsSettingsGlobalSettings) SetRquotaEnabled(v bool)`

SetRquotaEnabled sets RquotaEnabled field to given value.

### HasRquotaEnabled

`func (o *V14NfsSettingsGlobalSettings) HasRquotaEnabled() bool`

HasRquotaEnabled returns a boolean if a field has been set.

### GetService

`func (o *V14NfsSettingsGlobalSettings) GetService() bool`

GetService returns the Service field if non-nil, zero value otherwise.

### GetServiceOk

`func (o *V14NfsSettingsGlobalSettings) GetServiceOk() (*bool, bool)`

GetServiceOk returns a tuple with the Service field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetService

`func (o *V14NfsSettingsGlobalSettings) SetService(v bool)`

SetService sets Service field to given value.

### HasService

`func (o *V14NfsSettingsGlobalSettings) HasService() bool`

HasService returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


