# Createv3HardwareTapeNameResponseNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Error** | Pointer to **string** | Error message, if the HTTP status returned from this node was not 200. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**RescanReport** | Pointer to [**[]Createv3HardwareTapeNameResponseNodeRescanReportItem**](Createv3HardwareTapeNameResponseNodeRescanReportItem.md) | A list of device rescan status | [optional] 
**Status** | Pointer to **int32** | Status of the HTTP response from this node if not 200.  If 200, this field does not appear. | [optional] 

## Methods

### NewCreatev3HardwareTapeNameResponseNode

`func NewCreatev3HardwareTapeNameResponseNode() *Createv3HardwareTapeNameResponseNode`

NewCreatev3HardwareTapeNameResponseNode instantiates a new Createv3HardwareTapeNameResponseNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev3HardwareTapeNameResponseNodeWithDefaults

`func NewCreatev3HardwareTapeNameResponseNodeWithDefaults() *Createv3HardwareTapeNameResponseNode`

NewCreatev3HardwareTapeNameResponseNodeWithDefaults instantiates a new Createv3HardwareTapeNameResponseNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetError

`func (o *Createv3HardwareTapeNameResponseNode) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *Createv3HardwareTapeNameResponseNode) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *Createv3HardwareTapeNameResponseNode) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *Createv3HardwareTapeNameResponseNode) HasError() bool`

HasError returns a boolean if a field has been set.

### GetId

`func (o *Createv3HardwareTapeNameResponseNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv3HardwareTapeNameResponseNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv3HardwareTapeNameResponseNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *Createv3HardwareTapeNameResponseNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *Createv3HardwareTapeNameResponseNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *Createv3HardwareTapeNameResponseNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *Createv3HardwareTapeNameResponseNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *Createv3HardwareTapeNameResponseNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetRescanReport

`func (o *Createv3HardwareTapeNameResponseNode) GetRescanReport() []Createv3HardwareTapeNameResponseNodeRescanReportItem`

GetRescanReport returns the RescanReport field if non-nil, zero value otherwise.

### GetRescanReportOk

`func (o *Createv3HardwareTapeNameResponseNode) GetRescanReportOk() (*[]Createv3HardwareTapeNameResponseNodeRescanReportItem, bool)`

GetRescanReportOk returns a tuple with the RescanReport field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRescanReport

`func (o *Createv3HardwareTapeNameResponseNode) SetRescanReport(v []Createv3HardwareTapeNameResponseNodeRescanReportItem)`

SetRescanReport sets RescanReport field to given value.

### HasRescanReport

`func (o *Createv3HardwareTapeNameResponseNode) HasRescanReport() bool`

HasRescanReport returns a boolean if a field has been set.

### GetStatus

`func (o *Createv3HardwareTapeNameResponseNode) GetStatus() int32`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *Createv3HardwareTapeNameResponseNode) GetStatusOk() (*int32, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *Createv3HardwareTapeNameResponseNode) SetStatus(v int32)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *Createv3HardwareTapeNameResponseNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


