# V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FabricMonitoring** | **string** | Represents if backend fabric monitoring is enabled or disabled. | 
**SharedBackend** | Pointer to **bool** | Represents if backend network is shared among multiple OneFS clusters. | [optional] 

## Methods

### NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig

`func NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig(fabricMonitoring string, ) *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig`

NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig instantiates a new V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfigWithDefaults

`func NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfigWithDefaults() *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig`

NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfigWithDefaults instantiates a new V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFabricMonitoring

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig) GetFabricMonitoring() string`

GetFabricMonitoring returns the FabricMonitoring field if non-nil, zero value otherwise.

### GetFabricMonitoringOk

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig) GetFabricMonitoringOk() (*string, bool)`

GetFabricMonitoringOk returns a tuple with the FabricMonitoring field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFabricMonitoring

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig) SetFabricMonitoring(v string)`

SetFabricMonitoring sets FabricMonitoring field to given value.


### GetSharedBackend

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig) GetSharedBackend() bool`

GetSharedBackend returns the SharedBackend field if non-nil, zero value otherwise.

### GetSharedBackendOk

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig) GetSharedBackendOk() (*bool, bool)`

GetSharedBackendOk returns a tuple with the SharedBackend field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSharedBackend

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig) SetSharedBackend(v bool)`

SetSharedBackend sets SharedBackend field to given value.

### HasSharedBackend

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig) HasSharedBackend() bool`

HasSharedBackend returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


