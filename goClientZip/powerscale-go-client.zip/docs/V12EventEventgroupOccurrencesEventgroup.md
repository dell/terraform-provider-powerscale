# V12EventEventgroupOccurrencesEventgroup

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Causes** | Pointer to **[][]string** | List of eventgroup IDs that may be causes of this occurrence. | [optional] 
**Channels** | Pointer to **[]string** | List of channels to which alerts are configured for this eventgroup. | [optional] 
**EventCount** | Pointer to **int32** | Number of events linked to this eventgroup. | [optional] 
**EventgroupInstance** | Pointer to **string** | Unique identifier of eventgroup instance. | [optional] 
**Id** | Pointer to **string** | Same as eventgroup_instance. | [optional] 
**Ignore** | Pointer to **bool** | True if eventgroup is marked as &#39;ignore&#39;. | [optional] 
**IgnoreTime** | Pointer to **int32** | Time eventgroup was marked as &#39;ignore&#39;. | [optional] 
**LastEvent** | Pointer to **int32** | Time the most recent event was added to this eventgroup. | [optional] 
**ResolveTime** | Pointer to **int32** | When the eventgroup became resolved. | [optional] 
**Resolved** | Pointer to **bool** | True if eventgroup is resolved. | [optional] 
**Resolver** | Pointer to **string** | &#39;USER&#39; if the eventgroup was marked resolved by the user. &#39;&lt;event_instance&gt;&#39; if eventgroup was marked resolved as a result of an event. | [optional] 
**Sequence** | Pointer to **int32** | Unique sequence number assigned to the eventgroup, by order of creation. | [optional] 
**Severity** | Pointer to **string** | Event Group severity. | [optional] 
**Specifier** | Pointer to **map[string]interface{}** |  | [optional] 
**TimeNoticed** | Pointer to **int32** | Time of first event linked to this eventgroup. | [optional] 

## Methods

### NewV12EventEventgroupOccurrencesEventgroup

`func NewV12EventEventgroupOccurrencesEventgroup() *V12EventEventgroupOccurrencesEventgroup`

NewV12EventEventgroupOccurrencesEventgroup instantiates a new V12EventEventgroupOccurrencesEventgroup object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventEventgroupOccurrencesEventgroupWithDefaults

`func NewV12EventEventgroupOccurrencesEventgroupWithDefaults() *V12EventEventgroupOccurrencesEventgroup`

NewV12EventEventgroupOccurrencesEventgroupWithDefaults instantiates a new V12EventEventgroupOccurrencesEventgroup object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCauses

`func (o *V12EventEventgroupOccurrencesEventgroup) GetCauses() [][]string`

GetCauses returns the Causes field if non-nil, zero value otherwise.

### GetCausesOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetCausesOk() (*[][]string, bool)`

GetCausesOk returns a tuple with the Causes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCauses

`func (o *V12EventEventgroupOccurrencesEventgroup) SetCauses(v [][]string)`

SetCauses sets Causes field to given value.

### HasCauses

`func (o *V12EventEventgroupOccurrencesEventgroup) HasCauses() bool`

HasCauses returns a boolean if a field has been set.

### GetChannels

`func (o *V12EventEventgroupOccurrencesEventgroup) GetChannels() []string`

GetChannels returns the Channels field if non-nil, zero value otherwise.

### GetChannelsOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetChannelsOk() (*[]string, bool)`

GetChannelsOk returns a tuple with the Channels field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChannels

`func (o *V12EventEventgroupOccurrencesEventgroup) SetChannels(v []string)`

SetChannels sets Channels field to given value.

### HasChannels

`func (o *V12EventEventgroupOccurrencesEventgroup) HasChannels() bool`

HasChannels returns a boolean if a field has been set.

### GetEventCount

`func (o *V12EventEventgroupOccurrencesEventgroup) GetEventCount() int32`

GetEventCount returns the EventCount field if non-nil, zero value otherwise.

### GetEventCountOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetEventCountOk() (*int32, bool)`

GetEventCountOk returns a tuple with the EventCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventCount

`func (o *V12EventEventgroupOccurrencesEventgroup) SetEventCount(v int32)`

SetEventCount sets EventCount field to given value.

### HasEventCount

`func (o *V12EventEventgroupOccurrencesEventgroup) HasEventCount() bool`

HasEventCount returns a boolean if a field has been set.

### GetEventgroupInstance

`func (o *V12EventEventgroupOccurrencesEventgroup) GetEventgroupInstance() string`

GetEventgroupInstance returns the EventgroupInstance field if non-nil, zero value otherwise.

### GetEventgroupInstanceOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetEventgroupInstanceOk() (*string, bool)`

GetEventgroupInstanceOk returns a tuple with the EventgroupInstance field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventgroupInstance

`func (o *V12EventEventgroupOccurrencesEventgroup) SetEventgroupInstance(v string)`

SetEventgroupInstance sets EventgroupInstance field to given value.

### HasEventgroupInstance

`func (o *V12EventEventgroupOccurrencesEventgroup) HasEventgroupInstance() bool`

HasEventgroupInstance returns a boolean if a field has been set.

### GetId

`func (o *V12EventEventgroupOccurrencesEventgroup) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12EventEventgroupOccurrencesEventgroup) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V12EventEventgroupOccurrencesEventgroup) HasId() bool`

HasId returns a boolean if a field has been set.

### GetIgnore

`func (o *V12EventEventgroupOccurrencesEventgroup) GetIgnore() bool`

GetIgnore returns the Ignore field if non-nil, zero value otherwise.

### GetIgnoreOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetIgnoreOk() (*bool, bool)`

GetIgnoreOk returns a tuple with the Ignore field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnore

`func (o *V12EventEventgroupOccurrencesEventgroup) SetIgnore(v bool)`

SetIgnore sets Ignore field to given value.

### HasIgnore

`func (o *V12EventEventgroupOccurrencesEventgroup) HasIgnore() bool`

HasIgnore returns a boolean if a field has been set.

### GetIgnoreTime

`func (o *V12EventEventgroupOccurrencesEventgroup) GetIgnoreTime() int32`

GetIgnoreTime returns the IgnoreTime field if non-nil, zero value otherwise.

### GetIgnoreTimeOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetIgnoreTimeOk() (*int32, bool)`

GetIgnoreTimeOk returns a tuple with the IgnoreTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnoreTime

`func (o *V12EventEventgroupOccurrencesEventgroup) SetIgnoreTime(v int32)`

SetIgnoreTime sets IgnoreTime field to given value.

### HasIgnoreTime

`func (o *V12EventEventgroupOccurrencesEventgroup) HasIgnoreTime() bool`

HasIgnoreTime returns a boolean if a field has been set.

### GetLastEvent

`func (o *V12EventEventgroupOccurrencesEventgroup) GetLastEvent() int32`

GetLastEvent returns the LastEvent field if non-nil, zero value otherwise.

### GetLastEventOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetLastEventOk() (*int32, bool)`

GetLastEventOk returns a tuple with the LastEvent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLastEvent

`func (o *V12EventEventgroupOccurrencesEventgroup) SetLastEvent(v int32)`

SetLastEvent sets LastEvent field to given value.

### HasLastEvent

`func (o *V12EventEventgroupOccurrencesEventgroup) HasLastEvent() bool`

HasLastEvent returns a boolean if a field has been set.

### GetResolveTime

`func (o *V12EventEventgroupOccurrencesEventgroup) GetResolveTime() int32`

GetResolveTime returns the ResolveTime field if non-nil, zero value otherwise.

### GetResolveTimeOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetResolveTimeOk() (*int32, bool)`

GetResolveTimeOk returns a tuple with the ResolveTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResolveTime

`func (o *V12EventEventgroupOccurrencesEventgroup) SetResolveTime(v int32)`

SetResolveTime sets ResolveTime field to given value.

### HasResolveTime

`func (o *V12EventEventgroupOccurrencesEventgroup) HasResolveTime() bool`

HasResolveTime returns a boolean if a field has been set.

### GetResolved

`func (o *V12EventEventgroupOccurrencesEventgroup) GetResolved() bool`

GetResolved returns the Resolved field if non-nil, zero value otherwise.

### GetResolvedOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetResolvedOk() (*bool, bool)`

GetResolvedOk returns a tuple with the Resolved field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResolved

`func (o *V12EventEventgroupOccurrencesEventgroup) SetResolved(v bool)`

SetResolved sets Resolved field to given value.

### HasResolved

`func (o *V12EventEventgroupOccurrencesEventgroup) HasResolved() bool`

HasResolved returns a boolean if a field has been set.

### GetResolver

`func (o *V12EventEventgroupOccurrencesEventgroup) GetResolver() string`

GetResolver returns the Resolver field if non-nil, zero value otherwise.

### GetResolverOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetResolverOk() (*string, bool)`

GetResolverOk returns a tuple with the Resolver field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResolver

`func (o *V12EventEventgroupOccurrencesEventgroup) SetResolver(v string)`

SetResolver sets Resolver field to given value.

### HasResolver

`func (o *V12EventEventgroupOccurrencesEventgroup) HasResolver() bool`

HasResolver returns a boolean if a field has been set.

### GetSequence

`func (o *V12EventEventgroupOccurrencesEventgroup) GetSequence() int32`

GetSequence returns the Sequence field if non-nil, zero value otherwise.

### GetSequenceOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetSequenceOk() (*int32, bool)`

GetSequenceOk returns a tuple with the Sequence field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSequence

`func (o *V12EventEventgroupOccurrencesEventgroup) SetSequence(v int32)`

SetSequence sets Sequence field to given value.

### HasSequence

`func (o *V12EventEventgroupOccurrencesEventgroup) HasSequence() bool`

HasSequence returns a boolean if a field has been set.

### GetSeverity

`func (o *V12EventEventgroupOccurrencesEventgroup) GetSeverity() string`

GetSeverity returns the Severity field if non-nil, zero value otherwise.

### GetSeverityOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetSeverityOk() (*string, bool)`

GetSeverityOk returns a tuple with the Severity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSeverity

`func (o *V12EventEventgroupOccurrencesEventgroup) SetSeverity(v string)`

SetSeverity sets Severity field to given value.

### HasSeverity

`func (o *V12EventEventgroupOccurrencesEventgroup) HasSeverity() bool`

HasSeverity returns a boolean if a field has been set.

### GetSpecifier

`func (o *V12EventEventgroupOccurrencesEventgroup) GetSpecifier() map[string]interface{}`

GetSpecifier returns the Specifier field if non-nil, zero value otherwise.

### GetSpecifierOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetSpecifierOk() (*map[string]interface{}, bool)`

GetSpecifierOk returns a tuple with the Specifier field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpecifier

`func (o *V12EventEventgroupOccurrencesEventgroup) SetSpecifier(v map[string]interface{})`

SetSpecifier sets Specifier field to given value.

### HasSpecifier

`func (o *V12EventEventgroupOccurrencesEventgroup) HasSpecifier() bool`

HasSpecifier returns a boolean if a field has been set.

### GetTimeNoticed

`func (o *V12EventEventgroupOccurrencesEventgroup) GetTimeNoticed() int32`

GetTimeNoticed returns the TimeNoticed field if non-nil, zero value otherwise.

### GetTimeNoticedOk

`func (o *V12EventEventgroupOccurrencesEventgroup) GetTimeNoticedOk() (*int32, bool)`

GetTimeNoticedOk returns a tuple with the TimeNoticed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTimeNoticed

`func (o *V12EventEventgroupOccurrencesEventgroup) SetTimeNoticed(v int32)`

SetTimeNoticed sets TimeNoticed field to given value.

### HasTimeNoticed

`func (o *V12EventEventgroupOccurrencesEventgroup) HasTimeNoticed() bool`

HasTimeNoticed returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


