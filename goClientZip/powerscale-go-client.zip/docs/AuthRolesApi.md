# \AuthRolesApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateAuthRolesv14RolePrivilege**](AuthRolesApi.md#CreateAuthRolesv14RolePrivilege) | **Post** /platform/14/auth/roles/{Role}/privileges | 
[**CreateAuthRolesv1RoleMember**](AuthRolesApi.md#CreateAuthRolesv1RoleMember) | **Post** /platform/1/auth/roles/{Role}/members | 
[**CreateAuthRolesv1RolePrivilege**](AuthRolesApi.md#CreateAuthRolesv1RolePrivilege) | **Post** /platform/1/auth/roles/{Role}/privileges | 
[**CreateAuthRolesv7RoleMember**](AuthRolesApi.md#CreateAuthRolesv7RoleMember) | **Post** /platform/7/auth/roles/{Role}/members | 
[**CreateAuthRolesv7RolePrivilege**](AuthRolesApi.md#CreateAuthRolesv7RolePrivilege) | **Post** /platform/7/auth/roles/{Role}/privileges | 
[**CreateAuthRolesv8RoleMember**](AuthRolesApi.md#CreateAuthRolesv8RoleMember) | **Post** /platform/8/auth/roles/{Role}/members | 
[**ListAuthRolesv14RolePrivileges**](AuthRolesApi.md#ListAuthRolesv14RolePrivileges) | **Get** /platform/14/auth/roles/{Role}/privileges | 
[**ListAuthRolesv1RoleMembers**](AuthRolesApi.md#ListAuthRolesv1RoleMembers) | **Get** /platform/1/auth/roles/{Role}/members | 
[**ListAuthRolesv1RolePrivileges**](AuthRolesApi.md#ListAuthRolesv1RolePrivileges) | **Get** /platform/1/auth/roles/{Role}/privileges | 
[**ListAuthRolesv7RoleMembers**](AuthRolesApi.md#ListAuthRolesv7RoleMembers) | **Get** /platform/7/auth/roles/{Role}/members | 
[**ListAuthRolesv7RolePrivileges**](AuthRolesApi.md#ListAuthRolesv7RolePrivileges) | **Get** /platform/7/auth/roles/{Role}/privileges | 
[**ListAuthRolesv8RoleMembers**](AuthRolesApi.md#ListAuthRolesv8RoleMembers) | **Get** /platform/8/auth/roles/{Role}/members | 



## CreateAuthRolesv14RolePrivilege

> CreateResponse CreateAuthRolesv14RolePrivilege(ctx, role).V14RolePrivilege(v14RolePrivilege).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    v14RolePrivilege := *openapiclient.NewV14AuthIdNtokenPrivilegeItem("Id_example") // V14AuthIdNtokenPrivilegeItem | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.CreateAuthRolesv14RolePrivilege(context.Background(), role).V14RolePrivilege(v14RolePrivilege).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.CreateAuthRolesv14RolePrivilege``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthRolesv14RolePrivilege`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.CreateAuthRolesv14RolePrivilege`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthRolesv14RolePrivilegeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v14RolePrivilege** | [**V14AuthIdNtokenPrivilegeItem**](V14AuthIdNtokenPrivilegeItem.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthRolesv1RoleMember

> CreateResponse CreateAuthRolesv1RoleMember(ctx, role).V1RoleMember(v1RoleMember).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    v1RoleMember := *openapiclient.NewV1AuthAccessAccessItemFileGroup() // V1AuthAccessAccessItemFileGroup | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.CreateAuthRolesv1RoleMember(context.Background(), role).V1RoleMember(v1RoleMember).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.CreateAuthRolesv1RoleMember``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthRolesv1RoleMember`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.CreateAuthRolesv1RoleMember`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthRolesv1RoleMemberRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1RoleMember** | [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthRolesv1RolePrivilege

> CreateResponse CreateAuthRolesv1RolePrivilege(ctx, role).V1RolePrivilege(v1RolePrivilege).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    v1RolePrivilege := *openapiclient.NewV1AuthIdNtokenPrivilegeItem("Id_example") // V1AuthIdNtokenPrivilegeItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.CreateAuthRolesv1RolePrivilege(context.Background(), role).V1RolePrivilege(v1RolePrivilege).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.CreateAuthRolesv1RolePrivilege``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthRolesv1RolePrivilege`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.CreateAuthRolesv1RolePrivilege`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthRolesv1RolePrivilegeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1RolePrivilege** | [**V1AuthIdNtokenPrivilegeItem**](V1AuthIdNtokenPrivilegeItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthRolesv7RoleMember

> CreateResponse CreateAuthRolesv7RoleMember(ctx, role).V7RoleMember(v7RoleMember).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    v7RoleMember := *openapiclient.NewV1AuthAccessAccessItemFileGroup() // V1AuthAccessAccessItemFileGroup | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.CreateAuthRolesv7RoleMember(context.Background(), role).V7RoleMember(v7RoleMember).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.CreateAuthRolesv7RoleMember``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthRolesv7RoleMember`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.CreateAuthRolesv7RoleMember`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthRolesv7RoleMemberRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7RoleMember** | [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthRolesv7RolePrivilege

> CreateResponse CreateAuthRolesv7RolePrivilege(ctx, role).V7RolePrivilege(v7RolePrivilege).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    v7RolePrivilege := *openapiclient.NewV1AuthIdNtokenPrivilegeItem("Id_example") // V1AuthIdNtokenPrivilegeItem | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.CreateAuthRolesv7RolePrivilege(context.Background(), role).V7RolePrivilege(v7RolePrivilege).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.CreateAuthRolesv7RolePrivilege``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthRolesv7RolePrivilege`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.CreateAuthRolesv7RolePrivilege`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthRolesv7RolePrivilegeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7RolePrivilege** | [**V1AuthIdNtokenPrivilegeItem**](V1AuthIdNtokenPrivilegeItem.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateAuthRolesv8RoleMember

> CreateResponse CreateAuthRolesv8RoleMember(ctx, role).V8RoleMember(v8RoleMember).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    v8RoleMember := *openapiclient.NewV1AuthAccessAccessItemFileGroup() // V1AuthAccessAccessItemFileGroup | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.CreateAuthRolesv8RoleMember(context.Background(), role).V8RoleMember(v8RoleMember).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.CreateAuthRolesv8RoleMember``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuthRolesv8RoleMember`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.CreateAuthRolesv8RoleMember`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuthRolesv8RoleMemberRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v8RoleMember** | [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | 
 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthRolesv14RolePrivileges

> V14RolePrivileges ListAuthRolesv14RolePrivileges(ctx, role).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.ListAuthRolesv14RolePrivileges(context.Background(), role).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.ListAuthRolesv14RolePrivileges``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthRolesv14RolePrivileges`: V14RolePrivileges
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.ListAuthRolesv14RolePrivileges`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListAuthRolesv14RolePrivilegesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V14RolePrivileges**](V14RolePrivileges.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthRolesv1RoleMembers

> V1RoleMembers ListAuthRolesv1RoleMembers(ctx, role).ResolveNames(resolveNames).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    resolveNames := true // bool | Resolve names of personas. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.ListAuthRolesv1RoleMembers(context.Background(), role).ResolveNames(resolveNames).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.ListAuthRolesv1RoleMembers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthRolesv1RoleMembers`: V1RoleMembers
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.ListAuthRolesv1RoleMembers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListAuthRolesv1RoleMembersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **resolveNames** | **bool** | Resolve names of personas. | 

### Return type

[**V1RoleMembers**](V1RoleMembers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthRolesv1RolePrivileges

> V1RolePrivileges ListAuthRolesv1RolePrivileges(ctx, role).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.ListAuthRolesv1RolePrivileges(context.Background(), role).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.ListAuthRolesv1RolePrivileges``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthRolesv1RolePrivileges`: V1RolePrivileges
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.ListAuthRolesv1RolePrivileges`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListAuthRolesv1RolePrivilegesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1RolePrivileges**](V1RolePrivileges.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthRolesv7RoleMembers

> V1RoleMembers ListAuthRolesv7RoleMembers(ctx, role).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    resolveNames := true // bool | Resolve names of personas. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.ListAuthRolesv7RoleMembers(context.Background(), role).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.ListAuthRolesv7RoleMembers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthRolesv7RoleMembers`: V1RoleMembers
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.ListAuthRolesv7RoleMembers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListAuthRolesv7RoleMembersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **zone** | **string** | Specifies which access zone to use. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **resolveNames** | **bool** | Resolve names of personas. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1RoleMembers**](V1RoleMembers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthRolesv7RolePrivileges

> V1RolePrivileges ListAuthRolesv7RolePrivileges(ctx, role).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    zone := "zone_example" // string | Specifies which access zone to use. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.ListAuthRolesv7RolePrivileges(context.Background(), role).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.ListAuthRolesv7RolePrivileges``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthRolesv7RolePrivileges`: V1RolePrivileges
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.ListAuthRolesv7RolePrivileges`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListAuthRolesv7RolePrivilegesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **zone** | **string** | Specifies which access zone to use. | 

### Return type

[**V1RolePrivileges**](V1RolePrivileges.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuthRolesv8RoleMembers

> V8RoleMembers ListAuthRolesv8RoleMembers(ctx, role).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    role := "role_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    zone := "zone_example" // string | Specifies which access zone to use. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    resolveNames := true // bool | Resolve names of personas. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuthRolesApi.ListAuthRolesv8RoleMembers(context.Background(), role).Sort(sort).Zone(zone).Resume(resume).ResolveNames(resolveNames).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuthRolesApi.ListAuthRolesv8RoleMembers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuthRolesv8RoleMembers`: V8RoleMembers
    fmt.Fprintf(os.Stdout, "Response from `AuthRolesApi.ListAuthRolesv8RoleMembers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**role** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListAuthRolesv8RoleMembersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **zone** | **string** | Specifies which access zone to use. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **resolveNames** | **bool** | Resolve names of personas. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V8RoleMembers**](V8RoleMembers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

