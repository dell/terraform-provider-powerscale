# V10PerformanceDatasetExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreationTime** | **int32** | Timestamp of when the dataset was created. | 
**FilterCount** | **int32** | Number of filters applied to this dataset. | 
**Filters** | **[]string** | Filtered metrics for configuring this dataset. | 
**Id** | **int32** | Unique identifier for the configured dataset. | 
**Metrics** | **[]string** | Performance metrics defining the dataset. | 
**Name** | **string** | The name of the performance dataset. If a name is not specified then a default name is assigned. The default name will be an underscore separated list of the performance metrics and filters used to configure the dataset. | 
**Note** | Pointer to **string** | Additional information about this dataset | [optional] 
**Statkey** | **string** | Key for use in viewing associated raw statistics under the endpoints /statistics/history and /statistics/current. | 
**WorkloadCount** | **int32** | Number of workloads pinned to this dataset. | 

## Methods

### NewV10PerformanceDatasetExtended

`func NewV10PerformanceDatasetExtended(creationTime int32, filterCount int32, filters []string, id int32, metrics []string, name string, statkey string, workloadCount int32, ) *V10PerformanceDatasetExtended`

NewV10PerformanceDatasetExtended instantiates a new V10PerformanceDatasetExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10PerformanceDatasetExtendedWithDefaults

`func NewV10PerformanceDatasetExtendedWithDefaults() *V10PerformanceDatasetExtended`

NewV10PerformanceDatasetExtendedWithDefaults instantiates a new V10PerformanceDatasetExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCreationTime

`func (o *V10PerformanceDatasetExtended) GetCreationTime() int32`

GetCreationTime returns the CreationTime field if non-nil, zero value otherwise.

### GetCreationTimeOk

`func (o *V10PerformanceDatasetExtended) GetCreationTimeOk() (*int32, bool)`

GetCreationTimeOk returns a tuple with the CreationTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreationTime

`func (o *V10PerformanceDatasetExtended) SetCreationTime(v int32)`

SetCreationTime sets CreationTime field to given value.


### GetFilterCount

`func (o *V10PerformanceDatasetExtended) GetFilterCount() int32`

GetFilterCount returns the FilterCount field if non-nil, zero value otherwise.

### GetFilterCountOk

`func (o *V10PerformanceDatasetExtended) GetFilterCountOk() (*int32, bool)`

GetFilterCountOk returns a tuple with the FilterCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilterCount

`func (o *V10PerformanceDatasetExtended) SetFilterCount(v int32)`

SetFilterCount sets FilterCount field to given value.


### GetFilters

`func (o *V10PerformanceDatasetExtended) GetFilters() []string`

GetFilters returns the Filters field if non-nil, zero value otherwise.

### GetFiltersOk

`func (o *V10PerformanceDatasetExtended) GetFiltersOk() (*[]string, bool)`

GetFiltersOk returns a tuple with the Filters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFilters

`func (o *V10PerformanceDatasetExtended) SetFilters(v []string)`

SetFilters sets Filters field to given value.


### GetId

`func (o *V10PerformanceDatasetExtended) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10PerformanceDatasetExtended) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10PerformanceDatasetExtended) SetId(v int32)`

SetId sets Id field to given value.


### GetMetrics

`func (o *V10PerformanceDatasetExtended) GetMetrics() []string`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *V10PerformanceDatasetExtended) GetMetricsOk() (*[]string, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *V10PerformanceDatasetExtended) SetMetrics(v []string)`

SetMetrics sets Metrics field to given value.


### GetName

`func (o *V10PerformanceDatasetExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10PerformanceDatasetExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10PerformanceDatasetExtended) SetName(v string)`

SetName sets Name field to given value.


### GetNote

`func (o *V10PerformanceDatasetExtended) GetNote() string`

GetNote returns the Note field if non-nil, zero value otherwise.

### GetNoteOk

`func (o *V10PerformanceDatasetExtended) GetNoteOk() (*string, bool)`

GetNoteOk returns a tuple with the Note field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNote

`func (o *V10PerformanceDatasetExtended) SetNote(v string)`

SetNote sets Note field to given value.

### HasNote

`func (o *V10PerformanceDatasetExtended) HasNote() bool`

HasNote returns a boolean if a field has been set.

### GetStatkey

`func (o *V10PerformanceDatasetExtended) GetStatkey() string`

GetStatkey returns the Statkey field if non-nil, zero value otherwise.

### GetStatkeyOk

`func (o *V10PerformanceDatasetExtended) GetStatkeyOk() (*string, bool)`

GetStatkeyOk returns a tuple with the Statkey field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatkey

`func (o *V10PerformanceDatasetExtended) SetStatkey(v string)`

SetStatkey sets Statkey field to given value.


### GetWorkloadCount

`func (o *V10PerformanceDatasetExtended) GetWorkloadCount() int32`

GetWorkloadCount returns the WorkloadCount field if non-nil, zero value otherwise.

### GetWorkloadCountOk

`func (o *V10PerformanceDatasetExtended) GetWorkloadCountOk() (*int32, bool)`

GetWorkloadCountOk returns a tuple with the WorkloadCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWorkloadCount

`func (o *V10PerformanceDatasetExtended) SetWorkloadCount(v int32)`

SetWorkloadCount sets WorkloadCount field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


