# \CloudApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateCloudv3CloudAccessItem**](CloudApi.md#CreateCloudv3CloudAccessItem) | **Post** /platform/3/cloud/access | 
[**CreateCloudv3CloudJob**](CloudApi.md#CreateCloudv3CloudJob) | **Post** /platform/3/cloud/jobs | 
[**CreateCloudv3SettingsEncryptionKeyItem**](CloudApi.md#CreateCloudv3SettingsEncryptionKeyItem) | **Post** /platform/3/cloud/settings/encryption-key | 
[**CreateCloudv3SettingsReportingEulaItem**](CloudApi.md#CreateCloudv3SettingsReportingEulaItem) | **Post** /platform/3/cloud/settings/reporting-eula | 
[**CreateCloudv4CloudProxy**](CloudApi.md#CreateCloudv4CloudProxy) | **Post** /platform/4/cloud/proxies | 
[**CreateCloudv7CloudAccount**](CloudApi.md#CreateCloudv7CloudAccount) | **Post** /platform/7/cloud/accounts | 
[**CreateCloudv7CloudCertificate**](CloudApi.md#CreateCloudv7CloudCertificate) | **Post** /platform/7/cloud/certificates | 
[**CreateCloudv7CloudPool**](CloudApi.md#CreateCloudv7CloudPool) | **Post** /platform/7/cloud/pools | 
[**DeleteCloudv3CloudAccessGuid**](CloudApi.md#DeleteCloudv3CloudAccessGuid) | **Delete** /platform/3/cloud/access/{v3CloudAccessGuid} | 
[**DeleteCloudv3SettingsReportingEula**](CloudApi.md#DeleteCloudv3SettingsReportingEula) | **Delete** /platform/3/cloud/settings/reporting-eula | 
[**DeleteCloudv4CloudProxy**](CloudApi.md#DeleteCloudv4CloudProxy) | **Delete** /platform/4/cloud/proxies/{v4CloudProxyId} | 
[**DeleteCloudv7CloudAccount**](CloudApi.md#DeleteCloudv7CloudAccount) | **Delete** /platform/7/cloud/accounts/{v7CloudAccountId} | 
[**DeleteCloudv7CloudCertificate**](CloudApi.md#DeleteCloudv7CloudCertificate) | **Delete** /platform/7/cloud/certificates/{v7CloudCertificateId} | 
[**DeleteCloudv7CloudPool**](CloudApi.md#DeleteCloudv7CloudPool) | **Delete** /platform/7/cloud/pools/{v7CloudPoolId} | 
[**GetCloudv3CloudAccessGuid**](CloudApi.md#GetCloudv3CloudAccessGuid) | **Get** /platform/3/cloud/access/{v3CloudAccessGuid} | 
[**GetCloudv3CloudJob**](CloudApi.md#GetCloudv3CloudJob) | **Get** /platform/3/cloud/jobs/{v3CloudJobId} | 
[**GetCloudv3CloudJobsFile**](CloudApi.md#GetCloudv3CloudJobsFile) | **Get** /platform/3/cloud/jobs-files/{v3CloudJobsFileId} | 
[**GetCloudv3CloudSettings**](CloudApi.md#GetCloudv3CloudSettings) | **Get** /platform/3/cloud/settings | 
[**GetCloudv4CloudProxy**](CloudApi.md#GetCloudv4CloudProxy) | **Get** /platform/4/cloud/proxies/{v4CloudProxyId} | 
[**GetCloudv7CloudAccount**](CloudApi.md#GetCloudv7CloudAccount) | **Get** /platform/7/cloud/accounts/{v7CloudAccountId} | 
[**GetCloudv7CloudCertificate**](CloudApi.md#GetCloudv7CloudCertificate) | **Get** /platform/7/cloud/certificates/{v7CloudCertificateId} | 
[**GetCloudv7CloudPool**](CloudApi.md#GetCloudv7CloudPool) | **Get** /platform/7/cloud/pools/{v7CloudPoolId} | 
[**ListCloudv3CloudAccess**](CloudApi.md#ListCloudv3CloudAccess) | **Get** /platform/3/cloud/access | 
[**ListCloudv3CloudJobs**](CloudApi.md#ListCloudv3CloudJobs) | **Get** /platform/3/cloud/jobs | 
[**ListCloudv3SettingsReportingEula**](CloudApi.md#ListCloudv3SettingsReportingEula) | **Get** /platform/3/cloud/settings/reporting-eula | 
[**ListCloudv4CloudProxies**](CloudApi.md#ListCloudv4CloudProxies) | **Get** /platform/4/cloud/proxies | 
[**ListCloudv7CloudAccounts**](CloudApi.md#ListCloudv7CloudAccounts) | **Get** /platform/7/cloud/accounts | 
[**ListCloudv7CloudCertificates**](CloudApi.md#ListCloudv7CloudCertificates) | **Get** /platform/7/cloud/certificates | 
[**ListCloudv7CloudPools**](CloudApi.md#ListCloudv7CloudPools) | **Get** /platform/7/cloud/pools | 
[**UpdateCloudv3CloudJob**](CloudApi.md#UpdateCloudv3CloudJob) | **Put** /platform/3/cloud/jobs/{v3CloudJobId} | 
[**UpdateCloudv3CloudSettings**](CloudApi.md#UpdateCloudv3CloudSettings) | **Put** /platform/3/cloud/settings | 
[**UpdateCloudv4CloudProxy**](CloudApi.md#UpdateCloudv4CloudProxy) | **Put** /platform/4/cloud/proxies/{v4CloudProxyId} | 
[**UpdateCloudv7CloudAccount**](CloudApi.md#UpdateCloudv7CloudAccount) | **Put** /platform/7/cloud/accounts/{v7CloudAccountId} | 
[**UpdateCloudv7CloudCertificate**](CloudApi.md#UpdateCloudv7CloudCertificate) | **Put** /platform/7/cloud/certificates/{v7CloudCertificateId} | 
[**UpdateCloudv7CloudPool**](CloudApi.md#UpdateCloudv7CloudPool) | **Put** /platform/7/cloud/pools/{v7CloudPoolId} | 



## CreateCloudv3CloudAccessItem

> map[string]interface{} CreateCloudv3CloudAccessItem(ctx).V3CloudAccessItem(v3CloudAccessItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3CloudAccessItem := *openapiclient.NewV3CloudAccessItem("Guid_example") // V3CloudAccessItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.CreateCloudv3CloudAccessItem(context.Background()).V3CloudAccessItem(v3CloudAccessItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.CreateCloudv3CloudAccessItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateCloudv3CloudAccessItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.CreateCloudv3CloudAccessItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateCloudv3CloudAccessItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3CloudAccessItem** | [**V3CloudAccessItem**](V3CloudAccessItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateCloudv3CloudJob

> Createv3CloudJobResponse CreateCloudv3CloudJob(ctx).V3CloudJob(v3CloudJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3CloudJob := *openapiclient.NewV3CloudJob("Type_example") // V3CloudJob | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.CreateCloudv3CloudJob(context.Background()).V3CloudJob(v3CloudJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.CreateCloudv3CloudJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateCloudv3CloudJob`: Createv3CloudJobResponse
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.CreateCloudv3CloudJob`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateCloudv3CloudJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3CloudJob** | [**V3CloudJob**](V3CloudJob.md) |  | 

### Return type

[**Createv3CloudJobResponse**](Createv3CloudJobResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateCloudv3SettingsEncryptionKeyItem

> map[string]interface{} CreateCloudv3SettingsEncryptionKeyItem(ctx).V3SettingsEncryptionKeyItem(v3SettingsEncryptionKeyItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SettingsEncryptionKeyItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.CreateCloudv3SettingsEncryptionKeyItem(context.Background()).V3SettingsEncryptionKeyItem(v3SettingsEncryptionKeyItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.CreateCloudv3SettingsEncryptionKeyItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateCloudv3SettingsEncryptionKeyItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.CreateCloudv3SettingsEncryptionKeyItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateCloudv3SettingsEncryptionKeyItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SettingsEncryptionKeyItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateCloudv3SettingsReportingEulaItem

> map[string]interface{} CreateCloudv3SettingsReportingEulaItem(ctx).V3SettingsReportingEulaItem(v3SettingsReportingEulaItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SettingsReportingEulaItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.CreateCloudv3SettingsReportingEulaItem(context.Background()).V3SettingsReportingEulaItem(v3SettingsReportingEulaItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.CreateCloudv3SettingsReportingEulaItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateCloudv3SettingsReportingEulaItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.CreateCloudv3SettingsReportingEulaItem`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateCloudv3SettingsReportingEulaItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SettingsReportingEulaItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateCloudv4CloudProxy

> Createv4CloudProxyResponse CreateCloudv4CloudProxy(ctx).V4CloudProxy(v4CloudProxy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4CloudProxy := *openapiclient.NewV4CloudProxy("Host_example", "Name_example", int32(123), "Type_example") // V4CloudProxy | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.CreateCloudv4CloudProxy(context.Background()).V4CloudProxy(v4CloudProxy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.CreateCloudv4CloudProxy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateCloudv4CloudProxy`: Createv4CloudProxyResponse
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.CreateCloudv4CloudProxy`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateCloudv4CloudProxyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v4CloudProxy** | [**V4CloudProxy**](V4CloudProxy.md) |  | 

### Return type

[**Createv4CloudProxyResponse**](Createv4CloudProxyResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateCloudv7CloudAccount

> Createv7CloudAccountResponse CreateCloudv7CloudAccount(ctx).V7CloudAccount(v7CloudAccount).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudAccount := *openapiclient.NewV7CloudAccount("Name_example", "Type_example", "Uri_example") // V7CloudAccount | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.CreateCloudv7CloudAccount(context.Background()).V7CloudAccount(v7CloudAccount).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.CreateCloudv7CloudAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateCloudv7CloudAccount`: Createv7CloudAccountResponse
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.CreateCloudv7CloudAccount`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateCloudv7CloudAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7CloudAccount** | [**V7CloudAccount**](V7CloudAccount.md) |  | 

### Return type

[**Createv7CloudAccountResponse**](Createv7CloudAccountResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateCloudv7CloudCertificate

> CreateResponse CreateCloudv7CloudCertificate(ctx).V7CloudCertificate(v7CloudCertificate).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudCertificate := *openapiclient.NewV16CertificatesSyslogItem("CertificateKeyPath_example", "CertificatePath_example") // V16CertificatesSyslogItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.CreateCloudv7CloudCertificate(context.Background()).V7CloudCertificate(v7CloudCertificate).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.CreateCloudv7CloudCertificate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateCloudv7CloudCertificate`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.CreateCloudv7CloudCertificate`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateCloudv7CloudCertificateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7CloudCertificate** | [**V16CertificatesSyslogItem**](V16CertificatesSyslogItem.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateCloudv7CloudPool

> Createv7CloudPoolResponse CreateCloudv7CloudPool(ctx).V7CloudPool(v7CloudPool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudPool := *openapiclient.NewV7CloudPool([]string{"Accounts_example"}, "Name_example", "Type_example") // V7CloudPool | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.CreateCloudv7CloudPool(context.Background()).V7CloudPool(v7CloudPool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.CreateCloudv7CloudPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateCloudv7CloudPool`: Createv7CloudPoolResponse
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.CreateCloudv7CloudPool`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateCloudv7CloudPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7CloudPool** | [**V7CloudPool**](V7CloudPool.md) |  | 

### Return type

[**Createv7CloudPoolResponse**](Createv7CloudPoolResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCloudv3CloudAccessGuid

> DeleteCloudv3CloudAccessGuid(ctx, v3CloudAccessGuid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3CloudAccessGuid := "v3CloudAccessGuid_example" // string | Delete cloud access.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.DeleteCloudv3CloudAccessGuid(context.Background(), v3CloudAccessGuid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.DeleteCloudv3CloudAccessGuid``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3CloudAccessGuid** | **string** | Delete cloud access. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteCloudv3CloudAccessGuidRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCloudv3SettingsReportingEula

> DeleteCloudv3SettingsReportingEula(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.DeleteCloudv3SettingsReportingEula(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.DeleteCloudv3SettingsReportingEula``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteCloudv3SettingsReportingEulaRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCloudv4CloudProxy

> DeleteCloudv4CloudProxy(ctx, v4CloudProxyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4CloudProxyId := "v4CloudProxyId_example" // string | Delete cloud account.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.DeleteCloudv4CloudProxy(context.Background(), v4CloudProxyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.DeleteCloudv4CloudProxy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4CloudProxyId** | **string** | Delete cloud account. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteCloudv4CloudProxyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCloudv7CloudAccount

> DeleteCloudv7CloudAccount(ctx, v7CloudAccountId).AcknowledgeForceDelete(acknowledgeForceDelete).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudAccountId := "v7CloudAccountId_example" // string | Delete cloud account.
    acknowledgeForceDelete := "acknowledgeForceDelete_example" // string | A value of 1 acknowledges that the user is deleting data. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.DeleteCloudv7CloudAccount(context.Background(), v7CloudAccountId).AcknowledgeForceDelete(acknowledgeForceDelete).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.DeleteCloudv7CloudAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CloudAccountId** | **string** | Delete cloud account. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteCloudv7CloudAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **acknowledgeForceDelete** | **string** | A value of 1 acknowledges that the user is deleting data. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCloudv7CloudCertificate

> DeleteCloudv7CloudCertificate(ctx, v7CloudCertificateId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudCertificateId := "v7CloudCertificateId_example" // string | Delete a CloudPools TLS client certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.DeleteCloudv7CloudCertificate(context.Background(), v7CloudCertificateId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.DeleteCloudv7CloudCertificate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CloudCertificateId** | **string** | Delete a CloudPools TLS client certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteCloudv7CloudCertificateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteCloudv7CloudPool

> DeleteCloudv7CloudPool(ctx, v7CloudPoolId).AcknowledgeForceDelete(acknowledgeForceDelete).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudPoolId := "v7CloudPoolId_example" // string | Delete a cloud pool.
    acknowledgeForceDelete := "acknowledgeForceDelete_example" // string | A value of 1 acknowledges that the user is deleting data. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.DeleteCloudv7CloudPool(context.Background(), v7CloudPoolId).AcknowledgeForceDelete(acknowledgeForceDelete).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.DeleteCloudv7CloudPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CloudPoolId** | **string** | Delete a cloud pool. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteCloudv7CloudPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **acknowledgeForceDelete** | **string** | A value of 1 acknowledges that the user is deleting data. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCloudv3CloudAccessGuid

> V3CloudAccessExtended GetCloudv3CloudAccessGuid(ctx, v3CloudAccessGuid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3CloudAccessGuid := "v3CloudAccessGuid_example" // string | Retrieve cloud access information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.GetCloudv3CloudAccessGuid(context.Background(), v3CloudAccessGuid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.GetCloudv3CloudAccessGuid``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCloudv3CloudAccessGuid`: V3CloudAccessExtended
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.GetCloudv3CloudAccessGuid`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3CloudAccessGuid** | **string** | Retrieve cloud access information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetCloudv3CloudAccessGuidRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3CloudAccessExtended**](V3CloudAccessExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCloudv3CloudJob

> V3CloudJobsExtended GetCloudv3CloudJob(ctx, v3CloudJobId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3CloudJobId := "v3CloudJobId_example" // string | Retrieve cloudpool job information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.GetCloudv3CloudJob(context.Background(), v3CloudJobId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.GetCloudv3CloudJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCloudv3CloudJob`: V3CloudJobsExtended
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.GetCloudv3CloudJob`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3CloudJobId** | **string** | Retrieve cloudpool job information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetCloudv3CloudJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3CloudJobsExtended**](V3CloudJobsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCloudv3CloudJobsFile

> V3CloudJobsFiles GetCloudv3CloudJobsFile(ctx, v3CloudJobsFileId).Sort(sort).Resume(resume).Limit(limit).Offset(offset).Page(page).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3CloudJobsFileId := "v3CloudJobsFileId_example" // string | Retrieve files associated with a cloudpool job.
    sort := "sort_example" // string | The field that will be used for sorting. Output is limited to maximum of 100000 files. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Number of files to display; range from 1 to 100000. (optional)
    offset := int32(56) // int32 | Specifies the starting entry to be displayed. (optional)
    page := int32(56) // int32 | Used with limit option. If exists, specifies the starting page to display where page size is specified by limit. This option will be deprecated; please use offset option instead. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.GetCloudv3CloudJobsFile(context.Background(), v3CloudJobsFileId).Sort(sort).Resume(resume).Limit(limit).Offset(offset).Page(page).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.GetCloudv3CloudJobsFile``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCloudv3CloudJobsFile`: V3CloudJobsFiles
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.GetCloudv3CloudJobsFile`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3CloudJobsFileId** | **string** | Retrieve files associated with a cloudpool job. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetCloudv3CloudJobsFileRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. Output is limited to maximum of 100000 files. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Number of files to display; range from 1 to 100000. | 
 **offset** | **int32** | Specifies the starting entry to be displayed. | 
 **page** | **int32** | Used with limit option. If exists, specifies the starting page to display where page size is specified by limit. This option will be deprecated; please use offset option instead. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3CloudJobsFiles**](V3CloudJobsFiles.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCloudv3CloudSettings

> V3CloudSettings GetCloudv3CloudSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.GetCloudv3CloudSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.GetCloudv3CloudSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCloudv3CloudSettings`: V3CloudSettings
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.GetCloudv3CloudSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetCloudv3CloudSettingsRequest struct via the builder pattern


### Return type

[**V3CloudSettings**](V3CloudSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCloudv4CloudProxy

> V4CloudProxiesExtended GetCloudv4CloudProxy(ctx, v4CloudProxyId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4CloudProxyId := "v4CloudProxyId_example" // string | Retrieve cloud account information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.GetCloudv4CloudProxy(context.Background(), v4CloudProxyId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.GetCloudv4CloudProxy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCloudv4CloudProxy`: V4CloudProxiesExtended
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.GetCloudv4CloudProxy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4CloudProxyId** | **string** | Retrieve cloud account information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetCloudv4CloudProxyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V4CloudProxiesExtended**](V4CloudProxiesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCloudv7CloudAccount

> V7CloudAccountsExtended GetCloudv7CloudAccount(ctx, v7CloudAccountId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudAccountId := "v7CloudAccountId_example" // string | Retrieve cloud account information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.GetCloudv7CloudAccount(context.Background(), v7CloudAccountId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.GetCloudv7CloudAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCloudv7CloudAccount`: V7CloudAccountsExtended
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.GetCloudv7CloudAccount`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CloudAccountId** | **string** | Retrieve cloud account information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetCloudv7CloudAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7CloudAccountsExtended**](V7CloudAccountsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCloudv7CloudCertificate

> V16CertificatesSyslogExtended GetCloudv7CloudCertificate(ctx, v7CloudCertificateId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudCertificateId := "v7CloudCertificateId_example" // string | Retrieve a CloudPools TLS client certificate.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.GetCloudv7CloudCertificate(context.Background(), v7CloudCertificateId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.GetCloudv7CloudCertificate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCloudv7CloudCertificate`: V16CertificatesSyslogExtended
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.GetCloudv7CloudCertificate`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CloudCertificateId** | **string** | Retrieve a CloudPools TLS client certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetCloudv7CloudCertificateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V16CertificatesSyslogExtended**](V16CertificatesSyslogExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetCloudv7CloudPool

> V7CloudPoolsExtended GetCloudv7CloudPool(ctx, v7CloudPoolId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudPoolId := "v7CloudPoolId_example" // string | Retrieve cloud pool information

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.GetCloudv7CloudPool(context.Background(), v7CloudPoolId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.GetCloudv7CloudPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetCloudv7CloudPool`: V7CloudPoolsExtended
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.GetCloudv7CloudPool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CloudPoolId** | **string** | Retrieve cloud pool information | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetCloudv7CloudPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7CloudPoolsExtended**](V7CloudPoolsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCloudv3CloudAccess

> V3CloudAccess ListCloudv3CloudAccess(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.ListCloudv3CloudAccess(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.ListCloudv3CloudAccess``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListCloudv3CloudAccess`: V3CloudAccess
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.ListCloudv3CloudAccess`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListCloudv3CloudAccessRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3CloudAccess**](V3CloudAccess.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCloudv3CloudJobs

> V3CloudJobs ListCloudv3CloudJobs(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.ListCloudv3CloudJobs(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.ListCloudv3CloudJobs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListCloudv3CloudJobs`: V3CloudJobs
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.ListCloudv3CloudJobs`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListCloudv3CloudJobsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3CloudJobs**](V3CloudJobs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCloudv3SettingsReportingEula

> V3SettingsReportingEula ListCloudv3SettingsReportingEula(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.ListCloudv3SettingsReportingEula(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.ListCloudv3SettingsReportingEula``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListCloudv3SettingsReportingEula`: V3SettingsReportingEula
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.ListCloudv3SettingsReportingEula`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListCloudv3SettingsReportingEulaRequest struct via the builder pattern


### Return type

[**V3SettingsReportingEula**](V3SettingsReportingEula.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCloudv4CloudProxies

> V4CloudProxies ListCloudv4CloudProxies(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.ListCloudv4CloudProxies(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.ListCloudv4CloudProxies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListCloudv4CloudProxies`: V4CloudProxies
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.ListCloudv4CloudProxies`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListCloudv4CloudProxiesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V4CloudProxies**](V4CloudProxies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCloudv7CloudAccounts

> V7CloudAccounts ListCloudv7CloudAccounts(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.ListCloudv7CloudAccounts(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.ListCloudv7CloudAccounts``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListCloudv7CloudAccounts`: V7CloudAccounts
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.ListCloudv7CloudAccounts`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListCloudv7CloudAccountsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7CloudAccounts**](V7CloudAccounts.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCloudv7CloudCertificates

> V7CloudCertificates ListCloudv7CloudCertificates(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.ListCloudv7CloudCertificates(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.ListCloudv7CloudCertificates``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListCloudv7CloudCertificates`: V7CloudCertificates
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.ListCloudv7CloudCertificates`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListCloudv7CloudCertificatesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7CloudCertificates**](V7CloudCertificates.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListCloudv7CloudPools

> V7CloudPools ListCloudv7CloudPools(ctx).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.CloudApi.ListCloudv7CloudPools(context.Background()).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.ListCloudv7CloudPools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListCloudv7CloudPools`: V7CloudPools
    fmt.Fprintf(os.Stdout, "Response from `CloudApi.ListCloudv7CloudPools`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListCloudv7CloudPoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7CloudPools**](V7CloudPools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCloudv3CloudJob

> UpdateCloudv3CloudJob(ctx, v3CloudJobId).V3CloudJob(v3CloudJob).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3CloudJobId := "v3CloudJobId_example" // string | Modify a cloud job or operation.
    v3CloudJob := *openapiclient.NewV3CloudJobExtendedExtended() // V3CloudJobExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.UpdateCloudv3CloudJob(context.Background(), v3CloudJobId).V3CloudJob(v3CloudJob).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.UpdateCloudv3CloudJob``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3CloudJobId** | **string** | Modify a cloud job or operation. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCloudv3CloudJobRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3CloudJob** | [**V3CloudJobExtendedExtended**](V3CloudJobExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCloudv3CloudSettings

> UpdateCloudv3CloudSettings(ctx).V3CloudSettings(v3CloudSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3CloudSettings := *openapiclient.NewV3CloudSettingsSettings() // V3CloudSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.UpdateCloudv3CloudSettings(context.Background()).V3CloudSettings(v3CloudSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.UpdateCloudv3CloudSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCloudv3CloudSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3CloudSettings** | [**V3CloudSettingsSettings**](V3CloudSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCloudv4CloudProxy

> UpdateCloudv4CloudProxy(ctx, v4CloudProxyId).V4CloudProxy(v4CloudProxy).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v4CloudProxyId := "v4CloudProxyId_example" // string | Modify cloud account.  All fields are optional, but one or more must be supplied.
    v4CloudProxy := *openapiclient.NewV4CloudProxyExtendedExtended() // V4CloudProxyExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.UpdateCloudv4CloudProxy(context.Background(), v4CloudProxyId).V4CloudProxy(v4CloudProxy).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.UpdateCloudv4CloudProxy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v4CloudProxyId** | **string** | Modify cloud account.  All fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCloudv4CloudProxyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v4CloudProxy** | [**V4CloudProxyExtendedExtended**](V4CloudProxyExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCloudv7CloudAccount

> UpdateCloudv7CloudAccount(ctx, v7CloudAccountId).V7CloudAccount(v7CloudAccount).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudAccountId := "v7CloudAccountId_example" // string | Modify cloud account.  All fields are optional, but one or more must be supplied.
    v7CloudAccount := *openapiclient.NewV7CloudAccountExtendedExtended() // V7CloudAccountExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.UpdateCloudv7CloudAccount(context.Background(), v7CloudAccountId).V7CloudAccount(v7CloudAccount).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.UpdateCloudv7CloudAccount``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CloudAccountId** | **string** | Modify cloud account.  All fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCloudv7CloudAccountRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7CloudAccount** | [**V7CloudAccountExtendedExtended**](V7CloudAccountExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCloudv7CloudCertificate

> UpdateCloudv7CloudCertificate(ctx, v7CloudCertificateId).V7CloudCertificate(v7CloudCertificate).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudCertificateId := "v7CloudCertificateId_example" // string | Modify a CloudPools TLS client certificate.
    v7CloudCertificate := *openapiclient.NewV16CertificatesSyslogIdParams() // V16CertificatesSyslogIdParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.UpdateCloudv7CloudCertificate(context.Background(), v7CloudCertificateId).V7CloudCertificate(v7CloudCertificate).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.UpdateCloudv7CloudCertificate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CloudCertificateId** | **string** | Modify a CloudPools TLS client certificate. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCloudv7CloudCertificateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7CloudCertificate** | [**V16CertificatesSyslogIdParams**](V16CertificatesSyslogIdParams.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateCloudv7CloudPool

> UpdateCloudv7CloudPool(ctx, v7CloudPoolId).V7CloudPool(v7CloudPool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7CloudPoolId := "v7CloudPoolId_example" // string | Modify a cloud pool.  All fields are optional, but one or more must be supplied.
    v7CloudPool := *openapiclient.NewV7CloudPoolExtendedExtended() // V7CloudPoolExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.CloudApi.UpdateCloudv7CloudPool(context.Background(), v7CloudPoolId).V7CloudPool(v7CloudPool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `CloudApi.UpdateCloudv7CloudPool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7CloudPoolId** | **string** | Modify a cloud pool.  All fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateCloudv7CloudPoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7CloudPool** | [**V7CloudPoolExtendedExtended**](V7CloudPoolExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

