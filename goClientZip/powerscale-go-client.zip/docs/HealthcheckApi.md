# \HealthcheckApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateHealthcheckv10HealthcheckEvaluation**](HealthcheckApi.md#CreateHealthcheckv10HealthcheckEvaluation) | **Post** /platform/10/healthcheck/evaluations | 
[**CreateHealthcheckv10HealthcheckSchedule**](HealthcheckApi.md#CreateHealthcheckv10HealthcheckSchedule) | **Post** /platform/10/healthcheck/schedules | 
[**CreateHealthcheckv3HealthcheckEvaluation**](HealthcheckApi.md#CreateHealthcheckv3HealthcheckEvaluation) | **Post** /platform/3/healthcheck/evaluations | 
[**CreateHealthcheckv3HealthcheckParameter**](HealthcheckApi.md#CreateHealthcheckv3HealthcheckParameter) | **Post** /platform/3/healthcheck/parameters | 
[**DeleteHealthcheckv10HealthcheckEvaluation**](HealthcheckApi.md#DeleteHealthcheckv10HealthcheckEvaluation) | **Delete** /platform/10/healthcheck/evaluations/{v10HealthcheckEvaluationId} | 
[**DeleteHealthcheckv10HealthcheckSchedule**](HealthcheckApi.md#DeleteHealthcheckv10HealthcheckSchedule) | **Delete** /platform/10/healthcheck/schedules/{v10HealthcheckScheduleId} | 
[**DeleteHealthcheckv3HealthcheckEvaluation**](HealthcheckApi.md#DeleteHealthcheckv3HealthcheckEvaluation) | **Delete** /platform/3/healthcheck/evaluations/{v3HealthcheckEvaluationId} | 
[**DeleteHealthcheckv3HealthcheckParameter**](HealthcheckApi.md#DeleteHealthcheckv3HealthcheckParameter) | **Delete** /platform/3/healthcheck/parameters/{v3HealthcheckParameterId} | 
[**GetHealthcheckv10HealthcheckChecklist**](HealthcheckApi.md#GetHealthcheckv10HealthcheckChecklist) | **Get** /platform/10/healthcheck/checklists/{v10HealthcheckChecklistId} | 
[**GetHealthcheckv10HealthcheckChecklists**](HealthcheckApi.md#GetHealthcheckv10HealthcheckChecklists) | **Get** /platform/10/healthcheck/checklists | 
[**GetHealthcheckv10HealthcheckEvaluation**](HealthcheckApi.md#GetHealthcheckv10HealthcheckEvaluation) | **Get** /platform/10/healthcheck/evaluations/{v10HealthcheckEvaluationId} | 
[**GetHealthcheckv10HealthcheckSchedule**](HealthcheckApi.md#GetHealthcheckv10HealthcheckSchedule) | **Get** /platform/10/healthcheck/schedules/{v10HealthcheckScheduleId} | 
[**GetHealthcheckv3HealthcheckChecklist**](HealthcheckApi.md#GetHealthcheckv3HealthcheckChecklist) | **Get** /platform/3/healthcheck/checklists/{v3HealthcheckChecklistId} | 
[**GetHealthcheckv3HealthcheckChecklists**](HealthcheckApi.md#GetHealthcheckv3HealthcheckChecklists) | **Get** /platform/3/healthcheck/checklists | 
[**GetHealthcheckv3HealthcheckEvaluation**](HealthcheckApi.md#GetHealthcheckv3HealthcheckEvaluation) | **Get** /platform/3/healthcheck/evaluations/{v3HealthcheckEvaluationId} | 
[**GetHealthcheckv3HealthcheckItem**](HealthcheckApi.md#GetHealthcheckv3HealthcheckItem) | **Get** /platform/3/healthcheck/items/{v3HealthcheckItemId} | 
[**GetHealthcheckv3HealthcheckItems**](HealthcheckApi.md#GetHealthcheckv3HealthcheckItems) | **Get** /platform/3/healthcheck/items | 
[**GetHealthcheckv3HealthcheckParameter**](HealthcheckApi.md#GetHealthcheckv3HealthcheckParameter) | **Get** /platform/3/healthcheck/parameters/{v3HealthcheckParameterId} | 
[**ListHealthcheckv10HealthcheckEvaluations**](HealthcheckApi.md#ListHealthcheckv10HealthcheckEvaluations) | **Get** /platform/10/healthcheck/evaluations | 
[**ListHealthcheckv10HealthcheckSchedules**](HealthcheckApi.md#ListHealthcheckv10HealthcheckSchedules) | **Get** /platform/10/healthcheck/schedules | 
[**ListHealthcheckv3HealthcheckEvaluations**](HealthcheckApi.md#ListHealthcheckv3HealthcheckEvaluations) | **Get** /platform/3/healthcheck/evaluations | 
[**ListHealthcheckv3HealthcheckParameters**](HealthcheckApi.md#ListHealthcheckv3HealthcheckParameters) | **Get** /platform/3/healthcheck/parameters | 
[**UpdateHealthcheckv10HealthcheckChecklist**](HealthcheckApi.md#UpdateHealthcheckv10HealthcheckChecklist) | **Put** /platform/10/healthcheck/checklists/{v10HealthcheckChecklistId} | 
[**UpdateHealthcheckv10HealthcheckEvaluation**](HealthcheckApi.md#UpdateHealthcheckv10HealthcheckEvaluation) | **Put** /platform/10/healthcheck/evaluations/{v10HealthcheckEvaluationId} | 
[**UpdateHealthcheckv10HealthcheckSchedule**](HealthcheckApi.md#UpdateHealthcheckv10HealthcheckSchedule) | **Put** /platform/10/healthcheck/schedules/{v10HealthcheckScheduleId} | 
[**UpdateHealthcheckv3HealthcheckEvaluation**](HealthcheckApi.md#UpdateHealthcheckv3HealthcheckEvaluation) | **Put** /platform/3/healthcheck/evaluations/{v3HealthcheckEvaluationId} | 
[**UpdateHealthcheckv3HealthcheckParameter**](HealthcheckApi.md#UpdateHealthcheckv3HealthcheckParameter) | **Put** /platform/3/healthcheck/parameters/{v3HealthcheckParameterId} | 



## CreateHealthcheckv10HealthcheckEvaluation

> CreateResponse CreateHealthcheckv10HealthcheckEvaluation(ctx).V10HealthcheckEvaluation(v10HealthcheckEvaluation).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10HealthcheckEvaluation := *openapiclient.NewV10HealthcheckEvaluation("ChecklistId_example") // V10HealthcheckEvaluation | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.CreateHealthcheckv10HealthcheckEvaluation(context.Background()).V10HealthcheckEvaluation(v10HealthcheckEvaluation).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.CreateHealthcheckv10HealthcheckEvaluation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHealthcheckv10HealthcheckEvaluation`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.CreateHealthcheckv10HealthcheckEvaluation`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateHealthcheckv10HealthcheckEvaluationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10HealthcheckEvaluation** | [**V10HealthcheckEvaluation**](V10HealthcheckEvaluation.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateHealthcheckv10HealthcheckSchedule

> CreateResponse CreateHealthcheckv10HealthcheckSchedule(ctx).V10HealthcheckSchedule(v10HealthcheckSchedule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10HealthcheckSchedule := *openapiclient.NewV10HealthcheckSchedule([]string{"Checklist_example"}, "Name_example", "Schedule_example") // V10HealthcheckSchedule | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.CreateHealthcheckv10HealthcheckSchedule(context.Background()).V10HealthcheckSchedule(v10HealthcheckSchedule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.CreateHealthcheckv10HealthcheckSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHealthcheckv10HealthcheckSchedule`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.CreateHealthcheckv10HealthcheckSchedule`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateHealthcheckv10HealthcheckScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v10HealthcheckSchedule** | [**V10HealthcheckSchedule**](V10HealthcheckSchedule.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateHealthcheckv3HealthcheckEvaluation

> CreateResponse CreateHealthcheckv3HealthcheckEvaluation(ctx).V3HealthcheckEvaluation(v3HealthcheckEvaluation).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HealthcheckEvaluation := *openapiclient.NewV3HealthcheckEvaluation("ChecklistId_example") // V3HealthcheckEvaluation | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.CreateHealthcheckv3HealthcheckEvaluation(context.Background()).V3HealthcheckEvaluation(v3HealthcheckEvaluation).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.CreateHealthcheckv3HealthcheckEvaluation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHealthcheckv3HealthcheckEvaluation`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.CreateHealthcheckv3HealthcheckEvaluation`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateHealthcheckv3HealthcheckEvaluationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3HealthcheckEvaluation** | [**V3HealthcheckEvaluation**](V3HealthcheckEvaluation.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateHealthcheckv3HealthcheckParameter

> CreateResponse CreateHealthcheckv3HealthcheckParameter(ctx).V3HealthcheckParameter(v3HealthcheckParameter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HealthcheckParameter := *openapiclient.NewV3HealthcheckParameter("Name_example", "Value_example") // V3HealthcheckParameter | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.CreateHealthcheckv3HealthcheckParameter(context.Background()).V3HealthcheckParameter(v3HealthcheckParameter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.CreateHealthcheckv3HealthcheckParameter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateHealthcheckv3HealthcheckParameter`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.CreateHealthcheckv3HealthcheckParameter`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateHealthcheckv3HealthcheckParameterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3HealthcheckParameter** | [**V3HealthcheckParameter**](V3HealthcheckParameter.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteHealthcheckv10HealthcheckEvaluation

> DeleteHealthcheckv10HealthcheckEvaluation(ctx, v10HealthcheckEvaluationId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10HealthcheckEvaluationId := "v10HealthcheckEvaluationId_example" // string | Cancel an evaluation.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HealthcheckApi.DeleteHealthcheckv10HealthcheckEvaluation(context.Background(), v10HealthcheckEvaluationId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.DeleteHealthcheckv10HealthcheckEvaluation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10HealthcheckEvaluationId** | **string** | Cancel an evaluation. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteHealthcheckv10HealthcheckEvaluationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteHealthcheckv10HealthcheckSchedule

> DeleteHealthcheckv10HealthcheckSchedule(ctx, v10HealthcheckScheduleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10HealthcheckScheduleId := "v10HealthcheckScheduleId_example" // string | Delete a schedule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HealthcheckApi.DeleteHealthcheckv10HealthcheckSchedule(context.Background(), v10HealthcheckScheduleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.DeleteHealthcheckv10HealthcheckSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10HealthcheckScheduleId** | **string** | Delete a schedule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteHealthcheckv10HealthcheckScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteHealthcheckv3HealthcheckEvaluation

> DeleteHealthcheckv3HealthcheckEvaluation(ctx, v3HealthcheckEvaluationId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HealthcheckEvaluationId := "v3HealthcheckEvaluationId_example" // string | Cancel an evaluation.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HealthcheckApi.DeleteHealthcheckv3HealthcheckEvaluation(context.Background(), v3HealthcheckEvaluationId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.DeleteHealthcheckv3HealthcheckEvaluation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HealthcheckEvaluationId** | **string** | Cancel an evaluation. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteHealthcheckv3HealthcheckEvaluationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteHealthcheckv3HealthcheckParameter

> DeleteHealthcheckv3HealthcheckParameter(ctx, v3HealthcheckParameterId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HealthcheckParameterId := "v3HealthcheckParameterId_example" // string | Delete a parameter.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HealthcheckApi.DeleteHealthcheckv3HealthcheckParameter(context.Background(), v3HealthcheckParameterId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.DeleteHealthcheckv3HealthcheckParameter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HealthcheckParameterId** | **string** | Delete a parameter. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteHealthcheckv3HealthcheckParameterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHealthcheckv10HealthcheckChecklist

> V10HealthcheckChecklistsExtended GetHealthcheckv10HealthcheckChecklist(ctx, v10HealthcheckChecklistId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10HealthcheckChecklistId := "v10HealthcheckChecklistId_example" // string | Retrieve a checklist definition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.GetHealthcheckv10HealthcheckChecklist(context.Background(), v10HealthcheckChecklistId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.GetHealthcheckv10HealthcheckChecklist``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHealthcheckv10HealthcheckChecklist`: V10HealthcheckChecklistsExtended
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.GetHealthcheckv10HealthcheckChecklist`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10HealthcheckChecklistId** | **string** | Retrieve a checklist definition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetHealthcheckv10HealthcheckChecklistRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10HealthcheckChecklistsExtended**](V10HealthcheckChecklistsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHealthcheckv10HealthcheckChecklists

> V10HealthcheckChecklists GetHealthcheckv10HealthcheckChecklists(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.GetHealthcheckv10HealthcheckChecklists(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.GetHealthcheckv10HealthcheckChecklists``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHealthcheckv10HealthcheckChecklists`: V10HealthcheckChecklists
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.GetHealthcheckv10HealthcheckChecklists`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetHealthcheckv10HealthcheckChecklistsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V10HealthcheckChecklists**](V10HealthcheckChecklists.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHealthcheckv10HealthcheckEvaluation

> V10HealthcheckEvaluationsExtended GetHealthcheckv10HealthcheckEvaluation(ctx, v10HealthcheckEvaluationId).Detailed(detailed).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10HealthcheckEvaluationId := "v10HealthcheckEvaluationId_example" // string | Retrieve individual evaluation.
    detailed := true // bool | Also return details for items that pass (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.GetHealthcheckv10HealthcheckEvaluation(context.Background(), v10HealthcheckEvaluationId).Detailed(detailed).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.GetHealthcheckv10HealthcheckEvaluation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHealthcheckv10HealthcheckEvaluation`: V10HealthcheckEvaluationsExtended
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.GetHealthcheckv10HealthcheckEvaluation`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10HealthcheckEvaluationId** | **string** | Retrieve individual evaluation. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetHealthcheckv10HealthcheckEvaluationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **detailed** | **bool** | Also return details for items that pass | 

### Return type

[**V10HealthcheckEvaluationsExtended**](V10HealthcheckEvaluationsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHealthcheckv10HealthcheckSchedule

> V10HealthcheckSchedulesExtended GetHealthcheckv10HealthcheckSchedule(ctx, v10HealthcheckScheduleId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10HealthcheckScheduleId := "v10HealthcheckScheduleId_example" // string | Retrieve individual schedule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.GetHealthcheckv10HealthcheckSchedule(context.Background(), v10HealthcheckScheduleId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.GetHealthcheckv10HealthcheckSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHealthcheckv10HealthcheckSchedule`: V10HealthcheckSchedulesExtended
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.GetHealthcheckv10HealthcheckSchedule`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10HealthcheckScheduleId** | **string** | Retrieve individual schedule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetHealthcheckv10HealthcheckScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10HealthcheckSchedulesExtended**](V10HealthcheckSchedulesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHealthcheckv3HealthcheckChecklist

> V10HealthcheckChecklistsExtended GetHealthcheckv3HealthcheckChecklist(ctx, v3HealthcheckChecklistId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HealthcheckChecklistId := "v3HealthcheckChecklistId_example" // string | Retrieve a checklist definition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.GetHealthcheckv3HealthcheckChecklist(context.Background(), v3HealthcheckChecklistId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.GetHealthcheckv3HealthcheckChecklist``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHealthcheckv3HealthcheckChecklist`: V10HealthcheckChecklistsExtended
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.GetHealthcheckv3HealthcheckChecklist`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HealthcheckChecklistId** | **string** | Retrieve a checklist definition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetHealthcheckv3HealthcheckChecklistRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10HealthcheckChecklistsExtended**](V10HealthcheckChecklistsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHealthcheckv3HealthcheckChecklists

> V10HealthcheckChecklists GetHealthcheckv3HealthcheckChecklists(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.GetHealthcheckv3HealthcheckChecklists(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.GetHealthcheckv3HealthcheckChecklists``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHealthcheckv3HealthcheckChecklists`: V10HealthcheckChecklists
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.GetHealthcheckv3HealthcheckChecklists`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetHealthcheckv3HealthcheckChecklistsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V10HealthcheckChecklists**](V10HealthcheckChecklists.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHealthcheckv3HealthcheckEvaluation

> V3HealthcheckEvaluationsExtended GetHealthcheckv3HealthcheckEvaluation(ctx, v3HealthcheckEvaluationId).Detailed(detailed).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HealthcheckEvaluationId := "v3HealthcheckEvaluationId_example" // string | Retrieve individual evaluation.
    detailed := true // bool | Also return details for items that pass (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.GetHealthcheckv3HealthcheckEvaluation(context.Background(), v3HealthcheckEvaluationId).Detailed(detailed).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.GetHealthcheckv3HealthcheckEvaluation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHealthcheckv3HealthcheckEvaluation`: V3HealthcheckEvaluationsExtended
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.GetHealthcheckv3HealthcheckEvaluation`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HealthcheckEvaluationId** | **string** | Retrieve individual evaluation. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetHealthcheckv3HealthcheckEvaluationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **detailed** | **bool** | Also return details for items that pass | 

### Return type

[**V3HealthcheckEvaluationsExtended**](V3HealthcheckEvaluationsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHealthcheckv3HealthcheckItem

> V3HealthcheckItemsExtended GetHealthcheckv3HealthcheckItem(ctx, v3HealthcheckItemId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HealthcheckItemId := "v3HealthcheckItemId_example" // string | Retrieve an item definition.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.GetHealthcheckv3HealthcheckItem(context.Background(), v3HealthcheckItemId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.GetHealthcheckv3HealthcheckItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHealthcheckv3HealthcheckItem`: V3HealthcheckItemsExtended
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.GetHealthcheckv3HealthcheckItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HealthcheckItemId** | **string** | Retrieve an item definition. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetHealthcheckv3HealthcheckItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3HealthcheckItemsExtended**](V3HealthcheckItemsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHealthcheckv3HealthcheckItems

> V3HealthcheckItems GetHealthcheckv3HealthcheckItems(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.GetHealthcheckv3HealthcheckItems(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.GetHealthcheckv3HealthcheckItems``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHealthcheckv3HealthcheckItems`: V3HealthcheckItems
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.GetHealthcheckv3HealthcheckItems`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetHealthcheckv3HealthcheckItemsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3HealthcheckItems**](V3HealthcheckItems.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetHealthcheckv3HealthcheckParameter

> V3HealthcheckParametersExtended GetHealthcheckv3HealthcheckParameter(ctx, v3HealthcheckParameterId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HealthcheckParameterId := "v3HealthcheckParameterId_example" // string | Retrieve individual parameter.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.GetHealthcheckv3HealthcheckParameter(context.Background(), v3HealthcheckParameterId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.GetHealthcheckv3HealthcheckParameter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetHealthcheckv3HealthcheckParameter`: V3HealthcheckParametersExtended
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.GetHealthcheckv3HealthcheckParameter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HealthcheckParameterId** | **string** | Retrieve individual parameter. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetHealthcheckv3HealthcheckParameterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3HealthcheckParametersExtended**](V3HealthcheckParametersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListHealthcheckv10HealthcheckEvaluations

> V10HealthcheckEvaluations ListHealthcheckv10HealthcheckEvaluations(ctx).Detailed(detailed).Resume(resume).Limit(limit).Level(level).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    detailed := true // bool | Also return details for items that pass (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    level := "level_example" // string | Content detail level (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.ListHealthcheckv10HealthcheckEvaluations(context.Background()).Detailed(detailed).Resume(resume).Limit(limit).Level(level).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.ListHealthcheckv10HealthcheckEvaluations``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListHealthcheckv10HealthcheckEvaluations`: V10HealthcheckEvaluations
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.ListHealthcheckv10HealthcheckEvaluations`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListHealthcheckv10HealthcheckEvaluationsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **detailed** | **bool** | Also return details for items that pass | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **level** | **string** | Content detail level | 

### Return type

[**V10HealthcheckEvaluations**](V10HealthcheckEvaluations.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListHealthcheckv10HealthcheckSchedules

> V10HealthcheckSchedules ListHealthcheckv10HealthcheckSchedules(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.ListHealthcheckv10HealthcheckSchedules(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.ListHealthcheckv10HealthcheckSchedules``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListHealthcheckv10HealthcheckSchedules`: V10HealthcheckSchedules
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.ListHealthcheckv10HealthcheckSchedules`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListHealthcheckv10HealthcheckSchedulesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V10HealthcheckSchedules**](V10HealthcheckSchedules.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListHealthcheckv3HealthcheckEvaluations

> V3HealthcheckEvaluations ListHealthcheckv3HealthcheckEvaluations(ctx).Detailed(detailed).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    detailed := true // bool | Also return details for items that pass (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.ListHealthcheckv3HealthcheckEvaluations(context.Background()).Detailed(detailed).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.ListHealthcheckv3HealthcheckEvaluations``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListHealthcheckv3HealthcheckEvaluations`: V3HealthcheckEvaluations
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.ListHealthcheckv3HealthcheckEvaluations`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListHealthcheckv3HealthcheckEvaluationsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **detailed** | **bool** | Also return details for items that pass | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3HealthcheckEvaluations**](V3HealthcheckEvaluations.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListHealthcheckv3HealthcheckParameters

> V3HealthcheckParameters ListHealthcheckv3HealthcheckParameters(ctx).Limit(limit).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.HealthcheckApi.ListHealthcheckv3HealthcheckParameters(context.Background()).Limit(limit).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.ListHealthcheckv3HealthcheckParameters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListHealthcheckv3HealthcheckParameters`: V3HealthcheckParameters
    fmt.Fprintf(os.Stdout, "Response from `HealthcheckApi.ListHealthcheckv3HealthcheckParameters`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListHealthcheckv3HealthcheckParametersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V3HealthcheckParameters**](V3HealthcheckParameters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateHealthcheckv10HealthcheckChecklist

> UpdateHealthcheckv10HealthcheckChecklist(ctx, v10HealthcheckChecklistId).V10HealthcheckChecklist(v10HealthcheckChecklist).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10HealthcheckChecklistId := "v10HealthcheckChecklistId_example" // string | Modify checklist default delivery.
    v10HealthcheckChecklist := *openapiclient.NewV10HealthcheckChecklistExtended() // V10HealthcheckChecklistExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HealthcheckApi.UpdateHealthcheckv10HealthcheckChecklist(context.Background(), v10HealthcheckChecklistId).V10HealthcheckChecklist(v10HealthcheckChecklist).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.UpdateHealthcheckv10HealthcheckChecklist``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10HealthcheckChecklistId** | **string** | Modify checklist default delivery. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateHealthcheckv10HealthcheckChecklistRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v10HealthcheckChecklist** | [**V10HealthcheckChecklistExtended**](V10HealthcheckChecklistExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateHealthcheckv10HealthcheckEvaluation

> UpdateHealthcheckv10HealthcheckEvaluation(ctx, v10HealthcheckEvaluationId).V10HealthcheckEvaluation(v10HealthcheckEvaluation).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10HealthcheckEvaluationId := "v10HealthcheckEvaluationId_example" // string | Pause or resume an evaluation.
    v10HealthcheckEvaluation := *openapiclient.NewV10HealthcheckEvaluationExtendedExtended() // V10HealthcheckEvaluationExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HealthcheckApi.UpdateHealthcheckv10HealthcheckEvaluation(context.Background(), v10HealthcheckEvaluationId).V10HealthcheckEvaluation(v10HealthcheckEvaluation).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.UpdateHealthcheckv10HealthcheckEvaluation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10HealthcheckEvaluationId** | **string** | Pause or resume an evaluation. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateHealthcheckv10HealthcheckEvaluationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v10HealthcheckEvaluation** | [**V10HealthcheckEvaluationExtendedExtended**](V10HealthcheckEvaluationExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateHealthcheckv10HealthcheckSchedule

> UpdateHealthcheckv10HealthcheckSchedule(ctx, v10HealthcheckScheduleId).V10HealthcheckSchedule(v10HealthcheckSchedule).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v10HealthcheckScheduleId := "v10HealthcheckScheduleId_example" // string | Modify a schedule value.
    v10HealthcheckSchedule := *openapiclient.NewV10HealthcheckScheduleExtendedExtended("Name_example") // V10HealthcheckScheduleExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HealthcheckApi.UpdateHealthcheckv10HealthcheckSchedule(context.Background(), v10HealthcheckScheduleId).V10HealthcheckSchedule(v10HealthcheckSchedule).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.UpdateHealthcheckv10HealthcheckSchedule``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v10HealthcheckScheduleId** | **string** | Modify a schedule value. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateHealthcheckv10HealthcheckScheduleRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v10HealthcheckSchedule** | [**V10HealthcheckScheduleExtendedExtended**](V10HealthcheckScheduleExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateHealthcheckv3HealthcheckEvaluation

> UpdateHealthcheckv3HealthcheckEvaluation(ctx, v3HealthcheckEvaluationId).V3HealthcheckEvaluation(v3HealthcheckEvaluation).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HealthcheckEvaluationId := "v3HealthcheckEvaluationId_example" // string | Pause or resume an evaluation.
    v3HealthcheckEvaluation := *openapiclient.NewV10HealthcheckEvaluationExtendedExtended() // V10HealthcheckEvaluationExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HealthcheckApi.UpdateHealthcheckv3HealthcheckEvaluation(context.Background(), v3HealthcheckEvaluationId).V3HealthcheckEvaluation(v3HealthcheckEvaluation).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.UpdateHealthcheckv3HealthcheckEvaluation``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HealthcheckEvaluationId** | **string** | Pause or resume an evaluation. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateHealthcheckv3HealthcheckEvaluationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3HealthcheckEvaluation** | [**V10HealthcheckEvaluationExtendedExtended**](V10HealthcheckEvaluationExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateHealthcheckv3HealthcheckParameter

> UpdateHealthcheckv3HealthcheckParameter(ctx, v3HealthcheckParameterId).V3HealthcheckParameter(v3HealthcheckParameter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3HealthcheckParameterId := "v3HealthcheckParameterId_example" // string | Modify a parameter value.
    v3HealthcheckParameter := *openapiclient.NewV3HealthcheckParameterExtendedExtended() // V3HealthcheckParameterExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.HealthcheckApi.UpdateHealthcheckv3HealthcheckParameter(context.Background(), v3HealthcheckParameterId).V3HealthcheckParameter(v3HealthcheckParameter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `HealthcheckApi.UpdateHealthcheckv3HealthcheckParameter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3HealthcheckParameterId** | **string** | Modify a parameter value. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateHealthcheckv3HealthcheckParameterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3HealthcheckParameter** | [**V3HealthcheckParameterExtendedExtended**](V3HealthcheckParameterExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

