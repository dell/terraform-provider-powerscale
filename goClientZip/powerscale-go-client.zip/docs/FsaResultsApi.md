# \FsaResultsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetFsaResultsv3HistogramStatBy**](FsaResultsApi.md#GetFsaResultsv3HistogramStatBy) | **Get** /platform/3/fsa/results/{Id}/histogram/{Stat}/by | 
[**GetFsaResultsv3ResultDirectories**](FsaResultsApi.md#GetFsaResultsv3ResultDirectories) | **Get** /platform/3/fsa/results/{Id}/directories | 
[**GetFsaResultsv3ResultHistogram**](FsaResultsApi.md#GetFsaResultsv3ResultHistogram) | **Get** /platform/3/fsa/results/{Id}/histogram | 
[**GetFsaResultsv3ResultTopDirs**](FsaResultsApi.md#GetFsaResultsv3ResultTopDirs) | **Get** /platform/3/fsa/results/{Id}/top-dirs | 
[**GetFsaResultsv3ResultTopFiles**](FsaResultsApi.md#GetFsaResultsv3ResultTopFiles) | **Get** /platform/3/fsa/results/{Id}/top-files | 
[**GetFsaResultsv9ResultDirPoolsUsage**](FsaResultsApi.md#GetFsaResultsv9ResultDirPoolsUsage) | **Get** /platform/9/fsa/results/{Id}/dir_pools_usage | 



## GetFsaResultsv3HistogramStatBy

> V3HistogramStatBy GetFsaResultsv3HistogramStatBy(ctx, id, stat).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 
    stat := "stat_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaResultsApi.GetFsaResultsv3HistogramStatBy(context.Background(), id, stat).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaResultsApi.GetFsaResultsv3HistogramStatBy``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsaResultsv3HistogramStatBy`: V3HistogramStatBy
    fmt.Fprintf(os.Stdout, "Response from `FsaResultsApi.GetFsaResultsv3HistogramStatBy`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 
**stat** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsaResultsv3HistogramStatByRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V3HistogramStatBy**](V3HistogramStatBy.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsaResultsv3ResultDirectories

> V3ResultDirectories GetFsaResultsv3ResultDirectories(ctx, id).Sort(sort).Path(path).Limit(limit).CompReport(compReport).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    path := "path_example" // string | Primary directory path to report usage information, which may be specified instead of a LIN. (optional)
    limit := int32(56) // int32 | Limit the number of reported subdirectories. (optional)
    compReport := int32(56) // int32 | Result set identifier for comparison of database results. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaResultsApi.GetFsaResultsv3ResultDirectories(context.Background(), id).Sort(sort).Path(path).Limit(limit).CompReport(compReport).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaResultsApi.GetFsaResultsv3ResultDirectories``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsaResultsv3ResultDirectories`: V3ResultDirectories
    fmt.Fprintf(os.Stdout, "Response from `FsaResultsApi.GetFsaResultsv3ResultDirectories`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsaResultsv3ResultDirectoriesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **path** | **string** | Primary directory path to report usage information, which may be specified instead of a LIN. | 
 **limit** | **int32** | Limit the number of reported subdirectories. | 
 **compReport** | **int32** | Result set identifier for comparison of database results. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3ResultDirectories**](V3ResultDirectories.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsaResultsv3ResultHistogram

> V3ResultHistogram GetFsaResultsv3ResultHistogram(ctx, id).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaResultsApi.GetFsaResultsv3ResultHistogram(context.Background(), id).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaResultsApi.GetFsaResultsv3ResultHistogram``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsaResultsv3ResultHistogram`: V3ResultHistogram
    fmt.Fprintf(os.Stdout, "Response from `FsaResultsApi.GetFsaResultsv3ResultHistogram`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsaResultsv3ResultHistogramRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3ResultHistogram**](V3ResultHistogram.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsaResultsv3ResultTopDirs

> V3ResultTopDirs GetFsaResultsv3ResultTopDirs(ctx, id).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaResultsApi.GetFsaResultsv3ResultTopDirs(context.Background(), id).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaResultsApi.GetFsaResultsv3ResultTopDirs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsaResultsv3ResultTopDirs`: V3ResultTopDirs
    fmt.Fprintf(os.Stdout, "Response from `FsaResultsApi.GetFsaResultsv3ResultTopDirs`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsaResultsv3ResultTopDirsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3ResultTopDirs**](V3ResultTopDirs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsaResultsv3ResultTopFiles

> V3ResultTopFiles GetFsaResultsv3ResultTopFiles(ctx, id).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaResultsApi.GetFsaResultsv3ResultTopFiles(context.Background(), id).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaResultsApi.GetFsaResultsv3ResultTopFiles``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsaResultsv3ResultTopFiles`: V3ResultTopFiles
    fmt.Fprintf(os.Stdout, "Response from `FsaResultsApi.GetFsaResultsv3ResultTopFiles`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsaResultsv3ResultTopFilesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3ResultTopFiles**](V3ResultTopFiles.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsaResultsv9ResultDirPoolsUsage

> V9ResultDirPoolsUsage GetFsaResultsv9ResultDirPoolsUsage(ctx, id).Path(path).CompReport(compReport).StoragePoolType(storagePoolType).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    id := "id_example" // string | 
    path := "path_example" // string |  Directory absolute path to report usage information. Path should be UTF8 percent encoded, should be within \"/ifs\". Defaults to \"/ifs\". (optional)
    compReport := int32(56) // int32 | Result set identifier for comparison of database results. (optional)
    storagePoolType := "storagePoolType_example" // string | The type of the storage pool. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaResultsApi.GetFsaResultsv9ResultDirPoolsUsage(context.Background(), id).Path(path).CompReport(compReport).StoragePoolType(storagePoolType).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaResultsApi.GetFsaResultsv9ResultDirPoolsUsage``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsaResultsv9ResultDirPoolsUsage`: V9ResultDirPoolsUsage
    fmt.Fprintf(os.Stdout, "Response from `FsaResultsApi.GetFsaResultsv9ResultDirPoolsUsage`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsaResultsv9ResultDirPoolsUsageRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **path** | **string** |  Directory absolute path to report usage information. Path should be UTF8 percent encoded, should be within \&quot;/ifs\&quot;. Defaults to \&quot;/ifs\&quot;. | 
 **compReport** | **int32** | Result set identifier for comparison of database results. | 
 **storagePoolType** | **string** | The type of the storage pool. | 

### Return type

[**V9ResultDirPoolsUsage**](V9ResultDirPoolsUsage.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

