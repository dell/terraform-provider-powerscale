# \SnapshotSnapshotsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateSnapshotSnapshotsv1SnapshotLock**](SnapshotSnapshotsApi.md#CreateSnapshotSnapshotsv1SnapshotLock) | **Post** /platform/1/snapshot/snapshots/{Sid}/locks | 
[**DeleteSnapshotSnapshotsv1SnapshotLocks**](SnapshotSnapshotsApi.md#DeleteSnapshotSnapshotsv1SnapshotLocks) | **Delete** /platform/1/snapshot/snapshots/{Sid}/locks | 
[**ListSnapshotSnapshotsv1SnapshotLocks**](SnapshotSnapshotsApi.md#ListSnapshotSnapshotsv1SnapshotLocks) | **Get** /platform/1/snapshot/snapshots/{Sid}/locks | 



## CreateSnapshotSnapshotsv1SnapshotLock

> Createv1SnapshotLockResponse CreateSnapshotSnapshotsv1SnapshotLock(ctx, sid).V1SnapshotLock(v1SnapshotLock).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sid := "sid_example" // string | 
    v1SnapshotLock := *openapiclient.NewV1SnapshotLock() // V1SnapshotLock | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotSnapshotsApi.CreateSnapshotSnapshotsv1SnapshotLock(context.Background(), sid).V1SnapshotLock(v1SnapshotLock).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotSnapshotsApi.CreateSnapshotSnapshotsv1SnapshotLock``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateSnapshotSnapshotsv1SnapshotLock`: Createv1SnapshotLockResponse
    fmt.Fprintf(os.Stdout, "Response from `SnapshotSnapshotsApi.CreateSnapshotSnapshotsv1SnapshotLock`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**sid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateSnapshotSnapshotsv1SnapshotLockRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SnapshotLock** | [**V1SnapshotLock**](V1SnapshotLock.md) |  | 

### Return type

[**Createv1SnapshotLockResponse**](Createv1SnapshotLockResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteSnapshotSnapshotsv1SnapshotLocks

> DeleteSnapshotSnapshotsv1SnapshotLocks(ctx, sid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sid := "sid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SnapshotSnapshotsApi.DeleteSnapshotSnapshotsv1SnapshotLocks(context.Background(), sid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotSnapshotsApi.DeleteSnapshotSnapshotsv1SnapshotLocks``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**sid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteSnapshotSnapshotsv1SnapshotLocksRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSnapshotSnapshotsv1SnapshotLocks

> V1SnapshotLocks ListSnapshotSnapshotsv1SnapshotLocks(ctx, sid).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sid := "sid_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting.  Choices are id, expires, and comment.  Default is id. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SnapshotSnapshotsApi.ListSnapshotSnapshotsv1SnapshotLocks(context.Background(), sid).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SnapshotSnapshotsApi.ListSnapshotSnapshotsv1SnapshotLocks``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSnapshotSnapshotsv1SnapshotLocks`: V1SnapshotLocks
    fmt.Fprintf(os.Stdout, "Response from `SnapshotSnapshotsApi.ListSnapshotSnapshotsv1SnapshotLocks`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**sid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListSnapshotSnapshotsv1SnapshotLocksRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting.  Choices are id, expires, and comment.  Default is id. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V1SnapshotLocks**](V1SnapshotLocks.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

