# V10S3SettingsZoneSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BaseDomain** | Pointer to **string** | Specifies the S3 base domain name. | [optional] 
**BucketDirectoryCreateMode** | Pointer to **int32** | Create bucket directory with this permission mode | [optional] 
**ObjectAclPolicy** | Pointer to **string** | Default object ACL policy for S3 Buckets. | [optional] 
**RootPath** | Pointer to **string** | Specifies the S3 bucket root path. | [optional] 

## Methods

### NewV10S3SettingsZoneSettings

`func NewV10S3SettingsZoneSettings() *V10S3SettingsZoneSettings`

NewV10S3SettingsZoneSettings instantiates a new V10S3SettingsZoneSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10S3SettingsZoneSettingsWithDefaults

`func NewV10S3SettingsZoneSettingsWithDefaults() *V10S3SettingsZoneSettings`

NewV10S3SettingsZoneSettingsWithDefaults instantiates a new V10S3SettingsZoneSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBaseDomain

`func (o *V10S3SettingsZoneSettings) GetBaseDomain() string`

GetBaseDomain returns the BaseDomain field if non-nil, zero value otherwise.

### GetBaseDomainOk

`func (o *V10S3SettingsZoneSettings) GetBaseDomainOk() (*string, bool)`

GetBaseDomainOk returns a tuple with the BaseDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBaseDomain

`func (o *V10S3SettingsZoneSettings) SetBaseDomain(v string)`

SetBaseDomain sets BaseDomain field to given value.

### HasBaseDomain

`func (o *V10S3SettingsZoneSettings) HasBaseDomain() bool`

HasBaseDomain returns a boolean if a field has been set.

### GetBucketDirectoryCreateMode

`func (o *V10S3SettingsZoneSettings) GetBucketDirectoryCreateMode() int32`

GetBucketDirectoryCreateMode returns the BucketDirectoryCreateMode field if non-nil, zero value otherwise.

### GetBucketDirectoryCreateModeOk

`func (o *V10S3SettingsZoneSettings) GetBucketDirectoryCreateModeOk() (*int32, bool)`

GetBucketDirectoryCreateModeOk returns a tuple with the BucketDirectoryCreateMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBucketDirectoryCreateMode

`func (o *V10S3SettingsZoneSettings) SetBucketDirectoryCreateMode(v int32)`

SetBucketDirectoryCreateMode sets BucketDirectoryCreateMode field to given value.

### HasBucketDirectoryCreateMode

`func (o *V10S3SettingsZoneSettings) HasBucketDirectoryCreateMode() bool`

HasBucketDirectoryCreateMode returns a boolean if a field has been set.

### GetObjectAclPolicy

`func (o *V10S3SettingsZoneSettings) GetObjectAclPolicy() string`

GetObjectAclPolicy returns the ObjectAclPolicy field if non-nil, zero value otherwise.

### GetObjectAclPolicyOk

`func (o *V10S3SettingsZoneSettings) GetObjectAclPolicyOk() (*string, bool)`

GetObjectAclPolicyOk returns a tuple with the ObjectAclPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetObjectAclPolicy

`func (o *V10S3SettingsZoneSettings) SetObjectAclPolicy(v string)`

SetObjectAclPolicy sets ObjectAclPolicy field to given value.

### HasObjectAclPolicy

`func (o *V10S3SettingsZoneSettings) HasObjectAclPolicy() bool`

HasObjectAclPolicy returns a boolean if a field has been set.

### GetRootPath

`func (o *V10S3SettingsZoneSettings) GetRootPath() string`

GetRootPath returns the RootPath field if non-nil, zero value otherwise.

### GetRootPathOk

`func (o *V10S3SettingsZoneSettings) GetRootPathOk() (*string, bool)`

GetRootPathOk returns a tuple with the RootPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRootPath

`func (o *V10S3SettingsZoneSettings) SetRootPath(v string)`

SetRootPath sets RootPath field to given value.

### HasRootPath

`func (o *V10S3SettingsZoneSettings) HasRootPath() bool`

HasRootPath returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


