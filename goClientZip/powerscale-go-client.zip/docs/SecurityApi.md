# \SecurityApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateSecurityv15SecurityCheckItem**](SecurityApi.md#CreateSecurityv15SecurityCheckItem) | **Post** /platform/15/security/check | 
[**GetSecurityv15CheckReport**](SecurityApi.md#GetSecurityv15CheckReport) | **Get** /platform/15/security/check/report | 
[**GetSecurityv15CheckSettings**](SecurityApi.md#GetSecurityv15CheckSettings) | **Get** /platform/15/security/check/settings | 
[**GetSecurityv15SecuritySettings**](SecurityApi.md#GetSecurityv15SecuritySettings) | **Get** /platform/15/security/settings | 
[**ListSecurityv15SecurityCheck**](SecurityApi.md#ListSecurityv15SecurityCheck) | **Get** /platform/15/security/check | 
[**UpdateSecurityv15CheckSettings**](SecurityApi.md#UpdateSecurityv15CheckSettings) | **Put** /platform/15/security/check/settings | 
[**UpdateSecurityv15SecuritySettings**](SecurityApi.md#UpdateSecurityv15SecuritySettings) | **Put** /platform/15/security/settings | 



## CreateSecurityv15SecurityCheckItem

> CreateSecurityv15SecurityCheckItem(ctx).V15SecurityCheckItem(v15SecurityCheckItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15SecurityCheckItem := *openapiclient.NewV15SecurityCheckItem() // V15SecurityCheckItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SecurityApi.CreateSecurityv15SecurityCheckItem(context.Background()).V15SecurityCheckItem(v15SecurityCheckItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SecurityApi.CreateSecurityv15SecurityCheckItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateSecurityv15SecurityCheckItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15SecurityCheckItem** | [**V15SecurityCheckItem**](V15SecurityCheckItem.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSecurityv15CheckReport

> V15CheckReport GetSecurityv15CheckReport(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SecurityApi.GetSecurityv15CheckReport(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SecurityApi.GetSecurityv15CheckReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSecurityv15CheckReport`: V15CheckReport
    fmt.Fprintf(os.Stdout, "Response from `SecurityApi.GetSecurityv15CheckReport`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSecurityv15CheckReportRequest struct via the builder pattern


### Return type

[**V15CheckReport**](V15CheckReport.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSecurityv15CheckSettings

> V15CheckSettings GetSecurityv15CheckSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SecurityApi.GetSecurityv15CheckSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SecurityApi.GetSecurityv15CheckSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSecurityv15CheckSettings`: V15CheckSettings
    fmt.Fprintf(os.Stdout, "Response from `SecurityApi.GetSecurityv15CheckSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSecurityv15CheckSettingsRequest struct via the builder pattern


### Return type

[**V15CheckSettings**](V15CheckSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetSecurityv15SecuritySettings

> V15SecuritySettings GetSecurityv15SecuritySettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SecurityApi.GetSecurityv15SecuritySettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SecurityApi.GetSecurityv15SecuritySettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetSecurityv15SecuritySettings`: V15SecuritySettings
    fmt.Fprintf(os.Stdout, "Response from `SecurityApi.GetSecurityv15SecuritySettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetSecurityv15SecuritySettingsRequest struct via the builder pattern


### Return type

[**V15SecuritySettings**](V15SecuritySettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListSecurityv15SecurityCheck

> V15SecurityCheck ListSecurityv15SecurityCheck(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.SecurityApi.ListSecurityv15SecurityCheck(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SecurityApi.ListSecurityv15SecurityCheck``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListSecurityv15SecurityCheck`: V15SecurityCheck
    fmt.Fprintf(os.Stdout, "Response from `SecurityApi.ListSecurityv15SecurityCheck`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListSecurityv15SecurityCheckRequest struct via the builder pattern


### Return type

[**V15SecurityCheck**](V15SecurityCheck.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSecurityv15CheckSettings

> UpdateSecurityv15CheckSettings(ctx).V15CheckSettings(v15CheckSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15CheckSettings := *openapiclient.NewV15CheckSettingsSettings() // V15CheckSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SecurityApi.UpdateSecurityv15CheckSettings(context.Background()).V15CheckSettings(v15CheckSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SecurityApi.UpdateSecurityv15CheckSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSecurityv15CheckSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15CheckSettings** | [**V15CheckSettingsSettings**](V15CheckSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateSecurityv15SecuritySettings

> UpdateSecurityv15SecuritySettings(ctx).V15SecuritySettings(v15SecuritySettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v15SecuritySettings := *openapiclient.NewV15SecuritySettingsSettings() // V15SecuritySettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.SecurityApi.UpdateSecurityv15SecuritySettings(context.Background()).V15SecuritySettings(v15SecuritySettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `SecurityApi.UpdateSecurityv15SecuritySettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateSecurityv15SecuritySettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v15SecuritySettings** | [**V15SecuritySettingsSettings**](V15SecuritySettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

