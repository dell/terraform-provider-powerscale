# V12StoragepoolNodetypesExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nodetypes** | Pointer to [**[]V12StoragepoolNodetype**](V12StoragepoolNodetype.md) |  | [optional] 

## Methods

### NewV12StoragepoolNodetypesExtended

`func NewV12StoragepoolNodetypesExtended() *V12StoragepoolNodetypesExtended`

NewV12StoragepoolNodetypesExtended instantiates a new V12StoragepoolNodetypesExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12StoragepoolNodetypesExtendedWithDefaults

`func NewV12StoragepoolNodetypesExtendedWithDefaults() *V12StoragepoolNodetypesExtended`

NewV12StoragepoolNodetypesExtendedWithDefaults instantiates a new V12StoragepoolNodetypesExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNodetypes

`func (o *V12StoragepoolNodetypesExtended) GetNodetypes() []V12StoragepoolNodetype`

GetNodetypes returns the Nodetypes field if non-nil, zero value otherwise.

### GetNodetypesOk

`func (o *V12StoragepoolNodetypesExtended) GetNodetypesOk() (*[]V12StoragepoolNodetype, bool)`

GetNodetypesOk returns a tuple with the Nodetypes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodetypes

`func (o *V12StoragepoolNodetypesExtended) SetNodetypes(v []V12StoragepoolNodetype)`

SetNodetypes sets Nodetypes field to given value.

### HasNodetypes

`func (o *V12StoragepoolNodetypesExtended) HasNodetypes() bool`

HasNodetypes returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


