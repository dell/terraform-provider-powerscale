# V10NodeStatusNvram

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Errors** | Pointer to [**[]V11NodeStatusError**](V11NodeStatusError.md) | A list of errors encountered by the individual nodes involved in this request, or an empty list if there were no errors. | [optional] 
**Nodes** | Pointer to [**[]V10NodeStatusNvramNode**](V10NodeStatusNvramNode.md) | The responses from the individual nodes involved in this request. | [optional] 
**Total** | Pointer to **int32** | The total number of nodes responding. | [optional] 

## Methods

### NewV10NodeStatusNvram

`func NewV10NodeStatusNvram() *V10NodeStatusNvram`

NewV10NodeStatusNvram instantiates a new V10NodeStatusNvram object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NodeStatusNvramWithDefaults

`func NewV10NodeStatusNvramWithDefaults() *V10NodeStatusNvram`

NewV10NodeStatusNvramWithDefaults instantiates a new V10NodeStatusNvram object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetErrors

`func (o *V10NodeStatusNvram) GetErrors() []V11NodeStatusError`

GetErrors returns the Errors field if non-nil, zero value otherwise.

### GetErrorsOk

`func (o *V10NodeStatusNvram) GetErrorsOk() (*[]V11NodeStatusError, bool)`

GetErrorsOk returns a tuple with the Errors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetErrors

`func (o *V10NodeStatusNvram) SetErrors(v []V11NodeStatusError)`

SetErrors sets Errors field to given value.

### HasErrors

`func (o *V10NodeStatusNvram) HasErrors() bool`

HasErrors returns a boolean if a field has been set.

### GetNodes

`func (o *V10NodeStatusNvram) GetNodes() []V10NodeStatusNvramNode`

GetNodes returns the Nodes field if non-nil, zero value otherwise.

### GetNodesOk

`func (o *V10NodeStatusNvram) GetNodesOk() (*[]V10NodeStatusNvramNode, bool)`

GetNodesOk returns a tuple with the Nodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodes

`func (o *V10NodeStatusNvram) SetNodes(v []V10NodeStatusNvramNode)`

SetNodes sets Nodes field to given value.

### HasNodes

`func (o *V10NodeStatusNvram) HasNodes() bool`

HasNodes returns a boolean if a field has been set.

### GetTotal

`func (o *V10NodeStatusNvram) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10NodeStatusNvram) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10NodeStatusNvram) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10NodeStatusNvram) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


