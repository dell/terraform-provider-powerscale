# V12EventChannelsParameters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Address** | Pointer to **[]string** | Email addresses to send to. | [optional] 
**Batch** | Pointer to **string** | Batching criterion. | [optional] 
**BatchPeriod** | Pointer to **int32** | Period over which batching is to be performed. | [optional] 
**CustomTemplate** | Pointer to **string** | Path to custom notification template. | [optional] 
**SendAs** | Pointer to **string** | Email address to use as from. | [optional] 
**SmtpHost** | Pointer to **string** | SMTP relay host. | [optional] 
**SmtpPassword** | Pointer to **string** | Password for SMTP authentication - only if smtp_use_auth true. | [optional] 
**SmtpPort** | Pointer to **int32** | SMTP relay port - optional defaults to 25. | [optional] 
**SmtpSecurity** | Pointer to **string** | Encryption protocol to use for SMTP. | [optional] 
**SmtpUseAuth** | Pointer to **bool** | Use SMTP authentication - optional defaults to false. | [optional] 
**SmtpUsername** | Pointer to **string** | Username for SMTP authentication - only if smtp_use_auth true. | [optional] 
**Subject** | Pointer to **string** | Subject for emails. | [optional] 

## Methods

### NewV12EventChannelsParameters

`func NewV12EventChannelsParameters() *V12EventChannelsParameters`

NewV12EventChannelsParameters instantiates a new V12EventChannelsParameters object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventChannelsParametersWithDefaults

`func NewV12EventChannelsParametersWithDefaults() *V12EventChannelsParameters`

NewV12EventChannelsParametersWithDefaults instantiates a new V12EventChannelsParameters object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAddress

`func (o *V12EventChannelsParameters) GetAddress() []string`

GetAddress returns the Address field if non-nil, zero value otherwise.

### GetAddressOk

`func (o *V12EventChannelsParameters) GetAddressOk() (*[]string, bool)`

GetAddressOk returns a tuple with the Address field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAddress

`func (o *V12EventChannelsParameters) SetAddress(v []string)`

SetAddress sets Address field to given value.

### HasAddress

`func (o *V12EventChannelsParameters) HasAddress() bool`

HasAddress returns a boolean if a field has been set.

### GetBatch

`func (o *V12EventChannelsParameters) GetBatch() string`

GetBatch returns the Batch field if non-nil, zero value otherwise.

### GetBatchOk

`func (o *V12EventChannelsParameters) GetBatchOk() (*string, bool)`

GetBatchOk returns a tuple with the Batch field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBatch

`func (o *V12EventChannelsParameters) SetBatch(v string)`

SetBatch sets Batch field to given value.

### HasBatch

`func (o *V12EventChannelsParameters) HasBatch() bool`

HasBatch returns a boolean if a field has been set.

### GetBatchPeriod

`func (o *V12EventChannelsParameters) GetBatchPeriod() int32`

GetBatchPeriod returns the BatchPeriod field if non-nil, zero value otherwise.

### GetBatchPeriodOk

`func (o *V12EventChannelsParameters) GetBatchPeriodOk() (*int32, bool)`

GetBatchPeriodOk returns a tuple with the BatchPeriod field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBatchPeriod

`func (o *V12EventChannelsParameters) SetBatchPeriod(v int32)`

SetBatchPeriod sets BatchPeriod field to given value.

### HasBatchPeriod

`func (o *V12EventChannelsParameters) HasBatchPeriod() bool`

HasBatchPeriod returns a boolean if a field has been set.

### GetCustomTemplate

`func (o *V12EventChannelsParameters) GetCustomTemplate() string`

GetCustomTemplate returns the CustomTemplate field if non-nil, zero value otherwise.

### GetCustomTemplateOk

`func (o *V12EventChannelsParameters) GetCustomTemplateOk() (*string, bool)`

GetCustomTemplateOk returns a tuple with the CustomTemplate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCustomTemplate

`func (o *V12EventChannelsParameters) SetCustomTemplate(v string)`

SetCustomTemplate sets CustomTemplate field to given value.

### HasCustomTemplate

`func (o *V12EventChannelsParameters) HasCustomTemplate() bool`

HasCustomTemplate returns a boolean if a field has been set.

### GetSendAs

`func (o *V12EventChannelsParameters) GetSendAs() string`

GetSendAs returns the SendAs field if non-nil, zero value otherwise.

### GetSendAsOk

`func (o *V12EventChannelsParameters) GetSendAsOk() (*string, bool)`

GetSendAsOk returns a tuple with the SendAs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSendAs

`func (o *V12EventChannelsParameters) SetSendAs(v string)`

SetSendAs sets SendAs field to given value.

### HasSendAs

`func (o *V12EventChannelsParameters) HasSendAs() bool`

HasSendAs returns a boolean if a field has been set.

### GetSmtpHost

`func (o *V12EventChannelsParameters) GetSmtpHost() string`

GetSmtpHost returns the SmtpHost field if non-nil, zero value otherwise.

### GetSmtpHostOk

`func (o *V12EventChannelsParameters) GetSmtpHostOk() (*string, bool)`

GetSmtpHostOk returns a tuple with the SmtpHost field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmtpHost

`func (o *V12EventChannelsParameters) SetSmtpHost(v string)`

SetSmtpHost sets SmtpHost field to given value.

### HasSmtpHost

`func (o *V12EventChannelsParameters) HasSmtpHost() bool`

HasSmtpHost returns a boolean if a field has been set.

### GetSmtpPassword

`func (o *V12EventChannelsParameters) GetSmtpPassword() string`

GetSmtpPassword returns the SmtpPassword field if non-nil, zero value otherwise.

### GetSmtpPasswordOk

`func (o *V12EventChannelsParameters) GetSmtpPasswordOk() (*string, bool)`

GetSmtpPasswordOk returns a tuple with the SmtpPassword field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmtpPassword

`func (o *V12EventChannelsParameters) SetSmtpPassword(v string)`

SetSmtpPassword sets SmtpPassword field to given value.

### HasSmtpPassword

`func (o *V12EventChannelsParameters) HasSmtpPassword() bool`

HasSmtpPassword returns a boolean if a field has been set.

### GetSmtpPort

`func (o *V12EventChannelsParameters) GetSmtpPort() int32`

GetSmtpPort returns the SmtpPort field if non-nil, zero value otherwise.

### GetSmtpPortOk

`func (o *V12EventChannelsParameters) GetSmtpPortOk() (*int32, bool)`

GetSmtpPortOk returns a tuple with the SmtpPort field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmtpPort

`func (o *V12EventChannelsParameters) SetSmtpPort(v int32)`

SetSmtpPort sets SmtpPort field to given value.

### HasSmtpPort

`func (o *V12EventChannelsParameters) HasSmtpPort() bool`

HasSmtpPort returns a boolean if a field has been set.

### GetSmtpSecurity

`func (o *V12EventChannelsParameters) GetSmtpSecurity() string`

GetSmtpSecurity returns the SmtpSecurity field if non-nil, zero value otherwise.

### GetSmtpSecurityOk

`func (o *V12EventChannelsParameters) GetSmtpSecurityOk() (*string, bool)`

GetSmtpSecurityOk returns a tuple with the SmtpSecurity field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmtpSecurity

`func (o *V12EventChannelsParameters) SetSmtpSecurity(v string)`

SetSmtpSecurity sets SmtpSecurity field to given value.

### HasSmtpSecurity

`func (o *V12EventChannelsParameters) HasSmtpSecurity() bool`

HasSmtpSecurity returns a boolean if a field has been set.

### GetSmtpUseAuth

`func (o *V12EventChannelsParameters) GetSmtpUseAuth() bool`

GetSmtpUseAuth returns the SmtpUseAuth field if non-nil, zero value otherwise.

### GetSmtpUseAuthOk

`func (o *V12EventChannelsParameters) GetSmtpUseAuthOk() (*bool, bool)`

GetSmtpUseAuthOk returns a tuple with the SmtpUseAuth field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmtpUseAuth

`func (o *V12EventChannelsParameters) SetSmtpUseAuth(v bool)`

SetSmtpUseAuth sets SmtpUseAuth field to given value.

### HasSmtpUseAuth

`func (o *V12EventChannelsParameters) HasSmtpUseAuth() bool`

HasSmtpUseAuth returns a boolean if a field has been set.

### GetSmtpUsername

`func (o *V12EventChannelsParameters) GetSmtpUsername() string`

GetSmtpUsername returns the SmtpUsername field if non-nil, zero value otherwise.

### GetSmtpUsernameOk

`func (o *V12EventChannelsParameters) GetSmtpUsernameOk() (*string, bool)`

GetSmtpUsernameOk returns a tuple with the SmtpUsername field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSmtpUsername

`func (o *V12EventChannelsParameters) SetSmtpUsername(v string)`

SetSmtpUsername sets SmtpUsername field to given value.

### HasSmtpUsername

`func (o *V12EventChannelsParameters) HasSmtpUsername() bool`

HasSmtpUsername returns a boolean if a field has been set.

### GetSubject

`func (o *V12EventChannelsParameters) GetSubject() string`

GetSubject returns the Subject field if non-nil, zero value otherwise.

### GetSubjectOk

`func (o *V12EventChannelsParameters) GetSubjectOk() (*string, bool)`

GetSubjectOk returns a tuple with the Subject field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSubject

`func (o *V12EventChannelsParameters) SetSubject(v string)`

SetSubject sets Subject field to given value.

### HasSubject

`func (o *V12EventChannelsParameters) HasSubject() bool`

HasSubject returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


