# V10S3BucketAclItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Grantee** | [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | 
**Permission** | **string** | Specifies the S3 rights being allowed. | 

## Methods

### NewV10S3BucketAclItem

`func NewV10S3BucketAclItem(grantee V1AuthAccessAccessItemFileGroup, permission string, ) *V10S3BucketAclItem`

NewV10S3BucketAclItem instantiates a new V10S3BucketAclItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10S3BucketAclItemWithDefaults

`func NewV10S3BucketAclItemWithDefaults() *V10S3BucketAclItem`

NewV10S3BucketAclItemWithDefaults instantiates a new V10S3BucketAclItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetGrantee

`func (o *V10S3BucketAclItem) GetGrantee() V1AuthAccessAccessItemFileGroup`

GetGrantee returns the Grantee field if non-nil, zero value otherwise.

### GetGranteeOk

`func (o *V10S3BucketAclItem) GetGranteeOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetGranteeOk returns a tuple with the Grantee field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGrantee

`func (o *V10S3BucketAclItem) SetGrantee(v V1AuthAccessAccessItemFileGroup)`

SetGrantee sets Grantee field to given value.


### GetPermission

`func (o *V10S3BucketAclItem) GetPermission() string`

GetPermission returns the Permission field if non-nil, zero value otherwise.

### GetPermissionOk

`func (o *V10S3BucketAclItem) GetPermissionOk() (*string, bool)`

GetPermissionOk returns a tuple with the Permission field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPermission

`func (o *V10S3BucketAclItem) SetPermission(v string)`

SetPermission sets Permission field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


