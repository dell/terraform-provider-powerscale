# V12QuotaQuotaExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Container** | **bool** | If true, SMB shares using the quota directory see the quota thresholds as share size. | 
**EfficiencyRatio** | **float32** | Represents the ratio of logical space provided to physical space used. This accounts for protection overhead, metadata, and compression ratios for the data. | 
**Enforced** | **bool** | True if the quota provides enforcement, otherwise a accounting quota. | 
**Id** | **string** | The system ID given to the quota. | 
**IncludeSnapshots** | **bool** | If true, quota governs snapshot data as well as head data. | 
**Linked** | **bool** | For user, group and directory quotas, true if the quota is linked and controlled by a parent default-* quota. Linked quotas cannot be modified until they are unlinked. | 
**Notifications** | **string** | Summary of notifications: &#39;custom&#39; indicates one or more notification rules available from the notifications sub-resource; &#39;default&#39; indicates system default rules are used; &#39;disabled&#39; indicates that no notifications will be used for this quota.; &#39;badmap&#39; indicates that notification rule has problem in rule map. | 
**Path** | **string** | The /ifs path governed. | 
**Persona** | [**V1AuthAccessAccessItemFileGroup**](V1AuthAccessAccessItemFileGroup.md) |  | 
**Ready** | **bool** | True if the default resource accounting is accurate on the quota. If false, this quota is waiting on completion of a QuotaScan job. | 
**ReductionRatio** | **float32** | Represents the ratio of logical space provided to physical data space used. This accounts for compression and data deduplication effects. | 
**Thresholds** | [**V12QuotaQuotaThresholdsExtended**](V12QuotaQuotaThresholdsExtended.md) |  | 
**ThresholdsOn** | Pointer to **string** | Thresholds apply on quota accounting metric. | [optional] 
**Type** | **string** | The type of quota. | 
**Usage** | [**V12QuotaQuotaUsage**](V12QuotaQuotaUsage.md) |  | 

## Methods

### NewV12QuotaQuotaExtended

`func NewV12QuotaQuotaExtended(container bool, efficiencyRatio float32, enforced bool, id string, includeSnapshots bool, linked bool, notifications string, path string, persona V1AuthAccessAccessItemFileGroup, ready bool, reductionRatio float32, thresholds V12QuotaQuotaThresholdsExtended, type_ string, usage V12QuotaQuotaUsage, ) *V12QuotaQuotaExtended`

NewV12QuotaQuotaExtended instantiates a new V12QuotaQuotaExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12QuotaQuotaExtendedWithDefaults

`func NewV12QuotaQuotaExtendedWithDefaults() *V12QuotaQuotaExtended`

NewV12QuotaQuotaExtendedWithDefaults instantiates a new V12QuotaQuotaExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetContainer

`func (o *V12QuotaQuotaExtended) GetContainer() bool`

GetContainer returns the Container field if non-nil, zero value otherwise.

### GetContainerOk

`func (o *V12QuotaQuotaExtended) GetContainerOk() (*bool, bool)`

GetContainerOk returns a tuple with the Container field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetContainer

`func (o *V12QuotaQuotaExtended) SetContainer(v bool)`

SetContainer sets Container field to given value.


### GetEfficiencyRatio

`func (o *V12QuotaQuotaExtended) GetEfficiencyRatio() float32`

GetEfficiencyRatio returns the EfficiencyRatio field if non-nil, zero value otherwise.

### GetEfficiencyRatioOk

`func (o *V12QuotaQuotaExtended) GetEfficiencyRatioOk() (*float32, bool)`

GetEfficiencyRatioOk returns a tuple with the EfficiencyRatio field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEfficiencyRatio

`func (o *V12QuotaQuotaExtended) SetEfficiencyRatio(v float32)`

SetEfficiencyRatio sets EfficiencyRatio field to given value.


### GetEnforced

`func (o *V12QuotaQuotaExtended) GetEnforced() bool`

GetEnforced returns the Enforced field if non-nil, zero value otherwise.

### GetEnforcedOk

`func (o *V12QuotaQuotaExtended) GetEnforcedOk() (*bool, bool)`

GetEnforcedOk returns a tuple with the Enforced field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnforced

`func (o *V12QuotaQuotaExtended) SetEnforced(v bool)`

SetEnforced sets Enforced field to given value.


### GetId

`func (o *V12QuotaQuotaExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12QuotaQuotaExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12QuotaQuotaExtended) SetId(v string)`

SetId sets Id field to given value.


### GetIncludeSnapshots

`func (o *V12QuotaQuotaExtended) GetIncludeSnapshots() bool`

GetIncludeSnapshots returns the IncludeSnapshots field if non-nil, zero value otherwise.

### GetIncludeSnapshotsOk

`func (o *V12QuotaQuotaExtended) GetIncludeSnapshotsOk() (*bool, bool)`

GetIncludeSnapshotsOk returns a tuple with the IncludeSnapshots field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIncludeSnapshots

`func (o *V12QuotaQuotaExtended) SetIncludeSnapshots(v bool)`

SetIncludeSnapshots sets IncludeSnapshots field to given value.


### GetLinked

`func (o *V12QuotaQuotaExtended) GetLinked() bool`

GetLinked returns the Linked field if non-nil, zero value otherwise.

### GetLinkedOk

`func (o *V12QuotaQuotaExtended) GetLinkedOk() (*bool, bool)`

GetLinkedOk returns a tuple with the Linked field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLinked

`func (o *V12QuotaQuotaExtended) SetLinked(v bool)`

SetLinked sets Linked field to given value.


### GetNotifications

`func (o *V12QuotaQuotaExtended) GetNotifications() string`

GetNotifications returns the Notifications field if non-nil, zero value otherwise.

### GetNotificationsOk

`func (o *V12QuotaQuotaExtended) GetNotificationsOk() (*string, bool)`

GetNotificationsOk returns a tuple with the Notifications field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNotifications

`func (o *V12QuotaQuotaExtended) SetNotifications(v string)`

SetNotifications sets Notifications field to given value.


### GetPath

`func (o *V12QuotaQuotaExtended) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *V12QuotaQuotaExtended) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *V12QuotaQuotaExtended) SetPath(v string)`

SetPath sets Path field to given value.


### GetPersona

`func (o *V12QuotaQuotaExtended) GetPersona() V1AuthAccessAccessItemFileGroup`

GetPersona returns the Persona field if non-nil, zero value otherwise.

### GetPersonaOk

`func (o *V12QuotaQuotaExtended) GetPersonaOk() (*V1AuthAccessAccessItemFileGroup, bool)`

GetPersonaOk returns a tuple with the Persona field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPersona

`func (o *V12QuotaQuotaExtended) SetPersona(v V1AuthAccessAccessItemFileGroup)`

SetPersona sets Persona field to given value.


### GetReady

`func (o *V12QuotaQuotaExtended) GetReady() bool`

GetReady returns the Ready field if non-nil, zero value otherwise.

### GetReadyOk

`func (o *V12QuotaQuotaExtended) GetReadyOk() (*bool, bool)`

GetReadyOk returns a tuple with the Ready field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReady

`func (o *V12QuotaQuotaExtended) SetReady(v bool)`

SetReady sets Ready field to given value.


### GetReductionRatio

`func (o *V12QuotaQuotaExtended) GetReductionRatio() float32`

GetReductionRatio returns the ReductionRatio field if non-nil, zero value otherwise.

### GetReductionRatioOk

`func (o *V12QuotaQuotaExtended) GetReductionRatioOk() (*float32, bool)`

GetReductionRatioOk returns a tuple with the ReductionRatio field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReductionRatio

`func (o *V12QuotaQuotaExtended) SetReductionRatio(v float32)`

SetReductionRatio sets ReductionRatio field to given value.


### GetThresholds

`func (o *V12QuotaQuotaExtended) GetThresholds() V12QuotaQuotaThresholdsExtended`

GetThresholds returns the Thresholds field if non-nil, zero value otherwise.

### GetThresholdsOk

`func (o *V12QuotaQuotaExtended) GetThresholdsOk() (*V12QuotaQuotaThresholdsExtended, bool)`

GetThresholdsOk returns a tuple with the Thresholds field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholds

`func (o *V12QuotaQuotaExtended) SetThresholds(v V12QuotaQuotaThresholdsExtended)`

SetThresholds sets Thresholds field to given value.


### GetThresholdsOn

`func (o *V12QuotaQuotaExtended) GetThresholdsOn() string`

GetThresholdsOn returns the ThresholdsOn field if non-nil, zero value otherwise.

### GetThresholdsOnOk

`func (o *V12QuotaQuotaExtended) GetThresholdsOnOk() (*string, bool)`

GetThresholdsOnOk returns a tuple with the ThresholdsOn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetThresholdsOn

`func (o *V12QuotaQuotaExtended) SetThresholdsOn(v string)`

SetThresholdsOn sets ThresholdsOn field to given value.

### HasThresholdsOn

`func (o *V12QuotaQuotaExtended) HasThresholdsOn() bool`

HasThresholdsOn returns a boolean if a field has been set.

### GetType

`func (o *V12QuotaQuotaExtended) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V12QuotaQuotaExtended) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V12QuotaQuotaExtended) SetType(v string)`

SetType sets Type field to given value.


### GetUsage

`func (o *V12QuotaQuotaExtended) GetUsage() V12QuotaQuotaUsage`

GetUsage returns the Usage field if non-nil, zero value otherwise.

### GetUsageOk

`func (o *V12QuotaQuotaExtended) GetUsageOk() (*V12QuotaQuotaUsage, bool)`

GetUsageOk returns a tuple with the Usage field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUsage

`func (o *V12QuotaQuotaExtended) SetUsage(v V12QuotaQuotaUsage)`

SetUsage sets Usage field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


