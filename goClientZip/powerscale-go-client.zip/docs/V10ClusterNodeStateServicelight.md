# V10ClusterNodeStateServicelight

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | **bool** | The node service light state (True &#x3D; on). | 
**Present** | Pointer to **bool** | This node has a service light. | [optional] 
**Supported** | Pointer to **bool** | This node supports a service light. | [optional] 
**Valid** | Pointer to **bool** | The node service light state is valid (False &#x3D; Error). | [optional] 

## Methods

### NewV10ClusterNodeStateServicelight

`func NewV10ClusterNodeStateServicelight(enabled bool, ) *V10ClusterNodeStateServicelight`

NewV10ClusterNodeStateServicelight instantiates a new V10ClusterNodeStateServicelight object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeStateServicelightWithDefaults

`func NewV10ClusterNodeStateServicelightWithDefaults() *V10ClusterNodeStateServicelight`

NewV10ClusterNodeStateServicelightWithDefaults instantiates a new V10ClusterNodeStateServicelight object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *V10ClusterNodeStateServicelight) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V10ClusterNodeStateServicelight) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V10ClusterNodeStateServicelight) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.


### GetPresent

`func (o *V10ClusterNodeStateServicelight) GetPresent() bool`

GetPresent returns the Present field if non-nil, zero value otherwise.

### GetPresentOk

`func (o *V10ClusterNodeStateServicelight) GetPresentOk() (*bool, bool)`

GetPresentOk returns a tuple with the Present field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresent

`func (o *V10ClusterNodeStateServicelight) SetPresent(v bool)`

SetPresent sets Present field to given value.

### HasPresent

`func (o *V10ClusterNodeStateServicelight) HasPresent() bool`

HasPresent returns a boolean if a field has been set.

### GetSupported

`func (o *V10ClusterNodeStateServicelight) GetSupported() bool`

GetSupported returns the Supported field if non-nil, zero value otherwise.

### GetSupportedOk

`func (o *V10ClusterNodeStateServicelight) GetSupportedOk() (*bool, bool)`

GetSupportedOk returns a tuple with the Supported field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupported

`func (o *V10ClusterNodeStateServicelight) SetSupported(v bool)`

SetSupported sets Supported field to given value.

### HasSupported

`func (o *V10ClusterNodeStateServicelight) HasSupported() bool`

HasSupported returns a boolean if a field has been set.

### GetValid

`func (o *V10ClusterNodeStateServicelight) GetValid() bool`

GetValid returns the Valid field if non-nil, zero value otherwise.

### GetValidOk

`func (o *V10ClusterNodeStateServicelight) GetValidOk() (*bool, bool)`

GetValidOk returns a tuple with the Valid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValid

`func (o *V10ClusterNodeStateServicelight) SetValid(v bool)`

SetValid sets Valid field to given value.

### HasValid

`func (o *V10ClusterNodeStateServicelight) HasValid() bool`

HasValid returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


