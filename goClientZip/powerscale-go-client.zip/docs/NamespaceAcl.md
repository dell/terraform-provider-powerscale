# NamespaceAcl

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Acl** | Pointer to [**[]AclObject**](AclObject.md) | Provides the JSON array of access rights. | [optional] 
**Action** | Pointer to **string** | Action tells if we want to update the existing acl or delete and replace it with new acl defined. Default action is replace. | [optional] [default to "replace"]
**Authoritative** | Pointer to **string** | If the directory has access rights set, then this field is returned as acl. If the directory has POSIX permissions set, then this field is returned as mode. | [optional] 
**Group** | Pointer to [**MemberObject**](MemberObject.md) |  | [optional] 
**Mode** | Pointer to **string** | Provides the POSIX mode. | [optional] 
**Owner** | Pointer to [**MemberObject**](MemberObject.md) |  | [optional] 

## Methods

### NewNamespaceAcl

`func NewNamespaceAcl() *NamespaceAcl`

NewNamespaceAcl instantiates a new NamespaceAcl object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewNamespaceAclWithDefaults

`func NewNamespaceAclWithDefaults() *NamespaceAcl`

NewNamespaceAclWithDefaults instantiates a new NamespaceAcl object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAcl

`func (o *NamespaceAcl) GetAcl() []AclObject`

GetAcl returns the Acl field if non-nil, zero value otherwise.

### GetAclOk

`func (o *NamespaceAcl) GetAclOk() (*[]AclObject, bool)`

GetAclOk returns a tuple with the Acl field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAcl

`func (o *NamespaceAcl) SetAcl(v []AclObject)`

SetAcl sets Acl field to given value.

### HasAcl

`func (o *NamespaceAcl) HasAcl() bool`

HasAcl returns a boolean if a field has been set.

### GetAction

`func (o *NamespaceAcl) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *NamespaceAcl) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *NamespaceAcl) SetAction(v string)`

SetAction sets Action field to given value.

### HasAction

`func (o *NamespaceAcl) HasAction() bool`

HasAction returns a boolean if a field has been set.

### GetAuthoritative

`func (o *NamespaceAcl) GetAuthoritative() string`

GetAuthoritative returns the Authoritative field if non-nil, zero value otherwise.

### GetAuthoritativeOk

`func (o *NamespaceAcl) GetAuthoritativeOk() (*string, bool)`

GetAuthoritativeOk returns a tuple with the Authoritative field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuthoritative

`func (o *NamespaceAcl) SetAuthoritative(v string)`

SetAuthoritative sets Authoritative field to given value.

### HasAuthoritative

`func (o *NamespaceAcl) HasAuthoritative() bool`

HasAuthoritative returns a boolean if a field has been set.

### GetGroup

`func (o *NamespaceAcl) GetGroup() MemberObject`

GetGroup returns the Group field if non-nil, zero value otherwise.

### GetGroupOk

`func (o *NamespaceAcl) GetGroupOk() (*MemberObject, bool)`

GetGroupOk returns a tuple with the Group field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroup

`func (o *NamespaceAcl) SetGroup(v MemberObject)`

SetGroup sets Group field to given value.

### HasGroup

`func (o *NamespaceAcl) HasGroup() bool`

HasGroup returns a boolean if a field has been set.

### GetMode

`func (o *NamespaceAcl) GetMode() string`

GetMode returns the Mode field if non-nil, zero value otherwise.

### GetModeOk

`func (o *NamespaceAcl) GetModeOk() (*string, bool)`

GetModeOk returns a tuple with the Mode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMode

`func (o *NamespaceAcl) SetMode(v string)`

SetMode sets Mode field to given value.

### HasMode

`func (o *NamespaceAcl) HasMode() bool`

HasMode returns a boolean if a field has been set.

### GetOwner

`func (o *NamespaceAcl) GetOwner() MemberObject`

GetOwner returns the Owner field if non-nil, zero value otherwise.

### GetOwnerOk

`func (o *NamespaceAcl) GetOwnerOk() (*MemberObject, bool)`

GetOwnerOk returns a tuple with the Owner field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOwner

`func (o *NamespaceAcl) SetOwner(v MemberObject)`

SetOwner sets Owner field to given value.

### HasOwner

`func (o *NamespaceAcl) HasOwner() bool`

HasOwner returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


