# V10S3SettingsGlobal

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Settings** | [**V10S3SettingsGlobalSettings**](V10S3SettingsGlobalSettings.md) |  | 

## Methods

### NewV10S3SettingsGlobal

`func NewV10S3SettingsGlobal(settings V10S3SettingsGlobalSettings, ) *V10S3SettingsGlobal`

NewV10S3SettingsGlobal instantiates a new V10S3SettingsGlobal object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10S3SettingsGlobalWithDefaults

`func NewV10S3SettingsGlobalWithDefaults() *V10S3SettingsGlobal`

NewV10S3SettingsGlobalWithDefaults instantiates a new V10S3SettingsGlobal object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetSettings

`func (o *V10S3SettingsGlobal) GetSettings() V10S3SettingsGlobalSettings`

GetSettings returns the Settings field if non-nil, zero value otherwise.

### GetSettingsOk

`func (o *V10S3SettingsGlobal) GetSettingsOk() (*V10S3SettingsGlobalSettings, bool)`

GetSettingsOk returns a tuple with the Settings field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSettings

`func (o *V10S3SettingsGlobal) SetSettings(v V10S3SettingsGlobalSettings)`

SetSettings sets Settings field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


