# V10ClusterNodeDriveDConfigAllow

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FormatUnknownFirmware** | Pointer to **bool** | Allow formatting a drive model with unknown firmware. | [optional] [default to true]
**FormatUnknownModel** | Pointer to **bool** | Allow formatting an unknown drive model. | [optional] [default to true]

## Methods

### NewV10ClusterNodeDriveDConfigAllow

`func NewV10ClusterNodeDriveDConfigAllow() *V10ClusterNodeDriveDConfigAllow`

NewV10ClusterNodeDriveDConfigAllow instantiates a new V10ClusterNodeDriveDConfigAllow object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeDriveDConfigAllowWithDefaults

`func NewV10ClusterNodeDriveDConfigAllowWithDefaults() *V10ClusterNodeDriveDConfigAllow`

NewV10ClusterNodeDriveDConfigAllowWithDefaults instantiates a new V10ClusterNodeDriveDConfigAllow object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFormatUnknownFirmware

`func (o *V10ClusterNodeDriveDConfigAllow) GetFormatUnknownFirmware() bool`

GetFormatUnknownFirmware returns the FormatUnknownFirmware field if non-nil, zero value otherwise.

### GetFormatUnknownFirmwareOk

`func (o *V10ClusterNodeDriveDConfigAllow) GetFormatUnknownFirmwareOk() (*bool, bool)`

GetFormatUnknownFirmwareOk returns a tuple with the FormatUnknownFirmware field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFormatUnknownFirmware

`func (o *V10ClusterNodeDriveDConfigAllow) SetFormatUnknownFirmware(v bool)`

SetFormatUnknownFirmware sets FormatUnknownFirmware field to given value.

### HasFormatUnknownFirmware

`func (o *V10ClusterNodeDriveDConfigAllow) HasFormatUnknownFirmware() bool`

HasFormatUnknownFirmware returns a boolean if a field has been set.

### GetFormatUnknownModel

`func (o *V10ClusterNodeDriveDConfigAllow) GetFormatUnknownModel() bool`

GetFormatUnknownModel returns the FormatUnknownModel field if non-nil, zero value otherwise.

### GetFormatUnknownModelOk

`func (o *V10ClusterNodeDriveDConfigAllow) GetFormatUnknownModelOk() (*bool, bool)`

GetFormatUnknownModelOk returns a tuple with the FormatUnknownModel field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFormatUnknownModel

`func (o *V10ClusterNodeDriveDConfigAllow) SetFormatUnknownModel(v bool)`

SetFormatUnknownModel sets FormatUnknownModel field to given value.

### HasFormatUnknownModel

`func (o *V10ClusterNodeDriveDConfigAllow) HasFormatUnknownModel() bool`

HasFormatUnknownModel returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


