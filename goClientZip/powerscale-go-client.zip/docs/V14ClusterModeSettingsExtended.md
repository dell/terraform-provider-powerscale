# V14ClusterModeSettingsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudStorageConsole** | Pointer to **string** | URL for cloud storage console | [optional] 
**Monitoring** | Pointer to **string** | URL for monitoring | [optional] 
**Support** | Pointer to **string** | URL for support | [optional] 

## Methods

### NewV14ClusterModeSettingsExtended

`func NewV14ClusterModeSettingsExtended() *V14ClusterModeSettingsExtended`

NewV14ClusterModeSettingsExtended instantiates a new V14ClusterModeSettingsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ClusterModeSettingsExtendedWithDefaults

`func NewV14ClusterModeSettingsExtendedWithDefaults() *V14ClusterModeSettingsExtended`

NewV14ClusterModeSettingsExtendedWithDefaults instantiates a new V14ClusterModeSettingsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudStorageConsole

`func (o *V14ClusterModeSettingsExtended) GetCloudStorageConsole() string`

GetCloudStorageConsole returns the CloudStorageConsole field if non-nil, zero value otherwise.

### GetCloudStorageConsoleOk

`func (o *V14ClusterModeSettingsExtended) GetCloudStorageConsoleOk() (*string, bool)`

GetCloudStorageConsoleOk returns a tuple with the CloudStorageConsole field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudStorageConsole

`func (o *V14ClusterModeSettingsExtended) SetCloudStorageConsole(v string)`

SetCloudStorageConsole sets CloudStorageConsole field to given value.

### HasCloudStorageConsole

`func (o *V14ClusterModeSettingsExtended) HasCloudStorageConsole() bool`

HasCloudStorageConsole returns a boolean if a field has been set.

### GetMonitoring

`func (o *V14ClusterModeSettingsExtended) GetMonitoring() string`

GetMonitoring returns the Monitoring field if non-nil, zero value otherwise.

### GetMonitoringOk

`func (o *V14ClusterModeSettingsExtended) GetMonitoringOk() (*string, bool)`

GetMonitoringOk returns a tuple with the Monitoring field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMonitoring

`func (o *V14ClusterModeSettingsExtended) SetMonitoring(v string)`

SetMonitoring sets Monitoring field to given value.

### HasMonitoring

`func (o *V14ClusterModeSettingsExtended) HasMonitoring() bool`

HasMonitoring returns a boolean if a field has been set.

### GetSupport

`func (o *V14ClusterModeSettingsExtended) GetSupport() string`

GetSupport returns the Support field if non-nil, zero value otherwise.

### GetSupportOk

`func (o *V14ClusterModeSettingsExtended) GetSupportOk() (*string, bool)`

GetSupportOk returns a tuple with the Support field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupport

`func (o *V14ClusterModeSettingsExtended) SetSupport(v string)`

SetSupport sets Support field to given value.

### HasSupport

`func (o *V14ClusterModeSettingsExtended) HasSupport() bool`

HasSupport returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


