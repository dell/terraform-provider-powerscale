# V10JobJobAvscanParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ForceRun** | Pointer to **bool** | Force files to be scanned, even if excluded by the policy. | [optional] 
**Policy** | **string** | The antivirus scan policy to run. | 
**ReportId** | Pointer to **string** | An optional report id for the scan. | [optional] 
**Update** | Pointer to **bool** | Update the last run time for the policy. | [optional] 

## Methods

### NewV10JobJobAvscanParams

`func NewV10JobJobAvscanParams(policy string, ) *V10JobJobAvscanParams`

NewV10JobJobAvscanParams instantiates a new V10JobJobAvscanParams object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10JobJobAvscanParamsWithDefaults

`func NewV10JobJobAvscanParamsWithDefaults() *V10JobJobAvscanParams`

NewV10JobJobAvscanParamsWithDefaults instantiates a new V10JobJobAvscanParams object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetForceRun

`func (o *V10JobJobAvscanParams) GetForceRun() bool`

GetForceRun returns the ForceRun field if non-nil, zero value otherwise.

### GetForceRunOk

`func (o *V10JobJobAvscanParams) GetForceRunOk() (*bool, bool)`

GetForceRunOk returns a tuple with the ForceRun field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetForceRun

`func (o *V10JobJobAvscanParams) SetForceRun(v bool)`

SetForceRun sets ForceRun field to given value.

### HasForceRun

`func (o *V10JobJobAvscanParams) HasForceRun() bool`

HasForceRun returns a boolean if a field has been set.

### GetPolicy

`func (o *V10JobJobAvscanParams) GetPolicy() string`

GetPolicy returns the Policy field if non-nil, zero value otherwise.

### GetPolicyOk

`func (o *V10JobJobAvscanParams) GetPolicyOk() (*string, bool)`

GetPolicyOk returns a tuple with the Policy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicy

`func (o *V10JobJobAvscanParams) SetPolicy(v string)`

SetPolicy sets Policy field to given value.


### GetReportId

`func (o *V10JobJobAvscanParams) GetReportId() string`

GetReportId returns the ReportId field if non-nil, zero value otherwise.

### GetReportIdOk

`func (o *V10JobJobAvscanParams) GetReportIdOk() (*string, bool)`

GetReportIdOk returns a tuple with the ReportId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReportId

`func (o *V10JobJobAvscanParams) SetReportId(v string)`

SetReportId sets ReportId field to given value.

### HasReportId

`func (o *V10JobJobAvscanParams) HasReportId() bool`

HasReportId returns a boolean if a field has been set.

### GetUpdate

`func (o *V10JobJobAvscanParams) GetUpdate() bool`

GetUpdate returns the Update field if non-nil, zero value otherwise.

### GetUpdateOk

`func (o *V10JobJobAvscanParams) GetUpdateOk() (*bool, bool)`

GetUpdateOk returns a tuple with the Update field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpdate

`func (o *V10JobJobAvscanParams) SetUpdate(v bool)`

SetUpdate sets Update field to given value.

### HasUpdate

`func (o *V10JobJobAvscanParams) HasUpdate() bool`

HasUpdate returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


