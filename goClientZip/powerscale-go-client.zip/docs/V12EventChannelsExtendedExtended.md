# V12EventChannelsExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Channels** | Pointer to [**[]V12EventChannel**](V12EventChannel.md) |  | [optional] 

## Methods

### NewV12EventChannelsExtendedExtended

`func NewV12EventChannelsExtendedExtended() *V12EventChannelsExtendedExtended`

NewV12EventChannelsExtendedExtended instantiates a new V12EventChannelsExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventChannelsExtendedExtendedWithDefaults

`func NewV12EventChannelsExtendedExtendedWithDefaults() *V12EventChannelsExtendedExtended`

NewV12EventChannelsExtendedExtendedWithDefaults instantiates a new V12EventChannelsExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChannels

`func (o *V12EventChannelsExtendedExtended) GetChannels() []V12EventChannel`

GetChannels returns the Channels field if non-nil, zero value otherwise.

### GetChannelsOk

`func (o *V12EventChannelsExtendedExtended) GetChannelsOk() (*[]V12EventChannel, bool)`

GetChannelsOk returns a tuple with the Channels field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChannels

`func (o *V12EventChannelsExtendedExtended) SetChannels(v []V12EventChannel)`

SetChannels sets Channels field to given value.

### HasChannels

`func (o *V12EventChannelsExtendedExtended) HasChannels() bool`

HasChannels returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


