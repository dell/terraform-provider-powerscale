# \FilesystemApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetFilesystemv1SettingsAccessTime**](FilesystemApi.md#GetFilesystemv1SettingsAccessTime) | **Get** /platform/1/filesystem/settings/access-time | 
[**GetFilesystemv1SettingsCharacterEncodings**](FilesystemApi.md#GetFilesystemv1SettingsCharacterEncodings) | **Get** /platform/1/filesystem/settings/character-encodings | 
[**GetFilesystemv6SettingsCompression**](FilesystemApi.md#GetFilesystemv6SettingsCompression) | **Get** /platform/6/filesystem/settings/compression | 
[**GetFilesystemv7SettingsCharacterEncodings**](FilesystemApi.md#GetFilesystemv7SettingsCharacterEncodings) | **Get** /platform/7/filesystem/settings/character-encodings | 
[**UpdateFilesystemv1SettingsAccessTime**](FilesystemApi.md#UpdateFilesystemv1SettingsAccessTime) | **Put** /platform/1/filesystem/settings/access-time | 
[**UpdateFilesystemv1SettingsCharacterEncodings**](FilesystemApi.md#UpdateFilesystemv1SettingsCharacterEncodings) | **Put** /platform/1/filesystem/settings/character-encodings | 
[**UpdateFilesystemv6SettingsCompression**](FilesystemApi.md#UpdateFilesystemv6SettingsCompression) | **Put** /platform/6/filesystem/settings/compression | 
[**UpdateFilesystemv7SettingsCharacterEncodings**](FilesystemApi.md#UpdateFilesystemv7SettingsCharacterEncodings) | **Put** /platform/7/filesystem/settings/character-encodings | 



## GetFilesystemv1SettingsAccessTime

> V1SettingsAccessTime GetFilesystemv1SettingsAccessTime(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilesystemApi.GetFilesystemv1SettingsAccessTime(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilesystemApi.GetFilesystemv1SettingsAccessTime``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilesystemv1SettingsAccessTime`: V1SettingsAccessTime
    fmt.Fprintf(os.Stdout, "Response from `FilesystemApi.GetFilesystemv1SettingsAccessTime`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilesystemv1SettingsAccessTimeRequest struct via the builder pattern


### Return type

[**V1SettingsAccessTime**](V1SettingsAccessTime.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilesystemv1SettingsCharacterEncodings

> V1SettingsCharacterEncodings GetFilesystemv1SettingsCharacterEncodings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilesystemApi.GetFilesystemv1SettingsCharacterEncodings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilesystemApi.GetFilesystemv1SettingsCharacterEncodings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilesystemv1SettingsCharacterEncodings`: V1SettingsCharacterEncodings
    fmt.Fprintf(os.Stdout, "Response from `FilesystemApi.GetFilesystemv1SettingsCharacterEncodings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilesystemv1SettingsCharacterEncodingsRequest struct via the builder pattern


### Return type

[**V1SettingsCharacterEncodings**](V1SettingsCharacterEncodings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilesystemv6SettingsCompression

> V6SettingsCompression GetFilesystemv6SettingsCompression(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilesystemApi.GetFilesystemv6SettingsCompression(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilesystemApi.GetFilesystemv6SettingsCompression``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilesystemv6SettingsCompression`: V6SettingsCompression
    fmt.Fprintf(os.Stdout, "Response from `FilesystemApi.GetFilesystemv6SettingsCompression`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilesystemv6SettingsCompressionRequest struct via the builder pattern


### Return type

[**V6SettingsCompression**](V6SettingsCompression.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFilesystemv7SettingsCharacterEncodings

> V7SettingsCharacterEncodings GetFilesystemv7SettingsCharacterEncodings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FilesystemApi.GetFilesystemv7SettingsCharacterEncodings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilesystemApi.GetFilesystemv7SettingsCharacterEncodings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFilesystemv7SettingsCharacterEncodings`: V7SettingsCharacterEncodings
    fmt.Fprintf(os.Stdout, "Response from `FilesystemApi.GetFilesystemv7SettingsCharacterEncodings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFilesystemv7SettingsCharacterEncodingsRequest struct via the builder pattern


### Return type

[**V7SettingsCharacterEncodings**](V7SettingsCharacterEncodings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFilesystemv1SettingsAccessTime

> UpdateFilesystemv1SettingsAccessTime(ctx).V1SettingsAccessTime(v1SettingsAccessTime).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsAccessTime := *openapiclient.NewV1SettingsAccessTimeExtended() // V1SettingsAccessTimeExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilesystemApi.UpdateFilesystemv1SettingsAccessTime(context.Background()).V1SettingsAccessTime(v1SettingsAccessTime).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilesystemApi.UpdateFilesystemv1SettingsAccessTime``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFilesystemv1SettingsAccessTimeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SettingsAccessTime** | [**V1SettingsAccessTimeExtended**](V1SettingsAccessTimeExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFilesystemv1SettingsCharacterEncodings

> UpdateFilesystemv1SettingsCharacterEncodings(ctx).V1SettingsCharacterEncodings(v1SettingsCharacterEncodings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsCharacterEncodings := *openapiclient.NewV1SettingsCharacterEncodingsExtended() // V1SettingsCharacterEncodingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilesystemApi.UpdateFilesystemv1SettingsCharacterEncodings(context.Background()).V1SettingsCharacterEncodings(v1SettingsCharacterEncodings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilesystemApi.UpdateFilesystemv1SettingsCharacterEncodings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFilesystemv1SettingsCharacterEncodingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SettingsCharacterEncodings** | [**V1SettingsCharacterEncodingsExtended**](V1SettingsCharacterEncodingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFilesystemv6SettingsCompression

> UpdateFilesystemv6SettingsCompression(ctx).V6SettingsCompression(v6SettingsCompression).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v6SettingsCompression := *openapiclient.NewV6SettingsCompressionExtended() // V6SettingsCompressionExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilesystemApi.UpdateFilesystemv6SettingsCompression(context.Background()).V6SettingsCompression(v6SettingsCompression).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilesystemApi.UpdateFilesystemv6SettingsCompression``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFilesystemv6SettingsCompressionRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v6SettingsCompression** | [**V6SettingsCompressionExtended**](V6SettingsCompressionExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFilesystemv7SettingsCharacterEncodings

> UpdateFilesystemv7SettingsCharacterEncodings(ctx).V7SettingsCharacterEncodings(v7SettingsCharacterEncodings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SettingsCharacterEncodings := *openapiclient.NewV7SettingsCharacterEncodingsExtended() // V7SettingsCharacterEncodingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FilesystemApi.UpdateFilesystemv7SettingsCharacterEncodings(context.Background()).V7SettingsCharacterEncodings(v7SettingsCharacterEncodings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FilesystemApi.UpdateFilesystemv7SettingsCharacterEncodings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFilesystemv7SettingsCharacterEncodingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SettingsCharacterEncodings** | [**V7SettingsCharacterEncodingsExtended**](V7SettingsCharacterEncodingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

