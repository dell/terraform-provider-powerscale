# V10ClusterNodeDriveDConfigLog

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DriveStats** | Pointer to **bool** | Indicates whether or not to log the drive statistics. | [optional] [default to true]

## Methods

### NewV10ClusterNodeDriveDConfigLog

`func NewV10ClusterNodeDriveDConfigLog() *V10ClusterNodeDriveDConfigLog`

NewV10ClusterNodeDriveDConfigLog instantiates a new V10ClusterNodeDriveDConfigLog object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeDriveDConfigLogWithDefaults

`func NewV10ClusterNodeDriveDConfigLogWithDefaults() *V10ClusterNodeDriveDConfigLog`

NewV10ClusterNodeDriveDConfigLogWithDefaults instantiates a new V10ClusterNodeDriveDConfigLog object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDriveStats

`func (o *V10ClusterNodeDriveDConfigLog) GetDriveStats() bool`

GetDriveStats returns the DriveStats field if non-nil, zero value otherwise.

### GetDriveStatsOk

`func (o *V10ClusterNodeDriveDConfigLog) GetDriveStatsOk() (*bool, bool)`

GetDriveStatsOk returns a tuple with the DriveStats field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDriveStats

`func (o *V10ClusterNodeDriveDConfigLog) SetDriveStats(v bool)`

SetDriveStats sets DriveStats field to given value.

### HasDriveStats

`func (o *V10ClusterNodeDriveDConfigLog) HasDriveStats() bool`

HasDriveStats returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


