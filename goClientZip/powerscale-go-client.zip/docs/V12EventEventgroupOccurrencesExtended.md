# V12EventEventgroupOccurrencesExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ignore** | Pointer to **bool** | True if eventgroup is to be ignored. | [optional] 
**Resolved** | Pointer to **bool** | True if eventgroup is to be resolved. | [optional] 

## Methods

### NewV12EventEventgroupOccurrencesExtended

`func NewV12EventEventgroupOccurrencesExtended() *V12EventEventgroupOccurrencesExtended`

NewV12EventEventgroupOccurrencesExtended instantiates a new V12EventEventgroupOccurrencesExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventEventgroupOccurrencesExtendedWithDefaults

`func NewV12EventEventgroupOccurrencesExtendedWithDefaults() *V12EventEventgroupOccurrencesExtended`

NewV12EventEventgroupOccurrencesExtendedWithDefaults instantiates a new V12EventEventgroupOccurrencesExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIgnore

`func (o *V12EventEventgroupOccurrencesExtended) GetIgnore() bool`

GetIgnore returns the Ignore field if non-nil, zero value otherwise.

### GetIgnoreOk

`func (o *V12EventEventgroupOccurrencesExtended) GetIgnoreOk() (*bool, bool)`

GetIgnoreOk returns a tuple with the Ignore field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnore

`func (o *V12EventEventgroupOccurrencesExtended) SetIgnore(v bool)`

SetIgnore sets Ignore field to given value.

### HasIgnore

`func (o *V12EventEventgroupOccurrencesExtended) HasIgnore() bool`

HasIgnore returns a boolean if a field has been set.

### GetResolved

`func (o *V12EventEventgroupOccurrencesExtended) GetResolved() bool`

GetResolved returns the Resolved field if non-nil, zero value otherwise.

### GetResolvedOk

`func (o *V12EventEventgroupOccurrencesExtended) GetResolvedOk() (*bool, bool)`

GetResolvedOk returns a tuple with the Resolved field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResolved

`func (o *V12EventEventgroupOccurrencesExtended) SetResolved(v bool)`

SetResolved sets Resolved field to given value.

### HasResolved

`func (o *V12EventEventgroupOccurrencesExtended) HasResolved() bool`

HasResolved returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


