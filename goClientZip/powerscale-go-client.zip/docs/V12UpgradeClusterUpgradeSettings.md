# V12UpgradeClusterUpgradeSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**NodesToRollingUpgrade** | Pointer to **[]int32** | The nodes (to be) scheduled for upgrade ordered by queue position number. Null if the cluster_state is &#39;partially upgraded&#39; or upgrade_type is &#39;simultaneous&#39;. One of the following values: [&lt;lnn-1&gt;, &lt;lnn-2&gt;, ... ], &#39;all&#39;, null | [optional] 
**UpgradeType** | Pointer to **string** | The type of upgrade to perform. One of the following values: &#39;rolling&#39;, &#39;simultaneous&#39; | [optional] 

## Methods

### NewV12UpgradeClusterUpgradeSettings

`func NewV12UpgradeClusterUpgradeSettings() *V12UpgradeClusterUpgradeSettings`

NewV12UpgradeClusterUpgradeSettings instantiates a new V12UpgradeClusterUpgradeSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12UpgradeClusterUpgradeSettingsWithDefaults

`func NewV12UpgradeClusterUpgradeSettingsWithDefaults() *V12UpgradeClusterUpgradeSettings`

NewV12UpgradeClusterUpgradeSettingsWithDefaults instantiates a new V12UpgradeClusterUpgradeSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNodesToRollingUpgrade

`func (o *V12UpgradeClusterUpgradeSettings) GetNodesToRollingUpgrade() []int32`

GetNodesToRollingUpgrade returns the NodesToRollingUpgrade field if non-nil, zero value otherwise.

### GetNodesToRollingUpgradeOk

`func (o *V12UpgradeClusterUpgradeSettings) GetNodesToRollingUpgradeOk() (*[]int32, bool)`

GetNodesToRollingUpgradeOk returns a tuple with the NodesToRollingUpgrade field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodesToRollingUpgrade

`func (o *V12UpgradeClusterUpgradeSettings) SetNodesToRollingUpgrade(v []int32)`

SetNodesToRollingUpgrade sets NodesToRollingUpgrade field to given value.

### HasNodesToRollingUpgrade

`func (o *V12UpgradeClusterUpgradeSettings) HasNodesToRollingUpgrade() bool`

HasNodesToRollingUpgrade returns a boolean if a field has been set.

### GetUpgradeType

`func (o *V12UpgradeClusterUpgradeSettings) GetUpgradeType() string`

GetUpgradeType returns the UpgradeType field if non-nil, zero value otherwise.

### GetUpgradeTypeOk

`func (o *V12UpgradeClusterUpgradeSettings) GetUpgradeTypeOk() (*string, bool)`

GetUpgradeTypeOk returns a tuple with the UpgradeType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUpgradeType

`func (o *V12UpgradeClusterUpgradeSettings) SetUpgradeType(v string)`

SetUpgradeType sets UpgradeType field to given value.

### HasUpgradeType

`func (o *V12UpgradeClusterUpgradeSettings) HasUpgradeType() bool`

HasUpgradeType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


