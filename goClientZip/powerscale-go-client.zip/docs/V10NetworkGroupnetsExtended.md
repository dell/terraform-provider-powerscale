# V10NetworkGroupnetsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Groupnets** | Pointer to [**[]V10NetworkGroupnetExtended**](V10NetworkGroupnetExtended.md) |  | [optional] 

## Methods

### NewV10NetworkGroupnetsExtended

`func NewV10NetworkGroupnetsExtended() *V10NetworkGroupnetsExtended`

NewV10NetworkGroupnetsExtended instantiates a new V10NetworkGroupnetsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NetworkGroupnetsExtendedWithDefaults

`func NewV10NetworkGroupnetsExtendedWithDefaults() *V10NetworkGroupnetsExtended`

NewV10NetworkGroupnetsExtendedWithDefaults instantiates a new V10NetworkGroupnetsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetGroupnets

`func (o *V10NetworkGroupnetsExtended) GetGroupnets() []V10NetworkGroupnetExtended`

GetGroupnets returns the Groupnets field if non-nil, zero value otherwise.

### GetGroupnetsOk

`func (o *V10NetworkGroupnetsExtended) GetGroupnetsOk() (*[]V10NetworkGroupnetExtended, bool)`

GetGroupnetsOk returns a tuple with the Groupnets field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGroupnets

`func (o *V10NetworkGroupnetsExtended) SetGroupnets(v []V10NetworkGroupnetExtended)`

SetGroupnets sets Groupnets field to given value.

### HasGroupnets

`func (o *V10NetworkGroupnetsExtended) HasGroupnets() bool`

HasGroupnets returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


