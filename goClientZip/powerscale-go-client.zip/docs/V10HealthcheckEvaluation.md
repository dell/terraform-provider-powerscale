# V10HealthcheckEvaluation

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ChecklistId** | **string** | Checklist to be run | 
**Delivery** | Pointer to [**[]V10HealthcheckChecklistDeliveryItem**](V10HealthcheckChecklistDeliveryItem.md) | List of delivery addresses/methods for results | [optional] 
**Overrides** | Pointer to [**[]V10HealthcheckEvaluationOverride**](V10HealthcheckEvaluationOverride.md) | Optional overrides for thresholds etc. | [optional] 
**Parameters** | Pointer to **map[string]interface{}** |  | [optional] 

## Methods

### NewV10HealthcheckEvaluation

`func NewV10HealthcheckEvaluation(checklistId string, ) *V10HealthcheckEvaluation`

NewV10HealthcheckEvaluation instantiates a new V10HealthcheckEvaluation object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckEvaluationWithDefaults

`func NewV10HealthcheckEvaluationWithDefaults() *V10HealthcheckEvaluation`

NewV10HealthcheckEvaluationWithDefaults instantiates a new V10HealthcheckEvaluation object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChecklistId

`func (o *V10HealthcheckEvaluation) GetChecklistId() string`

GetChecklistId returns the ChecklistId field if non-nil, zero value otherwise.

### GetChecklistIdOk

`func (o *V10HealthcheckEvaluation) GetChecklistIdOk() (*string, bool)`

GetChecklistIdOk returns a tuple with the ChecklistId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChecklistId

`func (o *V10HealthcheckEvaluation) SetChecklistId(v string)`

SetChecklistId sets ChecklistId field to given value.


### GetDelivery

`func (o *V10HealthcheckEvaluation) GetDelivery() []V10HealthcheckChecklistDeliveryItem`

GetDelivery returns the Delivery field if non-nil, zero value otherwise.

### GetDeliveryOk

`func (o *V10HealthcheckEvaluation) GetDeliveryOk() (*[]V10HealthcheckChecklistDeliveryItem, bool)`

GetDeliveryOk returns a tuple with the Delivery field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDelivery

`func (o *V10HealthcheckEvaluation) SetDelivery(v []V10HealthcheckChecklistDeliveryItem)`

SetDelivery sets Delivery field to given value.

### HasDelivery

`func (o *V10HealthcheckEvaluation) HasDelivery() bool`

HasDelivery returns a boolean if a field has been set.

### GetOverrides

`func (o *V10HealthcheckEvaluation) GetOverrides() []V10HealthcheckEvaluationOverride`

GetOverrides returns the Overrides field if non-nil, zero value otherwise.

### GetOverridesOk

`func (o *V10HealthcheckEvaluation) GetOverridesOk() (*[]V10HealthcheckEvaluationOverride, bool)`

GetOverridesOk returns a tuple with the Overrides field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOverrides

`func (o *V10HealthcheckEvaluation) SetOverrides(v []V10HealthcheckEvaluationOverride)`

SetOverrides sets Overrides field to given value.

### HasOverrides

`func (o *V10HealthcheckEvaluation) HasOverrides() bool`

HasOverrides returns a boolean if a field has been set.

### GetParameters

`func (o *V10HealthcheckEvaluation) GetParameters() map[string]interface{}`

GetParameters returns the Parameters field if non-nil, zero value otherwise.

### GetParametersOk

`func (o *V10HealthcheckEvaluation) GetParametersOk() (*map[string]interface{}, bool)`

GetParametersOk returns a tuple with the Parameters field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetParameters

`func (o *V10HealthcheckEvaluation) SetParameters(v map[string]interface{})`

SetParameters sets Parameters field to given value.

### HasParameters

`func (o *V10HealthcheckEvaluation) HasParameters() bool`

HasParameters returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


