# V11NodeStatusNodeStatus

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AvVendor** | Pointer to **string** | Name of antivirus engine for scanning files. | [optional] 
**BlockingEvents** | Pointer to **[]string** | List of blocking event strings if CAVA is FAULTED | [optional] 
**CeeVersion** | Pointer to **string** | Remote CEE software version string. | [optional] 
**DtdVersion** | Pointer to **string** | Document type definition version for message exchanges. | [optional] 
**ServerStatus** | Pointer to [**[]V11NodeStatusNodeStatusServerStatusItem**](V11NodeStatusNodeStatusServerStatusItem.md) | Specifies the list of CAVA servers along with their status. | [optional] 
**SignatureTimestamp** | Pointer to **string** | Timestamp of the last antivirus signature update. | [optional] 
**SystemStats** | Pointer to [**V11NodeStatusNodeStatusSystemStats**](V11NodeStatusNodeStatusSystemStats.md) |  | [optional] 
**SystemStatus** | Pointer to **string** | Status of the CAVA antivirus system. | [optional] 

## Methods

### NewV11NodeStatusNodeStatus

`func NewV11NodeStatusNodeStatus() *V11NodeStatusNodeStatus`

NewV11NodeStatusNodeStatus instantiates a new V11NodeStatusNodeStatus object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11NodeStatusNodeStatusWithDefaults

`func NewV11NodeStatusNodeStatusWithDefaults() *V11NodeStatusNodeStatus`

NewV11NodeStatusNodeStatusWithDefaults instantiates a new V11NodeStatusNodeStatus object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAvVendor

`func (o *V11NodeStatusNodeStatus) GetAvVendor() string`

GetAvVendor returns the AvVendor field if non-nil, zero value otherwise.

### GetAvVendorOk

`func (o *V11NodeStatusNodeStatus) GetAvVendorOk() (*string, bool)`

GetAvVendorOk returns a tuple with the AvVendor field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvVendor

`func (o *V11NodeStatusNodeStatus) SetAvVendor(v string)`

SetAvVendor sets AvVendor field to given value.

### HasAvVendor

`func (o *V11NodeStatusNodeStatus) HasAvVendor() bool`

HasAvVendor returns a boolean if a field has been set.

### GetBlockingEvents

`func (o *V11NodeStatusNodeStatus) GetBlockingEvents() []string`

GetBlockingEvents returns the BlockingEvents field if non-nil, zero value otherwise.

### GetBlockingEventsOk

`func (o *V11NodeStatusNodeStatus) GetBlockingEventsOk() (*[]string, bool)`

GetBlockingEventsOk returns a tuple with the BlockingEvents field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBlockingEvents

`func (o *V11NodeStatusNodeStatus) SetBlockingEvents(v []string)`

SetBlockingEvents sets BlockingEvents field to given value.

### HasBlockingEvents

`func (o *V11NodeStatusNodeStatus) HasBlockingEvents() bool`

HasBlockingEvents returns a boolean if a field has been set.

### GetCeeVersion

`func (o *V11NodeStatusNodeStatus) GetCeeVersion() string`

GetCeeVersion returns the CeeVersion field if non-nil, zero value otherwise.

### GetCeeVersionOk

`func (o *V11NodeStatusNodeStatus) GetCeeVersionOk() (*string, bool)`

GetCeeVersionOk returns a tuple with the CeeVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCeeVersion

`func (o *V11NodeStatusNodeStatus) SetCeeVersion(v string)`

SetCeeVersion sets CeeVersion field to given value.

### HasCeeVersion

`func (o *V11NodeStatusNodeStatus) HasCeeVersion() bool`

HasCeeVersion returns a boolean if a field has been set.

### GetDtdVersion

`func (o *V11NodeStatusNodeStatus) GetDtdVersion() string`

GetDtdVersion returns the DtdVersion field if non-nil, zero value otherwise.

### GetDtdVersionOk

`func (o *V11NodeStatusNodeStatus) GetDtdVersionOk() (*string, bool)`

GetDtdVersionOk returns a tuple with the DtdVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDtdVersion

`func (o *V11NodeStatusNodeStatus) SetDtdVersion(v string)`

SetDtdVersion sets DtdVersion field to given value.

### HasDtdVersion

`func (o *V11NodeStatusNodeStatus) HasDtdVersion() bool`

HasDtdVersion returns a boolean if a field has been set.

### GetServerStatus

`func (o *V11NodeStatusNodeStatus) GetServerStatus() []V11NodeStatusNodeStatusServerStatusItem`

GetServerStatus returns the ServerStatus field if non-nil, zero value otherwise.

### GetServerStatusOk

`func (o *V11NodeStatusNodeStatus) GetServerStatusOk() (*[]V11NodeStatusNodeStatusServerStatusItem, bool)`

GetServerStatusOk returns a tuple with the ServerStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerStatus

`func (o *V11NodeStatusNodeStatus) SetServerStatus(v []V11NodeStatusNodeStatusServerStatusItem)`

SetServerStatus sets ServerStatus field to given value.

### HasServerStatus

`func (o *V11NodeStatusNodeStatus) HasServerStatus() bool`

HasServerStatus returns a boolean if a field has been set.

### GetSignatureTimestamp

`func (o *V11NodeStatusNodeStatus) GetSignatureTimestamp() string`

GetSignatureTimestamp returns the SignatureTimestamp field if non-nil, zero value otherwise.

### GetSignatureTimestampOk

`func (o *V11NodeStatusNodeStatus) GetSignatureTimestampOk() (*string, bool)`

GetSignatureTimestampOk returns a tuple with the SignatureTimestamp field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSignatureTimestamp

`func (o *V11NodeStatusNodeStatus) SetSignatureTimestamp(v string)`

SetSignatureTimestamp sets SignatureTimestamp field to given value.

### HasSignatureTimestamp

`func (o *V11NodeStatusNodeStatus) HasSignatureTimestamp() bool`

HasSignatureTimestamp returns a boolean if a field has been set.

### GetSystemStats

`func (o *V11NodeStatusNodeStatus) GetSystemStats() V11NodeStatusNodeStatusSystemStats`

GetSystemStats returns the SystemStats field if non-nil, zero value otherwise.

### GetSystemStatsOk

`func (o *V11NodeStatusNodeStatus) GetSystemStatsOk() (*V11NodeStatusNodeStatusSystemStats, bool)`

GetSystemStatsOk returns a tuple with the SystemStats field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemStats

`func (o *V11NodeStatusNodeStatus) SetSystemStats(v V11NodeStatusNodeStatusSystemStats)`

SetSystemStats sets SystemStats field to given value.

### HasSystemStats

`func (o *V11NodeStatusNodeStatus) HasSystemStats() bool`

HasSystemStats returns a boolean if a field has been set.

### GetSystemStatus

`func (o *V11NodeStatusNodeStatus) GetSystemStatus() string`

GetSystemStatus returns the SystemStatus field if non-nil, zero value otherwise.

### GetSystemStatusOk

`func (o *V11NodeStatusNodeStatus) GetSystemStatusOk() (*string, bool)`

GetSystemStatusOk returns a tuple with the SystemStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSystemStatus

`func (o *V11NodeStatusNodeStatus) SetSystemStatus(v string)`

SetSystemStatus sets SystemStatus field to given value.

### HasSystemStatus

`func (o *V11NodeStatusNodeStatus) HasSystemStatus() bool`

HasSystemStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


