# V10ClusterNodeStateReadonly

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Allowed** | Pointer to **bool** | The current read-only mode allowed status for the node. | [optional] 
**Enabled** | Pointer to **bool** | The current read-only user mode status for the node. NOTE: If read-only mode is currently disallowed for this node, it will remain read/write until read-only mode is allowed again. This value only sets or clears any user-specified requests for read-only mode. If the node has been placed into read-only mode by the system, it will remain in read-only mode until the system conditions which triggered read-only mode have cleared. | [optional] 
**Mode** | Pointer to **bool** | The current read-only mode status for the node. | [optional] 
**Status** | Pointer to **string** | The current read-only mode status description for the node. | [optional] 
**Valid** | Pointer to **bool** | The read-only state values are valid (False &#x3D; Error). | [optional] 
**Value** | Pointer to **int32** | The current read-only value (enumerated bitfield) for the node. | [optional] 

## Methods

### NewV10ClusterNodeStateReadonly

`func NewV10ClusterNodeStateReadonly() *V10ClusterNodeStateReadonly`

NewV10ClusterNodeStateReadonly instantiates a new V10ClusterNodeStateReadonly object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeStateReadonlyWithDefaults

`func NewV10ClusterNodeStateReadonlyWithDefaults() *V10ClusterNodeStateReadonly`

NewV10ClusterNodeStateReadonlyWithDefaults instantiates a new V10ClusterNodeStateReadonly object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAllowed

`func (o *V10ClusterNodeStateReadonly) GetAllowed() bool`

GetAllowed returns the Allowed field if non-nil, zero value otherwise.

### GetAllowedOk

`func (o *V10ClusterNodeStateReadonly) GetAllowedOk() (*bool, bool)`

GetAllowedOk returns a tuple with the Allowed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllowed

`func (o *V10ClusterNodeStateReadonly) SetAllowed(v bool)`

SetAllowed sets Allowed field to given value.

### HasAllowed

`func (o *V10ClusterNodeStateReadonly) HasAllowed() bool`

HasAllowed returns a boolean if a field has been set.

### GetEnabled

`func (o *V10ClusterNodeStateReadonly) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V10ClusterNodeStateReadonly) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V10ClusterNodeStateReadonly) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V10ClusterNodeStateReadonly) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetMode

`func (o *V10ClusterNodeStateReadonly) GetMode() bool`

GetMode returns the Mode field if non-nil, zero value otherwise.

### GetModeOk

`func (o *V10ClusterNodeStateReadonly) GetModeOk() (*bool, bool)`

GetModeOk returns a tuple with the Mode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMode

`func (o *V10ClusterNodeStateReadonly) SetMode(v bool)`

SetMode sets Mode field to given value.

### HasMode

`func (o *V10ClusterNodeStateReadonly) HasMode() bool`

HasMode returns a boolean if a field has been set.

### GetStatus

`func (o *V10ClusterNodeStateReadonly) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V10ClusterNodeStateReadonly) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V10ClusterNodeStateReadonly) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V10ClusterNodeStateReadonly) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetValid

`func (o *V10ClusterNodeStateReadonly) GetValid() bool`

GetValid returns the Valid field if non-nil, zero value otherwise.

### GetValidOk

`func (o *V10ClusterNodeStateReadonly) GetValidOk() (*bool, bool)`

GetValidOk returns a tuple with the Valid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValid

`func (o *V10ClusterNodeStateReadonly) SetValid(v bool)`

SetValid sets Valid field to given value.

### HasValid

`func (o *V10ClusterNodeStateReadonly) HasValid() bool`

HasValid returns a boolean if a field has been set.

### GetValue

`func (o *V10ClusterNodeStateReadonly) GetValue() int32`

GetValue returns the Value field if non-nil, zero value otherwise.

### GetValueOk

`func (o *V10ClusterNodeStateReadonly) GetValueOk() (*int32, bool)`

GetValueOk returns a tuple with the Value field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValue

`func (o *V10ClusterNodeStateReadonly) SetValue(v int32)`

SetValue sets Value field to given value.

### HasValue

`func (o *V10ClusterNodeStateReadonly) HasValue() bool`

HasValue returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


