# V10HealthcheckScheduleExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Checklist** | Pointer to **[]string** | Checklists or Items for scheduling. | [optional] 
**Id** | Pointer to **string** | The ID of the newly created schedule. | [optional] 
**Name** | **string** | The schedule name. | 
**Schedule** | Pointer to **string** | The isi-schedule compatible natural language description of the schedule. | [optional] 

## Methods

### NewV10HealthcheckScheduleExtendedExtended

`func NewV10HealthcheckScheduleExtendedExtended(name string, ) *V10HealthcheckScheduleExtendedExtended`

NewV10HealthcheckScheduleExtendedExtended instantiates a new V10HealthcheckScheduleExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckScheduleExtendedExtendedWithDefaults

`func NewV10HealthcheckScheduleExtendedExtendedWithDefaults() *V10HealthcheckScheduleExtendedExtended`

NewV10HealthcheckScheduleExtendedExtendedWithDefaults instantiates a new V10HealthcheckScheduleExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChecklist

`func (o *V10HealthcheckScheduleExtendedExtended) GetChecklist() []string`

GetChecklist returns the Checklist field if non-nil, zero value otherwise.

### GetChecklistOk

`func (o *V10HealthcheckScheduleExtendedExtended) GetChecklistOk() (*[]string, bool)`

GetChecklistOk returns a tuple with the Checklist field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChecklist

`func (o *V10HealthcheckScheduleExtendedExtended) SetChecklist(v []string)`

SetChecklist sets Checklist field to given value.

### HasChecklist

`func (o *V10HealthcheckScheduleExtendedExtended) HasChecklist() bool`

HasChecklist returns a boolean if a field has been set.

### GetId

`func (o *V10HealthcheckScheduleExtendedExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10HealthcheckScheduleExtendedExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10HealthcheckScheduleExtendedExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V10HealthcheckScheduleExtendedExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetName

`func (o *V10HealthcheckScheduleExtendedExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10HealthcheckScheduleExtendedExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10HealthcheckScheduleExtendedExtended) SetName(v string)`

SetName sets Name field to given value.


### GetSchedule

`func (o *V10HealthcheckScheduleExtendedExtended) GetSchedule() string`

GetSchedule returns the Schedule field if non-nil, zero value otherwise.

### GetScheduleOk

`func (o *V10HealthcheckScheduleExtendedExtended) GetScheduleOk() (*string, bool)`

GetScheduleOk returns a tuple with the Schedule field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSchedule

`func (o *V10HealthcheckScheduleExtendedExtended) SetSchedule(v string)`

SetSchedule sets Schedule field to given value.

### HasSchedule

`func (o *V10HealthcheckScheduleExtendedExtended) HasSchedule() bool`

HasSchedule returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


