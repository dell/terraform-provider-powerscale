# Createv10S3KeyResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Keys** | [**Createv10S3KeyResponseKeys**](Createv10S3KeyResponseKeys.md) |  | 

## Methods

### NewCreatev10S3KeyResponse

`func NewCreatev10S3KeyResponse(keys Createv10S3KeyResponseKeys, ) *Createv10S3KeyResponse`

NewCreatev10S3KeyResponse instantiates a new Createv10S3KeyResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev10S3KeyResponseWithDefaults

`func NewCreatev10S3KeyResponseWithDefaults() *Createv10S3KeyResponse`

NewCreatev10S3KeyResponseWithDefaults instantiates a new Createv10S3KeyResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetKeys

`func (o *Createv10S3KeyResponse) GetKeys() Createv10S3KeyResponseKeys`

GetKeys returns the Keys field if non-nil, zero value otherwise.

### GetKeysOk

`func (o *Createv10S3KeyResponse) GetKeysOk() (*Createv10S3KeyResponseKeys, bool)`

GetKeysOk returns a tuple with the Keys field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKeys

`func (o *Createv10S3KeyResponse) SetKeys(v Createv10S3KeyResponseKeys)`

SetKeys sets Keys field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


