# V14CatalogImport

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**File** | **string** | Path of the signed file to import in the catalog | 

## Methods

### NewV14CatalogImport

`func NewV14CatalogImport(file string, ) *V14CatalogImport`

NewV14CatalogImport instantiates a new V14CatalogImport object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14CatalogImportWithDefaults

`func NewV14CatalogImportWithDefaults() *V14CatalogImport`

NewV14CatalogImportWithDefaults instantiates a new V14CatalogImport object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFile

`func (o *V14CatalogImport) GetFile() string`

GetFile returns the File field if non-nil, zero value otherwise.

### GetFileOk

`func (o *V14CatalogImport) GetFileOk() (*string, bool)`

GetFileOk returns a tuple with the File field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFile

`func (o *V14CatalogImport) SetFile(v string)`

SetFile sets File field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


