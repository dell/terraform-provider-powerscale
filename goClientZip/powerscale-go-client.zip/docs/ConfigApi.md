# \ConfigApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateConfigv12ConfigExport**](ConfigApi.md#CreateConfigv12ConfigExport) | **Post** /platform/12/config/exports | 
[**CreateConfigv12ConfigImport**](ConfigApi.md#CreateConfigv12ConfigImport) | **Post** /platform/12/config/imports | 
[**GetConfigv12ConfigExport**](ConfigApi.md#GetConfigv12ConfigExport) | **Get** /platform/12/config/exports/{v12ConfigExportId} | 
[**GetConfigv12ConfigImport**](ConfigApi.md#GetConfigv12ConfigImport) | **Get** /platform/12/config/imports/{v12ConfigImportId} | 
[**ListConfigv12ConfigExports**](ConfigApi.md#ListConfigv12ConfigExports) | **Get** /platform/12/config/exports | 
[**ListConfigv12ConfigImports**](ConfigApi.md#ListConfigv12ConfigImports) | **Get** /platform/12/config/imports | 



## CreateConfigv12ConfigExport

> Createv12ConfigExportResponse CreateConfigv12ConfigExport(ctx).V12ConfigExport(v12ConfigExport).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12ConfigExport := *openapiclient.NewV12ConfigExport() // V12ConfigExport | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ConfigApi.CreateConfigv12ConfigExport(context.Background()).V12ConfigExport(v12ConfigExport).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ConfigApi.CreateConfigv12ConfigExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateConfigv12ConfigExport`: Createv12ConfigExportResponse
    fmt.Fprintf(os.Stdout, "Response from `ConfigApi.CreateConfigv12ConfigExport`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateConfigv12ConfigExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12ConfigExport** | [**V12ConfigExport**](V12ConfigExport.md) |  | 

### Return type

[**Createv12ConfigExportResponse**](Createv12ConfigExportResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateConfigv12ConfigImport

> Createv12ConfigImportResponse CreateConfigv12ConfigImport(ctx).V12ConfigImport(v12ConfigImport).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12ConfigImport := *openapiclient.NewV12ConfigImport("ExportId_example") // V12ConfigImport | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ConfigApi.CreateConfigv12ConfigImport(context.Background()).V12ConfigImport(v12ConfigImport).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ConfigApi.CreateConfigv12ConfigImport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateConfigv12ConfigImport`: Createv12ConfigImportResponse
    fmt.Fprintf(os.Stdout, "Response from `ConfigApi.CreateConfigv12ConfigImport`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateConfigv12ConfigImportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12ConfigImport** | [**V12ConfigImport**](V12ConfigImport.md) |  | 

### Return type

[**Createv12ConfigImportResponse**](Createv12ConfigImportResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetConfigv12ConfigExport

> V12ConfigExports GetConfigv12ConfigExport(ctx, v12ConfigExportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12ConfigExportId := "v12ConfigExportId_example" // string | Retrieve export task information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ConfigApi.GetConfigv12ConfigExport(context.Background(), v12ConfigExportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ConfigApi.GetConfigv12ConfigExport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetConfigv12ConfigExport`: V12ConfigExports
    fmt.Fprintf(os.Stdout, "Response from `ConfigApi.GetConfigv12ConfigExport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12ConfigExportId** | **string** | Retrieve export task information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetConfigv12ConfigExportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12ConfigExports**](V12ConfigExports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetConfigv12ConfigImport

> V12ConfigImports GetConfigv12ConfigImport(ctx, v12ConfigImportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12ConfigImportId := "v12ConfigImportId_example" // string | Retrieve import task information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ConfigApi.GetConfigv12ConfigImport(context.Background(), v12ConfigImportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ConfigApi.GetConfigv12ConfigImport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetConfigv12ConfigImport`: V12ConfigImports
    fmt.Fprintf(os.Stdout, "Response from `ConfigApi.GetConfigv12ConfigImport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12ConfigImportId** | **string** | Retrieve import task information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetConfigv12ConfigImportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12ConfigImports**](V12ConfigImports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListConfigv12ConfigExports

> V12ConfigExports ListConfigv12ConfigExports(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ConfigApi.ListConfigv12ConfigExports(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ConfigApi.ListConfigv12ConfigExports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListConfigv12ConfigExports`: V12ConfigExports
    fmt.Fprintf(os.Stdout, "Response from `ConfigApi.ListConfigv12ConfigExports`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListConfigv12ConfigExportsRequest struct via the builder pattern


### Return type

[**V12ConfigExports**](V12ConfigExports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListConfigv12ConfigImports

> V12ConfigImports ListConfigv12ConfigImports(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ConfigApi.ListConfigv12ConfigImports(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ConfigApi.ListConfigv12ConfigImports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListConfigv12ConfigImports`: V12ConfigImports
    fmt.Fprintf(os.Stdout, "Response from `ConfigApi.ListConfigv12ConfigImports`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListConfigv12ConfigImportsRequest struct via the builder pattern


### Return type

[**V12ConfigImports**](V12ConfigImports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

