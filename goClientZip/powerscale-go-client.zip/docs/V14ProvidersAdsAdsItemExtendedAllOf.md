# V14ProvidersAdsAdsItemExtendedAllOf

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RecommendedSpns** | Pointer to **[]string** | Configuration recommended SPNs. | [optional] 
**Spns** | Pointer to **[]string** | Currently configured SPNs. | [optional] 

## Methods

### NewV14ProvidersAdsAdsItemExtendedAllOf

`func NewV14ProvidersAdsAdsItemExtendedAllOf() *V14ProvidersAdsAdsItemExtendedAllOf`

NewV14ProvidersAdsAdsItemExtendedAllOf instantiates a new V14ProvidersAdsAdsItemExtendedAllOf object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ProvidersAdsAdsItemExtendedAllOfWithDefaults

`func NewV14ProvidersAdsAdsItemExtendedAllOfWithDefaults() *V14ProvidersAdsAdsItemExtendedAllOf`

NewV14ProvidersAdsAdsItemExtendedAllOfWithDefaults instantiates a new V14ProvidersAdsAdsItemExtendedAllOf object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetRecommendedSpns

`func (o *V14ProvidersAdsAdsItemExtendedAllOf) GetRecommendedSpns() []string`

GetRecommendedSpns returns the RecommendedSpns field if non-nil, zero value otherwise.

### GetRecommendedSpnsOk

`func (o *V14ProvidersAdsAdsItemExtendedAllOf) GetRecommendedSpnsOk() (*[]string, bool)`

GetRecommendedSpnsOk returns a tuple with the RecommendedSpns field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRecommendedSpns

`func (o *V14ProvidersAdsAdsItemExtendedAllOf) SetRecommendedSpns(v []string)`

SetRecommendedSpns sets RecommendedSpns field to given value.

### HasRecommendedSpns

`func (o *V14ProvidersAdsAdsItemExtendedAllOf) HasRecommendedSpns() bool`

HasRecommendedSpns returns a boolean if a field has been set.

### GetSpns

`func (o *V14ProvidersAdsAdsItemExtendedAllOf) GetSpns() []string`

GetSpns returns the Spns field if non-nil, zero value otherwise.

### GetSpnsOk

`func (o *V14ProvidersAdsAdsItemExtendedAllOf) GetSpnsOk() (*[]string, bool)`

GetSpnsOk returns a tuple with the Spns field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpns

`func (o *V14ProvidersAdsAdsItemExtendedAllOf) SetSpns(v []string)`

SetSpns sets Spns field to given value.

### HasSpns

`func (o *V14ProvidersAdsAdsItemExtendedAllOf) HasSpns() bool`

HasSpns returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


