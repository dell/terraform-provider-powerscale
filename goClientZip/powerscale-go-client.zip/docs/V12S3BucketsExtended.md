# V12S3BucketsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Buckets** | [**[]V12S3Bucket**](V12S3Bucket.md) |  | 

## Methods

### NewV12S3BucketsExtended

`func NewV12S3BucketsExtended(buckets []V12S3Bucket, ) *V12S3BucketsExtended`

NewV12S3BucketsExtended instantiates a new V12S3BucketsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12S3BucketsExtendedWithDefaults

`func NewV12S3BucketsExtendedWithDefaults() *V12S3BucketsExtended`

NewV12S3BucketsExtendedWithDefaults instantiates a new V12S3BucketsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBuckets

`func (o *V12S3BucketsExtended) GetBuckets() []V12S3Bucket`

GetBuckets returns the Buckets field if non-nil, zero value otherwise.

### GetBucketsOk

`func (o *V12S3BucketsExtended) GetBucketsOk() (*[]V12S3Bucket, bool)`

GetBucketsOk returns a tuple with the Buckets field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBuckets

`func (o *V12S3BucketsExtended) SetBuckets(v []V12S3Bucket)`

SetBuckets sets Buckets field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


