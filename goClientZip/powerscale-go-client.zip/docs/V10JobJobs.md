# V10JobJobs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Jobs** | Pointer to [**[]V10JobJobExtended**](V10JobJobExtended.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV10JobJobs

`func NewV10JobJobs() *V10JobJobs`

NewV10JobJobs instantiates a new V10JobJobs object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10JobJobsWithDefaults

`func NewV10JobJobsWithDefaults() *V10JobJobs`

NewV10JobJobsWithDefaults instantiates a new V10JobJobs object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetJobs

`func (o *V10JobJobs) GetJobs() []V10JobJobExtended`

GetJobs returns the Jobs field if non-nil, zero value otherwise.

### GetJobsOk

`func (o *V10JobJobs) GetJobsOk() (*[]V10JobJobExtended, bool)`

GetJobsOk returns a tuple with the Jobs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJobs

`func (o *V10JobJobs) SetJobs(v []V10JobJobExtended)`

SetJobs sets Jobs field to given value.

### HasJobs

`func (o *V10JobJobs) HasJobs() bool`

HasJobs returns a boolean if a field has been set.

### GetResume

`func (o *V10JobJobs) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V10JobJobs) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V10JobJobs) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V10JobJobs) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V10JobJobs) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10JobJobs) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10JobJobs) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10JobJobs) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


