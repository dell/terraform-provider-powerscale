# V10JobJobTreedeleteParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeleteQuotas** | Pointer to **bool** | Delete quotas encountered during TreeDelete. When set to false, the job will fail if a quota is encountered. | [optional] [default to false]

## Methods

### NewV10JobJobTreedeleteParams

`func NewV10JobJobTreedeleteParams() *V10JobJobTreedeleteParams`

NewV10JobJobTreedeleteParams instantiates a new V10JobJobTreedeleteParams object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10JobJobTreedeleteParamsWithDefaults

`func NewV10JobJobTreedeleteParamsWithDefaults() *V10JobJobTreedeleteParams`

NewV10JobJobTreedeleteParamsWithDefaults instantiates a new V10JobJobTreedeleteParams object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDeleteQuotas

`func (o *V10JobJobTreedeleteParams) GetDeleteQuotas() bool`

GetDeleteQuotas returns the DeleteQuotas field if non-nil, zero value otherwise.

### GetDeleteQuotasOk

`func (o *V10JobJobTreedeleteParams) GetDeleteQuotasOk() (*bool, bool)`

GetDeleteQuotasOk returns a tuple with the DeleteQuotas field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeleteQuotas

`func (o *V10JobJobTreedeleteParams) SetDeleteQuotas(v bool)`

SetDeleteQuotas sets DeleteQuotas field to given value.

### HasDeleteQuotas

`func (o *V10JobJobTreedeleteParams) HasDeleteQuotas() bool`

HasDeleteQuotas returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


