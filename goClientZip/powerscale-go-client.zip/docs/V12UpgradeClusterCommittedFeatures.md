# V12UpgradeClusterCommittedFeatures

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DefaultGen** | Pointer to **int32** |  | [optional] 
**GenBits** | Pointer to [**[]V12UpgradeClusterCommittedFeaturesGenBit**](V12UpgradeClusterCommittedFeaturesGenBit.md) |  | [optional] 

## Methods

### NewV12UpgradeClusterCommittedFeatures

`func NewV12UpgradeClusterCommittedFeatures() *V12UpgradeClusterCommittedFeatures`

NewV12UpgradeClusterCommittedFeatures instantiates a new V12UpgradeClusterCommittedFeatures object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12UpgradeClusterCommittedFeaturesWithDefaults

`func NewV12UpgradeClusterCommittedFeaturesWithDefaults() *V12UpgradeClusterCommittedFeatures`

NewV12UpgradeClusterCommittedFeaturesWithDefaults instantiates a new V12UpgradeClusterCommittedFeatures object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDefaultGen

`func (o *V12UpgradeClusterCommittedFeatures) GetDefaultGen() int32`

GetDefaultGen returns the DefaultGen field if non-nil, zero value otherwise.

### GetDefaultGenOk

`func (o *V12UpgradeClusterCommittedFeatures) GetDefaultGenOk() (*int32, bool)`

GetDefaultGenOk returns a tuple with the DefaultGen field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDefaultGen

`func (o *V12UpgradeClusterCommittedFeatures) SetDefaultGen(v int32)`

SetDefaultGen sets DefaultGen field to given value.

### HasDefaultGen

`func (o *V12UpgradeClusterCommittedFeatures) HasDefaultGen() bool`

HasDefaultGen returns a boolean if a field has been set.

### GetGenBits

`func (o *V12UpgradeClusterCommittedFeatures) GetGenBits() []V12UpgradeClusterCommittedFeaturesGenBit`

GetGenBits returns the GenBits field if non-nil, zero value otherwise.

### GetGenBitsOk

`func (o *V12UpgradeClusterCommittedFeatures) GetGenBitsOk() (*[]V12UpgradeClusterCommittedFeaturesGenBit, bool)`

GetGenBitsOk returns a tuple with the GenBits field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGenBits

`func (o *V12UpgradeClusterCommittedFeatures) SetGenBits(v []V12UpgradeClusterCommittedFeaturesGenBit)`

SetGenBits sets GenBits field to given value.

### HasGenBits

`func (o *V12UpgradeClusterCommittedFeatures) HasGenBits() bool`

HasGenBits returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


