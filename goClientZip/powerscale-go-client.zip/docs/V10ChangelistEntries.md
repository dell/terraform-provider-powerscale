# V10ChangelistEntries

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Entries** | Pointer to [**[]V10ChangelistEntry**](V10ChangelistEntry.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 

## Methods

### NewV10ChangelistEntries

`func NewV10ChangelistEntries() *V10ChangelistEntries`

NewV10ChangelistEntries instantiates a new V10ChangelistEntries object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ChangelistEntriesWithDefaults

`func NewV10ChangelistEntriesWithDefaults() *V10ChangelistEntries`

NewV10ChangelistEntriesWithDefaults instantiates a new V10ChangelistEntries object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEntries

`func (o *V10ChangelistEntries) GetEntries() []V10ChangelistEntry`

GetEntries returns the Entries field if non-nil, zero value otherwise.

### GetEntriesOk

`func (o *V10ChangelistEntries) GetEntriesOk() (*[]V10ChangelistEntry, bool)`

GetEntriesOk returns a tuple with the Entries field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEntries

`func (o *V10ChangelistEntries) SetEntries(v []V10ChangelistEntry)`

SetEntries sets Entries field to given value.

### HasEntries

`func (o *V10ChangelistEntries) HasEntries() bool`

HasEntries returns a boolean if a field has been set.

### GetResume

`func (o *V10ChangelistEntries) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V10ChangelistEntries) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V10ChangelistEntries) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V10ChangelistEntries) HasResume() bool`

HasResume returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


