# V14ClusterModeSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CloudStorageConsole** | Pointer to **string** | URL for cloud storage console | [optional] 
**Monitoring** | Pointer to **string** | URL for monitoring | [optional] 
**StaasModeEnabled** | Pointer to **bool** | Gives STaaS mode status | [optional] 
**Support** | Pointer to **string** | URL for support | [optional] 

## Methods

### NewV14ClusterModeSettings

`func NewV14ClusterModeSettings() *V14ClusterModeSettings`

NewV14ClusterModeSettings instantiates a new V14ClusterModeSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ClusterModeSettingsWithDefaults

`func NewV14ClusterModeSettingsWithDefaults() *V14ClusterModeSettings`

NewV14ClusterModeSettingsWithDefaults instantiates a new V14ClusterModeSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCloudStorageConsole

`func (o *V14ClusterModeSettings) GetCloudStorageConsole() string`

GetCloudStorageConsole returns the CloudStorageConsole field if non-nil, zero value otherwise.

### GetCloudStorageConsoleOk

`func (o *V14ClusterModeSettings) GetCloudStorageConsoleOk() (*string, bool)`

GetCloudStorageConsoleOk returns a tuple with the CloudStorageConsole field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloudStorageConsole

`func (o *V14ClusterModeSettings) SetCloudStorageConsole(v string)`

SetCloudStorageConsole sets CloudStorageConsole field to given value.

### HasCloudStorageConsole

`func (o *V14ClusterModeSettings) HasCloudStorageConsole() bool`

HasCloudStorageConsole returns a boolean if a field has been set.

### GetMonitoring

`func (o *V14ClusterModeSettings) GetMonitoring() string`

GetMonitoring returns the Monitoring field if non-nil, zero value otherwise.

### GetMonitoringOk

`func (o *V14ClusterModeSettings) GetMonitoringOk() (*string, bool)`

GetMonitoringOk returns a tuple with the Monitoring field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMonitoring

`func (o *V14ClusterModeSettings) SetMonitoring(v string)`

SetMonitoring sets Monitoring field to given value.

### HasMonitoring

`func (o *V14ClusterModeSettings) HasMonitoring() bool`

HasMonitoring returns a boolean if a field has been set.

### GetStaasModeEnabled

`func (o *V14ClusterModeSettings) GetStaasModeEnabled() bool`

GetStaasModeEnabled returns the StaasModeEnabled field if non-nil, zero value otherwise.

### GetStaasModeEnabledOk

`func (o *V14ClusterModeSettings) GetStaasModeEnabledOk() (*bool, bool)`

GetStaasModeEnabledOk returns a tuple with the StaasModeEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStaasModeEnabled

`func (o *V14ClusterModeSettings) SetStaasModeEnabled(v bool)`

SetStaasModeEnabled sets StaasModeEnabled field to given value.

### HasStaasModeEnabled

`func (o *V14ClusterModeSettings) HasStaasModeEnabled() bool`

HasStaasModeEnabled returns a boolean if a field has been set.

### GetSupport

`func (o *V14ClusterModeSettings) GetSupport() string`

GetSupport returns the Support field if non-nil, zero value otherwise.

### GetSupportOk

`func (o *V14ClusterModeSettings) GetSupportOk() (*string, bool)`

GetSupportOk returns a tuple with the Support field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupport

`func (o *V14ClusterModeSettings) SetSupport(v string)`

SetSupport sets Support field to given value.

### HasSupport

`func (o *V14ClusterModeSettings) HasSupport() bool`

HasSupport returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


