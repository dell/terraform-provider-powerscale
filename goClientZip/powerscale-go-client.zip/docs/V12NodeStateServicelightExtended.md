# V12NodeStateServicelightExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | Pointer to **bool** | The node service light state (True &#x3D; on). | [optional] 
**Supported** | Pointer to **bool** | This node supports a service light. | [optional] 
**Valid** | Pointer to **bool** | The node service light state is valid (False &#x3D; Error). | [optional] 

## Methods

### NewV12NodeStateServicelightExtended

`func NewV12NodeStateServicelightExtended() *V12NodeStateServicelightExtended`

NewV12NodeStateServicelightExtended instantiates a new V12NodeStateServicelightExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NodeStateServicelightExtendedWithDefaults

`func NewV12NodeStateServicelightExtendedWithDefaults() *V12NodeStateServicelightExtended`

NewV12NodeStateServicelightExtendedWithDefaults instantiates a new V12NodeStateServicelightExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *V12NodeStateServicelightExtended) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V12NodeStateServicelightExtended) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V12NodeStateServicelightExtended) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V12NodeStateServicelightExtended) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetSupported

`func (o *V12NodeStateServicelightExtended) GetSupported() bool`

GetSupported returns the Supported field if non-nil, zero value otherwise.

### GetSupportedOk

`func (o *V12NodeStateServicelightExtended) GetSupportedOk() (*bool, bool)`

GetSupportedOk returns a tuple with the Supported field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupported

`func (o *V12NodeStateServicelightExtended) SetSupported(v bool)`

SetSupported sets Supported field to given value.

### HasSupported

`func (o *V12NodeStateServicelightExtended) HasSupported() bool`

HasSupported returns a boolean if a field has been set.

### GetValid

`func (o *V12NodeStateServicelightExtended) GetValid() bool`

GetValid returns the Valid field if non-nil, zero value otherwise.

### GetValidOk

`func (o *V12NodeStateServicelightExtended) GetValidOk() (*bool, bool)`

GetValidOk returns a tuple with the Valid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValid

`func (o *V12NodeStateServicelightExtended) SetValid(v bool)`

SetValid sets Valid field to given value.

### HasValid

`func (o *V12NodeStateServicelightExtended) HasValid() bool`

HasValid returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


