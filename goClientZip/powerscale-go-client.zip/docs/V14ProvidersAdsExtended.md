# V14ProvidersAdsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ads** | Pointer to [**[]V14ProvidersAdsAdsItemExtended**](V14ProvidersAdsAdsItemExtended.md) |  | [optional] 

## Methods

### NewV14ProvidersAdsExtended

`func NewV14ProvidersAdsExtended() *V14ProvidersAdsExtended`

NewV14ProvidersAdsExtended instantiates a new V14ProvidersAdsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ProvidersAdsExtendedWithDefaults

`func NewV14ProvidersAdsExtendedWithDefaults() *V14ProvidersAdsExtended`

NewV14ProvidersAdsExtendedWithDefaults instantiates a new V14ProvidersAdsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAds

`func (o *V14ProvidersAdsExtended) GetAds() []V14ProvidersAdsAdsItemExtended`

GetAds returns the Ads field if non-nil, zero value otherwise.

### GetAdsOk

`func (o *V14ProvidersAdsExtended) GetAdsOk() (*[]V14ProvidersAdsAdsItemExtended, bool)`

GetAdsOk returns a tuple with the Ads field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAds

`func (o *V14ProvidersAdsExtended) SetAds(v []V14ProvidersAdsAdsItemExtended)`

SetAds sets Ads field to given value.

### HasAds

`func (o *V14ProvidersAdsExtended) HasAds() bool`

HasAds returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


