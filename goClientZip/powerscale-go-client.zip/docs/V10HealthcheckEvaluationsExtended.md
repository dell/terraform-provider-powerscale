# V10HealthcheckEvaluationsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Evaluations** | Pointer to [**[]V10HealthcheckEvaluationExtended**](V10HealthcheckEvaluationExtended.md) |  | [optional] 

## Methods

### NewV10HealthcheckEvaluationsExtended

`func NewV10HealthcheckEvaluationsExtended() *V10HealthcheckEvaluationsExtended`

NewV10HealthcheckEvaluationsExtended instantiates a new V10HealthcheckEvaluationsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckEvaluationsExtendedWithDefaults

`func NewV10HealthcheckEvaluationsExtendedWithDefaults() *V10HealthcheckEvaluationsExtended`

NewV10HealthcheckEvaluationsExtendedWithDefaults instantiates a new V10HealthcheckEvaluationsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEvaluations

`func (o *V10HealthcheckEvaluationsExtended) GetEvaluations() []V10HealthcheckEvaluationExtended`

GetEvaluations returns the Evaluations field if non-nil, zero value otherwise.

### GetEvaluationsOk

`func (o *V10HealthcheckEvaluationsExtended) GetEvaluationsOk() (*[]V10HealthcheckEvaluationExtended, bool)`

GetEvaluationsOk returns a tuple with the Evaluations field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEvaluations

`func (o *V10HealthcheckEvaluationsExtended) SetEvaluations(v []V10HealthcheckEvaluationExtended)`

SetEvaluations sets Evaluations field to given value.

### HasEvaluations

`func (o *V10HealthcheckEvaluationsExtended) HasEvaluations() bool`

HasEvaluations returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


