# NamespaceObjects

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Children** | Pointer to [**[]NamespaceObject**](NamespaceObject.md) |  | [optional] 
**Resume** | Pointer to **string** |  | [optional] 

## Methods

### NewNamespaceObjects

`func NewNamespaceObjects() *NamespaceObjects`

NewNamespaceObjects instantiates a new NamespaceObjects object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewNamespaceObjectsWithDefaults

`func NewNamespaceObjectsWithDefaults() *NamespaceObjects`

NewNamespaceObjectsWithDefaults instantiates a new NamespaceObjects object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChildren

`func (o *NamespaceObjects) GetChildren() []NamespaceObject`

GetChildren returns the Children field if non-nil, zero value otherwise.

### GetChildrenOk

`func (o *NamespaceObjects) GetChildrenOk() (*[]NamespaceObject, bool)`

GetChildrenOk returns a tuple with the Children field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChildren

`func (o *NamespaceObjects) SetChildren(v []NamespaceObject)`

SetChildren sets Children field to given value.

### HasChildren

`func (o *NamespaceObjects) HasChildren() bool`

HasChildren returns a boolean if a field has been set.

### GetResume

`func (o *NamespaceObjects) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *NamespaceObjects) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *NamespaceObjects) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *NamespaceObjects) HasResume() bool`

HasResume returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


