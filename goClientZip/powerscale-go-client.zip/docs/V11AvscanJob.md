# V11AvscanJob

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Description** | Pointer to **string** | Free-form customer description of job. | [optional] 
**Enabled** | Pointer to **bool** | Whether the job is enabled. | [optional] 
**FileExtensionAction** | Pointer to **string** | When a file matches an entry in the list of file extensions, do we include or exclude it?. | [optional] 
**FileExtensions** | Pointer to **[]string** | Array of file extensions to use in scanning decision. | [optional] 
**Id** | Pointer to **string** | A unique identifier for the job. | [optional] 
**IgnorePreviousScanStatus** | Pointer to **bool** | If True, force a scan of a previously scanned file. | [optional] 
**Impact** | Pointer to **string** | Specifies an impact policy for the antivirus scan jobs. | [optional] 
**JobName** | **string** | Unique short name for job. | 
**PathsToExclude** | Pointer to **[]string** | Array of relative paths under paths_to_include not to scan. | [optional] 
**PathsToInclude** | Pointer to **[]string** | Array of absolute paths under /ifs to scan. | [optional] 
**ScanCloudpoolFiles** | Pointer to **bool** | Perform real-time scans of cloudpool files? | [optional] 
**ScanIfNoExtension** | Pointer to **bool** | Scan files without extensions? | [optional] 
**Schedule** | Pointer to **string** | The ever-unfortunate &#39;schedule&#39; string type, e.g. &#39;every Thursday at 01:00&#39;. | [optional] 

## Methods

### NewV11AvscanJob

`func NewV11AvscanJob(jobName string, ) *V11AvscanJob`

NewV11AvscanJob instantiates a new V11AvscanJob object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanJobWithDefaults

`func NewV11AvscanJobWithDefaults() *V11AvscanJob`

NewV11AvscanJobWithDefaults instantiates a new V11AvscanJob object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDescription

`func (o *V11AvscanJob) GetDescription() string`

GetDescription returns the Description field if non-nil, zero value otherwise.

### GetDescriptionOk

`func (o *V11AvscanJob) GetDescriptionOk() (*string, bool)`

GetDescriptionOk returns a tuple with the Description field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDescription

`func (o *V11AvscanJob) SetDescription(v string)`

SetDescription sets Description field to given value.

### HasDescription

`func (o *V11AvscanJob) HasDescription() bool`

HasDescription returns a boolean if a field has been set.

### GetEnabled

`func (o *V11AvscanJob) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V11AvscanJob) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V11AvscanJob) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V11AvscanJob) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetFileExtensionAction

`func (o *V11AvscanJob) GetFileExtensionAction() string`

GetFileExtensionAction returns the FileExtensionAction field if non-nil, zero value otherwise.

### GetFileExtensionActionOk

`func (o *V11AvscanJob) GetFileExtensionActionOk() (*string, bool)`

GetFileExtensionActionOk returns a tuple with the FileExtensionAction field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileExtensionAction

`func (o *V11AvscanJob) SetFileExtensionAction(v string)`

SetFileExtensionAction sets FileExtensionAction field to given value.

### HasFileExtensionAction

`func (o *V11AvscanJob) HasFileExtensionAction() bool`

HasFileExtensionAction returns a boolean if a field has been set.

### GetFileExtensions

`func (o *V11AvscanJob) GetFileExtensions() []string`

GetFileExtensions returns the FileExtensions field if non-nil, zero value otherwise.

### GetFileExtensionsOk

`func (o *V11AvscanJob) GetFileExtensionsOk() (*[]string, bool)`

GetFileExtensionsOk returns a tuple with the FileExtensions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFileExtensions

`func (o *V11AvscanJob) SetFileExtensions(v []string)`

SetFileExtensions sets FileExtensions field to given value.

### HasFileExtensions

`func (o *V11AvscanJob) HasFileExtensions() bool`

HasFileExtensions returns a boolean if a field has been set.

### GetId

`func (o *V11AvscanJob) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11AvscanJob) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11AvscanJob) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11AvscanJob) HasId() bool`

HasId returns a boolean if a field has been set.

### GetIgnorePreviousScanStatus

`func (o *V11AvscanJob) GetIgnorePreviousScanStatus() bool`

GetIgnorePreviousScanStatus returns the IgnorePreviousScanStatus field if non-nil, zero value otherwise.

### GetIgnorePreviousScanStatusOk

`func (o *V11AvscanJob) GetIgnorePreviousScanStatusOk() (*bool, bool)`

GetIgnorePreviousScanStatusOk returns a tuple with the IgnorePreviousScanStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIgnorePreviousScanStatus

`func (o *V11AvscanJob) SetIgnorePreviousScanStatus(v bool)`

SetIgnorePreviousScanStatus sets IgnorePreviousScanStatus field to given value.

### HasIgnorePreviousScanStatus

`func (o *V11AvscanJob) HasIgnorePreviousScanStatus() bool`

HasIgnorePreviousScanStatus returns a boolean if a field has been set.

### GetImpact

`func (o *V11AvscanJob) GetImpact() string`

GetImpact returns the Impact field if non-nil, zero value otherwise.

### GetImpactOk

`func (o *V11AvscanJob) GetImpactOk() (*string, bool)`

GetImpactOk returns a tuple with the Impact field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImpact

`func (o *V11AvscanJob) SetImpact(v string)`

SetImpact sets Impact field to given value.

### HasImpact

`func (o *V11AvscanJob) HasImpact() bool`

HasImpact returns a boolean if a field has been set.

### GetJobName

`func (o *V11AvscanJob) GetJobName() string`

GetJobName returns the JobName field if non-nil, zero value otherwise.

### GetJobNameOk

`func (o *V11AvscanJob) GetJobNameOk() (*string, bool)`

GetJobNameOk returns a tuple with the JobName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJobName

`func (o *V11AvscanJob) SetJobName(v string)`

SetJobName sets JobName field to given value.


### GetPathsToExclude

`func (o *V11AvscanJob) GetPathsToExclude() []string`

GetPathsToExclude returns the PathsToExclude field if non-nil, zero value otherwise.

### GetPathsToExcludeOk

`func (o *V11AvscanJob) GetPathsToExcludeOk() (*[]string, bool)`

GetPathsToExcludeOk returns a tuple with the PathsToExclude field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPathsToExclude

`func (o *V11AvscanJob) SetPathsToExclude(v []string)`

SetPathsToExclude sets PathsToExclude field to given value.

### HasPathsToExclude

`func (o *V11AvscanJob) HasPathsToExclude() bool`

HasPathsToExclude returns a boolean if a field has been set.

### GetPathsToInclude

`func (o *V11AvscanJob) GetPathsToInclude() []string`

GetPathsToInclude returns the PathsToInclude field if non-nil, zero value otherwise.

### GetPathsToIncludeOk

`func (o *V11AvscanJob) GetPathsToIncludeOk() (*[]string, bool)`

GetPathsToIncludeOk returns a tuple with the PathsToInclude field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPathsToInclude

`func (o *V11AvscanJob) SetPathsToInclude(v []string)`

SetPathsToInclude sets PathsToInclude field to given value.

### HasPathsToInclude

`func (o *V11AvscanJob) HasPathsToInclude() bool`

HasPathsToInclude returns a boolean if a field has been set.

### GetScanCloudpoolFiles

`func (o *V11AvscanJob) GetScanCloudpoolFiles() bool`

GetScanCloudpoolFiles returns the ScanCloudpoolFiles field if non-nil, zero value otherwise.

### GetScanCloudpoolFilesOk

`func (o *V11AvscanJob) GetScanCloudpoolFilesOk() (*bool, bool)`

GetScanCloudpoolFilesOk returns a tuple with the ScanCloudpoolFiles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanCloudpoolFiles

`func (o *V11AvscanJob) SetScanCloudpoolFiles(v bool)`

SetScanCloudpoolFiles sets ScanCloudpoolFiles field to given value.

### HasScanCloudpoolFiles

`func (o *V11AvscanJob) HasScanCloudpoolFiles() bool`

HasScanCloudpoolFiles returns a boolean if a field has been set.

### GetScanIfNoExtension

`func (o *V11AvscanJob) GetScanIfNoExtension() bool`

GetScanIfNoExtension returns the ScanIfNoExtension field if non-nil, zero value otherwise.

### GetScanIfNoExtensionOk

`func (o *V11AvscanJob) GetScanIfNoExtensionOk() (*bool, bool)`

GetScanIfNoExtensionOk returns a tuple with the ScanIfNoExtension field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanIfNoExtension

`func (o *V11AvscanJob) SetScanIfNoExtension(v bool)`

SetScanIfNoExtension sets ScanIfNoExtension field to given value.

### HasScanIfNoExtension

`func (o *V11AvscanJob) HasScanIfNoExtension() bool`

HasScanIfNoExtension returns a boolean if a field has been set.

### GetSchedule

`func (o *V11AvscanJob) GetSchedule() string`

GetSchedule returns the Schedule field if non-nil, zero value otherwise.

### GetScheduleOk

`func (o *V11AvscanJob) GetScheduleOk() (*string, bool)`

GetScheduleOk returns a tuple with the Schedule field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSchedule

`func (o *V11AvscanJob) SetSchedule(v string)`

SetSchedule sets Schedule field to given value.

### HasSchedule

`func (o *V11AvscanJob) HasSchedule() bool`

HasSchedule returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


