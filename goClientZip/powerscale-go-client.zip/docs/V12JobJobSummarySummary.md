# V12JobJobSummarySummary

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClusterIsDegraded** | **bool** | Whether the cluster is in a degraded state.  Note this is from the perspective of the node handling the query, which might be different from another node. | 
**Connected** | **bool** | Whether isi_job_d instances on all up nodes in the cluster are connected to the coordinator. | 
**Coordinator** | **int32** | The devid of the job engine coordinator. | 
**CoordinatorLnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**DisconnectedNodes** | Pointer to **[]int32** | If connected&#x3D;false, this is the set of devids that are not connected to the coordinator. | [optional] 
**DownOrReadOnlyNodes** | **bool** | Whether the cluster has any down or read-only nodes.  These nodes are not considered in the connected property. | 
**JobDEnabled** | **bool** | Whether the isi_job_d is enabled. | 
**NextJid** | **int32** | The job ID to be assigned to the next job. | 
**NonRespondingNodes** | Pointer to **[]int32** | Shows which nodes have not acknowledged the coordinator. | [optional] 
**RunDegraded** | **bool** | Whether the job engine would allow most jobs to run even when the cluster is in a degraded state. | 
**StatsReady** | **bool** | Whether the coordinator has recently gathered statistics for all nodes in the cluster. | 

## Methods

### NewV12JobJobSummarySummary

`func NewV12JobJobSummarySummary(clusterIsDegraded bool, connected bool, coordinator int32, downOrReadOnlyNodes bool, jobDEnabled bool, nextJid int32, runDegraded bool, statsReady bool, ) *V12JobJobSummarySummary`

NewV12JobJobSummarySummary instantiates a new V12JobJobSummarySummary object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12JobJobSummarySummaryWithDefaults

`func NewV12JobJobSummarySummaryWithDefaults() *V12JobJobSummarySummary`

NewV12JobJobSummarySummaryWithDefaults instantiates a new V12JobJobSummarySummary object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetClusterIsDegraded

`func (o *V12JobJobSummarySummary) GetClusterIsDegraded() bool`

GetClusterIsDegraded returns the ClusterIsDegraded field if non-nil, zero value otherwise.

### GetClusterIsDegradedOk

`func (o *V12JobJobSummarySummary) GetClusterIsDegradedOk() (*bool, bool)`

GetClusterIsDegradedOk returns a tuple with the ClusterIsDegraded field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClusterIsDegraded

`func (o *V12JobJobSummarySummary) SetClusterIsDegraded(v bool)`

SetClusterIsDegraded sets ClusterIsDegraded field to given value.


### GetConnected

`func (o *V12JobJobSummarySummary) GetConnected() bool`

GetConnected returns the Connected field if non-nil, zero value otherwise.

### GetConnectedOk

`func (o *V12JobJobSummarySummary) GetConnectedOk() (*bool, bool)`

GetConnectedOk returns a tuple with the Connected field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConnected

`func (o *V12JobJobSummarySummary) SetConnected(v bool)`

SetConnected sets Connected field to given value.


### GetCoordinator

`func (o *V12JobJobSummarySummary) GetCoordinator() int32`

GetCoordinator returns the Coordinator field if non-nil, zero value otherwise.

### GetCoordinatorOk

`func (o *V12JobJobSummarySummary) GetCoordinatorOk() (*int32, bool)`

GetCoordinatorOk returns a tuple with the Coordinator field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCoordinator

`func (o *V12JobJobSummarySummary) SetCoordinator(v int32)`

SetCoordinator sets Coordinator field to given value.


### GetCoordinatorLnn

`func (o *V12JobJobSummarySummary) GetCoordinatorLnn() int32`

GetCoordinatorLnn returns the CoordinatorLnn field if non-nil, zero value otherwise.

### GetCoordinatorLnnOk

`func (o *V12JobJobSummarySummary) GetCoordinatorLnnOk() (*int32, bool)`

GetCoordinatorLnnOk returns a tuple with the CoordinatorLnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCoordinatorLnn

`func (o *V12JobJobSummarySummary) SetCoordinatorLnn(v int32)`

SetCoordinatorLnn sets CoordinatorLnn field to given value.

### HasCoordinatorLnn

`func (o *V12JobJobSummarySummary) HasCoordinatorLnn() bool`

HasCoordinatorLnn returns a boolean if a field has been set.

### GetDisconnectedNodes

`func (o *V12JobJobSummarySummary) GetDisconnectedNodes() []int32`

GetDisconnectedNodes returns the DisconnectedNodes field if non-nil, zero value otherwise.

### GetDisconnectedNodesOk

`func (o *V12JobJobSummarySummary) GetDisconnectedNodesOk() (*[]int32, bool)`

GetDisconnectedNodesOk returns a tuple with the DisconnectedNodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDisconnectedNodes

`func (o *V12JobJobSummarySummary) SetDisconnectedNodes(v []int32)`

SetDisconnectedNodes sets DisconnectedNodes field to given value.

### HasDisconnectedNodes

`func (o *V12JobJobSummarySummary) HasDisconnectedNodes() bool`

HasDisconnectedNodes returns a boolean if a field has been set.

### GetDownOrReadOnlyNodes

`func (o *V12JobJobSummarySummary) GetDownOrReadOnlyNodes() bool`

GetDownOrReadOnlyNodes returns the DownOrReadOnlyNodes field if non-nil, zero value otherwise.

### GetDownOrReadOnlyNodesOk

`func (o *V12JobJobSummarySummary) GetDownOrReadOnlyNodesOk() (*bool, bool)`

GetDownOrReadOnlyNodesOk returns a tuple with the DownOrReadOnlyNodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDownOrReadOnlyNodes

`func (o *V12JobJobSummarySummary) SetDownOrReadOnlyNodes(v bool)`

SetDownOrReadOnlyNodes sets DownOrReadOnlyNodes field to given value.


### GetJobDEnabled

`func (o *V12JobJobSummarySummary) GetJobDEnabled() bool`

GetJobDEnabled returns the JobDEnabled field if non-nil, zero value otherwise.

### GetJobDEnabledOk

`func (o *V12JobJobSummarySummary) GetJobDEnabledOk() (*bool, bool)`

GetJobDEnabledOk returns a tuple with the JobDEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJobDEnabled

`func (o *V12JobJobSummarySummary) SetJobDEnabled(v bool)`

SetJobDEnabled sets JobDEnabled field to given value.


### GetNextJid

`func (o *V12JobJobSummarySummary) GetNextJid() int32`

GetNextJid returns the NextJid field if non-nil, zero value otherwise.

### GetNextJidOk

`func (o *V12JobJobSummarySummary) GetNextJidOk() (*int32, bool)`

GetNextJidOk returns a tuple with the NextJid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNextJid

`func (o *V12JobJobSummarySummary) SetNextJid(v int32)`

SetNextJid sets NextJid field to given value.


### GetNonRespondingNodes

`func (o *V12JobJobSummarySummary) GetNonRespondingNodes() []int32`

GetNonRespondingNodes returns the NonRespondingNodes field if non-nil, zero value otherwise.

### GetNonRespondingNodesOk

`func (o *V12JobJobSummarySummary) GetNonRespondingNodesOk() (*[]int32, bool)`

GetNonRespondingNodesOk returns a tuple with the NonRespondingNodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNonRespondingNodes

`func (o *V12JobJobSummarySummary) SetNonRespondingNodes(v []int32)`

SetNonRespondingNodes sets NonRespondingNodes field to given value.

### HasNonRespondingNodes

`func (o *V12JobJobSummarySummary) HasNonRespondingNodes() bool`

HasNonRespondingNodes returns a boolean if a field has been set.

### GetRunDegraded

`func (o *V12JobJobSummarySummary) GetRunDegraded() bool`

GetRunDegraded returns the RunDegraded field if non-nil, zero value otherwise.

### GetRunDegradedOk

`func (o *V12JobJobSummarySummary) GetRunDegradedOk() (*bool, bool)`

GetRunDegradedOk returns a tuple with the RunDegraded field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRunDegraded

`func (o *V12JobJobSummarySummary) SetRunDegraded(v bool)`

SetRunDegraded sets RunDegraded field to given value.


### GetStatsReady

`func (o *V12JobJobSummarySummary) GetStatsReady() bool`

GetStatsReady returns the StatsReady field if non-nil, zero value otherwise.

### GetStatsReadyOk

`func (o *V12JobJobSummarySummary) GetStatsReadyOk() (*bool, bool)`

GetStatsReadyOk returns a tuple with the StatsReady field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatsReady

`func (o *V12JobJobSummarySummary) SetStatsReady(v bool)`

SetStatsReady sets StatsReady field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


