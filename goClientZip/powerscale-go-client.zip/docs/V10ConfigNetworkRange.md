# V10ConfigNetworkRange

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**High** | Pointer to **string** | IPv4 address in the format: xxx.xxx.xxx.xxx | [optional] 
**Low** | Pointer to **string** | IPv4 address in the format: xxx.xxx.xxx.xxx | [optional] 

## Methods

### NewV10ConfigNetworkRange

`func NewV10ConfigNetworkRange() *V10ConfigNetworkRange`

NewV10ConfigNetworkRange instantiates a new V10ConfigNetworkRange object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ConfigNetworkRangeWithDefaults

`func NewV10ConfigNetworkRangeWithDefaults() *V10ConfigNetworkRange`

NewV10ConfigNetworkRangeWithDefaults instantiates a new V10ConfigNetworkRange object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHigh

`func (o *V10ConfigNetworkRange) GetHigh() string`

GetHigh returns the High field if non-nil, zero value otherwise.

### GetHighOk

`func (o *V10ConfigNetworkRange) GetHighOk() (*string, bool)`

GetHighOk returns a tuple with the High field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHigh

`func (o *V10ConfigNetworkRange) SetHigh(v string)`

SetHigh sets High field to given value.

### HasHigh

`func (o *V10ConfigNetworkRange) HasHigh() bool`

HasHigh returns a boolean if a field has been set.

### GetLow

`func (o *V10ConfigNetworkRange) GetLow() string`

GetLow returns the Low field if non-nil, zero value otherwise.

### GetLowOk

`func (o *V10ConfigNetworkRange) GetLowOk() (*string, bool)`

GetLowOk returns a tuple with the Low field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLow

`func (o *V10ConfigNetworkRange) SetLow(v string)`

SetLow sets Low field to given value.

### HasLow

`func (o *V10ConfigNetworkRange) HasLow() bool`

HasLow returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


