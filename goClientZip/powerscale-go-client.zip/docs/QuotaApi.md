# \QuotaApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateQuotav12QuotaQuota**](QuotaApi.md#CreateQuotav12QuotaQuota) | **Post** /platform/12/quota/quotas | 
[**CreateQuotav1QuotaQuota**](QuotaApi.md#CreateQuotav1QuotaQuota) | **Post** /platform/1/quota/quotas | 
[**CreateQuotav1QuotaReport**](QuotaApi.md#CreateQuotav1QuotaReport) | **Post** /platform/1/quota/reports | 
[**CreateQuotav1SettingsMapping**](QuotaApi.md#CreateQuotav1SettingsMapping) | **Post** /platform/1/quota/settings/mappings | 
[**CreateQuotav1SettingsNotification**](QuotaApi.md#CreateQuotav1SettingsNotification) | **Post** /platform/1/quota/settings/notifications | 
[**CreateQuotav7QuotaQuota**](QuotaApi.md#CreateQuotav7QuotaQuota) | **Post** /platform/7/quota/quotas | 
[**CreateQuotav7SettingsNotification**](QuotaApi.md#CreateQuotav7SettingsNotification) | **Post** /platform/7/quota/settings/notifications | 
[**CreateQuotav8QuotaQuota**](QuotaApi.md#CreateQuotav8QuotaQuota) | **Post** /platform/8/quota/quotas | 
[**DeleteQuotav12QuotaQuota**](QuotaApi.md#DeleteQuotav12QuotaQuota) | **Delete** /platform/12/quota/quotas/{v12QuotaQuotaId} | 
[**DeleteQuotav12QuotaQuotas**](QuotaApi.md#DeleteQuotav12QuotaQuotas) | **Delete** /platform/12/quota/quotas | 
[**DeleteQuotav1QuotaQuota**](QuotaApi.md#DeleteQuotav1QuotaQuota) | **Delete** /platform/1/quota/quotas/{v1QuotaQuotaId} | 
[**DeleteQuotav1QuotaQuotas**](QuotaApi.md#DeleteQuotav1QuotaQuotas) | **Delete** /platform/1/quota/quotas | 
[**DeleteQuotav1QuotaReport**](QuotaApi.md#DeleteQuotav1QuotaReport) | **Delete** /platform/1/quota/reports/{v1QuotaReportId} | 
[**DeleteQuotav1QuotasQidNotification**](QuotaApi.md#DeleteQuotav1QuotasQidNotification) | **Delete** /platform/1/quota/quotas/{Qid}/notifications/{v1QuotasQidNotificationId} | 
[**DeleteQuotav1SettingsMapping**](QuotaApi.md#DeleteQuotav1SettingsMapping) | **Delete** /platform/1/quota/settings/mappings/{v1SettingsMappingId} | 
[**DeleteQuotav1SettingsMappings**](QuotaApi.md#DeleteQuotav1SettingsMappings) | **Delete** /platform/1/quota/settings/mappings | 
[**DeleteQuotav1SettingsNotification**](QuotaApi.md#DeleteQuotav1SettingsNotification) | **Delete** /platform/1/quota/settings/notifications/{v1SettingsNotificationId} | 
[**DeleteQuotav1SettingsNotifications**](QuotaApi.md#DeleteQuotav1SettingsNotifications) | **Delete** /platform/1/quota/settings/notifications | 
[**DeleteQuotav7QuotaQuota**](QuotaApi.md#DeleteQuotav7QuotaQuota) | **Delete** /platform/7/quota/quotas/{v7QuotaQuotaId} | 
[**DeleteQuotav7QuotaQuotas**](QuotaApi.md#DeleteQuotav7QuotaQuotas) | **Delete** /platform/7/quota/quotas | 
[**DeleteQuotav7QuotasQidNotification**](QuotaApi.md#DeleteQuotav7QuotasQidNotification) | **Delete** /platform/7/quota/quotas/{Qid}/notifications/{v7QuotasQidNotificationId} | 
[**DeleteQuotav7SettingsNotification**](QuotaApi.md#DeleteQuotav7SettingsNotification) | **Delete** /platform/7/quota/settings/notifications/{v7SettingsNotificationId} | 
[**DeleteQuotav7SettingsNotifications**](QuotaApi.md#DeleteQuotav7SettingsNotifications) | **Delete** /platform/7/quota/settings/notifications | 
[**DeleteQuotav8QuotaQuota**](QuotaApi.md#DeleteQuotav8QuotaQuota) | **Delete** /platform/8/quota/quotas/{v8QuotaQuotaId} | 
[**DeleteQuotav8QuotaQuotas**](QuotaApi.md#DeleteQuotav8QuotaQuotas) | **Delete** /platform/8/quota/quotas | 
[**GetQuotav12QuotaQuota**](QuotaApi.md#GetQuotav12QuotaQuota) | **Get** /platform/12/quota/quotas/{v12QuotaQuotaId} | 
[**GetQuotav1QuotaLicense**](QuotaApi.md#GetQuotav1QuotaLicense) | **Get** /platform/1/quota/license | 
[**GetQuotav1QuotaQuota**](QuotaApi.md#GetQuotav1QuotaQuota) | **Get** /platform/1/quota/quotas/{v1QuotaQuotaId} | 
[**GetQuotav1QuotaQuotasSummary**](QuotaApi.md#GetQuotav1QuotaQuotasSummary) | **Get** /platform/1/quota/quotas-summary | 
[**GetQuotav1QuotaReport**](QuotaApi.md#GetQuotav1QuotaReport) | **Get** /platform/1/quota/reports/{v1QuotaReportId} | 
[**GetQuotav1QuotasQidNotification**](QuotaApi.md#GetQuotav1QuotasQidNotification) | **Get** /platform/1/quota/quotas/{Qid}/notifications/{v1QuotasQidNotificationId} | 
[**GetQuotav1SettingsMapping**](QuotaApi.md#GetQuotav1SettingsMapping) | **Get** /platform/1/quota/settings/mappings/{v1SettingsMappingId} | 
[**GetQuotav1SettingsNotification**](QuotaApi.md#GetQuotav1SettingsNotification) | **Get** /platform/1/quota/settings/notifications/{v1SettingsNotificationId} | 
[**GetQuotav1SettingsReports**](QuotaApi.md#GetQuotav1SettingsReports) | **Get** /platform/1/quota/settings/reports | 
[**GetQuotav5QuotaLicense**](QuotaApi.md#GetQuotav5QuotaLicense) | **Get** /platform/5/quota/license | 
[**GetQuotav7QuotaQuota**](QuotaApi.md#GetQuotav7QuotaQuota) | **Get** /platform/7/quota/quotas/{v7QuotaQuotaId} | 
[**GetQuotav7QuotasQidNotification**](QuotaApi.md#GetQuotav7QuotasQidNotification) | **Get** /platform/7/quota/quotas/{Qid}/notifications/{v7QuotasQidNotificationId} | 
[**GetQuotav7SettingsNotification**](QuotaApi.md#GetQuotav7SettingsNotification) | **Get** /platform/7/quota/settings/notifications/{v7SettingsNotificationId} | 
[**GetQuotav8QuotaQuota**](QuotaApi.md#GetQuotav8QuotaQuota) | **Get** /platform/8/quota/quotas/{v8QuotaQuotaId} | 
[**ListQuotav12QuotaQuotas**](QuotaApi.md#ListQuotav12QuotaQuotas) | **Get** /platform/12/quota/quotas | 
[**ListQuotav1QuotaQuotas**](QuotaApi.md#ListQuotav1QuotaQuotas) | **Get** /platform/1/quota/quotas | 
[**ListQuotav1QuotaReports**](QuotaApi.md#ListQuotav1QuotaReports) | **Get** /platform/1/quota/reports | 
[**ListQuotav1SettingsMappings**](QuotaApi.md#ListQuotav1SettingsMappings) | **Get** /platform/1/quota/settings/mappings | 
[**ListQuotav1SettingsNotifications**](QuotaApi.md#ListQuotav1SettingsNotifications) | **Get** /platform/1/quota/settings/notifications | 
[**ListQuotav7QuotaQuotas**](QuotaApi.md#ListQuotav7QuotaQuotas) | **Get** /platform/7/quota/quotas | 
[**ListQuotav7SettingsNotifications**](QuotaApi.md#ListQuotav7SettingsNotifications) | **Get** /platform/7/quota/settings/notifications | 
[**ListQuotav8QuotaQuotas**](QuotaApi.md#ListQuotav8QuotaQuotas) | **Get** /platform/8/quota/quotas | 
[**UpdateQuotav12QuotaQuota**](QuotaApi.md#UpdateQuotav12QuotaQuota) | **Put** /platform/12/quota/quotas/{v12QuotaQuotaId} | 
[**UpdateQuotav1QuotaQuota**](QuotaApi.md#UpdateQuotav1QuotaQuota) | **Put** /platform/1/quota/quotas/{v1QuotaQuotaId} | 
[**UpdateQuotav1QuotasQidNotification**](QuotaApi.md#UpdateQuotav1QuotasQidNotification) | **Put** /platform/1/quota/quotas/{Qid}/notifications/{v1QuotasQidNotificationId} | 
[**UpdateQuotav1SettingsMapping**](QuotaApi.md#UpdateQuotav1SettingsMapping) | **Put** /platform/1/quota/settings/mappings/{v1SettingsMappingId} | 
[**UpdateQuotav1SettingsNotification**](QuotaApi.md#UpdateQuotav1SettingsNotification) | **Put** /platform/1/quota/settings/notifications/{v1SettingsNotificationId} | 
[**UpdateQuotav1SettingsReports**](QuotaApi.md#UpdateQuotav1SettingsReports) | **Put** /platform/1/quota/settings/reports | 
[**UpdateQuotav7QuotaQuota**](QuotaApi.md#UpdateQuotav7QuotaQuota) | **Put** /platform/7/quota/quotas/{v7QuotaQuotaId} | 
[**UpdateQuotav7QuotasQidNotification**](QuotaApi.md#UpdateQuotav7QuotasQidNotification) | **Put** /platform/7/quota/quotas/{Qid}/notifications/{v7QuotasQidNotificationId} | 
[**UpdateQuotav7SettingsNotification**](QuotaApi.md#UpdateQuotav7SettingsNotification) | **Put** /platform/7/quota/settings/notifications/{v7SettingsNotificationId} | 
[**UpdateQuotav8QuotaQuota**](QuotaApi.md#UpdateQuotav8QuotaQuota) | **Put** /platform/8/quota/quotas/{v8QuotaQuotaId} | 



## CreateQuotav12QuotaQuota

> CreateResponse CreateQuotav12QuotaQuota(ctx).V12QuotaQuota(v12QuotaQuota).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12QuotaQuota := *openapiclient.NewV12QuotaQuota(false, "Path_example", "Type_example") // V12QuotaQuota | 
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.CreateQuotav12QuotaQuota(context.Background()).V12QuotaQuota(v12QuotaQuota).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.CreateQuotav12QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateQuotav12QuotaQuota`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.CreateQuotav12QuotaQuota`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateQuotav12QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v12QuotaQuota** | [**V12QuotaQuota**](V12QuotaQuota.md) |  | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateQuotav1QuotaQuota

> CreateResponse CreateQuotav1QuotaQuota(ctx).V1QuotaQuota(v1QuotaQuota).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1QuotaQuota := *openapiclient.NewV1QuotaQuota(false, "Path_example", false, "Type_example") // V1QuotaQuota | 
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.CreateQuotav1QuotaQuota(context.Background()).V1QuotaQuota(v1QuotaQuota).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.CreateQuotav1QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateQuotav1QuotaQuota`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.CreateQuotav1QuotaQuota`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateQuotav1QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1QuotaQuota** | [**V1QuotaQuota**](V1QuotaQuota.md) |  | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateQuotav1QuotaReport

> Createv3EventEventResponse CreateQuotav1QuotaReport(ctx).V1QuotaReport(v1QuotaReport).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1QuotaReport := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.CreateQuotav1QuotaReport(context.Background()).V1QuotaReport(v1QuotaReport).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.CreateQuotav1QuotaReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateQuotav1QuotaReport`: Createv3EventEventResponse
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.CreateQuotav1QuotaReport`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateQuotav1QuotaReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1QuotaReport** | **map[string]interface{}** |  | 

### Return type

[**Createv3EventEventResponse**](Createv3EventEventResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateQuotav1SettingsMapping

> CreateResponse CreateQuotav1SettingsMapping(ctx).V1SettingsMapping(v1SettingsMapping).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsMapping := *openapiclient.NewV1SettingsMappingCreateParams("Domain_example", "Mapping_example", "Type_example") // V1SettingsMappingCreateParams | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.CreateQuotav1SettingsMapping(context.Background()).V1SettingsMapping(v1SettingsMapping).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.CreateQuotav1SettingsMapping``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateQuotav1SettingsMapping`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.CreateQuotav1SettingsMapping`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateQuotav1SettingsMappingRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SettingsMapping** | [**V1SettingsMappingCreateParams**](V1SettingsMappingCreateParams.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateQuotav1SettingsNotification

> CreateResponse CreateQuotav1SettingsNotification(ctx).V1SettingsNotification(v1SettingsNotification).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsNotification := *openapiclient.NewV1QuotaNotification("Condition_example", "Threshold_example") // V1QuotaNotification | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.CreateQuotav1SettingsNotification(context.Background()).V1SettingsNotification(v1SettingsNotification).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.CreateQuotav1SettingsNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateQuotav1SettingsNotification`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.CreateQuotav1SettingsNotification`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateQuotav1SettingsNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SettingsNotification** | [**V1QuotaNotification**](V1QuotaNotification.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateQuotav7QuotaQuota

> CreateResponse CreateQuotav7QuotaQuota(ctx).V7QuotaQuota(v7QuotaQuota).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7QuotaQuota := *openapiclient.NewV12QuotaQuota(false, "Path_example", "Type_example") // V12QuotaQuota | 
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.CreateQuotav7QuotaQuota(context.Background()).V7QuotaQuota(v7QuotaQuota).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.CreateQuotav7QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateQuotav7QuotaQuota`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.CreateQuotav7QuotaQuota`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateQuotav7QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7QuotaQuota** | [**V12QuotaQuota**](V12QuotaQuota.md) |  | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateQuotav7SettingsNotification

> CreateResponse CreateQuotav7SettingsNotification(ctx).V7SettingsNotification(v7SettingsNotification).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SettingsNotification := *openapiclient.NewV7QuotaNotification("Condition_example", "Threshold_example") // V7QuotaNotification | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.CreateQuotav7SettingsNotification(context.Background()).V7SettingsNotification(v7SettingsNotification).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.CreateQuotav7SettingsNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateQuotav7SettingsNotification`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.CreateQuotav7SettingsNotification`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateQuotav7SettingsNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SettingsNotification** | [**V7QuotaNotification**](V7QuotaNotification.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateQuotav8QuotaQuota

> CreateResponse CreateQuotav8QuotaQuota(ctx).V8QuotaQuota(v8QuotaQuota).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v8QuotaQuota := *openapiclient.NewV12QuotaQuota(false, "Path_example", "Type_example") // V12QuotaQuota | 
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.CreateQuotav8QuotaQuota(context.Background()).V8QuotaQuota(v8QuotaQuota).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.CreateQuotav8QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateQuotav8QuotaQuota`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.CreateQuotav8QuotaQuota`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateQuotav8QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v8QuotaQuota** | [**V12QuotaQuota**](V12QuotaQuota.md) |  | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav12QuotaQuota

> DeleteQuotav12QuotaQuota(ctx, v12QuotaQuotaId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12QuotaQuotaId := "v12QuotaQuotaId_example" // string | Delete the quota.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav12QuotaQuota(context.Background(), v12QuotaQuotaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav12QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12QuotaQuotaId** | **string** | Delete the quota. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav12QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav12QuotaQuotas

> DeleteQuotav12QuotaQuotas(ctx).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).RecursePathChildren(recursePathChildren).RecursePathParents(recursePathParents).Persona(persona).Path(path).Type_(type_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    enforced := true // bool | Only delete quotas with this enforcement (non-accounting). (optional)
    includeSnapshots := true // bool | Only delete quotas with this setting for include_snapshots. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)
    recursePathChildren := true // bool | If used with the path argument, delete all quotas at that path or any descendent sub-directory. (optional)
    recursePathParents := true // bool | If used with the path argument, delete all quotas at that path or any parent directory. (optional)
    persona := "persona_example" // string | Only delete user or group quotas matching this persona (must be used with the corresponding type argument).  Format is <PERSONA_TYPE>:<string/integer>, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. (optional)
    path := "path_example" // string | Only delete quotas matching this path (see also recurse_path_*). (optional)
    type_ := "type__example" // string | Only delete quotas matching this type. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav12QuotaQuotas(context.Background()).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).RecursePathChildren(recursePathChildren).RecursePathParents(recursePathParents).Persona(persona).Path(path).Type_(type_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav12QuotaQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav12QuotaQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enforced** | **bool** | Only delete quotas with this enforcement (non-accounting). | 
 **includeSnapshots** | **bool** | Only delete quotas with this setting for include_snapshots. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 
 **recursePathChildren** | **bool** | If used with the path argument, delete all quotas at that path or any descendent sub-directory. | 
 **recursePathParents** | **bool** | If used with the path argument, delete all quotas at that path or any parent directory. | 
 **persona** | **string** | Only delete user or group quotas matching this persona (must be used with the corresponding type argument).  Format is &lt;PERSONA_TYPE&gt;:&lt;string/integer&gt;, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. | 
 **path** | **string** | Only delete quotas matching this path (see also recurse_path_*). | 
 **type_** | **string** | Only delete quotas matching this type. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav1QuotaQuota

> DeleteQuotav1QuotaQuota(ctx, v1QuotaQuotaId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1QuotaQuotaId := "v1QuotaQuotaId_example" // string | Delete the quota.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav1QuotaQuota(context.Background(), v1QuotaQuotaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav1QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1QuotaQuotaId** | **string** | Delete the quota. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav1QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav1QuotaQuotas

> DeleteQuotav1QuotaQuotas(ctx).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).RecursePathChildren(recursePathChildren).RecursePathParents(recursePathParents).Persona(persona).Path(path).Type_(type_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    enforced := true // bool | Only delete quotas with this enforcement (non-accounting). (optional)
    includeSnapshots := true // bool | Only delete quotas with this setting for include_snapshots. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)
    recursePathChildren := true // bool | If used with the path argument, delete all quotas at that path or any descendent sub-directory. (optional)
    recursePathParents := true // bool | If used with the path argument, delete all quotas at that path or any parent directory. (optional)
    persona := "persona_example" // string | Only delete user or group quotas matching this persona (must be used with the corresponding type argument).  Format is <PERSONA_TYPE>:<string/integer>, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. (optional)
    path := "path_example" // string | Only delete quotas matching this path (see also recurse_path_*). (optional)
    type_ := "type__example" // string | Only delete quotas matching this type. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav1QuotaQuotas(context.Background()).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).RecursePathChildren(recursePathChildren).RecursePathParents(recursePathParents).Persona(persona).Path(path).Type_(type_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav1QuotaQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav1QuotaQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enforced** | **bool** | Only delete quotas with this enforcement (non-accounting). | 
 **includeSnapshots** | **bool** | Only delete quotas with this setting for include_snapshots. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 
 **recursePathChildren** | **bool** | If used with the path argument, delete all quotas at that path or any descendent sub-directory. | 
 **recursePathParents** | **bool** | If used with the path argument, delete all quotas at that path or any parent directory. | 
 **persona** | **string** | Only delete user or group quotas matching this persona (must be used with the corresponding type argument).  Format is &lt;PERSONA_TYPE&gt;:&lt;string/integer&gt;, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. | 
 **path** | **string** | Only delete quotas matching this path (see also recurse_path_*). | 
 **type_** | **string** | Only delete quotas matching this type. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav1QuotaReport

> DeleteQuotav1QuotaReport(ctx, v1QuotaReportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1QuotaReportId := "v1QuotaReportId_example" // string | Delete the report.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav1QuotaReport(context.Background(), v1QuotaReportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav1QuotaReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1QuotaReportId** | **string** | Delete the report. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav1QuotaReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav1QuotasQidNotification

> DeleteQuotav1QuotasQidNotification(ctx, v1QuotasQidNotificationId, qid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1QuotasQidNotificationId := "v1QuotasQidNotificationId_example" // string | Delete the notification rule.
    qid := "qid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav1QuotasQidNotification(context.Background(), v1QuotasQidNotificationId, qid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav1QuotasQidNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1QuotasQidNotificationId** | **string** | Delete the notification rule. | 
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav1QuotasQidNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav1SettingsMapping

> DeleteQuotav1SettingsMapping(ctx, v1SettingsMappingId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsMappingId := "v1SettingsMappingId_example" // string | Delete the mapping.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav1SettingsMapping(context.Background(), v1SettingsMappingId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav1SettingsMapping``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsMappingId** | **string** | Delete the mapping. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav1SettingsMappingRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav1SettingsMappings

> DeleteQuotav1SettingsMappings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav1SettingsMappings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav1SettingsMappings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav1SettingsMappingsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav1SettingsNotification

> DeleteQuotav1SettingsNotification(ctx, v1SettingsNotificationId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsNotificationId := "v1SettingsNotificationId_example" // string | Delete the notification rule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav1SettingsNotification(context.Background(), v1SettingsNotificationId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav1SettingsNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsNotificationId** | **string** | Delete the notification rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav1SettingsNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav1SettingsNotifications

> DeleteQuotav1SettingsNotifications(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav1SettingsNotifications(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav1SettingsNotifications``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav1SettingsNotificationsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav7QuotaQuota

> DeleteQuotav7QuotaQuota(ctx, v7QuotaQuotaId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7QuotaQuotaId := "v7QuotaQuotaId_example" // string | Delete the quota.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav7QuotaQuota(context.Background(), v7QuotaQuotaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav7QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7QuotaQuotaId** | **string** | Delete the quota. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav7QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav7QuotaQuotas

> DeleteQuotav7QuotaQuotas(ctx).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).RecursePathChildren(recursePathChildren).RecursePathParents(recursePathParents).Persona(persona).Path(path).Type_(type_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    enforced := true // bool | Only delete quotas with this enforcement (non-accounting). (optional)
    includeSnapshots := true // bool | Only delete quotas with this setting for include_snapshots. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)
    recursePathChildren := true // bool | If used with the path argument, delete all quotas at that path or any descendent sub-directory. (optional)
    recursePathParents := true // bool | If used with the path argument, delete all quotas at that path or any parent directory. (optional)
    persona := "persona_example" // string | Only delete user or group quotas matching this persona (must be used with the corresponding type argument).  Format is <PERSONA_TYPE>:<string/integer>, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. (optional)
    path := "path_example" // string | Only delete quotas matching this path (see also recurse_path_*). (optional)
    type_ := "type__example" // string | Only delete quotas matching this type. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav7QuotaQuotas(context.Background()).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).RecursePathChildren(recursePathChildren).RecursePathParents(recursePathParents).Persona(persona).Path(path).Type_(type_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav7QuotaQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav7QuotaQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enforced** | **bool** | Only delete quotas with this enforcement (non-accounting). | 
 **includeSnapshots** | **bool** | Only delete quotas with this setting for include_snapshots. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 
 **recursePathChildren** | **bool** | If used with the path argument, delete all quotas at that path or any descendent sub-directory. | 
 **recursePathParents** | **bool** | If used with the path argument, delete all quotas at that path or any parent directory. | 
 **persona** | **string** | Only delete user or group quotas matching this persona (must be used with the corresponding type argument).  Format is &lt;PERSONA_TYPE&gt;:&lt;string/integer&gt;, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. | 
 **path** | **string** | Only delete quotas matching this path (see also recurse_path_*). | 
 **type_** | **string** | Only delete quotas matching this type. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav7QuotasQidNotification

> DeleteQuotav7QuotasQidNotification(ctx, v7QuotasQidNotificationId, qid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7QuotasQidNotificationId := "v7QuotasQidNotificationId_example" // string | Delete the notification rule.
    qid := "qid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav7QuotasQidNotification(context.Background(), v7QuotasQidNotificationId, qid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav7QuotasQidNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7QuotasQidNotificationId** | **string** | Delete the notification rule. | 
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav7QuotasQidNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav7SettingsNotification

> DeleteQuotav7SettingsNotification(ctx, v7SettingsNotificationId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SettingsNotificationId := "v7SettingsNotificationId_example" // string | Delete the notification rule.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav7SettingsNotification(context.Background(), v7SettingsNotificationId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav7SettingsNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SettingsNotificationId** | **string** | Delete the notification rule. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav7SettingsNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav7SettingsNotifications

> DeleteQuotav7SettingsNotifications(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav7SettingsNotifications(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav7SettingsNotifications``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav7SettingsNotificationsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav8QuotaQuota

> DeleteQuotav8QuotaQuota(ctx, v8QuotaQuotaId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v8QuotaQuotaId := "v8QuotaQuotaId_example" // string | Delete the quota.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav8QuotaQuota(context.Background(), v8QuotaQuotaId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav8QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v8QuotaQuotaId** | **string** | Delete the quota. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav8QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotav8QuotaQuotas

> DeleteQuotav8QuotaQuotas(ctx).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).RecursePathChildren(recursePathChildren).RecursePathParents(recursePathParents).Persona(persona).Path(path).Type_(type_).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    enforced := true // bool | Only delete quotas with this enforcement (non-accounting). (optional)
    includeSnapshots := true // bool | Only delete quotas with this setting for include_snapshots. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)
    recursePathChildren := true // bool | If used with the path argument, delete all quotas at that path or any descendent sub-directory. (optional)
    recursePathParents := true // bool | If used with the path argument, delete all quotas at that path or any parent directory. (optional)
    persona := "persona_example" // string | Only delete user or group quotas matching this persona (must be used with the corresponding type argument).  Format is <PERSONA_TYPE>:<string/integer>, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. (optional)
    path := "path_example" // string | Only delete quotas matching this path (see also recurse_path_*). (optional)
    type_ := "type__example" // string | Only delete quotas matching this type. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.DeleteQuotav8QuotaQuotas(context.Background()).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).RecursePathChildren(recursePathChildren).RecursePathParents(recursePathParents).Persona(persona).Path(path).Type_(type_).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.DeleteQuotav8QuotaQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotav8QuotaQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enforced** | **bool** | Only delete quotas with this enforcement (non-accounting). | 
 **includeSnapshots** | **bool** | Only delete quotas with this setting for include_snapshots. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 
 **recursePathChildren** | **bool** | If used with the path argument, delete all quotas at that path or any descendent sub-directory. | 
 **recursePathParents** | **bool** | If used with the path argument, delete all quotas at that path or any parent directory. | 
 **persona** | **string** | Only delete user or group quotas matching this persona (must be used with the corresponding type argument).  Format is &lt;PERSONA_TYPE&gt;:&lt;string/integer&gt;, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. | 
 **path** | **string** | Only delete quotas matching this path (see also recurse_path_*). | 
 **type_** | **string** | Only delete quotas matching this type. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav12QuotaQuota

> V12QuotaQuotasExtended GetQuotav12QuotaQuota(ctx, v12QuotaQuotaId).ResolveNames(resolveNames).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12QuotaQuotaId := "v12QuotaQuotaId_example" // string | Retrieve quota information.
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav12QuotaQuota(context.Background(), v12QuotaQuotaId).ResolveNames(resolveNames).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav12QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav12QuotaQuota`: V12QuotaQuotasExtended
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav12QuotaQuota`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12QuotaQuotaId** | **string** | Retrieve quota information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav12QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 

### Return type

[**V12QuotaQuotasExtended**](V12QuotaQuotasExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav1QuotaLicense

> V1LicenseLicenseExtended GetQuotav1QuotaLicense(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav1QuotaLicense(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav1QuotaLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav1QuotaLicense`: V1LicenseLicenseExtended
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav1QuotaLicense`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav1QuotaLicenseRequest struct via the builder pattern


### Return type

[**V1LicenseLicenseExtended**](V1LicenseLicenseExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav1QuotaQuota

> V1QuotaQuotasExtended GetQuotav1QuotaQuota(ctx, v1QuotaQuotaId).ResolveNames(resolveNames).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1QuotaQuotaId := "v1QuotaQuotaId_example" // string | Retrieve quota information.
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav1QuotaQuota(context.Background(), v1QuotaQuotaId).ResolveNames(resolveNames).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav1QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav1QuotaQuota`: V1QuotaQuotasExtended
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav1QuotaQuota`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1QuotaQuotaId** | **string** | Retrieve quota information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav1QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 

### Return type

[**V1QuotaQuotasExtended**](V1QuotaQuotasExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav1QuotaQuotasSummary

> V1QuotaQuotasSummary GetQuotav1QuotaQuotasSummary(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav1QuotaQuotasSummary(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav1QuotaQuotasSummary``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav1QuotaQuotasSummary`: V1QuotaQuotasSummary
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav1QuotaQuotasSummary`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav1QuotaQuotasSummaryRequest struct via the builder pattern


### Return type

[**V1QuotaQuotasSummary**](V1QuotaQuotasSummary.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav1QuotaReport

> V1QuotaReportsExtended GetQuotav1QuotaReport(ctx, v1QuotaReportId).Contents(contents).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1QuotaReportId := "v1QuotaReportId_example" // string | Retrieve report data (XML) or contents (meta-data).
    contents := true // bool | Display JSON meta-data contents instead of report data. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav1QuotaReport(context.Background(), v1QuotaReportId).Contents(contents).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav1QuotaReport``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav1QuotaReport`: V1QuotaReportsExtended
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav1QuotaReport`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1QuotaReportId** | **string** | Retrieve report data (XML) or contents (meta-data). | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav1QuotaReportRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **contents** | **bool** | Display JSON meta-data contents instead of report data. | 

### Return type

[**V1QuotaReportsExtended**](V1QuotaReportsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav1QuotasQidNotification

> V1QuotasQidNotifications GetQuotav1QuotasQidNotification(ctx, v1QuotasQidNotificationId, qid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1QuotasQidNotificationId := "v1QuotasQidNotificationId_example" // string | Retrieve notification rule information.
    qid := "qid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav1QuotasQidNotification(context.Background(), v1QuotasQidNotificationId, qid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav1QuotasQidNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav1QuotasQidNotification`: V1QuotasQidNotifications
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav1QuotasQidNotification`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1QuotasQidNotificationId** | **string** | Retrieve notification rule information. | 
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav1QuotasQidNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V1QuotasQidNotifications**](V1QuotasQidNotifications.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav1SettingsMapping

> V1SettingsMappings GetQuotav1SettingsMapping(ctx, v1SettingsMappingId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsMappingId := "v1SettingsMappingId_example" // string | Retrieve the mapping information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav1SettingsMapping(context.Background(), v1SettingsMappingId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav1SettingsMapping``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav1SettingsMapping`: V1SettingsMappings
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav1SettingsMapping`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsMappingId** | **string** | Retrieve the mapping information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav1SettingsMappingRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1SettingsMappings**](V1SettingsMappings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav1SettingsNotification

> V1QuotasQidNotifications GetQuotav1SettingsNotification(ctx, v1SettingsNotificationId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsNotificationId := "v1SettingsNotificationId_example" // string | Retrieve notification rule information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav1SettingsNotification(context.Background(), v1SettingsNotificationId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav1SettingsNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav1SettingsNotification`: V1QuotasQidNotifications
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav1SettingsNotification`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsNotificationId** | **string** | Retrieve notification rule information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav1SettingsNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1QuotasQidNotifications**](V1QuotasQidNotifications.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav1SettingsReports

> V1SettingsReports GetQuotav1SettingsReports(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as \"effective\" or not specified, all fields are returned.  If specified as \"user\", only fields with non-default values are shown.  If specified as \"default\", the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav1SettingsReports(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav1SettingsReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav1SettingsReports`: V1SettingsReports
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav1SettingsReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav1SettingsReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as \&quot;effective\&quot; or not specified, all fields are returned.  If specified as \&quot;user\&quot;, only fields with non-default values are shown.  If specified as \&quot;default\&quot;, the original values are returned. | 

### Return type

[**V1SettingsReports**](V1SettingsReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav5QuotaLicense

> V5LicenseLicenseExtended GetQuotav5QuotaLicense(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav5QuotaLicense(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav5QuotaLicense``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav5QuotaLicense`: V5LicenseLicenseExtended
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav5QuotaLicense`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav5QuotaLicenseRequest struct via the builder pattern


### Return type

[**V5LicenseLicenseExtended**](V5LicenseLicenseExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav7QuotaQuota

> V7QuotaQuotasExtended GetQuotav7QuotaQuota(ctx, v7QuotaQuotaId).ResolveNames(resolveNames).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7QuotaQuotaId := "v7QuotaQuotaId_example" // string | Retrieve quota information.
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav7QuotaQuota(context.Background(), v7QuotaQuotaId).ResolveNames(resolveNames).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav7QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav7QuotaQuota`: V7QuotaQuotasExtended
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav7QuotaQuota`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7QuotaQuotaId** | **string** | Retrieve quota information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav7QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 

### Return type

[**V7QuotaQuotasExtended**](V7QuotaQuotasExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav7QuotasQidNotification

> V7QuotasQidNotifications GetQuotav7QuotasQidNotification(ctx, v7QuotasQidNotificationId, qid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7QuotasQidNotificationId := "v7QuotasQidNotificationId_example" // string | Retrieve notification rule information.
    qid := "qid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav7QuotasQidNotification(context.Background(), v7QuotasQidNotificationId, qid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav7QuotasQidNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav7QuotasQidNotification`: V7QuotasQidNotifications
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav7QuotasQidNotification`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7QuotasQidNotificationId** | **string** | Retrieve notification rule information. | 
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav7QuotasQidNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V7QuotasQidNotifications**](V7QuotasQidNotifications.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav7SettingsNotification

> V7QuotasQidNotifications GetQuotav7SettingsNotification(ctx, v7SettingsNotificationId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SettingsNotificationId := "v7SettingsNotificationId_example" // string | Retrieve notification rule information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav7SettingsNotification(context.Background(), v7SettingsNotificationId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav7SettingsNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav7SettingsNotification`: V7QuotasQidNotifications
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav7SettingsNotification`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SettingsNotificationId** | **string** | Retrieve notification rule information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav7SettingsNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7QuotasQidNotifications**](V7QuotasQidNotifications.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetQuotav8QuotaQuota

> V8QuotaQuotasExtended GetQuotav8QuotaQuota(ctx, v8QuotaQuotaId).ResolveNames(resolveNames).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v8QuotaQuotaId := "v8QuotaQuotaId_example" // string | Retrieve quota information.
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.GetQuotav8QuotaQuota(context.Background(), v8QuotaQuotaId).ResolveNames(resolveNames).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.GetQuotav8QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetQuotav8QuotaQuota`: V8QuotaQuotasExtended
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.GetQuotav8QuotaQuota`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v8QuotaQuotaId** | **string** | Retrieve quota information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetQuotav8QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 

### Return type

[**V8QuotaQuotasExtended**](V8QuotaQuotasExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListQuotav12QuotaQuotas

> V12QuotaQuotas ListQuotav12QuotaQuotas(ctx).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).Resume(resume).RecursePathChildren(recursePathChildren).ResolveNames(resolveNames).RecursePathParents(recursePathParents).Persona(persona).Limit(limit).Exceeded(exceeded).Path(path).Type_(type_).ReportId(reportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    enforced := true // bool | Only list quotas with this enforcement (non-accounting). (optional)
    includeSnapshots := true // bool | Only list quotas with this setting for include_snapshots. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    recursePathChildren := true // bool | If used with the path argument, match all quotas at that path or any descendent sub-directory. (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    recursePathParents := true // bool | If used with the path argument, match all quotas at that path or any parent directory. (optional)
    persona := "persona_example" // string | Only list user or group quotas matching this persona (must be used with the corresponding type argument).  Format is <PERSONA_TYPE>:<string/integer>, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    exceeded := true // bool | Set to true to only list quotas which have exceeded one or more of their thresholds. (optional)
    path := "path_example" // string | Only list quotas matching this path (see also recurse_path_*). (optional)
    type_ := "type__example" // string | Only list quotas matching this type. (optional)
    reportId := "reportId_example" // string | Use the named report as a source rather than the live quotas. See the /q/quota/reports resource for a list of valid reports. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.ListQuotav12QuotaQuotas(context.Background()).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).Resume(resume).RecursePathChildren(recursePathChildren).ResolveNames(resolveNames).RecursePathParents(recursePathParents).Persona(persona).Limit(limit).Exceeded(exceeded).Path(path).Type_(type_).ReportId(reportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.ListQuotav12QuotaQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListQuotav12QuotaQuotas`: V12QuotaQuotas
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.ListQuotav12QuotaQuotas`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListQuotav12QuotaQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enforced** | **bool** | Only list quotas with this enforcement (non-accounting). | 
 **includeSnapshots** | **bool** | Only list quotas with this setting for include_snapshots. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **recursePathChildren** | **bool** | If used with the path argument, match all quotas at that path or any descendent sub-directory. | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **recursePathParents** | **bool** | If used with the path argument, match all quotas at that path or any parent directory. | 
 **persona** | **string** | Only list user or group quotas matching this persona (must be used with the corresponding type argument).  Format is &lt;PERSONA_TYPE&gt;:&lt;string/integer&gt;, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **exceeded** | **bool** | Set to true to only list quotas which have exceeded one or more of their thresholds. | 
 **path** | **string** | Only list quotas matching this path (see also recurse_path_*). | 
 **type_** | **string** | Only list quotas matching this type. | 
 **reportId** | **string** | Use the named report as a source rather than the live quotas. See the /q/quota/reports resource for a list of valid reports. | 

### Return type

[**V12QuotaQuotas**](V12QuotaQuotas.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListQuotav1QuotaQuotas

> V1QuotaQuotas ListQuotav1QuotaQuotas(ctx).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).Resume(resume).RecursePathChildren(recursePathChildren).ResolveNames(resolveNames).RecursePathParents(recursePathParents).Persona(persona).Limit(limit).Exceeded(exceeded).Path(path).Type_(type_).ReportId(reportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    enforced := true // bool | Only list quotas with this enforcement (non-accounting). (optional)
    includeSnapshots := true // bool | Only list quotas with this setting for include_snapshots. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    recursePathChildren := true // bool | If used with the path argument, match all quotas at that path or any descendent sub-directory. (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    recursePathParents := true // bool | If used with the path argument, match all quotas at that path or any parent directory. (optional)
    persona := "persona_example" // string | Only list user or group quotas matching this persona (must be used with the corresponding type argument).  Format is <PERSONA_TYPE>:<string/integer>, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    exceeded := true // bool | Set to true to only list quotas which have exceeded one or more of their thresholds. (optional)
    path := "path_example" // string | Only list quotas matching this path (see also recurse_path_*). (optional)
    type_ := "type__example" // string | Only list quotas matching this type. (optional)
    reportId := "reportId_example" // string | Use the named report as a source rather than the live quotas. See the /q/quota/reports resource for a list of valid reports. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.ListQuotav1QuotaQuotas(context.Background()).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).Resume(resume).RecursePathChildren(recursePathChildren).ResolveNames(resolveNames).RecursePathParents(recursePathParents).Persona(persona).Limit(limit).Exceeded(exceeded).Path(path).Type_(type_).ReportId(reportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.ListQuotav1QuotaQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListQuotav1QuotaQuotas`: V1QuotaQuotas
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.ListQuotav1QuotaQuotas`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListQuotav1QuotaQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enforced** | **bool** | Only list quotas with this enforcement (non-accounting). | 
 **includeSnapshots** | **bool** | Only list quotas with this setting for include_snapshots. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **recursePathChildren** | **bool** | If used with the path argument, match all quotas at that path or any descendent sub-directory. | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **recursePathParents** | **bool** | If used with the path argument, match all quotas at that path or any parent directory. | 
 **persona** | **string** | Only list user or group quotas matching this persona (must be used with the corresponding type argument).  Format is &lt;PERSONA_TYPE&gt;:&lt;string/integer&gt;, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **exceeded** | **bool** | Set to true to only list quotas which have exceeded one or more of their thresholds. | 
 **path** | **string** | Only list quotas matching this path (see also recurse_path_*). | 
 **type_** | **string** | Only list quotas matching this type. | 
 **reportId** | **string** | Use the named report as a source rather than the live quotas. See the /q/quota/reports resource for a list of valid reports. | 

### Return type

[**V1QuotaQuotas**](V1QuotaQuotas.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListQuotav1QuotaReports

> V1QuotaReports ListQuotav1QuotaReports(ctx).Sort(sort).Resume(resume).Generated(generated).Limit(limit).Type_(type_).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | Order results by this field. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    generated := "generated_example" // string | Only list reports matching this source. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    type_ := "type__example" // string | Only list reports matching this type. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.ListQuotav1QuotaReports(context.Background()).Sort(sort).Resume(resume).Generated(generated).Limit(limit).Type_(type_).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.ListQuotav1QuotaReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListQuotav1QuotaReports`: V1QuotaReports
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.ListQuotav1QuotaReports`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListQuotav1QuotaReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | Order results by this field. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **generated** | **string** | Only list reports matching this source. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **type_** | **string** | Only list reports matching this type. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V1QuotaReports**](V1QuotaReports.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListQuotav1SettingsMappings

> V1SettingsMappings ListQuotav1SettingsMappings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.ListQuotav1SettingsMappings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.ListQuotav1SettingsMappings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListQuotav1SettingsMappings`: V1SettingsMappings
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.ListQuotav1SettingsMappings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListQuotav1SettingsMappingsRequest struct via the builder pattern


### Return type

[**V1SettingsMappings**](V1SettingsMappings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListQuotav1SettingsNotifications

> V1QuotaNotifications ListQuotav1SettingsNotifications(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.ListQuotav1SettingsNotifications(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.ListQuotav1SettingsNotifications``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListQuotav1SettingsNotifications`: V1QuotaNotifications
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.ListQuotav1SettingsNotifications`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListQuotav1SettingsNotificationsRequest struct via the builder pattern


### Return type

[**V1QuotaNotifications**](V1QuotaNotifications.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListQuotav7QuotaQuotas

> V7QuotaQuotas ListQuotav7QuotaQuotas(ctx).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).Resume(resume).RecursePathChildren(recursePathChildren).ResolveNames(resolveNames).RecursePathParents(recursePathParents).Persona(persona).Limit(limit).Exceeded(exceeded).Path(path).Type_(type_).ReportId(reportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    enforced := true // bool | Only list quotas with this enforcement (non-accounting). (optional)
    includeSnapshots := true // bool | Only list quotas with this setting for include_snapshots. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    recursePathChildren := true // bool | If used with the path argument, match all quotas at that path or any descendent sub-directory. (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    recursePathParents := true // bool | If used with the path argument, match all quotas at that path or any parent directory. (optional)
    persona := "persona_example" // string | Only list user or group quotas matching this persona (must be used with the corresponding type argument).  Format is <PERSONA_TYPE>:<string/integer>, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    exceeded := true // bool | Set to true to only list quotas which have exceeded one or more of their thresholds. (optional)
    path := "path_example" // string | Only list quotas matching this path (see also recurse_path_*). (optional)
    type_ := "type__example" // string | Only list quotas matching this type. (optional)
    reportId := "reportId_example" // string | Use the named report as a source rather than the live quotas. See the /q/quota/reports resource for a list of valid reports. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.ListQuotav7QuotaQuotas(context.Background()).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).Resume(resume).RecursePathChildren(recursePathChildren).ResolveNames(resolveNames).RecursePathParents(recursePathParents).Persona(persona).Limit(limit).Exceeded(exceeded).Path(path).Type_(type_).ReportId(reportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.ListQuotav7QuotaQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListQuotav7QuotaQuotas`: V7QuotaQuotas
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.ListQuotav7QuotaQuotas`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListQuotav7QuotaQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enforced** | **bool** | Only list quotas with this enforcement (non-accounting). | 
 **includeSnapshots** | **bool** | Only list quotas with this setting for include_snapshots. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **recursePathChildren** | **bool** | If used with the path argument, match all quotas at that path or any descendent sub-directory. | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **recursePathParents** | **bool** | If used with the path argument, match all quotas at that path or any parent directory. | 
 **persona** | **string** | Only list user or group quotas matching this persona (must be used with the corresponding type argument).  Format is &lt;PERSONA_TYPE&gt;:&lt;string/integer&gt;, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **exceeded** | **bool** | Set to true to only list quotas which have exceeded one or more of their thresholds. | 
 **path** | **string** | Only list quotas matching this path (see also recurse_path_*). | 
 **type_** | **string** | Only list quotas matching this type. | 
 **reportId** | **string** | Use the named report as a source rather than the live quotas. See the /q/quota/reports resource for a list of valid reports. | 

### Return type

[**V7QuotaQuotas**](V7QuotaQuotas.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListQuotav7SettingsNotifications

> V7QuotaNotifications ListQuotav7SettingsNotifications(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.ListQuotav7SettingsNotifications(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.ListQuotav7SettingsNotifications``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListQuotav7SettingsNotifications`: V7QuotaNotifications
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.ListQuotav7SettingsNotifications`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListQuotav7SettingsNotificationsRequest struct via the builder pattern


### Return type

[**V7QuotaNotifications**](V7QuotaNotifications.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListQuotav8QuotaQuotas

> V8QuotaQuotas ListQuotav8QuotaQuotas(ctx).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).Resume(resume).RecursePathChildren(recursePathChildren).ResolveNames(resolveNames).RecursePathParents(recursePathParents).Persona(persona).Limit(limit).Exceeded(exceeded).Path(path).Type_(type_).ReportId(reportId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    enforced := true // bool | Only list quotas with this enforcement (non-accounting). (optional)
    includeSnapshots := true // bool | Only list quotas with this setting for include_snapshots. (optional)
    zone := "zone_example" // string | Optional named zone to use for user and group resolution. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    recursePathChildren := true // bool | If used with the path argument, match all quotas at that path or any descendent sub-directory. (optional)
    resolveNames := true // bool | If true, resolve group and user names in personas. (optional)
    recursePathParents := true // bool | If used with the path argument, match all quotas at that path or any parent directory. (optional)
    persona := "persona_example" // string | Only list user or group quotas matching this persona (must be used with the corresponding type argument).  Format is <PERSONA_TYPE>:<string/integer>, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    exceeded := true // bool | Set to true to only list quotas which have exceeded one or more of their thresholds. (optional)
    path := "path_example" // string | Only list quotas matching this path (see also recurse_path_*). (optional)
    type_ := "type__example" // string | Only list quotas matching this type. (optional)
    reportId := "reportId_example" // string | Use the named report as a source rather than the live quotas. See the /q/quota/reports resource for a list of valid reports. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaApi.ListQuotav8QuotaQuotas(context.Background()).Enforced(enforced).IncludeSnapshots(includeSnapshots).Zone(zone).Resume(resume).RecursePathChildren(recursePathChildren).ResolveNames(resolveNames).RecursePathParents(recursePathParents).Persona(persona).Limit(limit).Exceeded(exceeded).Path(path).Type_(type_).ReportId(reportId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.ListQuotav8QuotaQuotas``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListQuotav8QuotaQuotas`: V8QuotaQuotas
    fmt.Fprintf(os.Stdout, "Response from `QuotaApi.ListQuotav8QuotaQuotas`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiListQuotav8QuotaQuotasRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **enforced** | **bool** | Only list quotas with this enforcement (non-accounting). | 
 **includeSnapshots** | **bool** | Only list quotas with this setting for include_snapshots. | 
 **zone** | **string** | Optional named zone to use for user and group resolution. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **recursePathChildren** | **bool** | If used with the path argument, match all quotas at that path or any descendent sub-directory. | 
 **resolveNames** | **bool** | If true, resolve group and user names in personas. | 
 **recursePathParents** | **bool** | If used with the path argument, match all quotas at that path or any parent directory. | 
 **persona** | **string** | Only list user or group quotas matching this persona (must be used with the corresponding type argument).  Format is &lt;PERSONA_TYPE&gt;:&lt;string/integer&gt;, where PERSONA_TYPE is one of USER, GROUP, SID, ID, or GID. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **exceeded** | **bool** | Set to true to only list quotas which have exceeded one or more of their thresholds. | 
 **path** | **string** | Only list quotas matching this path (see also recurse_path_*). | 
 **type_** | **string** | Only list quotas matching this type. | 
 **reportId** | **string** | Use the named report as a source rather than the live quotas. See the /q/quota/reports resource for a list of valid reports. | 

### Return type

[**V8QuotaQuotas**](V8QuotaQuotas.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotav12QuotaQuota

> UpdateQuotav12QuotaQuota(ctx, v12QuotaQuotaId).V12QuotaQuota(v12QuotaQuota).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12QuotaQuotaId := "v12QuotaQuotaId_example" // string | Modify quota. All input fields are optional, but one or more must be supplied.
    v12QuotaQuota := *openapiclient.NewV12QuotaQuotaExtendedExtended() // V12QuotaQuotaExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.UpdateQuotav12QuotaQuota(context.Background(), v12QuotaQuotaId).V12QuotaQuota(v12QuotaQuota).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.UpdateQuotav12QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12QuotaQuotaId** | **string** | Modify quota. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotav12QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12QuotaQuota** | [**V12QuotaQuotaExtendedExtended**](V12QuotaQuotaExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotav1QuotaQuota

> UpdateQuotav1QuotaQuota(ctx, v1QuotaQuotaId).V1QuotaQuota(v1QuotaQuota).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1QuotaQuotaId := "v1QuotaQuotaId_example" // string | Modify quota. All input fields are optional, but one or more must be supplied.
    v1QuotaQuota := *openapiclient.NewV1QuotaQuotaExtendedExtended() // V1QuotaQuotaExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.UpdateQuotav1QuotaQuota(context.Background(), v1QuotaQuotaId).V1QuotaQuota(v1QuotaQuota).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.UpdateQuotav1QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1QuotaQuotaId** | **string** | Modify quota. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotav1QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1QuotaQuota** | [**V1QuotaQuotaExtendedExtended**](V1QuotaQuotaExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotav1QuotasQidNotification

> UpdateQuotav1QuotasQidNotification(ctx, v1QuotasQidNotificationId, qid).V1QuotasQidNotification(v1QuotasQidNotification).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1QuotasQidNotificationId := "v1QuotasQidNotificationId_example" // string | Modify notification rule. All input fields are optional, but one or more must be supplied.
    qid := "qid_example" // string | 
    v1QuotasQidNotification := *openapiclient.NewV1QuotasQidNotification() // V1QuotasQidNotification | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.UpdateQuotav1QuotasQidNotification(context.Background(), v1QuotasQidNotificationId, qid).V1QuotasQidNotification(v1QuotasQidNotification).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.UpdateQuotav1QuotasQidNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1QuotasQidNotificationId** | **string** | Modify notification rule. All input fields are optional, but one or more must be supplied. | 
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotav1QuotasQidNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v1QuotasQidNotification** | [**V1QuotasQidNotification**](V1QuotasQidNotification.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotav1SettingsMapping

> UpdateQuotav1SettingsMapping(ctx, v1SettingsMappingId).V1SettingsMapping(v1SettingsMapping).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsMappingId := "v1SettingsMappingId_example" // string | Modify the mapping.
    v1SettingsMapping := *openapiclient.NewV1SettingsMappingExtendedExtended("Mapping_example") // V1SettingsMappingExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.UpdateQuotav1SettingsMapping(context.Background(), v1SettingsMappingId).V1SettingsMapping(v1SettingsMapping).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.UpdateQuotav1SettingsMapping``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsMappingId** | **string** | Modify the mapping. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotav1SettingsMappingRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SettingsMapping** | [**V1SettingsMappingExtendedExtended**](V1SettingsMappingExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotav1SettingsNotification

> UpdateQuotav1SettingsNotification(ctx, v1SettingsNotificationId).V1SettingsNotification(v1SettingsNotification).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsNotificationId := "v1SettingsNotificationId_example" // string | Modify notification rule. All input fields are optional, but one or more must be supplied.
    v1SettingsNotification := *openapiclient.NewV1QuotasQidNotification() // V1QuotasQidNotification | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.UpdateQuotav1SettingsNotification(context.Background(), v1SettingsNotificationId).V1SettingsNotification(v1SettingsNotification).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.UpdateQuotav1SettingsNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1SettingsNotificationId** | **string** | Modify notification rule. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotav1SettingsNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1SettingsNotification** | [**V1QuotasQidNotification**](V1QuotasQidNotification.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotav1SettingsReports

> UpdateQuotav1SettingsReports(ctx).V1SettingsReports(v1SettingsReports).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1SettingsReports := *openapiclient.NewV1SettingsReportsExtended() // V1SettingsReportsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.UpdateQuotav1SettingsReports(context.Background()).V1SettingsReports(v1SettingsReports).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.UpdateQuotav1SettingsReports``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotav1SettingsReportsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1SettingsReports** | [**V1SettingsReportsExtended**](V1SettingsReportsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotav7QuotaQuota

> UpdateQuotav7QuotaQuota(ctx, v7QuotaQuotaId).V7QuotaQuota(v7QuotaQuota).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7QuotaQuotaId := "v7QuotaQuotaId_example" // string | Modify quota. All input fields are optional, but one or more must be supplied.
    v7QuotaQuota := *openapiclient.NewV12QuotaQuotaExtendedExtended() // V12QuotaQuotaExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.UpdateQuotav7QuotaQuota(context.Background(), v7QuotaQuotaId).V7QuotaQuota(v7QuotaQuota).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.UpdateQuotav7QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7QuotaQuotaId** | **string** | Modify quota. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotav7QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7QuotaQuota** | [**V12QuotaQuotaExtendedExtended**](V12QuotaQuotaExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotav7QuotasQidNotification

> UpdateQuotav7QuotasQidNotification(ctx, v7QuotasQidNotificationId, qid).V7QuotasQidNotification(v7QuotasQidNotification).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7QuotasQidNotificationId := "v7QuotasQidNotificationId_example" // string | Modify notification rule. All input fields are optional, but one or more must be supplied.
    qid := "qid_example" // string | 
    v7QuotasQidNotification := *openapiclient.NewV7QuotasQidNotification() // V7QuotasQidNotification | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.UpdateQuotav7QuotasQidNotification(context.Background(), v7QuotasQidNotificationId, qid).V7QuotasQidNotification(v7QuotasQidNotification).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.UpdateQuotav7QuotasQidNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7QuotasQidNotificationId** | **string** | Modify notification rule. All input fields are optional, but one or more must be supplied. | 
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotav7QuotasQidNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v7QuotasQidNotification** | [**V7QuotasQidNotification**](V7QuotasQidNotification.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotav7SettingsNotification

> UpdateQuotav7SettingsNotification(ctx, v7SettingsNotificationId).V7SettingsNotification(v7SettingsNotification).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SettingsNotificationId := "v7SettingsNotificationId_example" // string | Modify notification rule. All input fields are optional, but one or more must be supplied.
    v7SettingsNotification := *openapiclient.NewV7QuotasQidNotification() // V7QuotasQidNotification | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.UpdateQuotav7SettingsNotification(context.Background(), v7SettingsNotificationId).V7SettingsNotification(v7SettingsNotification).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.UpdateQuotav7SettingsNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v7SettingsNotificationId** | **string** | Modify notification rule. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotav7SettingsNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7SettingsNotification** | [**V7QuotasQidNotification**](V7QuotasQidNotification.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotav8QuotaQuota

> UpdateQuotav8QuotaQuota(ctx, v8QuotaQuotaId).V8QuotaQuota(v8QuotaQuota).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v8QuotaQuotaId := "v8QuotaQuotaId_example" // string | Modify quota. All input fields are optional, but one or more must be supplied.
    v8QuotaQuota := *openapiclient.NewV12QuotaQuotaExtendedExtended() // V12QuotaQuotaExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaApi.UpdateQuotav8QuotaQuota(context.Background(), v8QuotaQuotaId).V8QuotaQuota(v8QuotaQuota).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaApi.UpdateQuotav8QuotaQuota``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v8QuotaQuotaId** | **string** | Modify quota. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotav8QuotaQuotaRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v8QuotaQuota** | [**V12QuotaQuotaExtendedExtended**](V12QuotaQuotaExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

