# V14PapiSettingsPapiSettingsChildSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ChildLimit** | Pointer to **int32** | The number of PAPI requests that can be processed concurrently. | [optional] 
**ChildLimitCeiling** | Pointer to **int32** | Max value of child_limit that can be controlled. | [optional] 
**ChildLimitExtension** | Pointer to **int32** | Extends the child limit for serving the URIs. | [optional] 
**ChildLimitFloor** | Pointer to **int32** | Min value of child_limit that can be controlled. | [optional] 

## Methods

### NewV14PapiSettingsPapiSettingsChildSettings

`func NewV14PapiSettingsPapiSettingsChildSettings() *V14PapiSettingsPapiSettingsChildSettings`

NewV14PapiSettingsPapiSettingsChildSettings instantiates a new V14PapiSettingsPapiSettingsChildSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14PapiSettingsPapiSettingsChildSettingsWithDefaults

`func NewV14PapiSettingsPapiSettingsChildSettingsWithDefaults() *V14PapiSettingsPapiSettingsChildSettings`

NewV14PapiSettingsPapiSettingsChildSettingsWithDefaults instantiates a new V14PapiSettingsPapiSettingsChildSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetChildLimit

`func (o *V14PapiSettingsPapiSettingsChildSettings) GetChildLimit() int32`

GetChildLimit returns the ChildLimit field if non-nil, zero value otherwise.

### GetChildLimitOk

`func (o *V14PapiSettingsPapiSettingsChildSettings) GetChildLimitOk() (*int32, bool)`

GetChildLimitOk returns a tuple with the ChildLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChildLimit

`func (o *V14PapiSettingsPapiSettingsChildSettings) SetChildLimit(v int32)`

SetChildLimit sets ChildLimit field to given value.

### HasChildLimit

`func (o *V14PapiSettingsPapiSettingsChildSettings) HasChildLimit() bool`

HasChildLimit returns a boolean if a field has been set.

### GetChildLimitCeiling

`func (o *V14PapiSettingsPapiSettingsChildSettings) GetChildLimitCeiling() int32`

GetChildLimitCeiling returns the ChildLimitCeiling field if non-nil, zero value otherwise.

### GetChildLimitCeilingOk

`func (o *V14PapiSettingsPapiSettingsChildSettings) GetChildLimitCeilingOk() (*int32, bool)`

GetChildLimitCeilingOk returns a tuple with the ChildLimitCeiling field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChildLimitCeiling

`func (o *V14PapiSettingsPapiSettingsChildSettings) SetChildLimitCeiling(v int32)`

SetChildLimitCeiling sets ChildLimitCeiling field to given value.

### HasChildLimitCeiling

`func (o *V14PapiSettingsPapiSettingsChildSettings) HasChildLimitCeiling() bool`

HasChildLimitCeiling returns a boolean if a field has been set.

### GetChildLimitExtension

`func (o *V14PapiSettingsPapiSettingsChildSettings) GetChildLimitExtension() int32`

GetChildLimitExtension returns the ChildLimitExtension field if non-nil, zero value otherwise.

### GetChildLimitExtensionOk

`func (o *V14PapiSettingsPapiSettingsChildSettings) GetChildLimitExtensionOk() (*int32, bool)`

GetChildLimitExtensionOk returns a tuple with the ChildLimitExtension field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChildLimitExtension

`func (o *V14PapiSettingsPapiSettingsChildSettings) SetChildLimitExtension(v int32)`

SetChildLimitExtension sets ChildLimitExtension field to given value.

### HasChildLimitExtension

`func (o *V14PapiSettingsPapiSettingsChildSettings) HasChildLimitExtension() bool`

HasChildLimitExtension returns a boolean if a field has been set.

### GetChildLimitFloor

`func (o *V14PapiSettingsPapiSettingsChildSettings) GetChildLimitFloor() int32`

GetChildLimitFloor returns the ChildLimitFloor field if non-nil, zero value otherwise.

### GetChildLimitFloorOk

`func (o *V14PapiSettingsPapiSettingsChildSettings) GetChildLimitFloorOk() (*int32, bool)`

GetChildLimitFloorOk returns a tuple with the ChildLimitFloor field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChildLimitFloor

`func (o *V14PapiSettingsPapiSettingsChildSettings) SetChildLimitFloor(v int32)`

SetChildLimitFloor sets ChildLimitFloor field to given value.

### HasChildLimitFloor

`func (o *V14PapiSettingsPapiSettingsChildSettings) HasChildLimitFloor() bool`

HasChildLimitFloor returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


