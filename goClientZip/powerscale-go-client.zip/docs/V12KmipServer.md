# V12KmipServer

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CaCertPath** | **string** | Certification Authority (CA) certificate, used for TLS Mutual Authentication with the KMIP Server. | 
**ClientCertPassword** | Pointer to **string** | Cluster identity private key password. | [optional] 
**ClientCertPath** | **string** | Cluster identity certificate and private key used for TLS Mutual Authentication with the KMIP Server. | 
**ConnectionTimeout** | Pointer to **int32** | KMIP RPC connection timeout in seconds. | [optional] 
**Host** | **string** | KMIP server hostname. | 
**Id** | **string** | Unique KMIP server identifier. | 
**MinimumTlsVersion** | Pointer to **string** | Denotes the minimum TLS version supported by the KTP. Default value is set to &#39;1.2&#39;. However other supported values are &#39;1.0&#39; and &#39;1.1&#39;. | [optional] 
**Port** | Pointer to **int32** | KMIP server port. | [optional] 
**RetryTimeout** | Pointer to **int32** | KMIP RPC retry timeout in milliseconds. | [optional] 

## Methods

### NewV12KmipServer

`func NewV12KmipServer(caCertPath string, clientCertPath string, host string, id string, ) *V12KmipServer`

NewV12KmipServer instantiates a new V12KmipServer object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12KmipServerWithDefaults

`func NewV12KmipServerWithDefaults() *V12KmipServer`

NewV12KmipServerWithDefaults instantiates a new V12KmipServer object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCaCertPath

`func (o *V12KmipServer) GetCaCertPath() string`

GetCaCertPath returns the CaCertPath field if non-nil, zero value otherwise.

### GetCaCertPathOk

`func (o *V12KmipServer) GetCaCertPathOk() (*string, bool)`

GetCaCertPathOk returns a tuple with the CaCertPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCaCertPath

`func (o *V12KmipServer) SetCaCertPath(v string)`

SetCaCertPath sets CaCertPath field to given value.


### GetClientCertPassword

`func (o *V12KmipServer) GetClientCertPassword() string`

GetClientCertPassword returns the ClientCertPassword field if non-nil, zero value otherwise.

### GetClientCertPasswordOk

`func (o *V12KmipServer) GetClientCertPasswordOk() (*string, bool)`

GetClientCertPasswordOk returns a tuple with the ClientCertPassword field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClientCertPassword

`func (o *V12KmipServer) SetClientCertPassword(v string)`

SetClientCertPassword sets ClientCertPassword field to given value.

### HasClientCertPassword

`func (o *V12KmipServer) HasClientCertPassword() bool`

HasClientCertPassword returns a boolean if a field has been set.

### GetClientCertPath

`func (o *V12KmipServer) GetClientCertPath() string`

GetClientCertPath returns the ClientCertPath field if non-nil, zero value otherwise.

### GetClientCertPathOk

`func (o *V12KmipServer) GetClientCertPathOk() (*string, bool)`

GetClientCertPathOk returns a tuple with the ClientCertPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClientCertPath

`func (o *V12KmipServer) SetClientCertPath(v string)`

SetClientCertPath sets ClientCertPath field to given value.


### GetConnectionTimeout

`func (o *V12KmipServer) GetConnectionTimeout() int32`

GetConnectionTimeout returns the ConnectionTimeout field if non-nil, zero value otherwise.

### GetConnectionTimeoutOk

`func (o *V12KmipServer) GetConnectionTimeoutOk() (*int32, bool)`

GetConnectionTimeoutOk returns a tuple with the ConnectionTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConnectionTimeout

`func (o *V12KmipServer) SetConnectionTimeout(v int32)`

SetConnectionTimeout sets ConnectionTimeout field to given value.

### HasConnectionTimeout

`func (o *V12KmipServer) HasConnectionTimeout() bool`

HasConnectionTimeout returns a boolean if a field has been set.

### GetHost

`func (o *V12KmipServer) GetHost() string`

GetHost returns the Host field if non-nil, zero value otherwise.

### GetHostOk

`func (o *V12KmipServer) GetHostOk() (*string, bool)`

GetHostOk returns a tuple with the Host field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHost

`func (o *V12KmipServer) SetHost(v string)`

SetHost sets Host field to given value.


### GetId

`func (o *V12KmipServer) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12KmipServer) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12KmipServer) SetId(v string)`

SetId sets Id field to given value.


### GetMinimumTlsVersion

`func (o *V12KmipServer) GetMinimumTlsVersion() string`

GetMinimumTlsVersion returns the MinimumTlsVersion field if non-nil, zero value otherwise.

### GetMinimumTlsVersionOk

`func (o *V12KmipServer) GetMinimumTlsVersionOk() (*string, bool)`

GetMinimumTlsVersionOk returns a tuple with the MinimumTlsVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinimumTlsVersion

`func (o *V12KmipServer) SetMinimumTlsVersion(v string)`

SetMinimumTlsVersion sets MinimumTlsVersion field to given value.

### HasMinimumTlsVersion

`func (o *V12KmipServer) HasMinimumTlsVersion() bool`

HasMinimumTlsVersion returns a boolean if a field has been set.

### GetPort

`func (o *V12KmipServer) GetPort() int32`

GetPort returns the Port field if non-nil, zero value otherwise.

### GetPortOk

`func (o *V12KmipServer) GetPortOk() (*int32, bool)`

GetPortOk returns a tuple with the Port field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPort

`func (o *V12KmipServer) SetPort(v int32)`

SetPort sets Port field to given value.

### HasPort

`func (o *V12KmipServer) HasPort() bool`

HasPort returns a boolean if a field has been set.

### GetRetryTimeout

`func (o *V12KmipServer) GetRetryTimeout() int32`

GetRetryTimeout returns the RetryTimeout field if non-nil, zero value otherwise.

### GetRetryTimeoutOk

`func (o *V12KmipServer) GetRetryTimeoutOk() (*int32, bool)`

GetRetryTimeoutOk returns a tuple with the RetryTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRetryTimeout

`func (o *V12KmipServer) SetRetryTimeout(v int32)`

SetRetryTimeout sets RetryTimeout field to given value.

### HasRetryTimeout

`func (o *V12KmipServer) HasRetryTimeout() bool`

HasRetryTimeout returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


