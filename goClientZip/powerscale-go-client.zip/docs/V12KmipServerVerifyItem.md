# V12KmipServerVerifyItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CaCertPath** | **string** | Certification Authority (CA) certificate, used for TLS Mutual Authentication with the KMIP Server. | 
**ClientCertPassword** | Pointer to **string** | Cluster identity private key password. | [optional] 
**ClientCertPath** | **string** | Cluster identity certificate and private key used for TLS Mutual Authentication with the KMIP Server. | 
**ConnectionTimeout** | Pointer to **int32** | KMIP RPC connection timeout in seconds. | [optional] 
**Host** | **string** | KMIP server hostname. | 
**MinimumTlsVersion** | Pointer to **string** | Denotes the minimum TLS version supported by the KTP. Default value is set to &#39;1.2&#39;. However other supported values are &#39;1.0&#39; and &#39;1.1&#39;. | [optional] 
**Port** | Pointer to **int32** | KMIP server port. | [optional] 
**RetryTimeout** | Pointer to **int32** | KMIP RPC retry timeout in milliseconds. | [optional] 

## Methods

### NewV12KmipServerVerifyItem

`func NewV12KmipServerVerifyItem(caCertPath string, clientCertPath string, host string, ) *V12KmipServerVerifyItem`

NewV12KmipServerVerifyItem instantiates a new V12KmipServerVerifyItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12KmipServerVerifyItemWithDefaults

`func NewV12KmipServerVerifyItemWithDefaults() *V12KmipServerVerifyItem`

NewV12KmipServerVerifyItemWithDefaults instantiates a new V12KmipServerVerifyItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCaCertPath

`func (o *V12KmipServerVerifyItem) GetCaCertPath() string`

GetCaCertPath returns the CaCertPath field if non-nil, zero value otherwise.

### GetCaCertPathOk

`func (o *V12KmipServerVerifyItem) GetCaCertPathOk() (*string, bool)`

GetCaCertPathOk returns a tuple with the CaCertPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCaCertPath

`func (o *V12KmipServerVerifyItem) SetCaCertPath(v string)`

SetCaCertPath sets CaCertPath field to given value.


### GetClientCertPassword

`func (o *V12KmipServerVerifyItem) GetClientCertPassword() string`

GetClientCertPassword returns the ClientCertPassword field if non-nil, zero value otherwise.

### GetClientCertPasswordOk

`func (o *V12KmipServerVerifyItem) GetClientCertPasswordOk() (*string, bool)`

GetClientCertPasswordOk returns a tuple with the ClientCertPassword field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClientCertPassword

`func (o *V12KmipServerVerifyItem) SetClientCertPassword(v string)`

SetClientCertPassword sets ClientCertPassword field to given value.

### HasClientCertPassword

`func (o *V12KmipServerVerifyItem) HasClientCertPassword() bool`

HasClientCertPassword returns a boolean if a field has been set.

### GetClientCertPath

`func (o *V12KmipServerVerifyItem) GetClientCertPath() string`

GetClientCertPath returns the ClientCertPath field if non-nil, zero value otherwise.

### GetClientCertPathOk

`func (o *V12KmipServerVerifyItem) GetClientCertPathOk() (*string, bool)`

GetClientCertPathOk returns a tuple with the ClientCertPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClientCertPath

`func (o *V12KmipServerVerifyItem) SetClientCertPath(v string)`

SetClientCertPath sets ClientCertPath field to given value.


### GetConnectionTimeout

`func (o *V12KmipServerVerifyItem) GetConnectionTimeout() int32`

GetConnectionTimeout returns the ConnectionTimeout field if non-nil, zero value otherwise.

### GetConnectionTimeoutOk

`func (o *V12KmipServerVerifyItem) GetConnectionTimeoutOk() (*int32, bool)`

GetConnectionTimeoutOk returns a tuple with the ConnectionTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConnectionTimeout

`func (o *V12KmipServerVerifyItem) SetConnectionTimeout(v int32)`

SetConnectionTimeout sets ConnectionTimeout field to given value.

### HasConnectionTimeout

`func (o *V12KmipServerVerifyItem) HasConnectionTimeout() bool`

HasConnectionTimeout returns a boolean if a field has been set.

### GetHost

`func (o *V12KmipServerVerifyItem) GetHost() string`

GetHost returns the Host field if non-nil, zero value otherwise.

### GetHostOk

`func (o *V12KmipServerVerifyItem) GetHostOk() (*string, bool)`

GetHostOk returns a tuple with the Host field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHost

`func (o *V12KmipServerVerifyItem) SetHost(v string)`

SetHost sets Host field to given value.


### GetMinimumTlsVersion

`func (o *V12KmipServerVerifyItem) GetMinimumTlsVersion() string`

GetMinimumTlsVersion returns the MinimumTlsVersion field if non-nil, zero value otherwise.

### GetMinimumTlsVersionOk

`func (o *V12KmipServerVerifyItem) GetMinimumTlsVersionOk() (*string, bool)`

GetMinimumTlsVersionOk returns a tuple with the MinimumTlsVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMinimumTlsVersion

`func (o *V12KmipServerVerifyItem) SetMinimumTlsVersion(v string)`

SetMinimumTlsVersion sets MinimumTlsVersion field to given value.

### HasMinimumTlsVersion

`func (o *V12KmipServerVerifyItem) HasMinimumTlsVersion() bool`

HasMinimumTlsVersion returns a boolean if a field has been set.

### GetPort

`func (o *V12KmipServerVerifyItem) GetPort() int32`

GetPort returns the Port field if non-nil, zero value otherwise.

### GetPortOk

`func (o *V12KmipServerVerifyItem) GetPortOk() (*int32, bool)`

GetPortOk returns a tuple with the Port field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPort

`func (o *V12KmipServerVerifyItem) SetPort(v int32)`

SetPort sets Port field to given value.

### HasPort

`func (o *V12KmipServerVerifyItem) HasPort() bool`

HasPort returns a boolean if a field has been set.

### GetRetryTimeout

`func (o *V12KmipServerVerifyItem) GetRetryTimeout() int32`

GetRetryTimeout returns the RetryTimeout field if non-nil, zero value otherwise.

### GetRetryTimeoutOk

`func (o *V12KmipServerVerifyItem) GetRetryTimeoutOk() (*int32, bool)`

GetRetryTimeoutOk returns a tuple with the RetryTimeout field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRetryTimeout

`func (o *V12KmipServerVerifyItem) SetRetryTimeout(v int32)`

SetRetryTimeout sets RetryTimeout field to given value.

### HasRetryTimeout

`func (o *V12KmipServerVerifyItem) HasRetryTimeout() bool`

HasRetryTimeout returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


