# V14SnapshotWritableItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DstPath** | **string** | The user supplied /ifs path of writable snapshot. | 
**SrcSnap** | **string** | The user supplied source snapshot name or ID. This will be null for writable snapshots pending delete. | 

## Methods

### NewV14SnapshotWritableItem

`func NewV14SnapshotWritableItem(dstPath string, srcSnap string, ) *V14SnapshotWritableItem`

NewV14SnapshotWritableItem instantiates a new V14SnapshotWritableItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SnapshotWritableItemWithDefaults

`func NewV14SnapshotWritableItemWithDefaults() *V14SnapshotWritableItem`

NewV14SnapshotWritableItemWithDefaults instantiates a new V14SnapshotWritableItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDstPath

`func (o *V14SnapshotWritableItem) GetDstPath() string`

GetDstPath returns the DstPath field if non-nil, zero value otherwise.

### GetDstPathOk

`func (o *V14SnapshotWritableItem) GetDstPathOk() (*string, bool)`

GetDstPathOk returns a tuple with the DstPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDstPath

`func (o *V14SnapshotWritableItem) SetDstPath(v string)`

SetDstPath sets DstPath field to given value.


### GetSrcSnap

`func (o *V14SnapshotWritableItem) GetSrcSnap() string`

GetSrcSnap returns the SrcSnap field if non-nil, zero value otherwise.

### GetSrcSnapOk

`func (o *V14SnapshotWritableItem) GetSrcSnapOk() (*string, bool)`

GetSrcSnapOk returns a tuple with the SrcSnap field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrcSnap

`func (o *V14SnapshotWritableItem) SetSrcSnap(v string)`

SetSrcSnap sets SrcSnap field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


