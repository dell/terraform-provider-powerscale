# \StoragepoolApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateStoragepoolv1StoragepoolNodepool**](StoragepoolApi.md#CreateStoragepoolv1StoragepoolNodepool) | **Post** /platform/1/storagepool/nodepools | 
[**CreateStoragepoolv1StoragepoolTier**](StoragepoolApi.md#CreateStoragepoolv1StoragepoolTier) | **Post** /platform/1/storagepool/tiers | 
[**CreateStoragepoolv3StoragepoolNodepool**](StoragepoolApi.md#CreateStoragepoolv3StoragepoolNodepool) | **Post** /platform/3/storagepool/nodepools | 
[**CreateStoragepoolv9StoragepoolNodepool**](StoragepoolApi.md#CreateStoragepoolv9StoragepoolNodepool) | **Post** /platform/9/storagepool/nodepools | 
[**DeleteStoragepoolv1StoragepoolNodepool**](StoragepoolApi.md#DeleteStoragepoolv1StoragepoolNodepool) | **Delete** /platform/1/storagepool/nodepools/{v1StoragepoolNodepoolId} | 
[**DeleteStoragepoolv1StoragepoolTier**](StoragepoolApi.md#DeleteStoragepoolv1StoragepoolTier) | **Delete** /platform/1/storagepool/tiers/{v1StoragepoolTierId} | 
[**DeleteStoragepoolv1StoragepoolTiers**](StoragepoolApi.md#DeleteStoragepoolv1StoragepoolTiers) | **Delete** /platform/1/storagepool/tiers | 
[**DeleteStoragepoolv3StoragepoolNodepool**](StoragepoolApi.md#DeleteStoragepoolv3StoragepoolNodepool) | **Delete** /platform/3/storagepool/nodepools/{v3StoragepoolNodepoolId} | 
[**DeleteStoragepoolv3StoragepoolNodepools**](StoragepoolApi.md#DeleteStoragepoolv3StoragepoolNodepools) | **Delete** /platform/3/storagepool/nodepools | 
[**DeleteStoragepoolv9StoragepoolNodepool**](StoragepoolApi.md#DeleteStoragepoolv9StoragepoolNodepool) | **Delete** /platform/9/storagepool/nodepools/{v9StoragepoolNodepoolId} | 
[**DeleteStoragepoolv9StoragepoolNodepools**](StoragepoolApi.md#DeleteStoragepoolv9StoragepoolNodepools) | **Delete** /platform/9/storagepool/nodepools | 
[**GetStoragepoolv12StoragepoolNodetype**](StoragepoolApi.md#GetStoragepoolv12StoragepoolNodetype) | **Get** /platform/12/storagepool/nodetypes/{v12StoragepoolNodetypeId} | 
[**GetStoragepoolv12StoragepoolNodetypes**](StoragepoolApi.md#GetStoragepoolv12StoragepoolNodetypes) | **Get** /platform/12/storagepool/nodetypes | 
[**GetStoragepoolv1StoragepoolNodepool**](StoragepoolApi.md#GetStoragepoolv1StoragepoolNodepool) | **Get** /platform/1/storagepool/nodepools/{v1StoragepoolNodepoolId} | 
[**GetStoragepoolv1StoragepoolSettings**](StoragepoolApi.md#GetStoragepoolv1StoragepoolSettings) | **Get** /platform/1/storagepool/settings | 
[**GetStoragepoolv1StoragepoolStatus**](StoragepoolApi.md#GetStoragepoolv1StoragepoolStatus) | **Get** /platform/1/storagepool/status | 
[**GetStoragepoolv1StoragepoolStoragepools**](StoragepoolApi.md#GetStoragepoolv1StoragepoolStoragepools) | **Get** /platform/1/storagepool/storagepools | 
[**GetStoragepoolv1StoragepoolTier**](StoragepoolApi.md#GetStoragepoolv1StoragepoolTier) | **Get** /platform/1/storagepool/tiers/{v1StoragepoolTierId} | 
[**GetStoragepoolv1StoragepoolUnprovisioned**](StoragepoolApi.md#GetStoragepoolv1StoragepoolUnprovisioned) | **Get** /platform/1/storagepool/unprovisioned | 
[**GetStoragepoolv3StoragepoolNodepool**](StoragepoolApi.md#GetStoragepoolv3StoragepoolNodepool) | **Get** /platform/3/storagepool/nodepools/{v3StoragepoolNodepoolId} | 
[**GetStoragepoolv3StoragepoolStoragepools**](StoragepoolApi.md#GetStoragepoolv3StoragepoolStoragepools) | **Get** /platform/3/storagepool/storagepools | 
[**GetStoragepoolv3StoragepoolSuggestedProtectionNid**](StoragepoolApi.md#GetStoragepoolv3StoragepoolSuggestedProtectionNid) | **Get** /platform/3/storagepool/suggested-protection/{v3StoragepoolSuggestedProtectionNid} | 
[**GetStoragepoolv5StoragepoolSettings**](StoragepoolApi.md#GetStoragepoolv5StoragepoolSettings) | **Get** /platform/5/storagepool/settings | 
[**GetStoragepoolv9StoragepoolNodepool**](StoragepoolApi.md#GetStoragepoolv9StoragepoolNodepool) | **Get** /platform/9/storagepool/nodepools/{v9StoragepoolNodepoolId} | 
[**GetStoragepoolv9StoragepoolNodetype**](StoragepoolApi.md#GetStoragepoolv9StoragepoolNodetype) | **Get** /platform/9/storagepool/nodetypes/{v9StoragepoolNodetypeId} | 
[**GetStoragepoolv9StoragepoolNodetypes**](StoragepoolApi.md#GetStoragepoolv9StoragepoolNodetypes) | **Get** /platform/9/storagepool/nodetypes | 
[**GetStoragepoolv9StoragepoolStoragepools**](StoragepoolApi.md#GetStoragepoolv9StoragepoolStoragepools) | **Get** /platform/9/storagepool/storagepools | 
[**ListStoragepoolv1StoragepoolNodepools**](StoragepoolApi.md#ListStoragepoolv1StoragepoolNodepools) | **Get** /platform/1/storagepool/nodepools | 
[**ListStoragepoolv1StoragepoolTiers**](StoragepoolApi.md#ListStoragepoolv1StoragepoolTiers) | **Get** /platform/1/storagepool/tiers | 
[**ListStoragepoolv3StoragepoolNodepools**](StoragepoolApi.md#ListStoragepoolv3StoragepoolNodepools) | **Get** /platform/3/storagepool/nodepools | 
[**ListStoragepoolv9StoragepoolNodepools**](StoragepoolApi.md#ListStoragepoolv9StoragepoolNodepools) | **Get** /platform/9/storagepool/nodepools | 
[**UpdateStoragepoolv1StoragepoolNodepool**](StoragepoolApi.md#UpdateStoragepoolv1StoragepoolNodepool) | **Put** /platform/1/storagepool/nodepools/{v1StoragepoolNodepoolId} | 
[**UpdateStoragepoolv1StoragepoolSettings**](StoragepoolApi.md#UpdateStoragepoolv1StoragepoolSettings) | **Put** /platform/1/storagepool/settings | 
[**UpdateStoragepoolv1StoragepoolTier**](StoragepoolApi.md#UpdateStoragepoolv1StoragepoolTier) | **Put** /platform/1/storagepool/tiers/{v1StoragepoolTierId} | 
[**UpdateStoragepoolv3StoragepoolNodepool**](StoragepoolApi.md#UpdateStoragepoolv3StoragepoolNodepool) | **Put** /platform/3/storagepool/nodepools/{v3StoragepoolNodepoolId} | 
[**UpdateStoragepoolv5StoragepoolSettings**](StoragepoolApi.md#UpdateStoragepoolv5StoragepoolSettings) | **Put** /platform/5/storagepool/settings | 
[**UpdateStoragepoolv9StoragepoolNodepool**](StoragepoolApi.md#UpdateStoragepoolv9StoragepoolNodepool) | **Put** /platform/9/storagepool/nodepools/{v9StoragepoolNodepoolId} | 



## CreateStoragepoolv1StoragepoolNodepool

> Createv1StoragepoolNodepoolResponse CreateStoragepoolv1StoragepoolNodepool(ctx).V1StoragepoolNodepool(v1StoragepoolNodepool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1StoragepoolNodepool := *openapiclient.NewV1StoragepoolNodepool([]int32{int32(123)}, "Name_example") // V1StoragepoolNodepool | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.CreateStoragepoolv1StoragepoolNodepool(context.Background()).V1StoragepoolNodepool(v1StoragepoolNodepool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.CreateStoragepoolv1StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateStoragepoolv1StoragepoolNodepool`: Createv1StoragepoolNodepoolResponse
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.CreateStoragepoolv1StoragepoolNodepool`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateStoragepoolv1StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1StoragepoolNodepool** | [**V1StoragepoolNodepool**](V1StoragepoolNodepool.md) |  | 

### Return type

[**Createv1StoragepoolNodepoolResponse**](Createv1StoragepoolNodepoolResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateStoragepoolv1StoragepoolTier

> Createv1StoragepoolNodepoolResponse CreateStoragepoolv1StoragepoolTier(ctx).V1StoragepoolTier(v1StoragepoolTier).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1StoragepoolTier := *openapiclient.NewV1StoragepoolTier("Name_example") // V1StoragepoolTier | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.CreateStoragepoolv1StoragepoolTier(context.Background()).V1StoragepoolTier(v1StoragepoolTier).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.CreateStoragepoolv1StoragepoolTier``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateStoragepoolv1StoragepoolTier`: Createv1StoragepoolNodepoolResponse
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.CreateStoragepoolv1StoragepoolTier`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateStoragepoolv1StoragepoolTierRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1StoragepoolTier** | [**V1StoragepoolTier**](V1StoragepoolTier.md) |  | 

### Return type

[**Createv1StoragepoolNodepoolResponse**](Createv1StoragepoolNodepoolResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateStoragepoolv3StoragepoolNodepool

> Createv1StoragepoolNodepoolResponse CreateStoragepoolv3StoragepoolNodepool(ctx).V3StoragepoolNodepool(v3StoragepoolNodepool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3StoragepoolNodepool := *openapiclient.NewV1StoragepoolNodepool([]int32{int32(123)}, "Name_example") // V1StoragepoolNodepool | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.CreateStoragepoolv3StoragepoolNodepool(context.Background()).V3StoragepoolNodepool(v3StoragepoolNodepool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.CreateStoragepoolv3StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateStoragepoolv3StoragepoolNodepool`: Createv1StoragepoolNodepoolResponse
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.CreateStoragepoolv3StoragepoolNodepool`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateStoragepoolv3StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3StoragepoolNodepool** | [**V1StoragepoolNodepool**](V1StoragepoolNodepool.md) |  | 

### Return type

[**Createv1StoragepoolNodepoolResponse**](Createv1StoragepoolNodepoolResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateStoragepoolv9StoragepoolNodepool

> Createv1StoragepoolNodepoolResponse CreateStoragepoolv9StoragepoolNodepool(ctx).V9StoragepoolNodepool(v9StoragepoolNodepool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9StoragepoolNodepool := *openapiclient.NewV9StoragepoolNodepool([]int32{int32(123)}, "Name_example") // V9StoragepoolNodepool | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.CreateStoragepoolv9StoragepoolNodepool(context.Background()).V9StoragepoolNodepool(v9StoragepoolNodepool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.CreateStoragepoolv9StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateStoragepoolv9StoragepoolNodepool`: Createv1StoragepoolNodepoolResponse
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.CreateStoragepoolv9StoragepoolNodepool`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateStoragepoolv9StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v9StoragepoolNodepool** | [**V9StoragepoolNodepool**](V9StoragepoolNodepool.md) |  | 

### Return type

[**Createv1StoragepoolNodepoolResponse**](Createv1StoragepoolNodepoolResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteStoragepoolv1StoragepoolNodepool

> DeleteStoragepoolv1StoragepoolNodepool(ctx, v1StoragepoolNodepoolId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1StoragepoolNodepoolId := "v1StoragepoolNodepoolId_example" // string | Delete node pool.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.DeleteStoragepoolv1StoragepoolNodepool(context.Background(), v1StoragepoolNodepoolId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.DeleteStoragepoolv1StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1StoragepoolNodepoolId** | **string** | Delete node pool. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteStoragepoolv1StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteStoragepoolv1StoragepoolTier

> DeleteStoragepoolv1StoragepoolTier(ctx, v1StoragepoolTierId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1StoragepoolTierId := "v1StoragepoolTierId_example" // string | Delete tier.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.DeleteStoragepoolv1StoragepoolTier(context.Background(), v1StoragepoolTierId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.DeleteStoragepoolv1StoragepoolTier``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1StoragepoolTierId** | **string** | Delete tier. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteStoragepoolv1StoragepoolTierRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteStoragepoolv1StoragepoolTiers

> DeleteStoragepoolv1StoragepoolTiers(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.DeleteStoragepoolv1StoragepoolTiers(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.DeleteStoragepoolv1StoragepoolTiers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteStoragepoolv1StoragepoolTiersRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteStoragepoolv3StoragepoolNodepool

> DeleteStoragepoolv3StoragepoolNodepool(ctx, v3StoragepoolNodepoolId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3StoragepoolNodepoolId := "v3StoragepoolNodepoolId_example" // string | Delete node pool.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.DeleteStoragepoolv3StoragepoolNodepool(context.Background(), v3StoragepoolNodepoolId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.DeleteStoragepoolv3StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3StoragepoolNodepoolId** | **string** | Delete node pool. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteStoragepoolv3StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteStoragepoolv3StoragepoolNodepools

> DeleteStoragepoolv3StoragepoolNodepools(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.DeleteStoragepoolv3StoragepoolNodepools(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.DeleteStoragepoolv3StoragepoolNodepools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteStoragepoolv3StoragepoolNodepoolsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteStoragepoolv9StoragepoolNodepool

> DeleteStoragepoolv9StoragepoolNodepool(ctx, v9StoragepoolNodepoolId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9StoragepoolNodepoolId := "v9StoragepoolNodepoolId_example" // string | Delete node pool.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.DeleteStoragepoolv9StoragepoolNodepool(context.Background(), v9StoragepoolNodepoolId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.DeleteStoragepoolv9StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9StoragepoolNodepoolId** | **string** | Delete node pool. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteStoragepoolv9StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteStoragepoolv9StoragepoolNodepools

> DeleteStoragepoolv9StoragepoolNodepools(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.DeleteStoragepoolv9StoragepoolNodepools(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.DeleteStoragepoolv9StoragepoolNodepools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteStoragepoolv9StoragepoolNodepoolsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv12StoragepoolNodetype

> V12StoragepoolNodetypesExtended GetStoragepoolv12StoragepoolNodetype(ctx, v12StoragepoolNodetypeId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v12StoragepoolNodetypeId := "v12StoragepoolNodetypeId_example" // string | Retrieve node type information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv12StoragepoolNodetype(context.Background(), v12StoragepoolNodetypeId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv12StoragepoolNodetype``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv12StoragepoolNodetype`: V12StoragepoolNodetypesExtended
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv12StoragepoolNodetype`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v12StoragepoolNodetypeId** | **string** | Retrieve node type information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv12StoragepoolNodetypeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12StoragepoolNodetypesExtended**](V12StoragepoolNodetypesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv12StoragepoolNodetypes

> V12StoragepoolNodetypes GetStoragepoolv12StoragepoolNodetypes(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv12StoragepoolNodetypes(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv12StoragepoolNodetypes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv12StoragepoolNodetypes`: V12StoragepoolNodetypes
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv12StoragepoolNodetypes`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv12StoragepoolNodetypesRequest struct via the builder pattern


### Return type

[**V12StoragepoolNodetypes**](V12StoragepoolNodetypes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv1StoragepoolNodepool

> V1StoragepoolNodepoolsExtended GetStoragepoolv1StoragepoolNodepool(ctx, v1StoragepoolNodepoolId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1StoragepoolNodepoolId := "v1StoragepoolNodepoolId_example" // string | Retrieve node pool information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv1StoragepoolNodepool(context.Background(), v1StoragepoolNodepoolId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv1StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv1StoragepoolNodepool`: V1StoragepoolNodepoolsExtended
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv1StoragepoolNodepool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1StoragepoolNodepoolId** | **string** | Retrieve node pool information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv1StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1StoragepoolNodepoolsExtended**](V1StoragepoolNodepoolsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv1StoragepoolSettings

> V1StoragepoolSettings GetStoragepoolv1StoragepoolSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv1StoragepoolSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv1StoragepoolSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv1StoragepoolSettings`: V1StoragepoolSettings
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv1StoragepoolSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv1StoragepoolSettingsRequest struct via the builder pattern


### Return type

[**V1StoragepoolSettings**](V1StoragepoolSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv1StoragepoolStatus

> V1StoragepoolStatus GetStoragepoolv1StoragepoolStatus(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv1StoragepoolStatus(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv1StoragepoolStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv1StoragepoolStatus`: V1StoragepoolStatus
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv1StoragepoolStatus`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv1StoragepoolStatusRequest struct via the builder pattern


### Return type

[**V1StoragepoolStatus**](V1StoragepoolStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv1StoragepoolStoragepools

> V1StoragepoolStoragepools GetStoragepoolv1StoragepoolStoragepools(ctx).Toplevels(toplevels).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    toplevels := "toplevels_example" // string | If true, node pools contained within tiers will be filtered out of results. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv1StoragepoolStoragepools(context.Background()).Toplevels(toplevels).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv1StoragepoolStoragepools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv1StoragepoolStoragepools`: V1StoragepoolStoragepools
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv1StoragepoolStoragepools`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv1StoragepoolStoragepoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **toplevels** | **string** | If true, node pools contained within tiers will be filtered out of results. | 

### Return type

[**V1StoragepoolStoragepools**](V1StoragepoolStoragepools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv1StoragepoolTier

> V1StoragepoolTiersExtended GetStoragepoolv1StoragepoolTier(ctx, v1StoragepoolTierId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1StoragepoolTierId := "v1StoragepoolTierId_example" // string | Retrieve tier information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv1StoragepoolTier(context.Background(), v1StoragepoolTierId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv1StoragepoolTier``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv1StoragepoolTier`: V1StoragepoolTiersExtended
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv1StoragepoolTier`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1StoragepoolTierId** | **string** | Retrieve tier information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv1StoragepoolTierRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1StoragepoolTiersExtended**](V1StoragepoolTiersExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv1StoragepoolUnprovisioned

> V1StoragepoolUnprovisioned GetStoragepoolv1StoragepoolUnprovisioned(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv1StoragepoolUnprovisioned(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv1StoragepoolUnprovisioned``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv1StoragepoolUnprovisioned`: V1StoragepoolUnprovisioned
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv1StoragepoolUnprovisioned`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv1StoragepoolUnprovisionedRequest struct via the builder pattern


### Return type

[**V1StoragepoolUnprovisioned**](V1StoragepoolUnprovisioned.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv3StoragepoolNodepool

> V3StoragepoolNodepoolsExtended GetStoragepoolv3StoragepoolNodepool(ctx, v3StoragepoolNodepoolId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3StoragepoolNodepoolId := "v3StoragepoolNodepoolId_example" // string | Retrieve node pool information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv3StoragepoolNodepool(context.Background(), v3StoragepoolNodepoolId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv3StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv3StoragepoolNodepool`: V3StoragepoolNodepoolsExtended
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv3StoragepoolNodepool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3StoragepoolNodepoolId** | **string** | Retrieve node pool information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv3StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3StoragepoolNodepoolsExtended**](V3StoragepoolNodepoolsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv3StoragepoolStoragepools

> V3StoragepoolStoragepools GetStoragepoolv3StoragepoolStoragepools(ctx).Sort(sort).Toplevels(toplevels).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    toplevels := "toplevels_example" // string | If true, node pools contained within tiers will be filtered out of results. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv3StoragepoolStoragepools(context.Background()).Sort(sort).Toplevels(toplevels).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv3StoragepoolStoragepools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv3StoragepoolStoragepools`: V3StoragepoolStoragepools
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv3StoragepoolStoragepools`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv3StoragepoolStoragepoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **toplevels** | **string** | If true, node pools contained within tiers will be filtered out of results. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3StoragepoolStoragepools**](V3StoragepoolStoragepools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv3StoragepoolSuggestedProtectionNid

> V3StoragepoolSuggestedProtection GetStoragepoolv3StoragepoolSuggestedProtectionNid(ctx, v3StoragepoolSuggestedProtectionNid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3StoragepoolSuggestedProtectionNid := "v3StoragepoolSuggestedProtectionNid_example" // string | Retrieve the suggested protection policy.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv3StoragepoolSuggestedProtectionNid(context.Background(), v3StoragepoolSuggestedProtectionNid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv3StoragepoolSuggestedProtectionNid``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv3StoragepoolSuggestedProtectionNid`: V3StoragepoolSuggestedProtection
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv3StoragepoolSuggestedProtectionNid`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3StoragepoolSuggestedProtectionNid** | **string** | Retrieve the suggested protection policy. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv3StoragepoolSuggestedProtectionNidRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3StoragepoolSuggestedProtection**](V3StoragepoolSuggestedProtection.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv5StoragepoolSettings

> V5StoragepoolSettings GetStoragepoolv5StoragepoolSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv5StoragepoolSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv5StoragepoolSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv5StoragepoolSettings`: V5StoragepoolSettings
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv5StoragepoolSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv5StoragepoolSettingsRequest struct via the builder pattern


### Return type

[**V5StoragepoolSettings**](V5StoragepoolSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv9StoragepoolNodepool

> V9StoragepoolNodepoolsExtended GetStoragepoolv9StoragepoolNodepool(ctx, v9StoragepoolNodepoolId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9StoragepoolNodepoolId := "v9StoragepoolNodepoolId_example" // string | Retrieve node pool information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv9StoragepoolNodepool(context.Background(), v9StoragepoolNodepoolId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv9StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv9StoragepoolNodepool`: V9StoragepoolNodepoolsExtended
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv9StoragepoolNodepool`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9StoragepoolNodepoolId** | **string** | Retrieve node pool information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv9StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V9StoragepoolNodepoolsExtended**](V9StoragepoolNodepoolsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv9StoragepoolNodetype

> V9StoragepoolNodetypesExtended GetStoragepoolv9StoragepoolNodetype(ctx, v9StoragepoolNodetypeId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9StoragepoolNodetypeId := "v9StoragepoolNodetypeId_example" // string | Retrieve node type information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv9StoragepoolNodetype(context.Background(), v9StoragepoolNodetypeId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv9StoragepoolNodetype``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv9StoragepoolNodetype`: V9StoragepoolNodetypesExtended
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv9StoragepoolNodetype`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9StoragepoolNodetypeId** | **string** | Retrieve node type information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv9StoragepoolNodetypeRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V9StoragepoolNodetypesExtended**](V9StoragepoolNodetypesExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv9StoragepoolNodetypes

> V9StoragepoolNodetypes GetStoragepoolv9StoragepoolNodetypes(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv9StoragepoolNodetypes(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv9StoragepoolNodetypes``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv9StoragepoolNodetypes`: V9StoragepoolNodetypes
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv9StoragepoolNodetypes`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv9StoragepoolNodetypesRequest struct via the builder pattern


### Return type

[**V9StoragepoolNodetypes**](V9StoragepoolNodetypes.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetStoragepoolv9StoragepoolStoragepools

> V9StoragepoolStoragepools GetStoragepoolv9StoragepoolStoragepools(ctx).Sort(sort).Toplevels(toplevels).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    toplevels := "toplevels_example" // string | If true, node pools contained within tiers will be filtered out of results. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.GetStoragepoolv9StoragepoolStoragepools(context.Background()).Sort(sort).Toplevels(toplevels).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.GetStoragepoolv9StoragepoolStoragepools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetStoragepoolv9StoragepoolStoragepools`: V9StoragepoolStoragepools
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.GetStoragepoolv9StoragepoolStoragepools`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetStoragepoolv9StoragepoolStoragepoolsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **sort** | **string** | The field that will be used for sorting. | 
 **toplevels** | **string** | If true, node pools contained within tiers will be filtered out of results. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V9StoragepoolStoragepools**](V9StoragepoolStoragepools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListStoragepoolv1StoragepoolNodepools

> V1StoragepoolNodepools ListStoragepoolv1StoragepoolNodepools(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.ListStoragepoolv1StoragepoolNodepools(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.ListStoragepoolv1StoragepoolNodepools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListStoragepoolv1StoragepoolNodepools`: V1StoragepoolNodepools
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.ListStoragepoolv1StoragepoolNodepools`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListStoragepoolv1StoragepoolNodepoolsRequest struct via the builder pattern


### Return type

[**V1StoragepoolNodepools**](V1StoragepoolNodepools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListStoragepoolv1StoragepoolTiers

> V1StoragepoolTiers ListStoragepoolv1StoragepoolTiers(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.ListStoragepoolv1StoragepoolTiers(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.ListStoragepoolv1StoragepoolTiers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListStoragepoolv1StoragepoolTiers`: V1StoragepoolTiers
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.ListStoragepoolv1StoragepoolTiers`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListStoragepoolv1StoragepoolTiersRequest struct via the builder pattern


### Return type

[**V1StoragepoolTiers**](V1StoragepoolTiers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListStoragepoolv3StoragepoolNodepools

> V3StoragepoolNodepools ListStoragepoolv3StoragepoolNodepools(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.ListStoragepoolv3StoragepoolNodepools(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.ListStoragepoolv3StoragepoolNodepools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListStoragepoolv3StoragepoolNodepools`: V3StoragepoolNodepools
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.ListStoragepoolv3StoragepoolNodepools`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListStoragepoolv3StoragepoolNodepoolsRequest struct via the builder pattern


### Return type

[**V3StoragepoolNodepools**](V3StoragepoolNodepools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListStoragepoolv9StoragepoolNodepools

> V9StoragepoolNodepools ListStoragepoolv9StoragepoolNodepools(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.StoragepoolApi.ListStoragepoolv9StoragepoolNodepools(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.ListStoragepoolv9StoragepoolNodepools``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListStoragepoolv9StoragepoolNodepools`: V9StoragepoolNodepools
    fmt.Fprintf(os.Stdout, "Response from `StoragepoolApi.ListStoragepoolv9StoragepoolNodepools`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListStoragepoolv9StoragepoolNodepoolsRequest struct via the builder pattern


### Return type

[**V9StoragepoolNodepools**](V9StoragepoolNodepools.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateStoragepoolv1StoragepoolNodepool

> UpdateStoragepoolv1StoragepoolNodepool(ctx, v1StoragepoolNodepoolId).V1StoragepoolNodepool(v1StoragepoolNodepool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1StoragepoolNodepoolId := "v1StoragepoolNodepoolId_example" // string | Modify node pool. All input fields are optional, but one or more must be supplied.
    v1StoragepoolNodepool := *openapiclient.NewV1StoragepoolNodepoolExtendedExtended() // V1StoragepoolNodepoolExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.UpdateStoragepoolv1StoragepoolNodepool(context.Background(), v1StoragepoolNodepoolId).V1StoragepoolNodepool(v1StoragepoolNodepool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.UpdateStoragepoolv1StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1StoragepoolNodepoolId** | **string** | Modify node pool. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateStoragepoolv1StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1StoragepoolNodepool** | [**V1StoragepoolNodepoolExtendedExtended**](V1StoragepoolNodepoolExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateStoragepoolv1StoragepoolSettings

> UpdateStoragepoolv1StoragepoolSettings(ctx).V1StoragepoolSettings(v1StoragepoolSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1StoragepoolSettings := *openapiclient.NewV1StoragepoolSettingsExtended() // V1StoragepoolSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.UpdateStoragepoolv1StoragepoolSettings(context.Background()).V1StoragepoolSettings(v1StoragepoolSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.UpdateStoragepoolv1StoragepoolSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateStoragepoolv1StoragepoolSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1StoragepoolSettings** | [**V1StoragepoolSettingsExtended**](V1StoragepoolSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateStoragepoolv1StoragepoolTier

> UpdateStoragepoolv1StoragepoolTier(ctx, v1StoragepoolTierId).V1StoragepoolTier(v1StoragepoolTier).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1StoragepoolTierId := "v1StoragepoolTierId_example" // string | Modify tier. All input fields are optional, but one or more must be supplied.
    v1StoragepoolTier := *openapiclient.NewV1StoragepoolTierExtendedExtended() // V1StoragepoolTierExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.UpdateStoragepoolv1StoragepoolTier(context.Background(), v1StoragepoolTierId).V1StoragepoolTier(v1StoragepoolTier).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.UpdateStoragepoolv1StoragepoolTier``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1StoragepoolTierId** | **string** | Modify tier. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateStoragepoolv1StoragepoolTierRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1StoragepoolTier** | [**V1StoragepoolTierExtendedExtended**](V1StoragepoolTierExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateStoragepoolv3StoragepoolNodepool

> UpdateStoragepoolv3StoragepoolNodepool(ctx, v3StoragepoolNodepoolId).V3StoragepoolNodepool(v3StoragepoolNodepool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3StoragepoolNodepoolId := "v3StoragepoolNodepoolId_example" // string | Modify node pool. All input fields are optional, but one or more must be supplied.
    v3StoragepoolNodepool := *openapiclient.NewV1StoragepoolNodepoolExtendedExtended() // V1StoragepoolNodepoolExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.UpdateStoragepoolv3StoragepoolNodepool(context.Background(), v3StoragepoolNodepoolId).V3StoragepoolNodepool(v3StoragepoolNodepool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.UpdateStoragepoolv3StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3StoragepoolNodepoolId** | **string** | Modify node pool. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateStoragepoolv3StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3StoragepoolNodepool** | [**V1StoragepoolNodepoolExtendedExtended**](V1StoragepoolNodepoolExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateStoragepoolv5StoragepoolSettings

> UpdateStoragepoolv5StoragepoolSettings(ctx).V5StoragepoolSettings(v5StoragepoolSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v5StoragepoolSettings := *openapiclient.NewV5StoragepoolSettingsExtended() // V5StoragepoolSettingsExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.UpdateStoragepoolv5StoragepoolSettings(context.Background()).V5StoragepoolSettings(v5StoragepoolSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.UpdateStoragepoolv5StoragepoolSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateStoragepoolv5StoragepoolSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v5StoragepoolSettings** | [**V5StoragepoolSettingsExtended**](V5StoragepoolSettingsExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateStoragepoolv9StoragepoolNodepool

> UpdateStoragepoolv9StoragepoolNodepool(ctx, v9StoragepoolNodepoolId).V9StoragepoolNodepool(v9StoragepoolNodepool).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9StoragepoolNodepoolId := "v9StoragepoolNodepoolId_example" // string | Modify node pool. All input fields are optional, but one or more must be supplied.
    v9StoragepoolNodepool := *openapiclient.NewV9StoragepoolNodepoolExtendedExtended() // V9StoragepoolNodepoolExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.StoragepoolApi.UpdateStoragepoolv9StoragepoolNodepool(context.Background(), v9StoragepoolNodepoolId).V9StoragepoolNodepool(v9StoragepoolNodepool).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `StoragepoolApi.UpdateStoragepoolv9StoragepoolNodepool``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9StoragepoolNodepoolId** | **string** | Modify node pool. All input fields are optional, but one or more must be supplied. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateStoragepoolv9StoragepoolNodepoolRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v9StoragepoolNodepool** | [**V9StoragepoolNodepoolExtendedExtended**](V9StoragepoolNodepoolExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

