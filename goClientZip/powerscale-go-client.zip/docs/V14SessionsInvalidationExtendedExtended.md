# V14SessionsInvalidationExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Expiration** | Pointer to **int32** | The time in seconds since the UNIX epoc when this invalidation expires. | [optional] 
**NotBefore** | Pointer to **int32** | The time in seconds since the UNIX epoch, before which sessions for a user are disallowed. | [optional] 

## Methods

### NewV14SessionsInvalidationExtendedExtended

`func NewV14SessionsInvalidationExtendedExtended() *V14SessionsInvalidationExtendedExtended`

NewV14SessionsInvalidationExtendedExtended instantiates a new V14SessionsInvalidationExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SessionsInvalidationExtendedExtendedWithDefaults

`func NewV14SessionsInvalidationExtendedExtendedWithDefaults() *V14SessionsInvalidationExtendedExtended`

NewV14SessionsInvalidationExtendedExtendedWithDefaults instantiates a new V14SessionsInvalidationExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetExpiration

`func (o *V14SessionsInvalidationExtendedExtended) GetExpiration() int32`

GetExpiration returns the Expiration field if non-nil, zero value otherwise.

### GetExpirationOk

`func (o *V14SessionsInvalidationExtendedExtended) GetExpirationOk() (*int32, bool)`

GetExpirationOk returns a tuple with the Expiration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpiration

`func (o *V14SessionsInvalidationExtendedExtended) SetExpiration(v int32)`

SetExpiration sets Expiration field to given value.

### HasExpiration

`func (o *V14SessionsInvalidationExtendedExtended) HasExpiration() bool`

HasExpiration returns a boolean if a field has been set.

### GetNotBefore

`func (o *V14SessionsInvalidationExtendedExtended) GetNotBefore() int32`

GetNotBefore returns the NotBefore field if non-nil, zero value otherwise.

### GetNotBeforeOk

`func (o *V14SessionsInvalidationExtendedExtended) GetNotBeforeOk() (*int32, bool)`

GetNotBeforeOk returns a tuple with the NotBefore field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNotBefore

`func (o *V14SessionsInvalidationExtendedExtended) SetNotBefore(v int32)`

SetNotBefore sets NotBefore field to given value.

### HasNotBefore

`func (o *V14SessionsInvalidationExtendedExtended) HasNotBefore() bool`

HasNotBefore returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


