# V12NodeStatusNvramNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Batteries** | Pointer to [**[]V10ClusterNodeStatusNvramBattery**](V10ClusterNodeStatusNvramBattery.md) | This node&#39;s NVRAM battery status information. | [optional] 
**BatteryCount** | Pointer to **int32** | This node&#39;s NVRAM battery count. On failure: -1, otherwise 1 or 2. | [optional] 
**ChargeStatus** | Pointer to **string** | This node&#39;s NVRAM battery charge status, as a color. | [optional] 
**ChargeStatusNumber** | Pointer to **int32** | This node&#39;s NVRAM battery charge status, as a number. Error or not supported: -1. BR_BLACK: 0. BR_GREEN: 1. BR_YELLOW: 2. BR_RED: 3. | [optional] 
**Error** | Pointer to **string** | Error message, if the HTTP status returned from this node was not 200. | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Present** | Pointer to **bool** | This node has NVRAM. | [optional] 
**PresentFlash** | Pointer to **bool** | This node has NVRAM with flash storage. | [optional] 
**PresentSize** | Pointer to **int32** | The size of the NVRAM, in bytes. | [optional] 
**PresentType** | Pointer to **string** | This node&#39;s NVRAM type. | [optional] 
**Status** | Pointer to **int32** | Status of the HTTP response from this node if not 200.  If 200, this field does not appear. | [optional] 
**Supported** | Pointer to **bool** | This node supports NVRAM. | [optional] 
**SupportedFlash** | Pointer to **bool** | This node supports NVRAM with flash storage. | [optional] 
**SupportedSize** | Pointer to **int32** | The maximum size of the NVRAM, in bytes. | [optional] 
**SupportedType** | Pointer to **string** | This node&#39;s supported NVRAM type. | [optional] 

## Methods

### NewV12NodeStatusNvramNode

`func NewV12NodeStatusNvramNode() *V12NodeStatusNvramNode`

NewV12NodeStatusNvramNode instantiates a new V12NodeStatusNvramNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NodeStatusNvramNodeWithDefaults

`func NewV12NodeStatusNvramNodeWithDefaults() *V12NodeStatusNvramNode`

NewV12NodeStatusNvramNodeWithDefaults instantiates a new V12NodeStatusNvramNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBatteries

`func (o *V12NodeStatusNvramNode) GetBatteries() []V10ClusterNodeStatusNvramBattery`

GetBatteries returns the Batteries field if non-nil, zero value otherwise.

### GetBatteriesOk

`func (o *V12NodeStatusNvramNode) GetBatteriesOk() (*[]V10ClusterNodeStatusNvramBattery, bool)`

GetBatteriesOk returns a tuple with the Batteries field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBatteries

`func (o *V12NodeStatusNvramNode) SetBatteries(v []V10ClusterNodeStatusNvramBattery)`

SetBatteries sets Batteries field to given value.

### HasBatteries

`func (o *V12NodeStatusNvramNode) HasBatteries() bool`

HasBatteries returns a boolean if a field has been set.

### GetBatteryCount

`func (o *V12NodeStatusNvramNode) GetBatteryCount() int32`

GetBatteryCount returns the BatteryCount field if non-nil, zero value otherwise.

### GetBatteryCountOk

`func (o *V12NodeStatusNvramNode) GetBatteryCountOk() (*int32, bool)`

GetBatteryCountOk returns a tuple with the BatteryCount field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBatteryCount

`func (o *V12NodeStatusNvramNode) SetBatteryCount(v int32)`

SetBatteryCount sets BatteryCount field to given value.

### HasBatteryCount

`func (o *V12NodeStatusNvramNode) HasBatteryCount() bool`

HasBatteryCount returns a boolean if a field has been set.

### GetChargeStatus

`func (o *V12NodeStatusNvramNode) GetChargeStatus() string`

GetChargeStatus returns the ChargeStatus field if non-nil, zero value otherwise.

### GetChargeStatusOk

`func (o *V12NodeStatusNvramNode) GetChargeStatusOk() (*string, bool)`

GetChargeStatusOk returns a tuple with the ChargeStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChargeStatus

`func (o *V12NodeStatusNvramNode) SetChargeStatus(v string)`

SetChargeStatus sets ChargeStatus field to given value.

### HasChargeStatus

`func (o *V12NodeStatusNvramNode) HasChargeStatus() bool`

HasChargeStatus returns a boolean if a field has been set.

### GetChargeStatusNumber

`func (o *V12NodeStatusNvramNode) GetChargeStatusNumber() int32`

GetChargeStatusNumber returns the ChargeStatusNumber field if non-nil, zero value otherwise.

### GetChargeStatusNumberOk

`func (o *V12NodeStatusNvramNode) GetChargeStatusNumberOk() (*int32, bool)`

GetChargeStatusNumberOk returns a tuple with the ChargeStatusNumber field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChargeStatusNumber

`func (o *V12NodeStatusNvramNode) SetChargeStatusNumber(v int32)`

SetChargeStatusNumber sets ChargeStatusNumber field to given value.

### HasChargeStatusNumber

`func (o *V12NodeStatusNvramNode) HasChargeStatusNumber() bool`

HasChargeStatusNumber returns a boolean if a field has been set.

### GetError

`func (o *V12NodeStatusNvramNode) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V12NodeStatusNvramNode) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V12NodeStatusNvramNode) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V12NodeStatusNvramNode) HasError() bool`

HasError returns a boolean if a field has been set.

### GetId

`func (o *V12NodeStatusNvramNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12NodeStatusNvramNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12NodeStatusNvramNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V12NodeStatusNvramNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V12NodeStatusNvramNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12NodeStatusNvramNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12NodeStatusNvramNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V12NodeStatusNvramNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetPresent

`func (o *V12NodeStatusNvramNode) GetPresent() bool`

GetPresent returns the Present field if non-nil, zero value otherwise.

### GetPresentOk

`func (o *V12NodeStatusNvramNode) GetPresentOk() (*bool, bool)`

GetPresentOk returns a tuple with the Present field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresent

`func (o *V12NodeStatusNvramNode) SetPresent(v bool)`

SetPresent sets Present field to given value.

### HasPresent

`func (o *V12NodeStatusNvramNode) HasPresent() bool`

HasPresent returns a boolean if a field has been set.

### GetPresentFlash

`func (o *V12NodeStatusNvramNode) GetPresentFlash() bool`

GetPresentFlash returns the PresentFlash field if non-nil, zero value otherwise.

### GetPresentFlashOk

`func (o *V12NodeStatusNvramNode) GetPresentFlashOk() (*bool, bool)`

GetPresentFlashOk returns a tuple with the PresentFlash field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresentFlash

`func (o *V12NodeStatusNvramNode) SetPresentFlash(v bool)`

SetPresentFlash sets PresentFlash field to given value.

### HasPresentFlash

`func (o *V12NodeStatusNvramNode) HasPresentFlash() bool`

HasPresentFlash returns a boolean if a field has been set.

### GetPresentSize

`func (o *V12NodeStatusNvramNode) GetPresentSize() int32`

GetPresentSize returns the PresentSize field if non-nil, zero value otherwise.

### GetPresentSizeOk

`func (o *V12NodeStatusNvramNode) GetPresentSizeOk() (*int32, bool)`

GetPresentSizeOk returns a tuple with the PresentSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresentSize

`func (o *V12NodeStatusNvramNode) SetPresentSize(v int32)`

SetPresentSize sets PresentSize field to given value.

### HasPresentSize

`func (o *V12NodeStatusNvramNode) HasPresentSize() bool`

HasPresentSize returns a boolean if a field has been set.

### GetPresentType

`func (o *V12NodeStatusNvramNode) GetPresentType() string`

GetPresentType returns the PresentType field if non-nil, zero value otherwise.

### GetPresentTypeOk

`func (o *V12NodeStatusNvramNode) GetPresentTypeOk() (*string, bool)`

GetPresentTypeOk returns a tuple with the PresentType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPresentType

`func (o *V12NodeStatusNvramNode) SetPresentType(v string)`

SetPresentType sets PresentType field to given value.

### HasPresentType

`func (o *V12NodeStatusNvramNode) HasPresentType() bool`

HasPresentType returns a boolean if a field has been set.

### GetStatus

`func (o *V12NodeStatusNvramNode) GetStatus() int32`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12NodeStatusNvramNode) GetStatusOk() (*int32, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12NodeStatusNvramNode) SetStatus(v int32)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V12NodeStatusNvramNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.

### GetSupported

`func (o *V12NodeStatusNvramNode) GetSupported() bool`

GetSupported returns the Supported field if non-nil, zero value otherwise.

### GetSupportedOk

`func (o *V12NodeStatusNvramNode) GetSupportedOk() (*bool, bool)`

GetSupportedOk returns a tuple with the Supported field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupported

`func (o *V12NodeStatusNvramNode) SetSupported(v bool)`

SetSupported sets Supported field to given value.

### HasSupported

`func (o *V12NodeStatusNvramNode) HasSupported() bool`

HasSupported returns a boolean if a field has been set.

### GetSupportedFlash

`func (o *V12NodeStatusNvramNode) GetSupportedFlash() bool`

GetSupportedFlash returns the SupportedFlash field if non-nil, zero value otherwise.

### GetSupportedFlashOk

`func (o *V12NodeStatusNvramNode) GetSupportedFlashOk() (*bool, bool)`

GetSupportedFlashOk returns a tuple with the SupportedFlash field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupportedFlash

`func (o *V12NodeStatusNvramNode) SetSupportedFlash(v bool)`

SetSupportedFlash sets SupportedFlash field to given value.

### HasSupportedFlash

`func (o *V12NodeStatusNvramNode) HasSupportedFlash() bool`

HasSupportedFlash returns a boolean if a field has been set.

### GetSupportedSize

`func (o *V12NodeStatusNvramNode) GetSupportedSize() int32`

GetSupportedSize returns the SupportedSize field if non-nil, zero value otherwise.

### GetSupportedSizeOk

`func (o *V12NodeStatusNvramNode) GetSupportedSizeOk() (*int32, bool)`

GetSupportedSizeOk returns a tuple with the SupportedSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupportedSize

`func (o *V12NodeStatusNvramNode) SetSupportedSize(v int32)`

SetSupportedSize sets SupportedSize field to given value.

### HasSupportedSize

`func (o *V12NodeStatusNvramNode) HasSupportedSize() bool`

HasSupportedSize returns a boolean if a field has been set.

### GetSupportedType

`func (o *V12NodeStatusNvramNode) GetSupportedType() string`

GetSupportedType returns the SupportedType field if non-nil, zero value otherwise.

### GetSupportedTypeOk

`func (o *V12NodeStatusNvramNode) GetSupportedTypeOk() (*string, bool)`

GetSupportedTypeOk returns a tuple with the SupportedType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSupportedType

`func (o *V12NodeStatusNvramNode) SetSupportedType(v string)`

SetSupportedType sets SupportedType field to given value.

### HasSupportedType

`func (o *V12NodeStatusNvramNode) HasSupportedType() bool`

HasSupportedType returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


