# V14InternalNetworksSettingsNetwork

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BackendConfig** | [**V14InternalNetworksSettingsNetworkBackendConfig**](V14InternalNetworksSettingsNetworkBackendConfig.md) |  | 
**Name** | **string** | Name of the backend network. | 

## Methods

### NewV14InternalNetworksSettingsNetwork

`func NewV14InternalNetworksSettingsNetwork(backendConfig V14InternalNetworksSettingsNetworkBackendConfig, name string, ) *V14InternalNetworksSettingsNetwork`

NewV14InternalNetworksSettingsNetwork instantiates a new V14InternalNetworksSettingsNetwork object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14InternalNetworksSettingsNetworkWithDefaults

`func NewV14InternalNetworksSettingsNetworkWithDefaults() *V14InternalNetworksSettingsNetwork`

NewV14InternalNetworksSettingsNetworkWithDefaults instantiates a new V14InternalNetworksSettingsNetwork object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBackendConfig

`func (o *V14InternalNetworksSettingsNetwork) GetBackendConfig() V14InternalNetworksSettingsNetworkBackendConfig`

GetBackendConfig returns the BackendConfig field if non-nil, zero value otherwise.

### GetBackendConfigOk

`func (o *V14InternalNetworksSettingsNetwork) GetBackendConfigOk() (*V14InternalNetworksSettingsNetworkBackendConfig, bool)`

GetBackendConfigOk returns a tuple with the BackendConfig field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBackendConfig

`func (o *V14InternalNetworksSettingsNetwork) SetBackendConfig(v V14InternalNetworksSettingsNetworkBackendConfig)`

SetBackendConfig sets BackendConfig field to given value.


### GetName

`func (o *V14InternalNetworksSettingsNetwork) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V14InternalNetworksSettingsNetwork) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V14InternalNetworksSettingsNetwork) SetName(v string)`

SetName sets Name field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


