# V10JobJobChangelistcreateParams

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreateDiffs** | Pointer to **bool** | Whether to store snapshot differential region information for files with data changes. | [optional] 
**NewerSnapid** | **int32** | Newer snapshot ID. | 
**OlderSnapid** | **int32** | Older snapshot ID. | 
**RetainRepstate** | Pointer to **bool** | Whether to retain the replication record after a changelist is created. Retaining a replication record allows a changelist to be recreated later. | [optional] 

## Methods

### NewV10JobJobChangelistcreateParams

`func NewV10JobJobChangelistcreateParams(newerSnapid int32, olderSnapid int32, ) *V10JobJobChangelistcreateParams`

NewV10JobJobChangelistcreateParams instantiates a new V10JobJobChangelistcreateParams object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10JobJobChangelistcreateParamsWithDefaults

`func NewV10JobJobChangelistcreateParamsWithDefaults() *V10JobJobChangelistcreateParams`

NewV10JobJobChangelistcreateParamsWithDefaults instantiates a new V10JobJobChangelistcreateParams object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCreateDiffs

`func (o *V10JobJobChangelistcreateParams) GetCreateDiffs() bool`

GetCreateDiffs returns the CreateDiffs field if non-nil, zero value otherwise.

### GetCreateDiffsOk

`func (o *V10JobJobChangelistcreateParams) GetCreateDiffsOk() (*bool, bool)`

GetCreateDiffsOk returns a tuple with the CreateDiffs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreateDiffs

`func (o *V10JobJobChangelistcreateParams) SetCreateDiffs(v bool)`

SetCreateDiffs sets CreateDiffs field to given value.

### HasCreateDiffs

`func (o *V10JobJobChangelistcreateParams) HasCreateDiffs() bool`

HasCreateDiffs returns a boolean if a field has been set.

### GetNewerSnapid

`func (o *V10JobJobChangelistcreateParams) GetNewerSnapid() int32`

GetNewerSnapid returns the NewerSnapid field if non-nil, zero value otherwise.

### GetNewerSnapidOk

`func (o *V10JobJobChangelistcreateParams) GetNewerSnapidOk() (*int32, bool)`

GetNewerSnapidOk returns a tuple with the NewerSnapid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNewerSnapid

`func (o *V10JobJobChangelistcreateParams) SetNewerSnapid(v int32)`

SetNewerSnapid sets NewerSnapid field to given value.


### GetOlderSnapid

`func (o *V10JobJobChangelistcreateParams) GetOlderSnapid() int32`

GetOlderSnapid returns the OlderSnapid field if non-nil, zero value otherwise.

### GetOlderSnapidOk

`func (o *V10JobJobChangelistcreateParams) GetOlderSnapidOk() (*int32, bool)`

GetOlderSnapidOk returns a tuple with the OlderSnapid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOlderSnapid

`func (o *V10JobJobChangelistcreateParams) SetOlderSnapid(v int32)`

SetOlderSnapid sets OlderSnapid field to given value.


### GetRetainRepstate

`func (o *V10JobJobChangelistcreateParams) GetRetainRepstate() bool`

GetRetainRepstate returns the RetainRepstate field if non-nil, zero value otherwise.

### GetRetainRepstateOk

`func (o *V10JobJobChangelistcreateParams) GetRetainRepstateOk() (*bool, bool)`

GetRetainRepstateOk returns a tuple with the RetainRepstate field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRetainRepstate

`func (o *V10JobJobChangelistcreateParams) SetRetainRepstate(v bool)`

SetRetainRepstate sets RetainRepstate field to given value.

### HasRetainRepstate

`func (o *V10JobJobChangelistcreateParams) HasRetainRepstate() bool`

HasRetainRepstate returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


