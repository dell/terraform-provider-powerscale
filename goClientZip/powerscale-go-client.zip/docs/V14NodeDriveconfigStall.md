# V14NodeDriveconfigStall

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaxTotalStallTimeWithoutError** | Pointer to **int32** | Max amount of time to spend in stalled before softfailing the drive even without new errors. | [optional] 

## Methods

### NewV14NodeDriveconfigStall

`func NewV14NodeDriveconfigStall() *V14NodeDriveconfigStall`

NewV14NodeDriveconfigStall instantiates a new V14NodeDriveconfigStall object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14NodeDriveconfigStallWithDefaults

`func NewV14NodeDriveconfigStallWithDefaults() *V14NodeDriveconfigStall`

NewV14NodeDriveconfigStallWithDefaults instantiates a new V14NodeDriveconfigStall object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMaxTotalStallTimeWithoutError

`func (o *V14NodeDriveconfigStall) GetMaxTotalStallTimeWithoutError() int32`

GetMaxTotalStallTimeWithoutError returns the MaxTotalStallTimeWithoutError field if non-nil, zero value otherwise.

### GetMaxTotalStallTimeWithoutErrorOk

`func (o *V14NodeDriveconfigStall) GetMaxTotalStallTimeWithoutErrorOk() (*int32, bool)`

GetMaxTotalStallTimeWithoutErrorOk returns a tuple with the MaxTotalStallTimeWithoutError field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxTotalStallTimeWithoutError

`func (o *V14NodeDriveconfigStall) SetMaxTotalStallTimeWithoutError(v int32)`

SetMaxTotalStallTimeWithoutError sets MaxTotalStallTimeWithoutError field to given value.

### HasMaxTotalStallTimeWithoutError

`func (o *V14NodeDriveconfigStall) HasMaxTotalStallTimeWithoutError() bool`

HasMaxTotalStallTimeWithoutError returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


