# V12NetworkExternalExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Ipv6AutoConfigEnabled** | Pointer to **bool** | True if rtsold daemon is enabled.  When set to false, the rtsold service is disabled, and IPv6 auto configuration is disabled | [optional] 
**Sbr** | Pointer to **bool** | Enable or disable Source Based Routing (Defaults to false) | [optional] 
**ScRebalanceDelay** | Pointer to **int32** | Delay in seconds for IP rebalance. | [optional] 
**TcpPorts** | Pointer to **[]int32** | List of client TCP ports. | [optional] 

## Methods

### NewV12NetworkExternalExtended

`func NewV12NetworkExternalExtended() *V12NetworkExternalExtended`

NewV12NetworkExternalExtended instantiates a new V12NetworkExternalExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NetworkExternalExtendedWithDefaults

`func NewV12NetworkExternalExtendedWithDefaults() *V12NetworkExternalExtended`

NewV12NetworkExternalExtendedWithDefaults instantiates a new V12NetworkExternalExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetIpv6AutoConfigEnabled

`func (o *V12NetworkExternalExtended) GetIpv6AutoConfigEnabled() bool`

GetIpv6AutoConfigEnabled returns the Ipv6AutoConfigEnabled field if non-nil, zero value otherwise.

### GetIpv6AutoConfigEnabledOk

`func (o *V12NetworkExternalExtended) GetIpv6AutoConfigEnabledOk() (*bool, bool)`

GetIpv6AutoConfigEnabledOk returns a tuple with the Ipv6AutoConfigEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpv6AutoConfigEnabled

`func (o *V12NetworkExternalExtended) SetIpv6AutoConfigEnabled(v bool)`

SetIpv6AutoConfigEnabled sets Ipv6AutoConfigEnabled field to given value.

### HasIpv6AutoConfigEnabled

`func (o *V12NetworkExternalExtended) HasIpv6AutoConfigEnabled() bool`

HasIpv6AutoConfigEnabled returns a boolean if a field has been set.

### GetSbr

`func (o *V12NetworkExternalExtended) GetSbr() bool`

GetSbr returns the Sbr field if non-nil, zero value otherwise.

### GetSbrOk

`func (o *V12NetworkExternalExtended) GetSbrOk() (*bool, bool)`

GetSbrOk returns a tuple with the Sbr field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSbr

`func (o *V12NetworkExternalExtended) SetSbr(v bool)`

SetSbr sets Sbr field to given value.

### HasSbr

`func (o *V12NetworkExternalExtended) HasSbr() bool`

HasSbr returns a boolean if a field has been set.

### GetScRebalanceDelay

`func (o *V12NetworkExternalExtended) GetScRebalanceDelay() int32`

GetScRebalanceDelay returns the ScRebalanceDelay field if non-nil, zero value otherwise.

### GetScRebalanceDelayOk

`func (o *V12NetworkExternalExtended) GetScRebalanceDelayOk() (*int32, bool)`

GetScRebalanceDelayOk returns a tuple with the ScRebalanceDelay field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScRebalanceDelay

`func (o *V12NetworkExternalExtended) SetScRebalanceDelay(v int32)`

SetScRebalanceDelay sets ScRebalanceDelay field to given value.

### HasScRebalanceDelay

`func (o *V12NetworkExternalExtended) HasScRebalanceDelay() bool`

HasScRebalanceDelay returns a boolean if a field has been set.

### GetTcpPorts

`func (o *V12NetworkExternalExtended) GetTcpPorts() []int32`

GetTcpPorts returns the TcpPorts field if non-nil, zero value otherwise.

### GetTcpPortsOk

`func (o *V12NetworkExternalExtended) GetTcpPortsOk() (*[]int32, bool)`

GetTcpPortsOk returns a tuple with the TcpPorts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTcpPorts

`func (o *V12NetworkExternalExtended) SetTcpPorts(v []int32)`

SetTcpPorts sets TcpPorts field to given value.

### HasTcpPorts

`func (o *V12NetworkExternalExtended) HasTcpPorts() bool`

HasTcpPorts returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


