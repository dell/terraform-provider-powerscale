# V14NodeDriveconfigNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alert** | Pointer to [**V10ClusterNodeDriveDConfigAlert**](V10ClusterNodeDriveDConfigAlert.md) |  | [optional] 
**Allow** | Pointer to [**V10ClusterNodeDriveDConfigAllow**](V10ClusterNodeDriveDConfigAllow.md) |  | [optional] 
**AutomaticReplacementRecognition** | Pointer to [**V10ClusterNodeDriveDConfigAutomaticReplacementRecognition**](V10ClusterNodeDriveDConfigAutomaticReplacementRecognition.md) |  | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**InstantSecureErase** | Pointer to [**V10ClusterNodeDriveDConfigInstantSecureErase**](V10ClusterNodeDriveDConfigInstantSecureErase.md) |  | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Log** | Pointer to [**V10ClusterNodeDriveDConfigLog**](V10ClusterNodeDriveDConfigLog.md) |  | [optional] 
**Reboot** | Pointer to [**V10ClusterNodeDriveDConfigReboot**](V10ClusterNodeDriveDConfigReboot.md) |  | [optional] 
**SpinWait** | Pointer to [**V10ClusterNodeDriveDConfigSpinWait**](V10ClusterNodeDriveDConfigSpinWait.md) |  | [optional] 
**Stall** | Pointer to [**V14ClusterNodeDriveDConfigStall**](V14ClusterNodeDriveDConfigStall.md) |  | [optional] 

## Methods

### NewV14NodeDriveconfigNode

`func NewV14NodeDriveconfigNode() *V14NodeDriveconfigNode`

NewV14NodeDriveconfigNode instantiates a new V14NodeDriveconfigNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14NodeDriveconfigNodeWithDefaults

`func NewV14NodeDriveconfigNodeWithDefaults() *V14NodeDriveconfigNode`

NewV14NodeDriveconfigNodeWithDefaults instantiates a new V14NodeDriveconfigNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlert

`func (o *V14NodeDriveconfigNode) GetAlert() V10ClusterNodeDriveDConfigAlert`

GetAlert returns the Alert field if non-nil, zero value otherwise.

### GetAlertOk

`func (o *V14NodeDriveconfigNode) GetAlertOk() (*V10ClusterNodeDriveDConfigAlert, bool)`

GetAlertOk returns a tuple with the Alert field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlert

`func (o *V14NodeDriveconfigNode) SetAlert(v V10ClusterNodeDriveDConfigAlert)`

SetAlert sets Alert field to given value.

### HasAlert

`func (o *V14NodeDriveconfigNode) HasAlert() bool`

HasAlert returns a boolean if a field has been set.

### GetAllow

`func (o *V14NodeDriveconfigNode) GetAllow() V10ClusterNodeDriveDConfigAllow`

GetAllow returns the Allow field if non-nil, zero value otherwise.

### GetAllowOk

`func (o *V14NodeDriveconfigNode) GetAllowOk() (*V10ClusterNodeDriveDConfigAllow, bool)`

GetAllowOk returns a tuple with the Allow field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAllow

`func (o *V14NodeDriveconfigNode) SetAllow(v V10ClusterNodeDriveDConfigAllow)`

SetAllow sets Allow field to given value.

### HasAllow

`func (o *V14NodeDriveconfigNode) HasAllow() bool`

HasAllow returns a boolean if a field has been set.

### GetAutomaticReplacementRecognition

`func (o *V14NodeDriveconfigNode) GetAutomaticReplacementRecognition() V10ClusterNodeDriveDConfigAutomaticReplacementRecognition`

GetAutomaticReplacementRecognition returns the AutomaticReplacementRecognition field if non-nil, zero value otherwise.

### GetAutomaticReplacementRecognitionOk

`func (o *V14NodeDriveconfigNode) GetAutomaticReplacementRecognitionOk() (*V10ClusterNodeDriveDConfigAutomaticReplacementRecognition, bool)`

GetAutomaticReplacementRecognitionOk returns a tuple with the AutomaticReplacementRecognition field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutomaticReplacementRecognition

`func (o *V14NodeDriveconfigNode) SetAutomaticReplacementRecognition(v V10ClusterNodeDriveDConfigAutomaticReplacementRecognition)`

SetAutomaticReplacementRecognition sets AutomaticReplacementRecognition field to given value.

### HasAutomaticReplacementRecognition

`func (o *V14NodeDriveconfigNode) HasAutomaticReplacementRecognition() bool`

HasAutomaticReplacementRecognition returns a boolean if a field has been set.

### GetId

`func (o *V14NodeDriveconfigNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V14NodeDriveconfigNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V14NodeDriveconfigNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V14NodeDriveconfigNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetInstantSecureErase

`func (o *V14NodeDriveconfigNode) GetInstantSecureErase() V10ClusterNodeDriveDConfigInstantSecureErase`

GetInstantSecureErase returns the InstantSecureErase field if non-nil, zero value otherwise.

### GetInstantSecureEraseOk

`func (o *V14NodeDriveconfigNode) GetInstantSecureEraseOk() (*V10ClusterNodeDriveDConfigInstantSecureErase, bool)`

GetInstantSecureEraseOk returns a tuple with the InstantSecureErase field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstantSecureErase

`func (o *V14NodeDriveconfigNode) SetInstantSecureErase(v V10ClusterNodeDriveDConfigInstantSecureErase)`

SetInstantSecureErase sets InstantSecureErase field to given value.

### HasInstantSecureErase

`func (o *V14NodeDriveconfigNode) HasInstantSecureErase() bool`

HasInstantSecureErase returns a boolean if a field has been set.

### GetLnn

`func (o *V14NodeDriveconfigNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V14NodeDriveconfigNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V14NodeDriveconfigNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V14NodeDriveconfigNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetLog

`func (o *V14NodeDriveconfigNode) GetLog() V10ClusterNodeDriveDConfigLog`

GetLog returns the Log field if non-nil, zero value otherwise.

### GetLogOk

`func (o *V14NodeDriveconfigNode) GetLogOk() (*V10ClusterNodeDriveDConfigLog, bool)`

GetLogOk returns a tuple with the Log field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLog

`func (o *V14NodeDriveconfigNode) SetLog(v V10ClusterNodeDriveDConfigLog)`

SetLog sets Log field to given value.

### HasLog

`func (o *V14NodeDriveconfigNode) HasLog() bool`

HasLog returns a boolean if a field has been set.

### GetReboot

`func (o *V14NodeDriveconfigNode) GetReboot() V10ClusterNodeDriveDConfigReboot`

GetReboot returns the Reboot field if non-nil, zero value otherwise.

### GetRebootOk

`func (o *V14NodeDriveconfigNode) GetRebootOk() (*V10ClusterNodeDriveDConfigReboot, bool)`

GetRebootOk returns a tuple with the Reboot field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReboot

`func (o *V14NodeDriveconfigNode) SetReboot(v V10ClusterNodeDriveDConfigReboot)`

SetReboot sets Reboot field to given value.

### HasReboot

`func (o *V14NodeDriveconfigNode) HasReboot() bool`

HasReboot returns a boolean if a field has been set.

### GetSpinWait

`func (o *V14NodeDriveconfigNode) GetSpinWait() V10ClusterNodeDriveDConfigSpinWait`

GetSpinWait returns the SpinWait field if non-nil, zero value otherwise.

### GetSpinWaitOk

`func (o *V14NodeDriveconfigNode) GetSpinWaitOk() (*V10ClusterNodeDriveDConfigSpinWait, bool)`

GetSpinWaitOk returns a tuple with the SpinWait field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpinWait

`func (o *V14NodeDriveconfigNode) SetSpinWait(v V10ClusterNodeDriveDConfigSpinWait)`

SetSpinWait sets SpinWait field to given value.

### HasSpinWait

`func (o *V14NodeDriveconfigNode) HasSpinWait() bool`

HasSpinWait returns a boolean if a field has been set.

### GetStall

`func (o *V14NodeDriveconfigNode) GetStall() V14ClusterNodeDriveDConfigStall`

GetStall returns the Stall field if non-nil, zero value otherwise.

### GetStallOk

`func (o *V14NodeDriveconfigNode) GetStallOk() (*V14ClusterNodeDriveDConfigStall, bool)`

GetStallOk returns a tuple with the Stall field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStall

`func (o *V14NodeDriveconfigNode) SetStall(v V14ClusterNodeDriveDConfigStall)`

SetStall sets Stall field to given value.

### HasStall

`func (o *V14NodeDriveconfigNode) HasStall() bool`

HasStall returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


