# \AuditApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateAuditv1AuditTopic**](AuditApi.md#CreateAuditv1AuditTopic) | **Post** /platform/1/audit/topics | 
[**DeleteAuditv11AuditLogs**](AuditApi.md#DeleteAuditv11AuditLogs) | **Delete** /platform/11/audit/logs | 
[**DeleteAuditv1AuditTopic**](AuditApi.md#DeleteAuditv1AuditTopic) | **Delete** /platform/1/audit/topics/{v1AuditTopicId} | 
[**GetAuditv11AuditLogs**](AuditApi.md#GetAuditv11AuditLogs) | **Get** /platform/11/audit/logs | 
[**GetAuditv11SettingsGlobal**](AuditApi.md#GetAuditv11SettingsGlobal) | **Get** /platform/11/audit/settings/global | 
[**GetAuditv1AuditSettings**](AuditApi.md#GetAuditv1AuditSettings) | **Get** /platform/1/audit/settings | 
[**GetAuditv1AuditTopic**](AuditApi.md#GetAuditv1AuditTopic) | **Get** /platform/1/audit/topics/{v1AuditTopicId} | 
[**GetAuditv3AuditSettings**](AuditApi.md#GetAuditv3AuditSettings) | **Get** /platform/3/audit/settings | 
[**GetAuditv3SettingsGlobal**](AuditApi.md#GetAuditv3SettingsGlobal) | **Get** /platform/3/audit/settings/global | 
[**GetAuditv4AuditProgress**](AuditApi.md#GetAuditv4AuditProgress) | **Get** /platform/4/audit/progress | 
[**GetAuditv4ProgressGlobal**](AuditApi.md#GetAuditv4ProgressGlobal) | **Get** /platform/4/audit/progress/global | 
[**GetAuditv7AuditSettings**](AuditApi.md#GetAuditv7AuditSettings) | **Get** /platform/7/audit/settings | 
[**GetAuditv7SettingsGlobal**](AuditApi.md#GetAuditv7SettingsGlobal) | **Get** /platform/7/audit/settings/global | 
[**ListAuditv1AuditTopics**](AuditApi.md#ListAuditv1AuditTopics) | **Get** /platform/1/audit/topics | 
[**UpdateAuditv11SettingsGlobal**](AuditApi.md#UpdateAuditv11SettingsGlobal) | **Put** /platform/11/audit/settings/global | 
[**UpdateAuditv1AuditSettings**](AuditApi.md#UpdateAuditv1AuditSettings) | **Put** /platform/1/audit/settings | 
[**UpdateAuditv1AuditTopic**](AuditApi.md#UpdateAuditv1AuditTopic) | **Put** /platform/1/audit/topics/{v1AuditTopicId} | 
[**UpdateAuditv3AuditSettings**](AuditApi.md#UpdateAuditv3AuditSettings) | **Put** /platform/3/audit/settings | 
[**UpdateAuditv3SettingsGlobal**](AuditApi.md#UpdateAuditv3SettingsGlobal) | **Put** /platform/3/audit/settings/global | 
[**UpdateAuditv7AuditSettings**](AuditApi.md#UpdateAuditv7AuditSettings) | **Put** /platform/7/audit/settings | 
[**UpdateAuditv7SettingsGlobal**](AuditApi.md#UpdateAuditv7SettingsGlobal) | **Put** /platform/7/audit/settings/global | 



## CreateAuditv1AuditTopic

> CreateResponse CreateAuditv1AuditTopic(ctx).V1AuditTopic(v1AuditTopic).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuditTopic := *openapiclient.NewV1AuditTopic("Name_example") // V1AuditTopic | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.CreateAuditv1AuditTopic(context.Background()).V1AuditTopic(v1AuditTopic).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.CreateAuditv1AuditTopic``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateAuditv1AuditTopic`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.CreateAuditv1AuditTopic`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiCreateAuditv1AuditTopicRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1AuditTopic** | [**V1AuditTopic**](V1AuditTopic.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuditv11AuditLogs

> DeleteAuditv11AuditLogs(ctx).Before(before).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    before := int32(56) // int32 | The timestamp before which logs will be deleted.
    force := true // bool | Do not ask for confirmation. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuditApi.DeleteAuditv11AuditLogs(context.Background()).Before(before).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.DeleteAuditv11AuditLogs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuditv11AuditLogsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **before** | **int32** | The timestamp before which logs will be deleted. | 
 **force** | **bool** | Do not ask for confirmation. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteAuditv1AuditTopic

> DeleteAuditv1AuditTopic(ctx, v1AuditTopicId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuditTopicId := "v1AuditTopicId_example" // string | Delete the audit topic.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuditApi.DeleteAuditv1AuditTopic(context.Background(), v1AuditTopicId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.DeleteAuditv1AuditTopic``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuditTopicId** | **string** | Delete the audit topic. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteAuditv1AuditTopicRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuditv11AuditLogs

> V11AuditLogs GetAuditv11AuditLogs(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.GetAuditv11AuditLogs(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.GetAuditv11AuditLogs``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuditv11AuditLogs`: V11AuditLogs
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.GetAuditv11AuditLogs`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuditv11AuditLogsRequest struct via the builder pattern


### Return type

[**V11AuditLogs**](V11AuditLogs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuditv11SettingsGlobal

> V11SettingsGlobal GetAuditv11SettingsGlobal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.GetAuditv11SettingsGlobal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.GetAuditv11SettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuditv11SettingsGlobal`: V11SettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.GetAuditv11SettingsGlobal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuditv11SettingsGlobalRequest struct via the builder pattern


### Return type

[**V11SettingsGlobal**](V11SettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuditv1AuditSettings

> V1AuditSettings GetAuditv1AuditSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.GetAuditv1AuditSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.GetAuditv1AuditSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuditv1AuditSettings`: V1AuditSettings
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.GetAuditv1AuditSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuditv1AuditSettingsRequest struct via the builder pattern


### Return type

[**V1AuditSettings**](V1AuditSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuditv1AuditTopic

> V1AuditTopics GetAuditv1AuditTopic(ctx, v1AuditTopicId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuditTopicId := "v1AuditTopicId_example" // string | Retrieve the audit topic information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.GetAuditv1AuditTopic(context.Background(), v1AuditTopicId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.GetAuditv1AuditTopic``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuditv1AuditTopic`: V1AuditTopics
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.GetAuditv1AuditTopic`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuditTopicId** | **string** | Retrieve the audit topic information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuditv1AuditTopicRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1AuditTopics**](V1AuditTopics.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuditv3AuditSettings

> V3AuditSettings GetAuditv3AuditSettings(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains audit settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.GetAuditv3AuditSettings(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.GetAuditv3AuditSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuditv3AuditSettings`: V3AuditSettings
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.GetAuditv3AuditSettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuditv3AuditSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains audit settings. | 

### Return type

[**V3AuditSettings**](V3AuditSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuditv3SettingsGlobal

> V1AuditSettings GetAuditv3SettingsGlobal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.GetAuditv3SettingsGlobal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.GetAuditv3SettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuditv3SettingsGlobal`: V1AuditSettings
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.GetAuditv3SettingsGlobal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuditv3SettingsGlobalRequest struct via the builder pattern


### Return type

[**V1AuditSettings**](V1AuditSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuditv4AuditProgress

> V4AuditProgress GetAuditv4AuditProgress(ctx).Lnn(lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | lnn of the node. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.GetAuditv4AuditProgress(context.Background()).Lnn(lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.GetAuditv4AuditProgress``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuditv4AuditProgress`: V4AuditProgress
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.GetAuditv4AuditProgress`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuditv4AuditProgressRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **lnn** | **int32** | lnn of the node. | 

### Return type

[**V4AuditProgress**](V4AuditProgress.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuditv4ProgressGlobal

> V4ProgressGlobal GetAuditv4ProgressGlobal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.GetAuditv4ProgressGlobal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.GetAuditv4ProgressGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuditv4ProgressGlobal`: V4ProgressGlobal
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.GetAuditv4ProgressGlobal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuditv4ProgressGlobalRequest struct via the builder pattern


### Return type

[**V4ProgressGlobal**](V4ProgressGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuditv7AuditSettings

> V7AuditSettings GetAuditv7AuditSettings(ctx).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zone := "zone_example" // string | Access zone which contains audit settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.GetAuditv7AuditSettings(context.Background()).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.GetAuditv7AuditSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuditv7AuditSettings`: V7AuditSettings
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.GetAuditv7AuditSettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetAuditv7AuditSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **zone** | **string** | Access zone which contains audit settings. | 

### Return type

[**V7AuditSettings**](V7AuditSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetAuditv7SettingsGlobal

> V7SettingsGlobal GetAuditv7SettingsGlobal(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.GetAuditv7SettingsGlobal(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.GetAuditv7SettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetAuditv7SettingsGlobal`: V7SettingsGlobal
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.GetAuditv7SettingsGlobal`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetAuditv7SettingsGlobalRequest struct via the builder pattern


### Return type

[**V7SettingsGlobal**](V7SettingsGlobal.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListAuditv1AuditTopics

> V1AuditTopics ListAuditv1AuditTopics(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.AuditApi.ListAuditv1AuditTopics(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.ListAuditv1AuditTopics``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListAuditv1AuditTopics`: V1AuditTopics
    fmt.Fprintf(os.Stdout, "Response from `AuditApi.ListAuditv1AuditTopics`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiListAuditv1AuditTopicsRequest struct via the builder pattern


### Return type

[**V1AuditTopics**](V1AuditTopics.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuditv11SettingsGlobal

> UpdateAuditv11SettingsGlobal(ctx).V11SettingsGlobal(v11SettingsGlobal).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v11SettingsGlobal := *openapiclient.NewV11SettingsGlobalSettings() // V11SettingsGlobalSettings | 
    force := true // bool | Do not ask for confirmation. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuditApi.UpdateAuditv11SettingsGlobal(context.Background()).V11SettingsGlobal(v11SettingsGlobal).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.UpdateAuditv11SettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuditv11SettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v11SettingsGlobal** | [**V11SettingsGlobalSettings**](V11SettingsGlobalSettings.md) |  | 
 **force** | **bool** | Do not ask for confirmation. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuditv1AuditSettings

> UpdateAuditv1AuditSettings(ctx).V1AuditSettings(v1AuditSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuditSettings := *openapiclient.NewV1AuditSettingsSettings() // V1AuditSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuditApi.UpdateAuditv1AuditSettings(context.Background()).V1AuditSettings(v1AuditSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.UpdateAuditv1AuditSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuditv1AuditSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1AuditSettings** | [**V1AuditSettingsSettings**](V1AuditSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuditv1AuditTopic

> UpdateAuditv1AuditTopic(ctx, v1AuditTopicId).V1AuditTopic(v1AuditTopic).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1AuditTopicId := "v1AuditTopicId_example" // string | Modify the audit topic.
    v1AuditTopic := *openapiclient.NewV1AuditTopicExtendedExtended() // V1AuditTopicExtendedExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuditApi.UpdateAuditv1AuditTopic(context.Background(), v1AuditTopicId).V1AuditTopic(v1AuditTopic).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.UpdateAuditv1AuditTopic``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1AuditTopicId** | **string** | Modify the audit topic. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuditv1AuditTopicRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1AuditTopic** | [**V1AuditTopicExtendedExtended**](V1AuditTopicExtendedExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuditv3AuditSettings

> UpdateAuditv3AuditSettings(ctx).V3AuditSettings(v3AuditSettings).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3AuditSettings := *openapiclient.NewV3AuditSettingsSettings() // V3AuditSettingsSettings | 
    zone := "zone_example" // string | Access zone which contains audit settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuditApi.UpdateAuditv3AuditSettings(context.Background()).V3AuditSettings(v3AuditSettings).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.UpdateAuditv3AuditSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuditv3AuditSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3AuditSettings** | [**V3AuditSettingsSettings**](V3AuditSettingsSettings.md) |  | 
 **zone** | **string** | Access zone which contains audit settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuditv3SettingsGlobal

> UpdateAuditv3SettingsGlobal(ctx).V3SettingsGlobal(v3SettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3SettingsGlobal := *openapiclient.NewV1AuditSettingsSettings() // V1AuditSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuditApi.UpdateAuditv3SettingsGlobal(context.Background()).V3SettingsGlobal(v3SettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.UpdateAuditv3SettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuditv3SettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v3SettingsGlobal** | [**V1AuditSettingsSettings**](V1AuditSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuditv7AuditSettings

> UpdateAuditv7AuditSettings(ctx).V7AuditSettings(v7AuditSettings).Zone(zone).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7AuditSettings := *openapiclient.NewV7AuditSettingsSettings() // V7AuditSettingsSettings | 
    zone := "zone_example" // string | Access zone which contains audit settings. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuditApi.UpdateAuditv7AuditSettings(context.Background()).V7AuditSettings(v7AuditSettings).Zone(zone).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.UpdateAuditv7AuditSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuditv7AuditSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7AuditSettings** | [**V7AuditSettingsSettings**](V7AuditSettingsSettings.md) |  | 
 **zone** | **string** | Access zone which contains audit settings. | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateAuditv7SettingsGlobal

> UpdateAuditv7SettingsGlobal(ctx).V7SettingsGlobal(v7SettingsGlobal).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v7SettingsGlobal := *openapiclient.NewV7SettingsGlobalSettings() // V7SettingsGlobalSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.AuditApi.UpdateAuditv7SettingsGlobal(context.Background()).V7SettingsGlobal(v7SettingsGlobal).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `AuditApi.UpdateAuditv7SettingsGlobal``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateAuditv7SettingsGlobalRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v7SettingsGlobal** | [**V7SettingsGlobalSettings**](V7SettingsGlobalSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

