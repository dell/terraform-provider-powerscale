# V11SettingsGlobalSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AuditedZones** | Pointer to **[]string** | Specifies zones that are audited when the protocol_auditing_enabled property is enabled. | [optional] 
**AutoPurgingEnabled** | Pointer to **bool** | whether auto purging of audit log files is enabled. | [optional] 
**CeeLogTime** | Pointer to **string** | Specifies that events past a certain date are forwarded by the audit CEE forwarder. Format these events as follows: &#39;Topic@YYYY-MM-DD HH:MM:SS&#39;. | [optional] 
**CeeServerUris** | Pointer to **[]string** | Specifies a list of Common Event Enabler (CEE) server URIs. Protocol audit logs are sent to these URIs for external processing. | [optional] 
**ConfigAuditingEnabled** | Pointer to **bool** | Specifies whether logging for API configuration changes are enabled. | [optional] 
**ConfigSyslogEnabled** | Pointer to **bool** | Specifies whether configuration audit syslog messages are forwarded. | [optional] 
**ConfigSyslogServers** | Pointer to **[]string** | Specifies a list of remote servers for audit logging of configuration changes. Audit logs are sent to syslog of these remote servers. | [optional] 
**Hostname** | Pointer to **string** | Specifies the hostname that is reported in protocol events from this cluster. | [optional] 
**ProtocolAuditingEnabled** | Pointer to **bool** | Specifies if logging for the I/O stream is enabled. | [optional] 
**ProtocolSyslogServers** | Pointer to **[]string** | Specifies a list of remote servers for protocol audit logging. Protocol audit logs are sent to syslog of these remote servers. | [optional] 
**RetentionPeriod** | Pointer to **int32** | Specifies the number of days for which audit log files will be retained before being purged. | [optional] 
**SyslogLogTime** | Pointer to **string** | Specifies that events past a specified date are forwarded by the audit syslog forwarder. Format these events as follows: &#39;Topic@YYYY-MM-DD HH:MM:SS&#39; format | [optional] 

## Methods

### NewV11SettingsGlobalSettings

`func NewV11SettingsGlobalSettings() *V11SettingsGlobalSettings`

NewV11SettingsGlobalSettings instantiates a new V11SettingsGlobalSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11SettingsGlobalSettingsWithDefaults

`func NewV11SettingsGlobalSettingsWithDefaults() *V11SettingsGlobalSettings`

NewV11SettingsGlobalSettingsWithDefaults instantiates a new V11SettingsGlobalSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAuditedZones

`func (o *V11SettingsGlobalSettings) GetAuditedZones() []string`

GetAuditedZones returns the AuditedZones field if non-nil, zero value otherwise.

### GetAuditedZonesOk

`func (o *V11SettingsGlobalSettings) GetAuditedZonesOk() (*[]string, bool)`

GetAuditedZonesOk returns a tuple with the AuditedZones field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAuditedZones

`func (o *V11SettingsGlobalSettings) SetAuditedZones(v []string)`

SetAuditedZones sets AuditedZones field to given value.

### HasAuditedZones

`func (o *V11SettingsGlobalSettings) HasAuditedZones() bool`

HasAuditedZones returns a boolean if a field has been set.

### GetAutoPurgingEnabled

`func (o *V11SettingsGlobalSettings) GetAutoPurgingEnabled() bool`

GetAutoPurgingEnabled returns the AutoPurgingEnabled field if non-nil, zero value otherwise.

### GetAutoPurgingEnabledOk

`func (o *V11SettingsGlobalSettings) GetAutoPurgingEnabledOk() (*bool, bool)`

GetAutoPurgingEnabledOk returns a tuple with the AutoPurgingEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutoPurgingEnabled

`func (o *V11SettingsGlobalSettings) SetAutoPurgingEnabled(v bool)`

SetAutoPurgingEnabled sets AutoPurgingEnabled field to given value.

### HasAutoPurgingEnabled

`func (o *V11SettingsGlobalSettings) HasAutoPurgingEnabled() bool`

HasAutoPurgingEnabled returns a boolean if a field has been set.

### GetCeeLogTime

`func (o *V11SettingsGlobalSettings) GetCeeLogTime() string`

GetCeeLogTime returns the CeeLogTime field if non-nil, zero value otherwise.

### GetCeeLogTimeOk

`func (o *V11SettingsGlobalSettings) GetCeeLogTimeOk() (*string, bool)`

GetCeeLogTimeOk returns a tuple with the CeeLogTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCeeLogTime

`func (o *V11SettingsGlobalSettings) SetCeeLogTime(v string)`

SetCeeLogTime sets CeeLogTime field to given value.

### HasCeeLogTime

`func (o *V11SettingsGlobalSettings) HasCeeLogTime() bool`

HasCeeLogTime returns a boolean if a field has been set.

### GetCeeServerUris

`func (o *V11SettingsGlobalSettings) GetCeeServerUris() []string`

GetCeeServerUris returns the CeeServerUris field if non-nil, zero value otherwise.

### GetCeeServerUrisOk

`func (o *V11SettingsGlobalSettings) GetCeeServerUrisOk() (*[]string, bool)`

GetCeeServerUrisOk returns a tuple with the CeeServerUris field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCeeServerUris

`func (o *V11SettingsGlobalSettings) SetCeeServerUris(v []string)`

SetCeeServerUris sets CeeServerUris field to given value.

### HasCeeServerUris

`func (o *V11SettingsGlobalSettings) HasCeeServerUris() bool`

HasCeeServerUris returns a boolean if a field has been set.

### GetConfigAuditingEnabled

`func (o *V11SettingsGlobalSettings) GetConfigAuditingEnabled() bool`

GetConfigAuditingEnabled returns the ConfigAuditingEnabled field if non-nil, zero value otherwise.

### GetConfigAuditingEnabledOk

`func (o *V11SettingsGlobalSettings) GetConfigAuditingEnabledOk() (*bool, bool)`

GetConfigAuditingEnabledOk returns a tuple with the ConfigAuditingEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConfigAuditingEnabled

`func (o *V11SettingsGlobalSettings) SetConfigAuditingEnabled(v bool)`

SetConfigAuditingEnabled sets ConfigAuditingEnabled field to given value.

### HasConfigAuditingEnabled

`func (o *V11SettingsGlobalSettings) HasConfigAuditingEnabled() bool`

HasConfigAuditingEnabled returns a boolean if a field has been set.

### GetConfigSyslogEnabled

`func (o *V11SettingsGlobalSettings) GetConfigSyslogEnabled() bool`

GetConfigSyslogEnabled returns the ConfigSyslogEnabled field if non-nil, zero value otherwise.

### GetConfigSyslogEnabledOk

`func (o *V11SettingsGlobalSettings) GetConfigSyslogEnabledOk() (*bool, bool)`

GetConfigSyslogEnabledOk returns a tuple with the ConfigSyslogEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConfigSyslogEnabled

`func (o *V11SettingsGlobalSettings) SetConfigSyslogEnabled(v bool)`

SetConfigSyslogEnabled sets ConfigSyslogEnabled field to given value.

### HasConfigSyslogEnabled

`func (o *V11SettingsGlobalSettings) HasConfigSyslogEnabled() bool`

HasConfigSyslogEnabled returns a boolean if a field has been set.

### GetConfigSyslogServers

`func (o *V11SettingsGlobalSettings) GetConfigSyslogServers() []string`

GetConfigSyslogServers returns the ConfigSyslogServers field if non-nil, zero value otherwise.

### GetConfigSyslogServersOk

`func (o *V11SettingsGlobalSettings) GetConfigSyslogServersOk() (*[]string, bool)`

GetConfigSyslogServersOk returns a tuple with the ConfigSyslogServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetConfigSyslogServers

`func (o *V11SettingsGlobalSettings) SetConfigSyslogServers(v []string)`

SetConfigSyslogServers sets ConfigSyslogServers field to given value.

### HasConfigSyslogServers

`func (o *V11SettingsGlobalSettings) HasConfigSyslogServers() bool`

HasConfigSyslogServers returns a boolean if a field has been set.

### GetHostname

`func (o *V11SettingsGlobalSettings) GetHostname() string`

GetHostname returns the Hostname field if non-nil, zero value otherwise.

### GetHostnameOk

`func (o *V11SettingsGlobalSettings) GetHostnameOk() (*string, bool)`

GetHostnameOk returns a tuple with the Hostname field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHostname

`func (o *V11SettingsGlobalSettings) SetHostname(v string)`

SetHostname sets Hostname field to given value.

### HasHostname

`func (o *V11SettingsGlobalSettings) HasHostname() bool`

HasHostname returns a boolean if a field has been set.

### GetProtocolAuditingEnabled

`func (o *V11SettingsGlobalSettings) GetProtocolAuditingEnabled() bool`

GetProtocolAuditingEnabled returns the ProtocolAuditingEnabled field if non-nil, zero value otherwise.

### GetProtocolAuditingEnabledOk

`func (o *V11SettingsGlobalSettings) GetProtocolAuditingEnabledOk() (*bool, bool)`

GetProtocolAuditingEnabledOk returns a tuple with the ProtocolAuditingEnabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProtocolAuditingEnabled

`func (o *V11SettingsGlobalSettings) SetProtocolAuditingEnabled(v bool)`

SetProtocolAuditingEnabled sets ProtocolAuditingEnabled field to given value.

### HasProtocolAuditingEnabled

`func (o *V11SettingsGlobalSettings) HasProtocolAuditingEnabled() bool`

HasProtocolAuditingEnabled returns a boolean if a field has been set.

### GetProtocolSyslogServers

`func (o *V11SettingsGlobalSettings) GetProtocolSyslogServers() []string`

GetProtocolSyslogServers returns the ProtocolSyslogServers field if non-nil, zero value otherwise.

### GetProtocolSyslogServersOk

`func (o *V11SettingsGlobalSettings) GetProtocolSyslogServersOk() (*[]string, bool)`

GetProtocolSyslogServersOk returns a tuple with the ProtocolSyslogServers field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetProtocolSyslogServers

`func (o *V11SettingsGlobalSettings) SetProtocolSyslogServers(v []string)`

SetProtocolSyslogServers sets ProtocolSyslogServers field to given value.

### HasProtocolSyslogServers

`func (o *V11SettingsGlobalSettings) HasProtocolSyslogServers() bool`

HasProtocolSyslogServers returns a boolean if a field has been set.

### GetRetentionPeriod

`func (o *V11SettingsGlobalSettings) GetRetentionPeriod() int32`

GetRetentionPeriod returns the RetentionPeriod field if non-nil, zero value otherwise.

### GetRetentionPeriodOk

`func (o *V11SettingsGlobalSettings) GetRetentionPeriodOk() (*int32, bool)`

GetRetentionPeriodOk returns a tuple with the RetentionPeriod field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRetentionPeriod

`func (o *V11SettingsGlobalSettings) SetRetentionPeriod(v int32)`

SetRetentionPeriod sets RetentionPeriod field to given value.

### HasRetentionPeriod

`func (o *V11SettingsGlobalSettings) HasRetentionPeriod() bool`

HasRetentionPeriod returns a boolean if a field has been set.

### GetSyslogLogTime

`func (o *V11SettingsGlobalSettings) GetSyslogLogTime() string`

GetSyslogLogTime returns the SyslogLogTime field if non-nil, zero value otherwise.

### GetSyslogLogTimeOk

`func (o *V11SettingsGlobalSettings) GetSyslogLogTimeOk() (*string, bool)`

GetSyslogLogTimeOk returns a tuple with the SyslogLogTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSyslogLogTime

`func (o *V11SettingsGlobalSettings) SetSyslogLogTime(v string)`

SetSyslogLogTime sets SyslogLogTime field to given value.

### HasSyslogLogTime

`func (o *V11SettingsGlobalSettings) HasSyslogLogTime() bool`

HasSyslogLogTime returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


