# \QuotaQuotasApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateQuotaQuotasv1QuotaNotification**](QuotaQuotasApi.md#CreateQuotaQuotasv1QuotaNotification) | **Post** /platform/1/quota/quotas/{Qid}/notifications | 
[**CreateQuotaQuotasv7QuotaNotification**](QuotaQuotasApi.md#CreateQuotaQuotasv7QuotaNotification) | **Post** /platform/7/quota/quotas/{Qid}/notifications | 
[**DeleteQuotaQuotasv1QuotaNotifications**](QuotaQuotasApi.md#DeleteQuotaQuotasv1QuotaNotifications) | **Delete** /platform/1/quota/quotas/{Qid}/notifications | 
[**DeleteQuotaQuotasv7QuotaNotifications**](QuotaQuotasApi.md#DeleteQuotaQuotasv7QuotaNotifications) | **Delete** /platform/7/quota/quotas/{Qid}/notifications | 
[**ListQuotaQuotasv1QuotaNotifications**](QuotaQuotasApi.md#ListQuotaQuotasv1QuotaNotifications) | **Get** /platform/1/quota/quotas/{Qid}/notifications | 
[**ListQuotaQuotasv7QuotaNotifications**](QuotaQuotasApi.md#ListQuotaQuotasv7QuotaNotifications) | **Get** /platform/7/quota/quotas/{Qid}/notifications | 
[**UpdateQuotaQuotasv1QuotaNotifications**](QuotaQuotasApi.md#UpdateQuotaQuotasv1QuotaNotifications) | **Put** /platform/1/quota/quotas/{Qid}/notifications | 
[**UpdateQuotaQuotasv7QuotaNotifications**](QuotaQuotasApi.md#UpdateQuotaQuotasv7QuotaNotifications) | **Put** /platform/7/quota/quotas/{Qid}/notifications | 



## CreateQuotaQuotasv1QuotaNotification

> CreateResponse CreateQuotaQuotasv1QuotaNotification(ctx, qid).V1QuotaNotification(v1QuotaNotification).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    qid := "qid_example" // string | 
    v1QuotaNotification := *openapiclient.NewV1QuotaNotification("Condition_example", "Threshold_example") // V1QuotaNotification | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaQuotasApi.CreateQuotaQuotasv1QuotaNotification(context.Background(), qid).V1QuotaNotification(v1QuotaNotification).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaQuotasApi.CreateQuotaQuotasv1QuotaNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateQuotaQuotasv1QuotaNotification`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `QuotaQuotasApi.CreateQuotaQuotasv1QuotaNotification`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateQuotaQuotasv1QuotaNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1QuotaNotification** | [**V1QuotaNotification**](V1QuotaNotification.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateQuotaQuotasv7QuotaNotification

> CreateResponse CreateQuotaQuotasv7QuotaNotification(ctx, qid).V7QuotaNotification(v7QuotaNotification).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    qid := "qid_example" // string | 
    v7QuotaNotification := *openapiclient.NewV7QuotaNotification("Condition_example", "Threshold_example") // V7QuotaNotification | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaQuotasApi.CreateQuotaQuotasv7QuotaNotification(context.Background(), qid).V7QuotaNotification(v7QuotaNotification).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaQuotasApi.CreateQuotaQuotasv7QuotaNotification``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateQuotaQuotasv7QuotaNotification`: CreateResponse
    fmt.Fprintf(os.Stdout, "Response from `QuotaQuotasApi.CreateQuotaQuotasv7QuotaNotification`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateQuotaQuotasv7QuotaNotificationRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7QuotaNotification** | [**V7QuotaNotification**](V7QuotaNotification.md) |  | 

### Return type

[**CreateResponse**](CreateResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotaQuotasv1QuotaNotifications

> DeleteQuotaQuotasv1QuotaNotifications(ctx, qid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    qid := "qid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaQuotasApi.DeleteQuotaQuotasv1QuotaNotifications(context.Background(), qid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaQuotasApi.DeleteQuotaQuotasv1QuotaNotifications``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotaQuotasv1QuotaNotificationsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteQuotaQuotasv7QuotaNotifications

> DeleteQuotaQuotasv7QuotaNotifications(ctx, qid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    qid := "qid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaQuotasApi.DeleteQuotaQuotasv7QuotaNotifications(context.Background(), qid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaQuotasApi.DeleteQuotaQuotasv7QuotaNotifications``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteQuotaQuotasv7QuotaNotificationsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListQuotaQuotasv1QuotaNotifications

> V1QuotaNotifications ListQuotaQuotasv1QuotaNotifications(ctx, qid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    qid := "qid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaQuotasApi.ListQuotaQuotasv1QuotaNotifications(context.Background(), qid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaQuotasApi.ListQuotaQuotasv1QuotaNotifications``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListQuotaQuotasv1QuotaNotifications`: V1QuotaNotifications
    fmt.Fprintf(os.Stdout, "Response from `QuotaQuotasApi.ListQuotaQuotasv1QuotaNotifications`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListQuotaQuotasv1QuotaNotificationsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1QuotaNotifications**](V1QuotaNotifications.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListQuotaQuotasv7QuotaNotifications

> V7QuotaNotifications ListQuotaQuotasv7QuotaNotifications(ctx, qid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    qid := "qid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.QuotaQuotasApi.ListQuotaQuotasv7QuotaNotifications(context.Background(), qid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaQuotasApi.ListQuotaQuotasv7QuotaNotifications``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListQuotaQuotasv7QuotaNotifications`: V7QuotaNotifications
    fmt.Fprintf(os.Stdout, "Response from `QuotaQuotasApi.ListQuotaQuotasv7QuotaNotifications`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListQuotaQuotasv7QuotaNotificationsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7QuotaNotifications**](V7QuotaNotifications.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotaQuotasv1QuotaNotifications

> UpdateQuotaQuotasv1QuotaNotifications(ctx, qid).V1QuotaNotifications(v1QuotaNotifications).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    qid := "qid_example" // string | 
    v1QuotaNotifications := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaQuotasApi.UpdateQuotaQuotasv1QuotaNotifications(context.Background(), qid).V1QuotaNotifications(v1QuotaNotifications).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaQuotasApi.UpdateQuotaQuotasv1QuotaNotifications``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotaQuotasv1QuotaNotificationsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1QuotaNotifications** | **map[string]interface{}** |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateQuotaQuotasv7QuotaNotifications

> UpdateQuotaQuotasv7QuotaNotifications(ctx, qid).V7QuotaNotifications(v7QuotaNotifications).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    qid := "qid_example" // string | 
    v7QuotaNotifications := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.QuotaQuotasApi.UpdateQuotaQuotasv7QuotaNotifications(context.Background(), qid).V7QuotaNotifications(v7QuotaNotifications).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `QuotaQuotasApi.UpdateQuotaQuotasv7QuotaNotifications``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**qid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateQuotaQuotasv7QuotaNotificationsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7QuotaNotifications** | **map[string]interface{}** |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

