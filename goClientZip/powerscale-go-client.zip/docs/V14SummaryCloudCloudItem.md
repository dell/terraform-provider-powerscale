# V14SummaryCloudCloudItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Account** | Pointer to **string** | Account name | [optional] 
**AccountKey** | Pointer to **string** | Key for account | [optional] 
**Cloud** | Pointer to **string** | Name of cloud provider | [optional] 
**Deletes** | Pointer to **int32** | Number of delete operations | [optional] 
**Guid** | Pointer to **string** | Cluster GUID | [optional] 
**In** | Pointer to **int32** | Number of bytes in | [optional] 
**Node** | Pointer to **int32** | The node this data came from | [optional] 
**Out** | Pointer to **int32** | Number of bytes out | [optional] 
**Policy** | Pointer to **string** | Policy name | [optional] 
**PolicyId** | Pointer to **int32** | Id of the policy | [optional] 
**Reads** | Pointer to **int32** | Number of read operations | [optional] 
**Time** | Pointer to **int32** | Timestamp | [optional] 
**Writes** | Pointer to **int32** | Number of write operations | [optional] 

## Methods

### NewV14SummaryCloudCloudItem

`func NewV14SummaryCloudCloudItem() *V14SummaryCloudCloudItem`

NewV14SummaryCloudCloudItem instantiates a new V14SummaryCloudCloudItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SummaryCloudCloudItemWithDefaults

`func NewV14SummaryCloudCloudItemWithDefaults() *V14SummaryCloudCloudItem`

NewV14SummaryCloudCloudItemWithDefaults instantiates a new V14SummaryCloudCloudItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAccount

`func (o *V14SummaryCloudCloudItem) GetAccount() string`

GetAccount returns the Account field if non-nil, zero value otherwise.

### GetAccountOk

`func (o *V14SummaryCloudCloudItem) GetAccountOk() (*string, bool)`

GetAccountOk returns a tuple with the Account field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccount

`func (o *V14SummaryCloudCloudItem) SetAccount(v string)`

SetAccount sets Account field to given value.

### HasAccount

`func (o *V14SummaryCloudCloudItem) HasAccount() bool`

HasAccount returns a boolean if a field has been set.

### GetAccountKey

`func (o *V14SummaryCloudCloudItem) GetAccountKey() string`

GetAccountKey returns the AccountKey field if non-nil, zero value otherwise.

### GetAccountKeyOk

`func (o *V14SummaryCloudCloudItem) GetAccountKeyOk() (*string, bool)`

GetAccountKeyOk returns a tuple with the AccountKey field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccountKey

`func (o *V14SummaryCloudCloudItem) SetAccountKey(v string)`

SetAccountKey sets AccountKey field to given value.

### HasAccountKey

`func (o *V14SummaryCloudCloudItem) HasAccountKey() bool`

HasAccountKey returns a boolean if a field has been set.

### GetCloud

`func (o *V14SummaryCloudCloudItem) GetCloud() string`

GetCloud returns the Cloud field if non-nil, zero value otherwise.

### GetCloudOk

`func (o *V14SummaryCloudCloudItem) GetCloudOk() (*string, bool)`

GetCloudOk returns a tuple with the Cloud field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCloud

`func (o *V14SummaryCloudCloudItem) SetCloud(v string)`

SetCloud sets Cloud field to given value.

### HasCloud

`func (o *V14SummaryCloudCloudItem) HasCloud() bool`

HasCloud returns a boolean if a field has been set.

### GetDeletes

`func (o *V14SummaryCloudCloudItem) GetDeletes() int32`

GetDeletes returns the Deletes field if non-nil, zero value otherwise.

### GetDeletesOk

`func (o *V14SummaryCloudCloudItem) GetDeletesOk() (*int32, bool)`

GetDeletesOk returns a tuple with the Deletes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeletes

`func (o *V14SummaryCloudCloudItem) SetDeletes(v int32)`

SetDeletes sets Deletes field to given value.

### HasDeletes

`func (o *V14SummaryCloudCloudItem) HasDeletes() bool`

HasDeletes returns a boolean if a field has been set.

### GetGuid

`func (o *V14SummaryCloudCloudItem) GetGuid() string`

GetGuid returns the Guid field if non-nil, zero value otherwise.

### GetGuidOk

`func (o *V14SummaryCloudCloudItem) GetGuidOk() (*string, bool)`

GetGuidOk returns a tuple with the Guid field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetGuid

`func (o *V14SummaryCloudCloudItem) SetGuid(v string)`

SetGuid sets Guid field to given value.

### HasGuid

`func (o *V14SummaryCloudCloudItem) HasGuid() bool`

HasGuid returns a boolean if a field has been set.

### GetIn

`func (o *V14SummaryCloudCloudItem) GetIn() int32`

GetIn returns the In field if non-nil, zero value otherwise.

### GetInOk

`func (o *V14SummaryCloudCloudItem) GetInOk() (*int32, bool)`

GetInOk returns a tuple with the In field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIn

`func (o *V14SummaryCloudCloudItem) SetIn(v int32)`

SetIn sets In field to given value.

### HasIn

`func (o *V14SummaryCloudCloudItem) HasIn() bool`

HasIn returns a boolean if a field has been set.

### GetNode

`func (o *V14SummaryCloudCloudItem) GetNode() int32`

GetNode returns the Node field if non-nil, zero value otherwise.

### GetNodeOk

`func (o *V14SummaryCloudCloudItem) GetNodeOk() (*int32, bool)`

GetNodeOk returns a tuple with the Node field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNode

`func (o *V14SummaryCloudCloudItem) SetNode(v int32)`

SetNode sets Node field to given value.

### HasNode

`func (o *V14SummaryCloudCloudItem) HasNode() bool`

HasNode returns a boolean if a field has been set.

### GetOut

`func (o *V14SummaryCloudCloudItem) GetOut() int32`

GetOut returns the Out field if non-nil, zero value otherwise.

### GetOutOk

`func (o *V14SummaryCloudCloudItem) GetOutOk() (*int32, bool)`

GetOutOk returns a tuple with the Out field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOut

`func (o *V14SummaryCloudCloudItem) SetOut(v int32)`

SetOut sets Out field to given value.

### HasOut

`func (o *V14SummaryCloudCloudItem) HasOut() bool`

HasOut returns a boolean if a field has been set.

### GetPolicy

`func (o *V14SummaryCloudCloudItem) GetPolicy() string`

GetPolicy returns the Policy field if non-nil, zero value otherwise.

### GetPolicyOk

`func (o *V14SummaryCloudCloudItem) GetPolicyOk() (*string, bool)`

GetPolicyOk returns a tuple with the Policy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicy

`func (o *V14SummaryCloudCloudItem) SetPolicy(v string)`

SetPolicy sets Policy field to given value.

### HasPolicy

`func (o *V14SummaryCloudCloudItem) HasPolicy() bool`

HasPolicy returns a boolean if a field has been set.

### GetPolicyId

`func (o *V14SummaryCloudCloudItem) GetPolicyId() int32`

GetPolicyId returns the PolicyId field if non-nil, zero value otherwise.

### GetPolicyIdOk

`func (o *V14SummaryCloudCloudItem) GetPolicyIdOk() (*int32, bool)`

GetPolicyIdOk returns a tuple with the PolicyId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicyId

`func (o *V14SummaryCloudCloudItem) SetPolicyId(v int32)`

SetPolicyId sets PolicyId field to given value.

### HasPolicyId

`func (o *V14SummaryCloudCloudItem) HasPolicyId() bool`

HasPolicyId returns a boolean if a field has been set.

### GetReads

`func (o *V14SummaryCloudCloudItem) GetReads() int32`

GetReads returns the Reads field if non-nil, zero value otherwise.

### GetReadsOk

`func (o *V14SummaryCloudCloudItem) GetReadsOk() (*int32, bool)`

GetReadsOk returns a tuple with the Reads field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReads

`func (o *V14SummaryCloudCloudItem) SetReads(v int32)`

SetReads sets Reads field to given value.

### HasReads

`func (o *V14SummaryCloudCloudItem) HasReads() bool`

HasReads returns a boolean if a field has been set.

### GetTime

`func (o *V14SummaryCloudCloudItem) GetTime() int32`

GetTime returns the Time field if non-nil, zero value otherwise.

### GetTimeOk

`func (o *V14SummaryCloudCloudItem) GetTimeOk() (*int32, bool)`

GetTimeOk returns a tuple with the Time field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTime

`func (o *V14SummaryCloudCloudItem) SetTime(v int32)`

SetTime sets Time field to given value.

### HasTime

`func (o *V14SummaryCloudCloudItem) HasTime() bool`

HasTime returns a boolean if a field has been set.

### GetWrites

`func (o *V14SummaryCloudCloudItem) GetWrites() int32`

GetWrites returns the Writes field if non-nil, zero value otherwise.

### GetWritesOk

`func (o *V14SummaryCloudCloudItem) GetWritesOk() (*int32, bool)`

GetWritesOk returns a tuple with the Writes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWrites

`func (o *V14SummaryCloudCloudItem) SetWrites(v int32)`

SetWrites sets Writes field to given value.

### HasWrites

`func (o *V14SummaryCloudCloudItem) HasWrites() bool`

HasWrites returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


