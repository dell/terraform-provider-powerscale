# V11LicenseActivationElmsError

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | Pointer to **string** | An error code corresponding to an error returned from the SRS ELMS rest call. | [optional] 
**Error** | Pointer to **string** | An error string returned from the SRS ELMS rest call | [optional] 

## Methods

### NewV11LicenseActivationElmsError

`func NewV11LicenseActivationElmsError() *V11LicenseActivationElmsError`

NewV11LicenseActivationElmsError instantiates a new V11LicenseActivationElmsError object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11LicenseActivationElmsErrorWithDefaults

`func NewV11LicenseActivationElmsErrorWithDefaults() *V11LicenseActivationElmsError`

NewV11LicenseActivationElmsErrorWithDefaults instantiates a new V11LicenseActivationElmsError object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCode

`func (o *V11LicenseActivationElmsError) GetCode() string`

GetCode returns the Code field if non-nil, zero value otherwise.

### GetCodeOk

`func (o *V11LicenseActivationElmsError) GetCodeOk() (*string, bool)`

GetCodeOk returns a tuple with the Code field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCode

`func (o *V11LicenseActivationElmsError) SetCode(v string)`

SetCode sets Code field to given value.

### HasCode

`func (o *V11LicenseActivationElmsError) HasCode() bool`

HasCode returns a boolean if a field has been set.

### GetError

`func (o *V11LicenseActivationElmsError) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V11LicenseActivationElmsError) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V11LicenseActivationElmsError) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V11LicenseActivationElmsError) HasError() bool`

HasError returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


