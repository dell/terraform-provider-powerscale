# V14SessionsInvalidations

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Invalidations** | Pointer to [**[]V14SessionsInvalidationExtended**](V14SessionsInvalidationExtended.md) |  | [optional] 

## Methods

### NewV14SessionsInvalidations

`func NewV14SessionsInvalidations() *V14SessionsInvalidations`

NewV14SessionsInvalidations instantiates a new V14SessionsInvalidations object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SessionsInvalidationsWithDefaults

`func NewV14SessionsInvalidationsWithDefaults() *V14SessionsInvalidations`

NewV14SessionsInvalidationsWithDefaults instantiates a new V14SessionsInvalidations object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetInvalidations

`func (o *V14SessionsInvalidations) GetInvalidations() []V14SessionsInvalidationExtended`

GetInvalidations returns the Invalidations field if non-nil, zero value otherwise.

### GetInvalidationsOk

`func (o *V14SessionsInvalidations) GetInvalidationsOk() (*[]V14SessionsInvalidationExtended, bool)`

GetInvalidationsOk returns a tuple with the Invalidations field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInvalidations

`func (o *V14SessionsInvalidations) SetInvalidations(v []V14SessionsInvalidationExtended)`

SetInvalidations sets Invalidations field to given value.

### HasInvalidations

`func (o *V14SessionsInvalidations) HasInvalidations() bool`

HasInvalidations returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


