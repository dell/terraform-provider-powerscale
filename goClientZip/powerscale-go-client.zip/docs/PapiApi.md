# \PapiApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetPapiv14PapiSettings**](PapiApi.md#GetPapiv14PapiSettings) | **Get** /platform/14/papi/settings | 
[**UpdatePapiv14PapiSettings**](PapiApi.md#UpdatePapiv14PapiSettings) | **Put** /platform/14/papi/settings | 



## GetPapiv14PapiSettings

> V14PapiSettings GetPapiv14PapiSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PapiApi.GetPapiv14PapiSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PapiApi.GetPapiv14PapiSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetPapiv14PapiSettings`: V14PapiSettings
    fmt.Fprintf(os.Stdout, "Response from `PapiApi.GetPapiv14PapiSettings`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetPapiv14PapiSettingsRequest struct via the builder pattern


### Return type

[**V14PapiSettings**](V14PapiSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdatePapiv14PapiSettings

> UpdatePapiv14PapiSettings(ctx).V14PapiSettings(v14PapiSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v14PapiSettings := *openapiclient.NewV14PapiSettingsPapiSettings() // V14PapiSettingsPapiSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PapiApi.UpdatePapiv14PapiSettings(context.Background()).V14PapiSettings(v14PapiSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PapiApi.UpdatePapiv14PapiSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdatePapiv14PapiSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v14PapiSettings** | [**V14PapiSettingsPapiSettings**](V14PapiSettingsPapiSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

