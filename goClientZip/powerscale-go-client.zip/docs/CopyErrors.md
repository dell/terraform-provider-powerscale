# CopyErrors

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CopyErrors** | Pointer to [**[]CopyErrorsCopyErrorsInner**](CopyErrorsCopyErrorsInner.md) |  | [optional] 

## Methods

### NewCopyErrors

`func NewCopyErrors() *CopyErrors`

NewCopyErrors instantiates a new CopyErrors object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCopyErrorsWithDefaults

`func NewCopyErrorsWithDefaults() *CopyErrors`

NewCopyErrorsWithDefaults instantiates a new CopyErrors object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCopyErrors

`func (o *CopyErrors) GetCopyErrors() []CopyErrorsCopyErrorsInner`

GetCopyErrors returns the CopyErrors field if non-nil, zero value otherwise.

### GetCopyErrorsOk

`func (o *CopyErrors) GetCopyErrorsOk() (*[]CopyErrorsCopyErrorsInner, bool)`

GetCopyErrorsOk returns a tuple with the CopyErrors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCopyErrors

`func (o *CopyErrors) SetCopyErrors(v []CopyErrorsCopyErrorsInner)`

SetCopyErrors sets CopyErrors field to given value.

### HasCopyErrors

`func (o *CopyErrors) HasCopyErrors() bool`

HasCopyErrors returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


