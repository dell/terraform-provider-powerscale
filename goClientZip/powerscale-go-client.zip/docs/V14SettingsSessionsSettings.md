# V14SettingsSessionsSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**KeyRotation** | Pointer to **int32** | The amount of time in seconds before rotating the session signing key with a new key. | [optional] 

## Methods

### NewV14SettingsSessionsSettings

`func NewV14SettingsSessionsSettings() *V14SettingsSessionsSettings`

NewV14SettingsSessionsSettings instantiates a new V14SettingsSessionsSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SettingsSessionsSettingsWithDefaults

`func NewV14SettingsSessionsSettingsWithDefaults() *V14SettingsSessionsSettings`

NewV14SettingsSessionsSettingsWithDefaults instantiates a new V14SettingsSessionsSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetKeyRotation

`func (o *V14SettingsSessionsSettings) GetKeyRotation() int32`

GetKeyRotation returns the KeyRotation field if non-nil, zero value otherwise.

### GetKeyRotationOk

`func (o *V14SettingsSessionsSettings) GetKeyRotationOk() (*int32, bool)`

GetKeyRotationOk returns a tuple with the KeyRotation field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetKeyRotation

`func (o *V14SettingsSessionsSettings) SetKeyRotation(v int32)`

SetKeyRotation sets KeyRotation field to given value.

### HasKeyRotation

`func (o *V14SettingsSessionsSettings) HasKeyRotation() bool`

HasKeyRotation returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


