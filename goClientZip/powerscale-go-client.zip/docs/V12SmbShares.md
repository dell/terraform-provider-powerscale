# V12SmbShares

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Digest** | Pointer to **string** | An identifier for a set of shares. | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Shares** | [**[]V12SmbShareExtended**](V12SmbShareExtended.md) |  | 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV12SmbShares

`func NewV12SmbShares(shares []V12SmbShareExtended, ) *V12SmbShares`

NewV12SmbShares instantiates a new V12SmbShares object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SmbSharesWithDefaults

`func NewV12SmbSharesWithDefaults() *V12SmbShares`

NewV12SmbSharesWithDefaults instantiates a new V12SmbShares object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDigest

`func (o *V12SmbShares) GetDigest() string`

GetDigest returns the Digest field if non-nil, zero value otherwise.

### GetDigestOk

`func (o *V12SmbShares) GetDigestOk() (*string, bool)`

GetDigestOk returns a tuple with the Digest field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDigest

`func (o *V12SmbShares) SetDigest(v string)`

SetDigest sets Digest field to given value.

### HasDigest

`func (o *V12SmbShares) HasDigest() bool`

HasDigest returns a boolean if a field has been set.

### GetResume

`func (o *V12SmbShares) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12SmbShares) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12SmbShares) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12SmbShares) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetShares

`func (o *V12SmbShares) GetShares() []V12SmbShareExtended`

GetShares returns the Shares field if non-nil, zero value otherwise.

### GetSharesOk

`func (o *V12SmbShares) GetSharesOk() (*[]V12SmbShareExtended, bool)`

GetSharesOk returns a tuple with the Shares field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShares

`func (o *V12SmbShares) SetShares(v []V12SmbShareExtended)`

SetShares sets Shares field to given value.


### GetTotal

`func (o *V12SmbShares) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12SmbShares) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12SmbShares) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12SmbShares) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


