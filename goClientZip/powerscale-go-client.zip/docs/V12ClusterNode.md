# V12ClusterNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Drives** | Pointer to [**[]V10ClusterNodeDrive**](V10ClusterNodeDrive.md) | List of the drives in this node. | [optional] 
**Hardware** | Pointer to [**V12ClusterNodeHardware**](V12ClusterNodeHardware.md) |  | [optional] 
**Id** | Pointer to **int32** | Node ID (Device Number) of a node. | [optional] 
**Lnn** | Pointer to **int32** | Logical Node Number (LNN) of a node. | [optional] 
**Partitions** | Pointer to [**V10ClusterNodePartitions**](V10ClusterNodePartitions.md) |  | [optional] 
**Sensors** | Pointer to [**V10ClusterNodeSensors**](V10ClusterNodeSensors.md) |  | [optional] 
**State** | Pointer to [**V12ClusterNodeState**](V12ClusterNodeState.md) |  | [optional] 
**Status** | Pointer to [**V12ClusterNodeStatus**](V12ClusterNodeStatus.md) |  | [optional] 

## Methods

### NewV12ClusterNode

`func NewV12ClusterNode() *V12ClusterNode`

NewV12ClusterNode instantiates a new V12ClusterNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterNodeWithDefaults

`func NewV12ClusterNodeWithDefaults() *V12ClusterNode`

NewV12ClusterNodeWithDefaults instantiates a new V12ClusterNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDrives

`func (o *V12ClusterNode) GetDrives() []V10ClusterNodeDrive`

GetDrives returns the Drives field if non-nil, zero value otherwise.

### GetDrivesOk

`func (o *V12ClusterNode) GetDrivesOk() (*[]V10ClusterNodeDrive, bool)`

GetDrivesOk returns a tuple with the Drives field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrives

`func (o *V12ClusterNode) SetDrives(v []V10ClusterNodeDrive)`

SetDrives sets Drives field to given value.

### HasDrives

`func (o *V12ClusterNode) HasDrives() bool`

HasDrives returns a boolean if a field has been set.

### GetHardware

`func (o *V12ClusterNode) GetHardware() V12ClusterNodeHardware`

GetHardware returns the Hardware field if non-nil, zero value otherwise.

### GetHardwareOk

`func (o *V12ClusterNode) GetHardwareOk() (*V12ClusterNodeHardware, bool)`

GetHardwareOk returns a tuple with the Hardware field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHardware

`func (o *V12ClusterNode) SetHardware(v V12ClusterNodeHardware)`

SetHardware sets Hardware field to given value.

### HasHardware

`func (o *V12ClusterNode) HasHardware() bool`

HasHardware returns a boolean if a field has been set.

### GetId

`func (o *V12ClusterNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12ClusterNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12ClusterNode) SetId(v int32)`

SetId sets Id field to given value.

### HasId

`func (o *V12ClusterNode) HasId() bool`

HasId returns a boolean if a field has been set.

### GetLnn

`func (o *V12ClusterNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12ClusterNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12ClusterNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V12ClusterNode) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetPartitions

`func (o *V12ClusterNode) GetPartitions() V10ClusterNodePartitions`

GetPartitions returns the Partitions field if non-nil, zero value otherwise.

### GetPartitionsOk

`func (o *V12ClusterNode) GetPartitionsOk() (*V10ClusterNodePartitions, bool)`

GetPartitionsOk returns a tuple with the Partitions field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPartitions

`func (o *V12ClusterNode) SetPartitions(v V10ClusterNodePartitions)`

SetPartitions sets Partitions field to given value.

### HasPartitions

`func (o *V12ClusterNode) HasPartitions() bool`

HasPartitions returns a boolean if a field has been set.

### GetSensors

`func (o *V12ClusterNode) GetSensors() V10ClusterNodeSensors`

GetSensors returns the Sensors field if non-nil, zero value otherwise.

### GetSensorsOk

`func (o *V12ClusterNode) GetSensorsOk() (*V10ClusterNodeSensors, bool)`

GetSensorsOk returns a tuple with the Sensors field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSensors

`func (o *V12ClusterNode) SetSensors(v V10ClusterNodeSensors)`

SetSensors sets Sensors field to given value.

### HasSensors

`func (o *V12ClusterNode) HasSensors() bool`

HasSensors returns a boolean if a field has been set.

### GetState

`func (o *V12ClusterNode) GetState() V12ClusterNodeState`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *V12ClusterNode) GetStateOk() (*V12ClusterNodeState, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *V12ClusterNode) SetState(v V12ClusterNodeState)`

SetState sets State field to given value.

### HasState

`func (o *V12ClusterNode) HasState() bool`

HasState returns a boolean if a field has been set.

### GetStatus

`func (o *V12ClusterNode) GetStatus() V12ClusterNodeStatus`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12ClusterNode) GetStatusOk() (*V12ClusterNodeStatus, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12ClusterNode) SetStatus(v V12ClusterNodeStatus)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V12ClusterNode) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


