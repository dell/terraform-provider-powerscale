# V11ReportsScansReport

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AvService** | Pointer to **string** | The actual antivirus service that started the scanning job. | [optional] 
**BytesSent** | Pointer to **int32** | The number of bytes sent to the virus definition server to be scanned. | [optional] 
**Duration** | Pointer to **int32** | The length of time the job ran for. | [optional] 
**End** | Pointer to **int32** | The time the job ended. | [optional] 
**Files** | Pointer to **int32** | The number of files scanned. | [optional] 
**Id** | Pointer to **string** | A unique identifier for the report. | [optional] 
**Infections** | Pointer to **int32** | The number of infections found. | [optional] 
**JobId** | Pointer to **int32** | The ID of the job that ran the policy.  If the scan was manually run on a single file, this field will be null. | [optional] 
**NumCloudFiles** | Pointer to **int32** | The number of cloud pool files scanned. | [optional] 
**NumCloudFilesRev** | Pointer to **int32** | The number of cloud pool files reviewed for scan. | [optional] 
**NumFilesRev** | Pointer to **int32** | The number of files reviewed for scan. | [optional] 
**PolicyId** | Pointer to **string** | The id of the policy that this scan job executed. | [optional] 
**ScanFails** | Pointer to **int32** | The number of files scanned unsuccessfully. | [optional] 
**Size** | Pointer to **int32** | The cumulative size of the files scanned. | [optional] 
**Start** | Pointer to **int32** | The time the job started. | [optional] 
**Status** | Pointer to **string** | The state of the job. | [optional] 

## Methods

### NewV11ReportsScansReport

`func NewV11ReportsScansReport() *V11ReportsScansReport`

NewV11ReportsScansReport instantiates a new V11ReportsScansReport object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11ReportsScansReportWithDefaults

`func NewV11ReportsScansReportWithDefaults() *V11ReportsScansReport`

NewV11ReportsScansReportWithDefaults instantiates a new V11ReportsScansReport object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAvService

`func (o *V11ReportsScansReport) GetAvService() string`

GetAvService returns the AvService field if non-nil, zero value otherwise.

### GetAvServiceOk

`func (o *V11ReportsScansReport) GetAvServiceOk() (*string, bool)`

GetAvServiceOk returns a tuple with the AvService field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAvService

`func (o *V11ReportsScansReport) SetAvService(v string)`

SetAvService sets AvService field to given value.

### HasAvService

`func (o *V11ReportsScansReport) HasAvService() bool`

HasAvService returns a boolean if a field has been set.

### GetBytesSent

`func (o *V11ReportsScansReport) GetBytesSent() int32`

GetBytesSent returns the BytesSent field if non-nil, zero value otherwise.

### GetBytesSentOk

`func (o *V11ReportsScansReport) GetBytesSentOk() (*int32, bool)`

GetBytesSentOk returns a tuple with the BytesSent field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBytesSent

`func (o *V11ReportsScansReport) SetBytesSent(v int32)`

SetBytesSent sets BytesSent field to given value.

### HasBytesSent

`func (o *V11ReportsScansReport) HasBytesSent() bool`

HasBytesSent returns a boolean if a field has been set.

### GetDuration

`func (o *V11ReportsScansReport) GetDuration() int32`

GetDuration returns the Duration field if non-nil, zero value otherwise.

### GetDurationOk

`func (o *V11ReportsScansReport) GetDurationOk() (*int32, bool)`

GetDurationOk returns a tuple with the Duration field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDuration

`func (o *V11ReportsScansReport) SetDuration(v int32)`

SetDuration sets Duration field to given value.

### HasDuration

`func (o *V11ReportsScansReport) HasDuration() bool`

HasDuration returns a boolean if a field has been set.

### GetEnd

`func (o *V11ReportsScansReport) GetEnd() int32`

GetEnd returns the End field if non-nil, zero value otherwise.

### GetEndOk

`func (o *V11ReportsScansReport) GetEndOk() (*int32, bool)`

GetEndOk returns a tuple with the End field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnd

`func (o *V11ReportsScansReport) SetEnd(v int32)`

SetEnd sets End field to given value.

### HasEnd

`func (o *V11ReportsScansReport) HasEnd() bool`

HasEnd returns a boolean if a field has been set.

### GetFiles

`func (o *V11ReportsScansReport) GetFiles() int32`

GetFiles returns the Files field if non-nil, zero value otherwise.

### GetFilesOk

`func (o *V11ReportsScansReport) GetFilesOk() (*int32, bool)`

GetFilesOk returns a tuple with the Files field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFiles

`func (o *V11ReportsScansReport) SetFiles(v int32)`

SetFiles sets Files field to given value.

### HasFiles

`func (o *V11ReportsScansReport) HasFiles() bool`

HasFiles returns a boolean if a field has been set.

### GetId

`func (o *V11ReportsScansReport) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11ReportsScansReport) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11ReportsScansReport) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11ReportsScansReport) HasId() bool`

HasId returns a boolean if a field has been set.

### GetInfections

`func (o *V11ReportsScansReport) GetInfections() int32`

GetInfections returns the Infections field if non-nil, zero value otherwise.

### GetInfectionsOk

`func (o *V11ReportsScansReport) GetInfectionsOk() (*int32, bool)`

GetInfectionsOk returns a tuple with the Infections field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInfections

`func (o *V11ReportsScansReport) SetInfections(v int32)`

SetInfections sets Infections field to given value.

### HasInfections

`func (o *V11ReportsScansReport) HasInfections() bool`

HasInfections returns a boolean if a field has been set.

### GetJobId

`func (o *V11ReportsScansReport) GetJobId() int32`

GetJobId returns the JobId field if non-nil, zero value otherwise.

### GetJobIdOk

`func (o *V11ReportsScansReport) GetJobIdOk() (*int32, bool)`

GetJobIdOk returns a tuple with the JobId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJobId

`func (o *V11ReportsScansReport) SetJobId(v int32)`

SetJobId sets JobId field to given value.

### HasJobId

`func (o *V11ReportsScansReport) HasJobId() bool`

HasJobId returns a boolean if a field has been set.

### GetNumCloudFiles

`func (o *V11ReportsScansReport) GetNumCloudFiles() int32`

GetNumCloudFiles returns the NumCloudFiles field if non-nil, zero value otherwise.

### GetNumCloudFilesOk

`func (o *V11ReportsScansReport) GetNumCloudFilesOk() (*int32, bool)`

GetNumCloudFilesOk returns a tuple with the NumCloudFiles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumCloudFiles

`func (o *V11ReportsScansReport) SetNumCloudFiles(v int32)`

SetNumCloudFiles sets NumCloudFiles field to given value.

### HasNumCloudFiles

`func (o *V11ReportsScansReport) HasNumCloudFiles() bool`

HasNumCloudFiles returns a boolean if a field has been set.

### GetNumCloudFilesRev

`func (o *V11ReportsScansReport) GetNumCloudFilesRev() int32`

GetNumCloudFilesRev returns the NumCloudFilesRev field if non-nil, zero value otherwise.

### GetNumCloudFilesRevOk

`func (o *V11ReportsScansReport) GetNumCloudFilesRevOk() (*int32, bool)`

GetNumCloudFilesRevOk returns a tuple with the NumCloudFilesRev field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumCloudFilesRev

`func (o *V11ReportsScansReport) SetNumCloudFilesRev(v int32)`

SetNumCloudFilesRev sets NumCloudFilesRev field to given value.

### HasNumCloudFilesRev

`func (o *V11ReportsScansReport) HasNumCloudFilesRev() bool`

HasNumCloudFilesRev returns a boolean if a field has been set.

### GetNumFilesRev

`func (o *V11ReportsScansReport) GetNumFilesRev() int32`

GetNumFilesRev returns the NumFilesRev field if non-nil, zero value otherwise.

### GetNumFilesRevOk

`func (o *V11ReportsScansReport) GetNumFilesRevOk() (*int32, bool)`

GetNumFilesRevOk returns a tuple with the NumFilesRev field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNumFilesRev

`func (o *V11ReportsScansReport) SetNumFilesRev(v int32)`

SetNumFilesRev sets NumFilesRev field to given value.

### HasNumFilesRev

`func (o *V11ReportsScansReport) HasNumFilesRev() bool`

HasNumFilesRev returns a boolean if a field has been set.

### GetPolicyId

`func (o *V11ReportsScansReport) GetPolicyId() string`

GetPolicyId returns the PolicyId field if non-nil, zero value otherwise.

### GetPolicyIdOk

`func (o *V11ReportsScansReport) GetPolicyIdOk() (*string, bool)`

GetPolicyIdOk returns a tuple with the PolicyId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPolicyId

`func (o *V11ReportsScansReport) SetPolicyId(v string)`

SetPolicyId sets PolicyId field to given value.

### HasPolicyId

`func (o *V11ReportsScansReport) HasPolicyId() bool`

HasPolicyId returns a boolean if a field has been set.

### GetScanFails

`func (o *V11ReportsScansReport) GetScanFails() int32`

GetScanFails returns the ScanFails field if non-nil, zero value otherwise.

### GetScanFailsOk

`func (o *V11ReportsScansReport) GetScanFailsOk() (*int32, bool)`

GetScanFailsOk returns a tuple with the ScanFails field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanFails

`func (o *V11ReportsScansReport) SetScanFails(v int32)`

SetScanFails sets ScanFails field to given value.

### HasScanFails

`func (o *V11ReportsScansReport) HasScanFails() bool`

HasScanFails returns a boolean if a field has been set.

### GetSize

`func (o *V11ReportsScansReport) GetSize() int32`

GetSize returns the Size field if non-nil, zero value otherwise.

### GetSizeOk

`func (o *V11ReportsScansReport) GetSizeOk() (*int32, bool)`

GetSizeOk returns a tuple with the Size field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSize

`func (o *V11ReportsScansReport) SetSize(v int32)`

SetSize sets Size field to given value.

### HasSize

`func (o *V11ReportsScansReport) HasSize() bool`

HasSize returns a boolean if a field has been set.

### GetStart

`func (o *V11ReportsScansReport) GetStart() int32`

GetStart returns the Start field if non-nil, zero value otherwise.

### GetStartOk

`func (o *V11ReportsScansReport) GetStartOk() (*int32, bool)`

GetStartOk returns a tuple with the Start field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStart

`func (o *V11ReportsScansReport) SetStart(v int32)`

SetStart sets Start field to given value.

### HasStart

`func (o *V11ReportsScansReport) HasStart() bool`

HasStart returns a boolean if a field has been set.

### GetStatus

`func (o *V11ReportsScansReport) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V11ReportsScansReport) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V11ReportsScansReport) SetStatus(v string)`

SetStatus sets Status field to given value.

### HasStatus

`func (o *V11ReportsScansReport) HasStatus() bool`

HasStatus returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


