# V10NodeHardware

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nodes** | Pointer to [**[]V10NodeHardwareNode**](V10NodeHardwareNode.md) |  | [optional] 
**Total** | Pointer to **int32** | Total number of items available. | [optional] 

## Methods

### NewV10NodeHardware

`func NewV10NodeHardware() *V10NodeHardware`

NewV10NodeHardware instantiates a new V10NodeHardware object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10NodeHardwareWithDefaults

`func NewV10NodeHardwareWithDefaults() *V10NodeHardware`

NewV10NodeHardwareWithDefaults instantiates a new V10NodeHardware object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNodes

`func (o *V10NodeHardware) GetNodes() []V10NodeHardwareNode`

GetNodes returns the Nodes field if non-nil, zero value otherwise.

### GetNodesOk

`func (o *V10NodeHardware) GetNodesOk() (*[]V10NodeHardwareNode, bool)`

GetNodesOk returns a tuple with the Nodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodes

`func (o *V10NodeHardware) SetNodes(v []V10NodeHardwareNode)`

SetNodes sets Nodes field to given value.

### HasNodes

`func (o *V10NodeHardware) HasNodes() bool`

HasNodes returns a boolean if a field has been set.

### GetTotal

`func (o *V10NodeHardware) GetTotal() int32`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V10NodeHardware) GetTotalOk() (*int32, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V10NodeHardware) SetTotal(v int32)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V10NodeHardware) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


