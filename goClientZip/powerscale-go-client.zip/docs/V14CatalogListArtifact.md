# V14CatalogListArtifact

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ContentType** | Pointer to **string** | the type of upgrade | [optional] 
**Desc** | Pointer to **string** | description of pacakge | [optional] 
**Hash** | Pointer to **string** | hash associated with artifact | [optional] 
**OnefsVersion** | Pointer to **int32** | onefs version | [optional] 
**Readme** | Pointer to **bool** | value describing that README file exists | [optional] 
**Reference** | Pointer to **string** | onefs component that references this entry. | [optional] 

## Methods

### NewV14CatalogListArtifact

`func NewV14CatalogListArtifact() *V14CatalogListArtifact`

NewV14CatalogListArtifact instantiates a new V14CatalogListArtifact object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14CatalogListArtifactWithDefaults

`func NewV14CatalogListArtifactWithDefaults() *V14CatalogListArtifact`

NewV14CatalogListArtifactWithDefaults instantiates a new V14CatalogListArtifact object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetContentType

`func (o *V14CatalogListArtifact) GetContentType() string`

GetContentType returns the ContentType field if non-nil, zero value otherwise.

### GetContentTypeOk

`func (o *V14CatalogListArtifact) GetContentTypeOk() (*string, bool)`

GetContentTypeOk returns a tuple with the ContentType field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetContentType

`func (o *V14CatalogListArtifact) SetContentType(v string)`

SetContentType sets ContentType field to given value.

### HasContentType

`func (o *V14CatalogListArtifact) HasContentType() bool`

HasContentType returns a boolean if a field has been set.

### GetDesc

`func (o *V14CatalogListArtifact) GetDesc() string`

GetDesc returns the Desc field if non-nil, zero value otherwise.

### GetDescOk

`func (o *V14CatalogListArtifact) GetDescOk() (*string, bool)`

GetDescOk returns a tuple with the Desc field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDesc

`func (o *V14CatalogListArtifact) SetDesc(v string)`

SetDesc sets Desc field to given value.

### HasDesc

`func (o *V14CatalogListArtifact) HasDesc() bool`

HasDesc returns a boolean if a field has been set.

### GetHash

`func (o *V14CatalogListArtifact) GetHash() string`

GetHash returns the Hash field if non-nil, zero value otherwise.

### GetHashOk

`func (o *V14CatalogListArtifact) GetHashOk() (*string, bool)`

GetHashOk returns a tuple with the Hash field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHash

`func (o *V14CatalogListArtifact) SetHash(v string)`

SetHash sets Hash field to given value.

### HasHash

`func (o *V14CatalogListArtifact) HasHash() bool`

HasHash returns a boolean if a field has been set.

### GetOnefsVersion

`func (o *V14CatalogListArtifact) GetOnefsVersion() int32`

GetOnefsVersion returns the OnefsVersion field if non-nil, zero value otherwise.

### GetOnefsVersionOk

`func (o *V14CatalogListArtifact) GetOnefsVersionOk() (*int32, bool)`

GetOnefsVersionOk returns a tuple with the OnefsVersion field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOnefsVersion

`func (o *V14CatalogListArtifact) SetOnefsVersion(v int32)`

SetOnefsVersion sets OnefsVersion field to given value.

### HasOnefsVersion

`func (o *V14CatalogListArtifact) HasOnefsVersion() bool`

HasOnefsVersion returns a boolean if a field has been set.

### GetReadme

`func (o *V14CatalogListArtifact) GetReadme() bool`

GetReadme returns the Readme field if non-nil, zero value otherwise.

### GetReadmeOk

`func (o *V14CatalogListArtifact) GetReadmeOk() (*bool, bool)`

GetReadmeOk returns a tuple with the Readme field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReadme

`func (o *V14CatalogListArtifact) SetReadme(v bool)`

SetReadme sets Readme field to given value.

### HasReadme

`func (o *V14CatalogListArtifact) HasReadme() bool`

HasReadme returns a boolean if a field has been set.

### GetReference

`func (o *V14CatalogListArtifact) GetReference() string`

GetReference returns the Reference field if non-nil, zero value otherwise.

### GetReferenceOk

`func (o *V14CatalogListArtifact) GetReferenceOk() (*string, bool)`

GetReferenceOk returns a tuple with the Reference field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetReference

`func (o *V14CatalogListArtifact) SetReference(v string)`

SetReference sets Reference field to given value.

### HasReference

`func (o *V14CatalogListArtifact) HasReference() bool`

HasReference returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


