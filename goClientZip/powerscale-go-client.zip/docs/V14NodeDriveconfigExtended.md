# V14NodeDriveconfigExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AutomaticReplacementRecognition** | Pointer to [**V10ClusterNodeDriveDConfigAutomaticReplacementRecognition**](V10ClusterNodeDriveDConfigAutomaticReplacementRecognition.md) |  | [optional] 
**InstantSecureErase** | Pointer to [**V10ClusterNodeDriveDConfigInstantSecureErase**](V10ClusterNodeDriveDConfigInstantSecureErase.md) |  | [optional] 
**Stall** | Pointer to [**V14NodeDriveconfigStall**](V14NodeDriveconfigStall.md) |  | [optional] 

## Methods

### NewV14NodeDriveconfigExtended

`func NewV14NodeDriveconfigExtended() *V14NodeDriveconfigExtended`

NewV14NodeDriveconfigExtended instantiates a new V14NodeDriveconfigExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14NodeDriveconfigExtendedWithDefaults

`func NewV14NodeDriveconfigExtendedWithDefaults() *V14NodeDriveconfigExtended`

NewV14NodeDriveconfigExtendedWithDefaults instantiates a new V14NodeDriveconfigExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAutomaticReplacementRecognition

`func (o *V14NodeDriveconfigExtended) GetAutomaticReplacementRecognition() V10ClusterNodeDriveDConfigAutomaticReplacementRecognition`

GetAutomaticReplacementRecognition returns the AutomaticReplacementRecognition field if non-nil, zero value otherwise.

### GetAutomaticReplacementRecognitionOk

`func (o *V14NodeDriveconfigExtended) GetAutomaticReplacementRecognitionOk() (*V10ClusterNodeDriveDConfigAutomaticReplacementRecognition, bool)`

GetAutomaticReplacementRecognitionOk returns a tuple with the AutomaticReplacementRecognition field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAutomaticReplacementRecognition

`func (o *V14NodeDriveconfigExtended) SetAutomaticReplacementRecognition(v V10ClusterNodeDriveDConfigAutomaticReplacementRecognition)`

SetAutomaticReplacementRecognition sets AutomaticReplacementRecognition field to given value.

### HasAutomaticReplacementRecognition

`func (o *V14NodeDriveconfigExtended) HasAutomaticReplacementRecognition() bool`

HasAutomaticReplacementRecognition returns a boolean if a field has been set.

### GetInstantSecureErase

`func (o *V14NodeDriveconfigExtended) GetInstantSecureErase() V10ClusterNodeDriveDConfigInstantSecureErase`

GetInstantSecureErase returns the InstantSecureErase field if non-nil, zero value otherwise.

### GetInstantSecureEraseOk

`func (o *V14NodeDriveconfigExtended) GetInstantSecureEraseOk() (*V10ClusterNodeDriveDConfigInstantSecureErase, bool)`

GetInstantSecureEraseOk returns a tuple with the InstantSecureErase field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInstantSecureErase

`func (o *V14NodeDriveconfigExtended) SetInstantSecureErase(v V10ClusterNodeDriveDConfigInstantSecureErase)`

SetInstantSecureErase sets InstantSecureErase field to given value.

### HasInstantSecureErase

`func (o *V14NodeDriveconfigExtended) HasInstantSecureErase() bool`

HasInstantSecureErase returns a boolean if a field has been set.

### GetStall

`func (o *V14NodeDriveconfigExtended) GetStall() V14NodeDriveconfigStall`

GetStall returns the Stall field if non-nil, zero value otherwise.

### GetStallOk

`func (o *V14NodeDriveconfigExtended) GetStallOk() (*V14NodeDriveconfigStall, bool)`

GetStallOk returns a tuple with the Stall field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStall

`func (o *V14NodeDriveconfigExtended) SetStall(v V14NodeDriveconfigStall)`

SetStall sets Stall field to given value.

### HasStall

`func (o *V14NodeDriveconfigExtended) HasStall() bool`

HasStall returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


