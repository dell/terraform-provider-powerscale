# V12EventSettingsSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**HeartbeatInterval** | Pointer to **string** | Interval between heartbeat events. \&quot;daily\&quot;, \&quot;weekly\&quot;, or \&quot;monthly\&quot;. | [optional] 
**RetentionDays** | Pointer to **int32** | Retention period in days. | [optional] 
**StorageLimit** | Pointer to **int32** | Storage limit in megabytes per terabyte of available storage. | [optional] 

## Methods

### NewV12EventSettingsSettings

`func NewV12EventSettingsSettings() *V12EventSettingsSettings`

NewV12EventSettingsSettings instantiates a new V12EventSettingsSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventSettingsSettingsWithDefaults

`func NewV12EventSettingsSettingsWithDefaults() *V12EventSettingsSettings`

NewV12EventSettingsSettingsWithDefaults instantiates a new V12EventSettingsSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetHeartbeatInterval

`func (o *V12EventSettingsSettings) GetHeartbeatInterval() string`

GetHeartbeatInterval returns the HeartbeatInterval field if non-nil, zero value otherwise.

### GetHeartbeatIntervalOk

`func (o *V12EventSettingsSettings) GetHeartbeatIntervalOk() (*string, bool)`

GetHeartbeatIntervalOk returns a tuple with the HeartbeatInterval field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHeartbeatInterval

`func (o *V12EventSettingsSettings) SetHeartbeatInterval(v string)`

SetHeartbeatInterval sets HeartbeatInterval field to given value.

### HasHeartbeatInterval

`func (o *V12EventSettingsSettings) HasHeartbeatInterval() bool`

HasHeartbeatInterval returns a boolean if a field has been set.

### GetRetentionDays

`func (o *V12EventSettingsSettings) GetRetentionDays() int32`

GetRetentionDays returns the RetentionDays field if non-nil, zero value otherwise.

### GetRetentionDaysOk

`func (o *V12EventSettingsSettings) GetRetentionDaysOk() (*int32, bool)`

GetRetentionDaysOk returns a tuple with the RetentionDays field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRetentionDays

`func (o *V12EventSettingsSettings) SetRetentionDays(v int32)`

SetRetentionDays sets RetentionDays field to given value.

### HasRetentionDays

`func (o *V12EventSettingsSettings) HasRetentionDays() bool`

HasRetentionDays returns a boolean if a field has been set.

### GetStorageLimit

`func (o *V12EventSettingsSettings) GetStorageLimit() int32`

GetStorageLimit returns the StorageLimit field if non-nil, zero value otherwise.

### GetStorageLimitOk

`func (o *V12EventSettingsSettings) GetStorageLimitOk() (*int32, bool)`

GetStorageLimitOk returns a tuple with the StorageLimit field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStorageLimit

`func (o *V12EventSettingsSettings) SetStorageLimit(v int32)`

SetStorageLimit sets StorageLimit field to given value.

### HasStorageLimit

`func (o *V12EventSettingsSettings) HasStorageLimit() bool`

HasStorageLimit returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


