# V12EventEventgroupOccurrencesExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Eventgroups** | Pointer to [**[]V12EventEventgroupOccurrencesEventgroup**](V12EventEventgroupOccurrencesEventgroup.md) |  | [optional] 

## Methods

### NewV12EventEventgroupOccurrencesExtendedExtended

`func NewV12EventEventgroupOccurrencesExtendedExtended() *V12EventEventgroupOccurrencesExtendedExtended`

NewV12EventEventgroupOccurrencesExtendedExtended instantiates a new V12EventEventgroupOccurrencesExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12EventEventgroupOccurrencesExtendedExtendedWithDefaults

`func NewV12EventEventgroupOccurrencesExtendedExtendedWithDefaults() *V12EventEventgroupOccurrencesExtendedExtended`

NewV12EventEventgroupOccurrencesExtendedExtendedWithDefaults instantiates a new V12EventEventgroupOccurrencesExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEventgroups

`func (o *V12EventEventgroupOccurrencesExtendedExtended) GetEventgroups() []V12EventEventgroupOccurrencesEventgroup`

GetEventgroups returns the Eventgroups field if non-nil, zero value otherwise.

### GetEventgroupsOk

`func (o *V12EventEventgroupOccurrencesExtendedExtended) GetEventgroupsOk() (*[]V12EventEventgroupOccurrencesEventgroup, bool)`

GetEventgroupsOk returns a tuple with the Eventgroups field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEventgroups

`func (o *V12EventEventgroupOccurrencesExtendedExtended) SetEventgroups(v []V12EventEventgroupOccurrencesEventgroup)`

SetEventgroups sets Eventgroups field to given value.

### HasEventgroups

`func (o *V12EventEventgroupOccurrencesExtendedExtended) HasEventgroups() bool`

HasEventgroups returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


