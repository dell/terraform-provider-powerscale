# \ClusterNodesApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreateClusterNodesv3DrivesDriveAddItem**](ClusterNodesApi.md#CreateClusterNodesv3DrivesDriveAddItem) | **Post** /platform/3/cluster/nodes/{Lnn}/drives/{Driveid}/add | 
[**CreateClusterNodesv3DrivesDriveFirmwareUpdateItem**](ClusterNodesApi.md#CreateClusterNodesv3DrivesDriveFirmwareUpdateItem) | **Post** /platform/3/cluster/nodes/{Lnn}/drives/{Driveid}/firmware/update | 
[**CreateClusterNodesv3DrivesDriveFormatItem**](ClusterNodesApi.md#CreateClusterNodesv3DrivesDriveFormatItem) | **Post** /platform/3/cluster/nodes/{Lnn}/drives/{Driveid}/format | 
[**CreateClusterNodesv3DrivesDrivePurposeItem**](ClusterNodesApi.md#CreateClusterNodesv3DrivesDrivePurposeItem) | **Post** /platform/3/cluster/nodes/{Lnn}/drives/{Driveid}/purpose | 
[**CreateClusterNodesv3DrivesDriveSmartfailItem**](ClusterNodesApi.md#CreateClusterNodesv3DrivesDriveSmartfailItem) | **Post** /platform/3/cluster/nodes/{Lnn}/drives/{Driveid}/smartfail | 
[**CreateClusterNodesv3DrivesDriveStopfailItem**](ClusterNodesApi.md#CreateClusterNodesv3DrivesDriveStopfailItem) | **Post** /platform/3/cluster/nodes/{Lnn}/drives/{Driveid}/stopfail | 
[**CreateClusterNodesv3DrivesDriveSuspendItem**](ClusterNodesApi.md#CreateClusterNodesv3DrivesDriveSuspendItem) | **Post** /platform/3/cluster/nodes/{Lnn}/drives/{Driveid}/suspend | 
[**CreateClusterNodesv3NodeRebootItem**](ClusterNodesApi.md#CreateClusterNodesv3NodeRebootItem) | **Post** /platform/3/cluster/nodes/{Lnn}/reboot | 
[**CreateClusterNodesv3NodeShutdownItem**](ClusterNodesApi.md#CreateClusterNodesv3NodeShutdownItem) | **Post** /platform/3/cluster/nodes/{Lnn}/shutdown | 
[**CreateClusterNodesv5NodeRebootItem**](ClusterNodesApi.md#CreateClusterNodesv5NodeRebootItem) | **Post** /platform/5/cluster/nodes/{Lnn}/reboot | 
[**CreateClusterNodesv5NodeShutdownItem**](ClusterNodesApi.md#CreateClusterNodesv5NodeShutdownItem) | **Post** /platform/5/cluster/nodes/{Lnn}/shutdown | 
[**GetClusterNodesv10NodeHardware**](ClusterNodesApi.md#GetClusterNodesv10NodeHardware) | **Get** /platform/10/cluster/nodes/{Lnn}/hardware | 
[**GetClusterNodesv10NodeStatusCpu**](ClusterNodesApi.md#GetClusterNodesv10NodeStatusCpu) | **Get** /platform/10/cluster/nodes/{Lnn}/status/cpu | 
[**GetClusterNodesv10NodeStatusNvram**](ClusterNodesApi.md#GetClusterNodesv10NodeStatusNvram) | **Get** /platform/10/cluster/nodes/{Lnn}/status/nvram | 
[**GetClusterNodesv10NodeStatusPowersupplies**](ClusterNodesApi.md#GetClusterNodesv10NodeStatusPowersupplies) | **Get** /platform/10/cluster/nodes/{Lnn}/status/powersupplies | 
[**GetClusterNodesv12NodeHardware**](ClusterNodesApi.md#GetClusterNodesv12NodeHardware) | **Get** /platform/12/cluster/nodes/{Lnn}/hardware | 
[**GetClusterNodesv12NodeState**](ClusterNodesApi.md#GetClusterNodesv12NodeState) | **Get** /platform/12/cluster/nodes/{Lnn}/state | 
[**GetClusterNodesv12NodeStateServicelight**](ClusterNodesApi.md#GetClusterNodesv12NodeStateServicelight) | **Get** /platform/12/cluster/nodes/{Lnn}/state/servicelight | 
[**GetClusterNodesv12NodeStatus**](ClusterNodesApi.md#GetClusterNodesv12NodeStatus) | **Get** /platform/12/cluster/nodes/{Lnn}/status | 
[**GetClusterNodesv12NodeStatusNvram**](ClusterNodesApi.md#GetClusterNodesv12NodeStatusNvram) | **Get** /platform/12/cluster/nodes/{Lnn}/status/nvram | 
[**GetClusterNodesv12NodeStatusPowersupplies**](ClusterNodesApi.md#GetClusterNodesv12NodeStatusPowersupplies) | **Get** /platform/12/cluster/nodes/{Lnn}/status/powersupplies | 
[**GetClusterNodesv14NodeDriveconfig**](ClusterNodesApi.md#GetClusterNodesv14NodeDriveconfig) | **Get** /platform/14/cluster/nodes/{Lnn}/driveconfig | 
[**GetClusterNodesv15NodeDrives**](ClusterNodesApi.md#GetClusterNodesv15NodeDrives) | **Get** /platform/15/cluster/nodes/{Lnn}/drives | 
[**GetClusterNodesv3DrivesDriveFirmware**](ClusterNodesApi.md#GetClusterNodesv3DrivesDriveFirmware) | **Get** /platform/3/cluster/nodes/{Lnn}/drives/{Driveid}/firmware | 
[**GetClusterNodesv3NodeDrives**](ClusterNodesApi.md#GetClusterNodesv3NodeDrives) | **Get** /platform/3/cluster/nodes/{Lnn}/drives | 
[**GetClusterNodesv3NodeDrivesPurposelist**](ClusterNodesApi.md#GetClusterNodesv3NodeDrivesPurposelist) | **Get** /platform/3/cluster/nodes/{Lnn}/drives-purposelist | 
[**GetClusterNodesv3NodeHardware**](ClusterNodesApi.md#GetClusterNodesv3NodeHardware) | **Get** /platform/3/cluster/nodes/{Lnn}/hardware | 
[**GetClusterNodesv3NodeHardwareFast**](ClusterNodesApi.md#GetClusterNodesv3NodeHardwareFast) | **Get** /platform/3/cluster/nodes/{Lnn}/hardware-fast | 
[**GetClusterNodesv3NodePartitions**](ClusterNodesApi.md#GetClusterNodesv3NodePartitions) | **Get** /platform/3/cluster/nodes/{Lnn}/partitions | 
[**GetClusterNodesv3NodeSensors**](ClusterNodesApi.md#GetClusterNodesv3NodeSensors) | **Get** /platform/3/cluster/nodes/{Lnn}/sensors | 
[**GetClusterNodesv3NodeState**](ClusterNodesApi.md#GetClusterNodesv3NodeState) | **Get** /platform/3/cluster/nodes/{Lnn}/state | 
[**GetClusterNodesv3NodeStateReadonly**](ClusterNodesApi.md#GetClusterNodesv3NodeStateReadonly) | **Get** /platform/3/cluster/nodes/{Lnn}/state/readonly | 
[**GetClusterNodesv3NodeStateServicelight**](ClusterNodesApi.md#GetClusterNodesv3NodeStateServicelight) | **Get** /platform/3/cluster/nodes/{Lnn}/state/servicelight | 
[**GetClusterNodesv3NodeStateSmartfail**](ClusterNodesApi.md#GetClusterNodesv3NodeStateSmartfail) | **Get** /platform/3/cluster/nodes/{Lnn}/state/smartfail | 
[**GetClusterNodesv3NodeStatus**](ClusterNodesApi.md#GetClusterNodesv3NodeStatus) | **Get** /platform/3/cluster/nodes/{Lnn}/status | 
[**GetClusterNodesv3NodeStatusBatterystatus**](ClusterNodesApi.md#GetClusterNodesv3NodeStatusBatterystatus) | **Get** /platform/3/cluster/nodes/{Lnn}/status/batterystatus | 
[**GetClusterNodesv5NodeDriveconfig**](ClusterNodesApi.md#GetClusterNodesv5NodeDriveconfig) | **Get** /platform/5/cluster/nodes/{Lnn}/driveconfig | 
[**GetClusterNodesv5NodeDrives**](ClusterNodesApi.md#GetClusterNodesv5NodeDrives) | **Get** /platform/5/cluster/nodes/{Lnn}/drives | 
[**GetClusterNodesv5NodeHardware**](ClusterNodesApi.md#GetClusterNodesv5NodeHardware) | **Get** /platform/5/cluster/nodes/{Lnn}/hardware | 
[**GetClusterNodesv5NodeSleds**](ClusterNodesApi.md#GetClusterNodesv5NodeSleds) | **Get** /platform/5/cluster/nodes/{Lnn}/sleds | 
[**GetClusterNodesv7DrivesDriveFirmware**](ClusterNodesApi.md#GetClusterNodesv7DrivesDriveFirmware) | **Get** /platform/7/cluster/nodes/{Lnn}/drives/{Driveid}/firmware | 
[**GetClusterNodesv7NodeDriveconfig**](ClusterNodesApi.md#GetClusterNodesv7NodeDriveconfig) | **Get** /platform/7/cluster/nodes/{Lnn}/driveconfig | 
[**GetClusterNodesv7NodeDrives**](ClusterNodesApi.md#GetClusterNodesv7NodeDrives) | **Get** /platform/7/cluster/nodes/{Lnn}/drives | 
[**GetClusterNodesv7NodeInternalIpAddress**](ClusterNodesApi.md#GetClusterNodesv7NodeInternalIpAddress) | **Get** /platform/7/cluster/nodes/{Lnn}/internal-ip-address | 
[**ListClusterNodesv3DrivesDriveFirmwareUpdate**](ClusterNodesApi.md#ListClusterNodesv3DrivesDriveFirmwareUpdate) | **Get** /platform/3/cluster/nodes/{Lnn}/drives/{Driveid}/firmware/update | 
[**UpdateClusterNodesv12NodeStateServicelight**](ClusterNodesApi.md#UpdateClusterNodesv12NodeStateServicelight) | **Put** /platform/12/cluster/nodes/{Lnn}/state/servicelight | 
[**UpdateClusterNodesv14NodeDriveconfig**](ClusterNodesApi.md#UpdateClusterNodesv14NodeDriveconfig) | **Put** /platform/14/cluster/nodes/{Lnn}/driveconfig | 
[**UpdateClusterNodesv3NodeStateReadonly**](ClusterNodesApi.md#UpdateClusterNodesv3NodeStateReadonly) | **Put** /platform/3/cluster/nodes/{Lnn}/state/readonly | 
[**UpdateClusterNodesv3NodeStateServicelight**](ClusterNodesApi.md#UpdateClusterNodesv3NodeStateServicelight) | **Put** /platform/3/cluster/nodes/{Lnn}/state/servicelight | 
[**UpdateClusterNodesv3NodeStateSmartfail**](ClusterNodesApi.md#UpdateClusterNodesv3NodeStateSmartfail) | **Put** /platform/3/cluster/nodes/{Lnn}/state/smartfail | 
[**UpdateClusterNodesv5NodeDriveconfig**](ClusterNodesApi.md#UpdateClusterNodesv5NodeDriveconfig) | **Put** /platform/5/cluster/nodes/{Lnn}/driveconfig | 
[**UpdateClusterNodesv7NodeDriveconfig**](ClusterNodesApi.md#UpdateClusterNodesv7NodeDriveconfig) | **Put** /platform/7/cluster/nodes/{Lnn}/driveconfig | 



## CreateClusterNodesv3DrivesDriveAddItem

> map[string]interface{} CreateClusterNodesv3DrivesDriveAddItem(ctx, lnn, driveid).V3DrivesDriveAddItem(v3DrivesDriveAddItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    driveid := "driveid_example" // string | 
    v3DrivesDriveAddItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv3DrivesDriveAddItem(context.Background(), lnn, driveid).V3DrivesDriveAddItem(v3DrivesDriveAddItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv3DrivesDriveAddItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv3DrivesDriveAddItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv3DrivesDriveAddItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 
**driveid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv3DrivesDriveAddItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v3DrivesDriveAddItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterNodesv3DrivesDriveFirmwareUpdateItem

> map[string]interface{} CreateClusterNodesv3DrivesDriveFirmwareUpdateItem(ctx, lnn, driveid).V3DrivesDriveFirmwareUpdateItem(v3DrivesDriveFirmwareUpdateItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    driveid := "driveid_example" // string | 
    v3DrivesDriveFirmwareUpdateItem := *openapiclient.NewV3DrivesDriveFirmwareUpdateItem(false) // V3DrivesDriveFirmwareUpdateItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv3DrivesDriveFirmwareUpdateItem(context.Background(), lnn, driveid).V3DrivesDriveFirmwareUpdateItem(v3DrivesDriveFirmwareUpdateItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv3DrivesDriveFirmwareUpdateItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv3DrivesDriveFirmwareUpdateItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv3DrivesDriveFirmwareUpdateItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 
**driveid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv3DrivesDriveFirmwareUpdateItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v3DrivesDriveFirmwareUpdateItem** | [**V3DrivesDriveFirmwareUpdateItem**](V3DrivesDriveFirmwareUpdateItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterNodesv3DrivesDriveFormatItem

> map[string]interface{} CreateClusterNodesv3DrivesDriveFormatItem(ctx, lnn, driveid).V3DrivesDriveFormatItem(v3DrivesDriveFormatItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    driveid := "driveid_example" // string | 
    v3DrivesDriveFormatItem := *openapiclient.NewV3DrivesDriveFormatItem() // V3DrivesDriveFormatItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv3DrivesDriveFormatItem(context.Background(), lnn, driveid).V3DrivesDriveFormatItem(v3DrivesDriveFormatItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv3DrivesDriveFormatItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv3DrivesDriveFormatItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv3DrivesDriveFormatItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 
**driveid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv3DrivesDriveFormatItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v3DrivesDriveFormatItem** | [**V3DrivesDriveFormatItem**](V3DrivesDriveFormatItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterNodesv3DrivesDrivePurposeItem

> map[string]interface{} CreateClusterNodesv3DrivesDrivePurposeItem(ctx, lnn, driveid).V3DrivesDrivePurposeItem(v3DrivesDrivePurposeItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    driveid := "driveid_example" // string | 
    v3DrivesDrivePurposeItem := *openapiclient.NewV3DrivesDrivePurposeItem("Purpose_example") // V3DrivesDrivePurposeItem | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv3DrivesDrivePurposeItem(context.Background(), lnn, driveid).V3DrivesDrivePurposeItem(v3DrivesDrivePurposeItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv3DrivesDrivePurposeItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv3DrivesDrivePurposeItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv3DrivesDrivePurposeItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 
**driveid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv3DrivesDrivePurposeItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v3DrivesDrivePurposeItem** | [**V3DrivesDrivePurposeItem**](V3DrivesDrivePurposeItem.md) |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterNodesv3DrivesDriveSmartfailItem

> map[string]interface{} CreateClusterNodesv3DrivesDriveSmartfailItem(ctx, lnn, driveid).V3DrivesDriveSmartfailItem(v3DrivesDriveSmartfailItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    driveid := "driveid_example" // string | 
    v3DrivesDriveSmartfailItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv3DrivesDriveSmartfailItem(context.Background(), lnn, driveid).V3DrivesDriveSmartfailItem(v3DrivesDriveSmartfailItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv3DrivesDriveSmartfailItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv3DrivesDriveSmartfailItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv3DrivesDriveSmartfailItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 
**driveid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv3DrivesDriveSmartfailItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v3DrivesDriveSmartfailItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterNodesv3DrivesDriveStopfailItem

> map[string]interface{} CreateClusterNodesv3DrivesDriveStopfailItem(ctx, lnn, driveid).V3DrivesDriveStopfailItem(v3DrivesDriveStopfailItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    driveid := "driveid_example" // string | 
    v3DrivesDriveStopfailItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv3DrivesDriveStopfailItem(context.Background(), lnn, driveid).V3DrivesDriveStopfailItem(v3DrivesDriveStopfailItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv3DrivesDriveStopfailItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv3DrivesDriveStopfailItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv3DrivesDriveStopfailItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 
**driveid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv3DrivesDriveStopfailItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v3DrivesDriveStopfailItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterNodesv3DrivesDriveSuspendItem

> map[string]interface{} CreateClusterNodesv3DrivesDriveSuspendItem(ctx, lnn, driveid).V3DrivesDriveSuspendItem(v3DrivesDriveSuspendItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    driveid := "driveid_example" // string | 
    v3DrivesDriveSuspendItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv3DrivesDriveSuspendItem(context.Background(), lnn, driveid).V3DrivesDriveSuspendItem(v3DrivesDriveSuspendItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv3DrivesDriveSuspendItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv3DrivesDriveSuspendItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv3DrivesDriveSuspendItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 
**driveid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv3DrivesDriveSuspendItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **v3DrivesDriveSuspendItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterNodesv3NodeRebootItem

> map[string]interface{} CreateClusterNodesv3NodeRebootItem(ctx, lnn).V3NodeRebootItem(v3NodeRebootItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v3NodeRebootItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv3NodeRebootItem(context.Background(), lnn).V3NodeRebootItem(v3NodeRebootItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv3NodeRebootItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv3NodeRebootItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv3NodeRebootItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv3NodeRebootItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3NodeRebootItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterNodesv3NodeShutdownItem

> map[string]interface{} CreateClusterNodesv3NodeShutdownItem(ctx, lnn).V3NodeShutdownItem(v3NodeShutdownItem).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v3NodeShutdownItem := map[string]interface{}{ ... } // map[string]interface{} | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv3NodeShutdownItem(context.Background(), lnn).V3NodeShutdownItem(v3NodeShutdownItem).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv3NodeShutdownItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv3NodeShutdownItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv3NodeShutdownItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv3NodeShutdownItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3NodeShutdownItem** | **map[string]interface{}** |  | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterNodesv5NodeRebootItem

> map[string]interface{} CreateClusterNodesv5NodeRebootItem(ctx, lnn).V5NodeRebootItem(v5NodeRebootItem).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v5NodeRebootItem := map[string]interface{}{ ... } // map[string]interface{} | 
    force := true // bool | Force reboot on Infinity platform even if a drive sled is not present. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv5NodeRebootItem(context.Background(), lnn).V5NodeRebootItem(v5NodeRebootItem).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv5NodeRebootItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv5NodeRebootItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv5NodeRebootItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv5NodeRebootItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v5NodeRebootItem** | **map[string]interface{}** |  | 
 **force** | **bool** | Force reboot on Infinity platform even if a drive sled is not present. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreateClusterNodesv5NodeShutdownItem

> map[string]interface{} CreateClusterNodesv5NodeShutdownItem(ctx, lnn).V5NodeShutdownItem(v5NodeShutdownItem).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v5NodeShutdownItem := map[string]interface{}{ ... } // map[string]interface{} | 
    force := true // bool | Force shutdown on Infinity platform even if a drive sled is not present. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.CreateClusterNodesv5NodeShutdownItem(context.Background(), lnn).V5NodeShutdownItem(v5NodeShutdownItem).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.CreateClusterNodesv5NodeShutdownItem``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreateClusterNodesv5NodeShutdownItem`: map[string]interface{}
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.CreateClusterNodesv5NodeShutdownItem`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreateClusterNodesv5NodeShutdownItemRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v5NodeShutdownItem** | **map[string]interface{}** |  | 
 **force** | **bool** | Force shutdown on Infinity platform even if a drive sled is not present. | 

### Return type

**map[string]interface{}**

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv10NodeHardware

> V10NodeHardware GetClusterNodesv10NodeHardware(ctx, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv10NodeHardware(context.Background(), lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv10NodeHardware``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv10NodeHardware`: V10NodeHardware
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv10NodeHardware`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv10NodeHardwareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V10NodeHardware**](V10NodeHardware.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv10NodeStatusCpu

> V10NodeStatusCpu GetClusterNodesv10NodeStatusCpu(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv10NodeStatusCpu(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv10NodeStatusCpu``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv10NodeStatusCpu`: V10NodeStatusCpu
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv10NodeStatusCpu`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv10NodeStatusCpuRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10NodeStatusCpu**](V10NodeStatusCpu.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv10NodeStatusNvram

> V10NodeStatusNvram GetClusterNodesv10NodeStatusNvram(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv10NodeStatusNvram(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv10NodeStatusNvram``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv10NodeStatusNvram`: V10NodeStatusNvram
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv10NodeStatusNvram`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv10NodeStatusNvramRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10NodeStatusNvram**](V10NodeStatusNvram.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv10NodeStatusPowersupplies

> V10NodeStatusPowersupplies GetClusterNodesv10NodeStatusPowersupplies(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv10NodeStatusPowersupplies(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv10NodeStatusPowersupplies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv10NodeStatusPowersupplies`: V10NodeStatusPowersupplies
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv10NodeStatusPowersupplies`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv10NodeStatusPowersuppliesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V10NodeStatusPowersupplies**](V10NodeStatusPowersupplies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv12NodeHardware

> V12NodeHardware GetClusterNodesv12NodeHardware(ctx, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv12NodeHardware(context.Background(), lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv12NodeHardware``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv12NodeHardware`: V12NodeHardware
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv12NodeHardware`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv12NodeHardwareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V12NodeHardware**](V12NodeHardware.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv12NodeState

> V12NodeState GetClusterNodesv12NodeState(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv12NodeState(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv12NodeState``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv12NodeState`: V12NodeState
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv12NodeState`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv12NodeStateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12NodeState**](V12NodeState.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv12NodeStateServicelight

> V12NodeStateServicelight GetClusterNodesv12NodeStateServicelight(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv12NodeStateServicelight(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv12NodeStateServicelight``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv12NodeStateServicelight`: V12NodeStateServicelight
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv12NodeStateServicelight`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv12NodeStateServicelightRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12NodeStateServicelight**](V12NodeStateServicelight.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv12NodeStatus

> V12NodeStatus GetClusterNodesv12NodeStatus(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv12NodeStatus(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv12NodeStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv12NodeStatus`: V12NodeStatus
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv12NodeStatus`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv12NodeStatusRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12NodeStatus**](V12NodeStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv12NodeStatusNvram

> V12NodeStatusNvram GetClusterNodesv12NodeStatusNvram(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv12NodeStatusNvram(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv12NodeStatusNvram``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv12NodeStatusNvram`: V12NodeStatusNvram
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv12NodeStatusNvram`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv12NodeStatusNvramRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12NodeStatusNvram**](V12NodeStatusNvram.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv12NodeStatusPowersupplies

> V12NodeStatusPowersupplies GetClusterNodesv12NodeStatusPowersupplies(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv12NodeStatusPowersupplies(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv12NodeStatusPowersupplies``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv12NodeStatusPowersupplies`: V12NodeStatusPowersupplies
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv12NodeStatusPowersupplies`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv12NodeStatusPowersuppliesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V12NodeStatusPowersupplies**](V12NodeStatusPowersupplies.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv14NodeDriveconfig

> V14NodeDriveconfig GetClusterNodesv14NodeDriveconfig(ctx, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv14NodeDriveconfig(context.Background(), lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv14NodeDriveconfig``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv14NodeDriveconfig`: V14NodeDriveconfig
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv14NodeDriveconfig`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv14NodeDriveconfigRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V14NodeDriveconfig**](V14NodeDriveconfig.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv15NodeDrives

> V15NodeDrives GetClusterNodesv15NodeDrives(ctx, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv15NodeDrives(context.Background(), lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv15NodeDrives``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv15NodeDrives`: V15NodeDrives
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv15NodeDrives`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv15NodeDrivesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V15NodeDrives**](V15NodeDrives.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3DrivesDriveFirmware

> V3DrivesDriveFirmware GetClusterNodesv3DrivesDriveFirmware(ctx, lnn, driveid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    driveid := "driveid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3DrivesDriveFirmware(context.Background(), lnn, driveid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3DrivesDriveFirmware``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3DrivesDriveFirmware`: V3DrivesDriveFirmware
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3DrivesDriveFirmware`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 
**driveid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3DrivesDriveFirmwareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V3DrivesDriveFirmware**](V3DrivesDriveFirmware.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeDrives

> V3NodeDrives GetClusterNodesv3NodeDrives(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeDrives(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeDrives``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeDrives`: V3NodeDrives
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeDrives`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeDrivesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeDrives**](V3NodeDrives.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeDrivesPurposelist

> V3NodeDrivesPurposelist GetClusterNodesv3NodeDrivesPurposelist(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeDrivesPurposelist(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeDrivesPurposelist``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeDrivesPurposelist`: V3NodeDrivesPurposelist
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeDrivesPurposelist`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeDrivesPurposelistRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeDrivesPurposelist**](V3NodeDrivesPurposelist.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeHardware

> V3NodeHardware GetClusterNodesv3NodeHardware(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeHardware(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeHardware``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeHardware`: V3NodeHardware
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeHardware`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeHardwareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeHardware**](V3NodeHardware.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeHardwareFast

> V3NodeHardwareFast GetClusterNodesv3NodeHardwareFast(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeHardwareFast(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeHardwareFast``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeHardwareFast`: V3NodeHardwareFast
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeHardwareFast`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeHardwareFastRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeHardwareFast**](V3NodeHardwareFast.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodePartitions

> V3NodePartitions GetClusterNodesv3NodePartitions(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodePartitions(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodePartitions``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodePartitions`: V3NodePartitions
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodePartitions`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodePartitionsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodePartitions**](V3NodePartitions.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeSensors

> V3NodeSensors GetClusterNodesv3NodeSensors(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeSensors(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeSensors``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeSensors`: V3NodeSensors
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeSensors`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeSensorsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeSensors**](V3NodeSensors.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeState

> V3NodeState GetClusterNodesv3NodeState(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeState(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeState``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeState`: V3NodeState
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeState`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeStateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeState**](V3NodeState.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeStateReadonly

> V3NodeStateReadonly GetClusterNodesv3NodeStateReadonly(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeStateReadonly(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeStateReadonly``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeStateReadonly`: V3NodeStateReadonly
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeStateReadonly`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeStateReadonlyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeStateReadonly**](V3NodeStateReadonly.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeStateServicelight

> V3NodeStateServicelight GetClusterNodesv3NodeStateServicelight(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeStateServicelight(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeStateServicelight``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeStateServicelight`: V3NodeStateServicelight
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeStateServicelight`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeStateServicelightRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeStateServicelight**](V3NodeStateServicelight.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeStateSmartfail

> V3NodeStateSmartfail GetClusterNodesv3NodeStateSmartfail(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeStateSmartfail(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeStateSmartfail``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeStateSmartfail`: V3NodeStateSmartfail
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeStateSmartfail`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeStateSmartfailRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeStateSmartfail**](V3NodeStateSmartfail.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeStatus

> V3NodeStatus GetClusterNodesv3NodeStatus(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeStatus(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeStatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeStatus`: V3NodeStatus
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeStatus`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeStatusRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeStatus**](V3NodeStatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv3NodeStatusBatterystatus

> V3NodeStatusBatterystatus GetClusterNodesv3NodeStatusBatterystatus(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv3NodeStatusBatterystatus(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv3NodeStatusBatterystatus``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv3NodeStatusBatterystatus`: V3NodeStatusBatterystatus
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv3NodeStatusBatterystatus`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv3NodeStatusBatterystatusRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3NodeStatusBatterystatus**](V3NodeStatusBatterystatus.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv5NodeDriveconfig

> V5NodeDriveconfig GetClusterNodesv5NodeDriveconfig(ctx, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv5NodeDriveconfig(context.Background(), lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv5NodeDriveconfig``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv5NodeDriveconfig`: V5NodeDriveconfig
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv5NodeDriveconfig`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv5NodeDriveconfigRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V5NodeDriveconfig**](V5NodeDriveconfig.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv5NodeDrives

> V5NodeDrives GetClusterNodesv5NodeDrives(ctx, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv5NodeDrives(context.Background(), lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv5NodeDrives``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv5NodeDrives`: V5NodeDrives
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv5NodeDrives`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv5NodeDrivesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V5NodeDrives**](V5NodeDrives.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv5NodeHardware

> V5NodeHardware GetClusterNodesv5NodeHardware(ctx, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv5NodeHardware(context.Background(), lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv5NodeHardware``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv5NodeHardware`: V5NodeHardware
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv5NodeHardware`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv5NodeHardwareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V5NodeHardware**](V5NodeHardware.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv5NodeSleds

> V5NodeSleds GetClusterNodesv5NodeSleds(ctx, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv5NodeSleds(context.Background(), lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv5NodeSleds``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv5NodeSleds`: V5NodeSleds
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv5NodeSleds`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv5NodeSledsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V5NodeSleds**](V5NodeSleds.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv7DrivesDriveFirmware

> V3DrivesDriveFirmware GetClusterNodesv7DrivesDriveFirmware(ctx, lnn, driveid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    driveid := "driveid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv7DrivesDriveFirmware(context.Background(), lnn, driveid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv7DrivesDriveFirmware``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv7DrivesDriveFirmware`: V3DrivesDriveFirmware
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv7DrivesDriveFirmware`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 
**driveid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv7DrivesDriveFirmwareRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V3DrivesDriveFirmware**](V3DrivesDriveFirmware.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv7NodeDriveconfig

> V7NodeDriveconfig GetClusterNodesv7NodeDriveconfig(ctx, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv7NodeDriveconfig(context.Background(), lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv7NodeDriveconfig``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv7NodeDriveconfig`: V7NodeDriveconfig
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv7NodeDriveconfig`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv7NodeDriveconfigRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V7NodeDriveconfig**](V7NodeDriveconfig.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv7NodeDrives

> V7NodeDrives GetClusterNodesv7NodeDrives(ctx, lnn).Timeout(timeout).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    timeout := float32(8.14) // float32 | Request timeout (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv7NodeDrives(context.Background(), lnn).Timeout(timeout).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv7NodeDrives``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv7NodeDrives`: V7NodeDrives
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv7NodeDrives`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv7NodeDrivesRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **timeout** | **float32** | Request timeout | 

### Return type

[**V7NodeDrives**](V7NodeDrives.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetClusterNodesv7NodeInternalIpAddress

> V7NodeInternalIpAddress GetClusterNodesv7NodeInternalIpAddress(ctx, lnn).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.GetClusterNodesv7NodeInternalIpAddress(context.Background(), lnn).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.GetClusterNodesv7NodeInternalIpAddress``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetClusterNodesv7NodeInternalIpAddress`: V7NodeInternalIpAddress
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.GetClusterNodesv7NodeInternalIpAddress`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetClusterNodesv7NodeInternalIpAddressRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V7NodeInternalIpAddress**](V7NodeInternalIpAddress.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListClusterNodesv3DrivesDriveFirmwareUpdate

> V3DrivesDriveFirmwareUpdate ListClusterNodesv3DrivesDriveFirmwareUpdate(ctx, lnn, driveid).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    driveid := "driveid_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.ClusterNodesApi.ListClusterNodesv3DrivesDriveFirmwareUpdate(context.Background(), lnn, driveid).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.ListClusterNodesv3DrivesDriveFirmwareUpdate``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListClusterNodesv3DrivesDriveFirmwareUpdate`: V3DrivesDriveFirmwareUpdate
    fmt.Fprintf(os.Stdout, "Response from `ClusterNodesApi.ListClusterNodesv3DrivesDriveFirmwareUpdate`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 
**driveid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListClusterNodesv3DrivesDriveFirmwareUpdateRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



### Return type

[**V3DrivesDriveFirmwareUpdate**](V3DrivesDriveFirmwareUpdate.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterNodesv12NodeStateServicelight

> UpdateClusterNodesv12NodeStateServicelight(ctx, lnn).V12NodeStateServicelight(v12NodeStateServicelight).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v12NodeStateServicelight := *openapiclient.NewV12NodeStateServicelightExtended() // V12NodeStateServicelightExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterNodesApi.UpdateClusterNodesv12NodeStateServicelight(context.Background(), lnn).V12NodeStateServicelight(v12NodeStateServicelight).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.UpdateClusterNodesv12NodeStateServicelight``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterNodesv12NodeStateServicelightRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12NodeStateServicelight** | [**V12NodeStateServicelightExtended**](V12NodeStateServicelightExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterNodesv14NodeDriveconfig

> UpdateClusterNodesv14NodeDriveconfig(ctx, lnn).V14NodeDriveconfig(v14NodeDriveconfig).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v14NodeDriveconfig := *openapiclient.NewV14NodeDriveconfigExtended() // V14NodeDriveconfigExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterNodesApi.UpdateClusterNodesv14NodeDriveconfig(context.Background(), lnn).V14NodeDriveconfig(v14NodeDriveconfig).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.UpdateClusterNodesv14NodeDriveconfig``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterNodesv14NodeDriveconfigRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v14NodeDriveconfig** | [**V14NodeDriveconfigExtended**](V14NodeDriveconfigExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterNodesv3NodeStateReadonly

> UpdateClusterNodesv3NodeStateReadonly(ctx, lnn).V3NodeStateReadonly(v3NodeStateReadonly).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v3NodeStateReadonly := *openapiclient.NewV10ClusterNodeStateReadonly() // V10ClusterNodeStateReadonly | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterNodesApi.UpdateClusterNodesv3NodeStateReadonly(context.Background(), lnn).V3NodeStateReadonly(v3NodeStateReadonly).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.UpdateClusterNodesv3NodeStateReadonly``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterNodesv3NodeStateReadonlyRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3NodeStateReadonly** | [**V10ClusterNodeStateReadonly**](V10ClusterNodeStateReadonly.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterNodesv3NodeStateServicelight

> UpdateClusterNodesv3NodeStateServicelight(ctx, lnn).V3NodeStateServicelight(v3NodeStateServicelight).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v3NodeStateServicelight := *openapiclient.NewV3NodeStateServicelightExtended() // V3NodeStateServicelightExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterNodesApi.UpdateClusterNodesv3NodeStateServicelight(context.Background(), lnn).V3NodeStateServicelight(v3NodeStateServicelight).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.UpdateClusterNodesv3NodeStateServicelight``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterNodesv3NodeStateServicelightRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3NodeStateServicelight** | [**V3NodeStateServicelightExtended**](V3NodeStateServicelightExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterNodesv3NodeStateSmartfail

> UpdateClusterNodesv3NodeStateSmartfail(ctx, lnn).V3NodeStateSmartfail(v3NodeStateSmartfail).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v3NodeStateSmartfail := *openapiclient.NewV10ClusterNodeStateSmartfail() // V10ClusterNodeStateSmartfail | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterNodesApi.UpdateClusterNodesv3NodeStateSmartfail(context.Background(), lnn).V3NodeStateSmartfail(v3NodeStateSmartfail).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.UpdateClusterNodesv3NodeStateSmartfail``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterNodesv3NodeStateSmartfailRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3NodeStateSmartfail** | [**V10ClusterNodeStateSmartfail**](V10ClusterNodeStateSmartfail.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterNodesv5NodeDriveconfig

> UpdateClusterNodesv5NodeDriveconfig(ctx, lnn).V5NodeDriveconfig(v5NodeDriveconfig).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v5NodeDriveconfig := *openapiclient.NewV5NodeDriveconfigExtended(*openapiclient.NewV10ClusterNodeDriveDConfigAutomaticReplacementRecognition()) // V5NodeDriveconfigExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterNodesApi.UpdateClusterNodesv5NodeDriveconfig(context.Background(), lnn).V5NodeDriveconfig(v5NodeDriveconfig).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.UpdateClusterNodesv5NodeDriveconfig``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterNodesv5NodeDriveconfigRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v5NodeDriveconfig** | [**V5NodeDriveconfigExtended**](V5NodeDriveconfigExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateClusterNodesv7NodeDriveconfig

> UpdateClusterNodesv7NodeDriveconfig(ctx, lnn).V7NodeDriveconfig(v7NodeDriveconfig).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    lnn := int32(56) // int32 | 
    v7NodeDriveconfig := *openapiclient.NewV7NodeDriveconfigExtended() // V7NodeDriveconfigExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.ClusterNodesApi.UpdateClusterNodesv7NodeDriveconfig(context.Background(), lnn).V7NodeDriveconfig(v7NodeDriveconfig).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `ClusterNodesApi.UpdateClusterNodesv7NodeDriveconfig``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**lnn** | **int32** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateClusterNodesv7NodeDriveconfigRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7NodeDriveconfig** | [**V7NodeDriveconfigExtended**](V7NodeDriveconfigExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

