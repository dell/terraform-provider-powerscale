# V14SnapshotWritableExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Writable** | Pointer to [**[]Createv14SnapshotWritableItemResponse**](Createv14SnapshotWritableItemResponse.md) |  | [optional] 

## Methods

### NewV14SnapshotWritableExtended

`func NewV14SnapshotWritableExtended() *V14SnapshotWritableExtended`

NewV14SnapshotWritableExtended instantiates a new V14SnapshotWritableExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14SnapshotWritableExtendedWithDefaults

`func NewV14SnapshotWritableExtendedWithDefaults() *V14SnapshotWritableExtended`

NewV14SnapshotWritableExtendedWithDefaults instantiates a new V14SnapshotWritableExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetWritable

`func (o *V14SnapshotWritableExtended) GetWritable() []Createv14SnapshotWritableItemResponse`

GetWritable returns the Writable field if non-nil, zero value otherwise.

### GetWritableOk

`func (o *V14SnapshotWritableExtended) GetWritableOk() (*[]Createv14SnapshotWritableItemResponse, bool)`

GetWritableOk returns a tuple with the Writable field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetWritable

`func (o *V14SnapshotWritableExtended) SetWritable(v []Createv14SnapshotWritableItemResponse)`

SetWritable sets Writable field to given value.

### HasWritable

`func (o *V14SnapshotWritableExtended) HasWritable() bool`

HasWritable returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


