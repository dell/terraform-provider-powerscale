# Createv1SnapshotSnapshotResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Alias** | Pointer to **string** | Alias name to create for this snapshot. If null, remove any alias. | [optional] 
**Created** | **int32** | The Unix Epoch time the snapshot was created. | 
**Expires** | **int32** | The Unix Epoch time the snapshot will expire and be eligible for automatic deletion. | 
**HasLocks** | **bool** | True if the snapshot has one or more locks present see, see the locks subresource of a snapshot for a list of locks. | 
**Id** | **int32** | The system ID given to the snapshot. This is useful for tracking the status of delete pending snapshots. | 
**Name** | **string** | The user or system supplied snapshot name. This will be null for snapshots pending delete. | 
**Path** | **string** | The /ifs path snapshotted. | 
**PctFilesystem** | **float32** | Percentage of /ifs used for storing this snapshot. | 
**PctReserve** | **float32** | Percentage of configured snapshot reserved used for storing this snapshot. | 
**Schedule** | **string** | The name of the schedule used to create this snapshot, if applicable. | 
**ShadowBytes** | **int32** | The amount of shadow bytes referred to by this snapshot. | 
**Size** | **int32** | The amount of storage in bytes used to store this snapshot. | 
**State** | **string** | Snapshot state. | 
**TargetId** | **int32** | The ID of the snapshot pointed to if this is an alias. 18446744073709551615 (max uint64) is returned for an alias to the live filesystem. | 
**TargetName** | **string** | The name of the snapshot pointed to if this is an alias. | 

## Methods

### NewCreatev1SnapshotSnapshotResponse

`func NewCreatev1SnapshotSnapshotResponse(created int32, expires int32, hasLocks bool, id int32, name string, path string, pctFilesystem float32, pctReserve float32, schedule string, shadowBytes int32, size int32, state string, targetId int32, targetName string, ) *Createv1SnapshotSnapshotResponse`

NewCreatev1SnapshotSnapshotResponse instantiates a new Createv1SnapshotSnapshotResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev1SnapshotSnapshotResponseWithDefaults

`func NewCreatev1SnapshotSnapshotResponseWithDefaults() *Createv1SnapshotSnapshotResponse`

NewCreatev1SnapshotSnapshotResponseWithDefaults instantiates a new Createv1SnapshotSnapshotResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAlias

`func (o *Createv1SnapshotSnapshotResponse) GetAlias() string`

GetAlias returns the Alias field if non-nil, zero value otherwise.

### GetAliasOk

`func (o *Createv1SnapshotSnapshotResponse) GetAliasOk() (*string, bool)`

GetAliasOk returns a tuple with the Alias field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAlias

`func (o *Createv1SnapshotSnapshotResponse) SetAlias(v string)`

SetAlias sets Alias field to given value.

### HasAlias

`func (o *Createv1SnapshotSnapshotResponse) HasAlias() bool`

HasAlias returns a boolean if a field has been set.

### GetCreated

`func (o *Createv1SnapshotSnapshotResponse) GetCreated() int32`

GetCreated returns the Created field if non-nil, zero value otherwise.

### GetCreatedOk

`func (o *Createv1SnapshotSnapshotResponse) GetCreatedOk() (*int32, bool)`

GetCreatedOk returns a tuple with the Created field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreated

`func (o *Createv1SnapshotSnapshotResponse) SetCreated(v int32)`

SetCreated sets Created field to given value.


### GetExpires

`func (o *Createv1SnapshotSnapshotResponse) GetExpires() int32`

GetExpires returns the Expires field if non-nil, zero value otherwise.

### GetExpiresOk

`func (o *Createv1SnapshotSnapshotResponse) GetExpiresOk() (*int32, bool)`

GetExpiresOk returns a tuple with the Expires field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExpires

`func (o *Createv1SnapshotSnapshotResponse) SetExpires(v int32)`

SetExpires sets Expires field to given value.


### GetHasLocks

`func (o *Createv1SnapshotSnapshotResponse) GetHasLocks() bool`

GetHasLocks returns the HasLocks field if non-nil, zero value otherwise.

### GetHasLocksOk

`func (o *Createv1SnapshotSnapshotResponse) GetHasLocksOk() (*bool, bool)`

GetHasLocksOk returns a tuple with the HasLocks field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetHasLocks

`func (o *Createv1SnapshotSnapshotResponse) SetHasLocks(v bool)`

SetHasLocks sets HasLocks field to given value.


### GetId

`func (o *Createv1SnapshotSnapshotResponse) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv1SnapshotSnapshotResponse) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv1SnapshotSnapshotResponse) SetId(v int32)`

SetId sets Id field to given value.


### GetName

`func (o *Createv1SnapshotSnapshotResponse) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *Createv1SnapshotSnapshotResponse) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *Createv1SnapshotSnapshotResponse) SetName(v string)`

SetName sets Name field to given value.


### GetPath

`func (o *Createv1SnapshotSnapshotResponse) GetPath() string`

GetPath returns the Path field if non-nil, zero value otherwise.

### GetPathOk

`func (o *Createv1SnapshotSnapshotResponse) GetPathOk() (*string, bool)`

GetPathOk returns a tuple with the Path field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPath

`func (o *Createv1SnapshotSnapshotResponse) SetPath(v string)`

SetPath sets Path field to given value.


### GetPctFilesystem

`func (o *Createv1SnapshotSnapshotResponse) GetPctFilesystem() float32`

GetPctFilesystem returns the PctFilesystem field if non-nil, zero value otherwise.

### GetPctFilesystemOk

`func (o *Createv1SnapshotSnapshotResponse) GetPctFilesystemOk() (*float32, bool)`

GetPctFilesystemOk returns a tuple with the PctFilesystem field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPctFilesystem

`func (o *Createv1SnapshotSnapshotResponse) SetPctFilesystem(v float32)`

SetPctFilesystem sets PctFilesystem field to given value.


### GetPctReserve

`func (o *Createv1SnapshotSnapshotResponse) GetPctReserve() float32`

GetPctReserve returns the PctReserve field if non-nil, zero value otherwise.

### GetPctReserveOk

`func (o *Createv1SnapshotSnapshotResponse) GetPctReserveOk() (*float32, bool)`

GetPctReserveOk returns a tuple with the PctReserve field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPctReserve

`func (o *Createv1SnapshotSnapshotResponse) SetPctReserve(v float32)`

SetPctReserve sets PctReserve field to given value.


### GetSchedule

`func (o *Createv1SnapshotSnapshotResponse) GetSchedule() string`

GetSchedule returns the Schedule field if non-nil, zero value otherwise.

### GetScheduleOk

`func (o *Createv1SnapshotSnapshotResponse) GetScheduleOk() (*string, bool)`

GetScheduleOk returns a tuple with the Schedule field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSchedule

`func (o *Createv1SnapshotSnapshotResponse) SetSchedule(v string)`

SetSchedule sets Schedule field to given value.


### GetShadowBytes

`func (o *Createv1SnapshotSnapshotResponse) GetShadowBytes() int32`

GetShadowBytes returns the ShadowBytes field if non-nil, zero value otherwise.

### GetShadowBytesOk

`func (o *Createv1SnapshotSnapshotResponse) GetShadowBytesOk() (*int32, bool)`

GetShadowBytesOk returns a tuple with the ShadowBytes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowBytes

`func (o *Createv1SnapshotSnapshotResponse) SetShadowBytes(v int32)`

SetShadowBytes sets ShadowBytes field to given value.


### GetSize

`func (o *Createv1SnapshotSnapshotResponse) GetSize() int32`

GetSize returns the Size field if non-nil, zero value otherwise.

### GetSizeOk

`func (o *Createv1SnapshotSnapshotResponse) GetSizeOk() (*int32, bool)`

GetSizeOk returns a tuple with the Size field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSize

`func (o *Createv1SnapshotSnapshotResponse) SetSize(v int32)`

SetSize sets Size field to given value.


### GetState

`func (o *Createv1SnapshotSnapshotResponse) GetState() string`

GetState returns the State field if non-nil, zero value otherwise.

### GetStateOk

`func (o *Createv1SnapshotSnapshotResponse) GetStateOk() (*string, bool)`

GetStateOk returns a tuple with the State field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetState

`func (o *Createv1SnapshotSnapshotResponse) SetState(v string)`

SetState sets State field to given value.


### GetTargetId

`func (o *Createv1SnapshotSnapshotResponse) GetTargetId() int32`

GetTargetId returns the TargetId field if non-nil, zero value otherwise.

### GetTargetIdOk

`func (o *Createv1SnapshotSnapshotResponse) GetTargetIdOk() (*int32, bool)`

GetTargetIdOk returns a tuple with the TargetId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetId

`func (o *Createv1SnapshotSnapshotResponse) SetTargetId(v int32)`

SetTargetId sets TargetId field to given value.


### GetTargetName

`func (o *Createv1SnapshotSnapshotResponse) GetTargetName() string`

GetTargetName returns the TargetName field if non-nil, zero value otherwise.

### GetTargetNameOk

`func (o *Createv1SnapshotSnapshotResponse) GetTargetNameOk() (*string, bool)`

GetTargetNameOk returns a tuple with the TargetName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTargetName

`func (o *Createv1SnapshotSnapshotResponse) SetTargetName(v string)`

SetTargetName sets TargetName field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


