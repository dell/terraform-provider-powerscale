# \IdResolutionZonesApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**GetIdResolutionZonesv7ZoneGroups**](IdResolutionZonesApi.md#GetIdResolutionZonesv7ZoneGroups) | **Get** /platform/7/id-resolution/zones/{Zid}/groups | 
[**GetIdResolutionZonesv7ZoneUsers**](IdResolutionZonesApi.md#GetIdResolutionZonesv7ZoneUsers) | **Get** /platform/7/id-resolution/zones/{Zid}/users | 



## GetIdResolutionZonesv7ZoneGroups

> V7ZoneGroups GetIdResolutionZonesv7ZoneGroups(ctx, zid).Sort(sort).Resume(resume).Gsids(gsids).Gids(gids).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zid := "zid_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    gsids := "gsids_example" // string | A comma separated list specifying the gsids to map with a groupname. (optional)
    gids := "gids_example" // string | A comma separated list specifying the gids to map with a groupname. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IdResolutionZonesApi.GetIdResolutionZonesv7ZoneGroups(context.Background(), zid).Sort(sort).Resume(resume).Gsids(gsids).Gids(gids).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IdResolutionZonesApi.GetIdResolutionZonesv7ZoneGroups``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIdResolutionZonesv7ZoneGroups`: V7ZoneGroups
    fmt.Fprintf(os.Stdout, "Response from `IdResolutionZonesApi.GetIdResolutionZonesv7ZoneGroups`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**zid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetIdResolutionZonesv7ZoneGroupsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **gsids** | **string** | A comma separated list specifying the gsids to map with a groupname. | 
 **gids** | **string** | A comma separated list specifying the gids to map with a groupname. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7ZoneGroups**](V7ZoneGroups.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetIdResolutionZonesv7ZoneUsers

> V7ZoneUsers GetIdResolutionZonesv7ZoneUsers(ctx, zid).Sort(sort).Uids(uids).Resume(resume).Sids(sids).Limit(limit).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    zid := "zid_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    uids := "uids_example" // string | A comma separated list specifying the uids to map with a username. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)
    sids := "sids_example" // string | A comma separated list specifying the sids to map with a username. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.IdResolutionZonesApi.GetIdResolutionZonesv7ZoneUsers(context.Background(), zid).Sort(sort).Uids(uids).Resume(resume).Sids(sids).Limit(limit).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `IdResolutionZonesApi.GetIdResolutionZonesv7ZoneUsers``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetIdResolutionZonesv7ZoneUsers`: V7ZoneUsers
    fmt.Fprintf(os.Stdout, "Response from `IdResolutionZonesApi.GetIdResolutionZonesv7ZoneUsers`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**zid** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetIdResolutionZonesv7ZoneUsersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **uids** | **string** | A comma separated list specifying the uids to map with a username. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 
 **sids** | **string** | A comma separated list specifying the sids to map with a username. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V7ZoneUsers**](V7ZoneUsers.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

