# V12ConfigImports

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Imports** | Pointer to [**[]V12ConfigImportExtended**](V12ConfigImportExtended.md) |  | [optional] 

## Methods

### NewV12ConfigImports

`func NewV12ConfigImports() *V12ConfigImports`

NewV12ConfigImports instantiates a new V12ConfigImports object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ConfigImportsWithDefaults

`func NewV12ConfigImportsWithDefaults() *V12ConfigImports`

NewV12ConfigImportsWithDefaults instantiates a new V12ConfigImports object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetImports

`func (o *V12ConfigImports) GetImports() []V12ConfigImportExtended`

GetImports returns the Imports field if non-nil, zero value otherwise.

### GetImportsOk

`func (o *V12ConfigImports) GetImportsOk() (*[]V12ConfigImportExtended, bool)`

GetImportsOk returns a tuple with the Imports field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetImports

`func (o *V12ConfigImports) SetImports(v []V12ConfigImportExtended)`

SetImports sets Imports field to given value.

### HasImports

`func (o *V12ConfigImports) HasImports() bool`

HasImports returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


