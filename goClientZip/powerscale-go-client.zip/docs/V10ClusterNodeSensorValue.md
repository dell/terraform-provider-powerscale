# V10ClusterNodeSensorValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Desc** | Pointer to **string** | The descriptive name of this sensor. | [optional] 
**Name** | Pointer to **string** | The identifier name of this sensor. | [optional] 
**Units** | Pointer to **string** | The units of this sensor. | [optional] 
**Value** | Pointer to **string** | The value of this sensor. | [optional] 

## Methods

### NewV10ClusterNodeSensorValue

`func NewV10ClusterNodeSensorValue() *V10ClusterNodeSensorValue`

NewV10ClusterNodeSensorValue instantiates a new V10ClusterNodeSensorValue object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeSensorValueWithDefaults

`func NewV10ClusterNodeSensorValueWithDefaults() *V10ClusterNodeSensorValue`

NewV10ClusterNodeSensorValueWithDefaults instantiates a new V10ClusterNodeSensorValue object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDesc

`func (o *V10ClusterNodeSensorValue) GetDesc() string`

GetDesc returns the Desc field if non-nil, zero value otherwise.

### GetDescOk

`func (o *V10ClusterNodeSensorValue) GetDescOk() (*string, bool)`

GetDescOk returns a tuple with the Desc field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDesc

`func (o *V10ClusterNodeSensorValue) SetDesc(v string)`

SetDesc sets Desc field to given value.

### HasDesc

`func (o *V10ClusterNodeSensorValue) HasDesc() bool`

HasDesc returns a boolean if a field has been set.

### GetName

`func (o *V10ClusterNodeSensorValue) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10ClusterNodeSensorValue) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10ClusterNodeSensorValue) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V10ClusterNodeSensorValue) HasName() bool`

HasName returns a boolean if a field has been set.

### GetUnits

`func (o *V10ClusterNodeSensorValue) GetUnits() string`

GetUnits returns the Units field if non-nil, zero value otherwise.

### GetUnitsOk

`func (o *V10ClusterNodeSensorValue) GetUnitsOk() (*string, bool)`

GetUnitsOk returns a tuple with the Units field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnits

`func (o *V10ClusterNodeSensorValue) SetUnits(v string)`

SetUnits sets Units field to given value.

### HasUnits

`func (o *V10ClusterNodeSensorValue) HasUnits() bool`

HasUnits returns a boolean if a field has been set.

### GetValue

`func (o *V10ClusterNodeSensorValue) GetValue() string`

GetValue returns the Value field if non-nil, zero value otherwise.

### GetValueOk

`func (o *V10ClusterNodeSensorValue) GetValueOk() (*string, bool)`

GetValueOk returns a tuple with the Value field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValue

`func (o *V10ClusterNodeSensorValue) SetValue(v string)`

SetValue sets Value field to given value.

### HasValue

`func (o *V10ClusterNodeSensorValue) HasValue() bool`

HasValue returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


