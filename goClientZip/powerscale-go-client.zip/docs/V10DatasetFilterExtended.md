# V10DatasetFilterExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreationTime** | Pointer to **int32** | Timestamp of when the filter was applied. | [optional] 
**DatasetId** | Pointer to **int32** | Unique identifier of the associated dataset. | [optional] 
**Error** | Pointer to **string** | If this field is present, then there was an error fetching the filter configuration. | [optional] 
**Id** | **int32** | The filter ID. Unique and automatically assigned. | 
**MetricValues** | Pointer to [**V10DatasetFilterMetricValuesExtended**](V10DatasetFilterMetricValuesExtended.md) |  | [optional] 
**Name** | Pointer to **string** | The name of the filter. User specified. | [optional] 

## Methods

### NewV10DatasetFilterExtended

`func NewV10DatasetFilterExtended(id int32, ) *V10DatasetFilterExtended`

NewV10DatasetFilterExtended instantiates a new V10DatasetFilterExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10DatasetFilterExtendedWithDefaults

`func NewV10DatasetFilterExtendedWithDefaults() *V10DatasetFilterExtended`

NewV10DatasetFilterExtendedWithDefaults instantiates a new V10DatasetFilterExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetCreationTime

`func (o *V10DatasetFilterExtended) GetCreationTime() int32`

GetCreationTime returns the CreationTime field if non-nil, zero value otherwise.

### GetCreationTimeOk

`func (o *V10DatasetFilterExtended) GetCreationTimeOk() (*int32, bool)`

GetCreationTimeOk returns a tuple with the CreationTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetCreationTime

`func (o *V10DatasetFilterExtended) SetCreationTime(v int32)`

SetCreationTime sets CreationTime field to given value.

### HasCreationTime

`func (o *V10DatasetFilterExtended) HasCreationTime() bool`

HasCreationTime returns a boolean if a field has been set.

### GetDatasetId

`func (o *V10DatasetFilterExtended) GetDatasetId() int32`

GetDatasetId returns the DatasetId field if non-nil, zero value otherwise.

### GetDatasetIdOk

`func (o *V10DatasetFilterExtended) GetDatasetIdOk() (*int32, bool)`

GetDatasetIdOk returns a tuple with the DatasetId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDatasetId

`func (o *V10DatasetFilterExtended) SetDatasetId(v int32)`

SetDatasetId sets DatasetId field to given value.

### HasDatasetId

`func (o *V10DatasetFilterExtended) HasDatasetId() bool`

HasDatasetId returns a boolean if a field has been set.

### GetError

`func (o *V10DatasetFilterExtended) GetError() string`

GetError returns the Error field if non-nil, zero value otherwise.

### GetErrorOk

`func (o *V10DatasetFilterExtended) GetErrorOk() (*string, bool)`

GetErrorOk returns a tuple with the Error field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetError

`func (o *V10DatasetFilterExtended) SetError(v string)`

SetError sets Error field to given value.

### HasError

`func (o *V10DatasetFilterExtended) HasError() bool`

HasError returns a boolean if a field has been set.

### GetId

`func (o *V10DatasetFilterExtended) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10DatasetFilterExtended) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10DatasetFilterExtended) SetId(v int32)`

SetId sets Id field to given value.


### GetMetricValues

`func (o *V10DatasetFilterExtended) GetMetricValues() V10DatasetFilterMetricValuesExtended`

GetMetricValues returns the MetricValues field if non-nil, zero value otherwise.

### GetMetricValuesOk

`func (o *V10DatasetFilterExtended) GetMetricValuesOk() (*V10DatasetFilterMetricValuesExtended, bool)`

GetMetricValuesOk returns a tuple with the MetricValues field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetricValues

`func (o *V10DatasetFilterExtended) SetMetricValues(v V10DatasetFilterMetricValuesExtended)`

SetMetricValues sets MetricValues field to given value.

### HasMetricValues

`func (o *V10DatasetFilterExtended) HasMetricValues() bool`

HasMetricValues returns a boolean if a field has been set.

### GetName

`func (o *V10DatasetFilterExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10DatasetFilterExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10DatasetFilterExtended) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V10DatasetFilterExtended) HasName() bool`

HasName returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


