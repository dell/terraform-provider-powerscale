# V12NetworkInterface

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Flags** | **[]string** | List of interface flags | 
**Id** | **string** | Id is a concatenation of lnn and name in the format &#39;lnn:name&#39; e.g. 3:ext-2. | 
**IpAddrs** | **[]string** | List of IP addresses | 
**Ipv4Gateway** | **string** | Address of the default IPv4 gateway | 
**Ipv6Gateway** | **string** | Address of the default IPv6 gateway | 
**Lnn** | **int32** | Logical Node Number (LNN) of a node. | 
**Mtu** | **int32** | The mtu the interface. | 
**Name** | **string** | The name of the interface. | 
**NicName** | **string** | NIC name | 
**Owners** | [**[]V12NetworkInterfaceOwner**](V12NetworkInterfaceOwner.md) | List of owners (membership) | 
**Status** | **string** | Status of the interface | 
**Type** | **string** | The type of network interface | 
**Vlans** | [**[]V12NetworkInterfaceVlan**](V12NetworkInterfaceVlan.md) | List of VLANs | 

## Methods

### NewV12NetworkInterface

`func NewV12NetworkInterface(flags []string, id string, ipAddrs []string, ipv4Gateway string, ipv6Gateway string, lnn int32, mtu int32, name string, nicName string, owners []V12NetworkInterfaceOwner, status string, type_ string, vlans []V12NetworkInterfaceVlan, ) *V12NetworkInterface`

NewV12NetworkInterface instantiates a new V12NetworkInterface object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12NetworkInterfaceWithDefaults

`func NewV12NetworkInterfaceWithDefaults() *V12NetworkInterface`

NewV12NetworkInterfaceWithDefaults instantiates a new V12NetworkInterface object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFlags

`func (o *V12NetworkInterface) GetFlags() []string`

GetFlags returns the Flags field if non-nil, zero value otherwise.

### GetFlagsOk

`func (o *V12NetworkInterface) GetFlagsOk() (*[]string, bool)`

GetFlagsOk returns a tuple with the Flags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFlags

`func (o *V12NetworkInterface) SetFlags(v []string)`

SetFlags sets Flags field to given value.


### GetId

`func (o *V12NetworkInterface) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12NetworkInterface) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12NetworkInterface) SetId(v string)`

SetId sets Id field to given value.


### GetIpAddrs

`func (o *V12NetworkInterface) GetIpAddrs() []string`

GetIpAddrs returns the IpAddrs field if non-nil, zero value otherwise.

### GetIpAddrsOk

`func (o *V12NetworkInterface) GetIpAddrsOk() (*[]string, bool)`

GetIpAddrsOk returns a tuple with the IpAddrs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpAddrs

`func (o *V12NetworkInterface) SetIpAddrs(v []string)`

SetIpAddrs sets IpAddrs field to given value.


### GetIpv4Gateway

`func (o *V12NetworkInterface) GetIpv4Gateway() string`

GetIpv4Gateway returns the Ipv4Gateway field if non-nil, zero value otherwise.

### GetIpv4GatewayOk

`func (o *V12NetworkInterface) GetIpv4GatewayOk() (*string, bool)`

GetIpv4GatewayOk returns a tuple with the Ipv4Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpv4Gateway

`func (o *V12NetworkInterface) SetIpv4Gateway(v string)`

SetIpv4Gateway sets Ipv4Gateway field to given value.


### GetIpv6Gateway

`func (o *V12NetworkInterface) GetIpv6Gateway() string`

GetIpv6Gateway returns the Ipv6Gateway field if non-nil, zero value otherwise.

### GetIpv6GatewayOk

`func (o *V12NetworkInterface) GetIpv6GatewayOk() (*string, bool)`

GetIpv6GatewayOk returns a tuple with the Ipv6Gateway field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetIpv6Gateway

`func (o *V12NetworkInterface) SetIpv6Gateway(v string)`

SetIpv6Gateway sets Ipv6Gateway field to given value.


### GetLnn

`func (o *V12NetworkInterface) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12NetworkInterface) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12NetworkInterface) SetLnn(v int32)`

SetLnn sets Lnn field to given value.


### GetMtu

`func (o *V12NetworkInterface) GetMtu() int32`

GetMtu returns the Mtu field if non-nil, zero value otherwise.

### GetMtuOk

`func (o *V12NetworkInterface) GetMtuOk() (*int32, bool)`

GetMtuOk returns a tuple with the Mtu field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMtu

`func (o *V12NetworkInterface) SetMtu(v int32)`

SetMtu sets Mtu field to given value.


### GetName

`func (o *V12NetworkInterface) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V12NetworkInterface) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V12NetworkInterface) SetName(v string)`

SetName sets Name field to given value.


### GetNicName

`func (o *V12NetworkInterface) GetNicName() string`

GetNicName returns the NicName field if non-nil, zero value otherwise.

### GetNicNameOk

`func (o *V12NetworkInterface) GetNicNameOk() (*string, bool)`

GetNicNameOk returns a tuple with the NicName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNicName

`func (o *V12NetworkInterface) SetNicName(v string)`

SetNicName sets NicName field to given value.


### GetOwners

`func (o *V12NetworkInterface) GetOwners() []V12NetworkInterfaceOwner`

GetOwners returns the Owners field if non-nil, zero value otherwise.

### GetOwnersOk

`func (o *V12NetworkInterface) GetOwnersOk() (*[]V12NetworkInterfaceOwner, bool)`

GetOwnersOk returns a tuple with the Owners field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOwners

`func (o *V12NetworkInterface) SetOwners(v []V12NetworkInterfaceOwner)`

SetOwners sets Owners field to given value.


### GetStatus

`func (o *V12NetworkInterface) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12NetworkInterface) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12NetworkInterface) SetStatus(v string)`

SetStatus sets Status field to given value.


### GetType

`func (o *V12NetworkInterface) GetType() string`

GetType returns the Type field if non-nil, zero value otherwise.

### GetTypeOk

`func (o *V12NetworkInterface) GetTypeOk() (*string, bool)`

GetTypeOk returns a tuple with the Type field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetType

`func (o *V12NetworkInterface) SetType(v string)`

SetType sets Type field to given value.


### GetVlans

`func (o *V12NetworkInterface) GetVlans() []V12NetworkInterfaceVlan`

GetVlans returns the Vlans field if non-nil, zero value otherwise.

### GetVlansOk

`func (o *V12NetworkInterface) GetVlansOk() (*[]V12NetworkInterfaceVlan, bool)`

GetVlansOk returns a tuple with the Vlans field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetVlans

`func (o *V12NetworkInterface) SetVlans(v []V12NetworkInterfaceVlan)`

SetVlans sets Vlans field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


