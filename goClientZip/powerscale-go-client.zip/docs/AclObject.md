# AclObject

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Accessrights** | Pointer to **[]string** |  | [optional] 
**Accesstype** | Pointer to **string** |  | [optional] 
**InheritFlags** | Pointer to **[]string** |  | [optional] 
**Op** | Pointer to **string** |  | [optional] 
**Trustee** | Pointer to [**MemberObject**](MemberObject.md) |  | [optional] 

## Methods

### NewAclObject

`func NewAclObject() *AclObject`

NewAclObject instantiates a new AclObject object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewAclObjectWithDefaults

`func NewAclObjectWithDefaults() *AclObject`

NewAclObjectWithDefaults instantiates a new AclObject object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAccessrights

`func (o *AclObject) GetAccessrights() []string`

GetAccessrights returns the Accessrights field if non-nil, zero value otherwise.

### GetAccessrightsOk

`func (o *AclObject) GetAccessrightsOk() (*[]string, bool)`

GetAccessrightsOk returns a tuple with the Accessrights field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccessrights

`func (o *AclObject) SetAccessrights(v []string)`

SetAccessrights sets Accessrights field to given value.

### HasAccessrights

`func (o *AclObject) HasAccessrights() bool`

HasAccessrights returns a boolean if a field has been set.

### GetAccesstype

`func (o *AclObject) GetAccesstype() string`

GetAccesstype returns the Accesstype field if non-nil, zero value otherwise.

### GetAccesstypeOk

`func (o *AclObject) GetAccesstypeOk() (*string, bool)`

GetAccesstypeOk returns a tuple with the Accesstype field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAccesstype

`func (o *AclObject) SetAccesstype(v string)`

SetAccesstype sets Accesstype field to given value.

### HasAccesstype

`func (o *AclObject) HasAccesstype() bool`

HasAccesstype returns a boolean if a field has been set.

### GetInheritFlags

`func (o *AclObject) GetInheritFlags() []string`

GetInheritFlags returns the InheritFlags field if non-nil, zero value otherwise.

### GetInheritFlagsOk

`func (o *AclObject) GetInheritFlagsOk() (*[]string, bool)`

GetInheritFlagsOk returns a tuple with the InheritFlags field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInheritFlags

`func (o *AclObject) SetInheritFlags(v []string)`

SetInheritFlags sets InheritFlags field to given value.

### HasInheritFlags

`func (o *AclObject) HasInheritFlags() bool`

HasInheritFlags returns a boolean if a field has been set.

### GetOp

`func (o *AclObject) GetOp() string`

GetOp returns the Op field if non-nil, zero value otherwise.

### GetOpOk

`func (o *AclObject) GetOpOk() (*string, bool)`

GetOpOk returns a tuple with the Op field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOp

`func (o *AclObject) SetOp(v string)`

SetOp sets Op field to given value.

### HasOp

`func (o *AclObject) HasOp() bool`

HasOp returns a boolean if a field has been set.

### GetTrustee

`func (o *AclObject) GetTrustee() MemberObject`

GetTrustee returns the Trustee field if non-nil, zero value otherwise.

### GetTrusteeOk

`func (o *AclObject) GetTrusteeOk() (*MemberObject, bool)`

GetTrusteeOk returns a tuple with the Trustee field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTrustee

`func (o *AclObject) SetTrustee(v MemberObject)`

SetTrustee sets Trustee field to given value.

### HasTrustee

`func (o *AclObject) HasTrustee() bool`

HasTrustee returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


