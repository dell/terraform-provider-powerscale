# V10ClusterNodeDriveDConfigStall

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ClearTime** | Pointer to **int32** | The amount of time in seconds with no stalls before ignoring previous stalls. | [optional] 
**DiskscrubStripes** | Pointer to **int32** | Number of stripes to read during a diskscrub. | [optional] 
**MaxErrorFrequency** | Pointer to **int32** | The number of errors during stalled drive disk exercises to cause the drive to be softfailed. | [optional] 
**MaxSlowAccess** | Pointer to **int32** | The number of slow accesses during stalled drive disk exercises to cause the drive to be softfailed. | [optional] 
**MaxSlowFrequency** | Pointer to **int32** | The number of slow frequency triggers during stalled drive disk exercises to cause the drive to be softfailed. | [optional] 
**MaxTotalStallTime** | Pointer to **int32** | The maximum amount of time, in seconds, to remain stalled before softfailing the drive. | [optional] 
**ScanMaxEccDelay** | Pointer to **int32** | Maximum delay in seconds after an ECC correction during a scan. | [optional] 
**ScanSize** | Pointer to **int32** | Total bytes of error-free reads to complete a scan. | [optional] 
**Sleep** | Pointer to **int32** | Delay in seconds between evaluations. | [optional] 

## Methods

### NewV10ClusterNodeDriveDConfigStall

`func NewV10ClusterNodeDriveDConfigStall() *V10ClusterNodeDriveDConfigStall`

NewV10ClusterNodeDriveDConfigStall instantiates a new V10ClusterNodeDriveDConfigStall object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10ClusterNodeDriveDConfigStallWithDefaults

`func NewV10ClusterNodeDriveDConfigStallWithDefaults() *V10ClusterNodeDriveDConfigStall`

NewV10ClusterNodeDriveDConfigStallWithDefaults instantiates a new V10ClusterNodeDriveDConfigStall object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetClearTime

`func (o *V10ClusterNodeDriveDConfigStall) GetClearTime() int32`

GetClearTime returns the ClearTime field if non-nil, zero value otherwise.

### GetClearTimeOk

`func (o *V10ClusterNodeDriveDConfigStall) GetClearTimeOk() (*int32, bool)`

GetClearTimeOk returns a tuple with the ClearTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetClearTime

`func (o *V10ClusterNodeDriveDConfigStall) SetClearTime(v int32)`

SetClearTime sets ClearTime field to given value.

### HasClearTime

`func (o *V10ClusterNodeDriveDConfigStall) HasClearTime() bool`

HasClearTime returns a boolean if a field has been set.

### GetDiskscrubStripes

`func (o *V10ClusterNodeDriveDConfigStall) GetDiskscrubStripes() int32`

GetDiskscrubStripes returns the DiskscrubStripes field if non-nil, zero value otherwise.

### GetDiskscrubStripesOk

`func (o *V10ClusterNodeDriveDConfigStall) GetDiskscrubStripesOk() (*int32, bool)`

GetDiskscrubStripesOk returns a tuple with the DiskscrubStripes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDiskscrubStripes

`func (o *V10ClusterNodeDriveDConfigStall) SetDiskscrubStripes(v int32)`

SetDiskscrubStripes sets DiskscrubStripes field to given value.

### HasDiskscrubStripes

`func (o *V10ClusterNodeDriveDConfigStall) HasDiskscrubStripes() bool`

HasDiskscrubStripes returns a boolean if a field has been set.

### GetMaxErrorFrequency

`func (o *V10ClusterNodeDriveDConfigStall) GetMaxErrorFrequency() int32`

GetMaxErrorFrequency returns the MaxErrorFrequency field if non-nil, zero value otherwise.

### GetMaxErrorFrequencyOk

`func (o *V10ClusterNodeDriveDConfigStall) GetMaxErrorFrequencyOk() (*int32, bool)`

GetMaxErrorFrequencyOk returns a tuple with the MaxErrorFrequency field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxErrorFrequency

`func (o *V10ClusterNodeDriveDConfigStall) SetMaxErrorFrequency(v int32)`

SetMaxErrorFrequency sets MaxErrorFrequency field to given value.

### HasMaxErrorFrequency

`func (o *V10ClusterNodeDriveDConfigStall) HasMaxErrorFrequency() bool`

HasMaxErrorFrequency returns a boolean if a field has been set.

### GetMaxSlowAccess

`func (o *V10ClusterNodeDriveDConfigStall) GetMaxSlowAccess() int32`

GetMaxSlowAccess returns the MaxSlowAccess field if non-nil, zero value otherwise.

### GetMaxSlowAccessOk

`func (o *V10ClusterNodeDriveDConfigStall) GetMaxSlowAccessOk() (*int32, bool)`

GetMaxSlowAccessOk returns a tuple with the MaxSlowAccess field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxSlowAccess

`func (o *V10ClusterNodeDriveDConfigStall) SetMaxSlowAccess(v int32)`

SetMaxSlowAccess sets MaxSlowAccess field to given value.

### HasMaxSlowAccess

`func (o *V10ClusterNodeDriveDConfigStall) HasMaxSlowAccess() bool`

HasMaxSlowAccess returns a boolean if a field has been set.

### GetMaxSlowFrequency

`func (o *V10ClusterNodeDriveDConfigStall) GetMaxSlowFrequency() int32`

GetMaxSlowFrequency returns the MaxSlowFrequency field if non-nil, zero value otherwise.

### GetMaxSlowFrequencyOk

`func (o *V10ClusterNodeDriveDConfigStall) GetMaxSlowFrequencyOk() (*int32, bool)`

GetMaxSlowFrequencyOk returns a tuple with the MaxSlowFrequency field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxSlowFrequency

`func (o *V10ClusterNodeDriveDConfigStall) SetMaxSlowFrequency(v int32)`

SetMaxSlowFrequency sets MaxSlowFrequency field to given value.

### HasMaxSlowFrequency

`func (o *V10ClusterNodeDriveDConfigStall) HasMaxSlowFrequency() bool`

HasMaxSlowFrequency returns a boolean if a field has been set.

### GetMaxTotalStallTime

`func (o *V10ClusterNodeDriveDConfigStall) GetMaxTotalStallTime() int32`

GetMaxTotalStallTime returns the MaxTotalStallTime field if non-nil, zero value otherwise.

### GetMaxTotalStallTimeOk

`func (o *V10ClusterNodeDriveDConfigStall) GetMaxTotalStallTimeOk() (*int32, bool)`

GetMaxTotalStallTimeOk returns a tuple with the MaxTotalStallTime field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMaxTotalStallTime

`func (o *V10ClusterNodeDriveDConfigStall) SetMaxTotalStallTime(v int32)`

SetMaxTotalStallTime sets MaxTotalStallTime field to given value.

### HasMaxTotalStallTime

`func (o *V10ClusterNodeDriveDConfigStall) HasMaxTotalStallTime() bool`

HasMaxTotalStallTime returns a boolean if a field has been set.

### GetScanMaxEccDelay

`func (o *V10ClusterNodeDriveDConfigStall) GetScanMaxEccDelay() int32`

GetScanMaxEccDelay returns the ScanMaxEccDelay field if non-nil, zero value otherwise.

### GetScanMaxEccDelayOk

`func (o *V10ClusterNodeDriveDConfigStall) GetScanMaxEccDelayOk() (*int32, bool)`

GetScanMaxEccDelayOk returns a tuple with the ScanMaxEccDelay field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanMaxEccDelay

`func (o *V10ClusterNodeDriveDConfigStall) SetScanMaxEccDelay(v int32)`

SetScanMaxEccDelay sets ScanMaxEccDelay field to given value.

### HasScanMaxEccDelay

`func (o *V10ClusterNodeDriveDConfigStall) HasScanMaxEccDelay() bool`

HasScanMaxEccDelay returns a boolean if a field has been set.

### GetScanSize

`func (o *V10ClusterNodeDriveDConfigStall) GetScanSize() int32`

GetScanSize returns the ScanSize field if non-nil, zero value otherwise.

### GetScanSizeOk

`func (o *V10ClusterNodeDriveDConfigStall) GetScanSizeOk() (*int32, bool)`

GetScanSizeOk returns a tuple with the ScanSize field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetScanSize

`func (o *V10ClusterNodeDriveDConfigStall) SetScanSize(v int32)`

SetScanSize sets ScanSize field to given value.

### HasScanSize

`func (o *V10ClusterNodeDriveDConfigStall) HasScanSize() bool`

HasScanSize returns a boolean if a field has been set.

### GetSleep

`func (o *V10ClusterNodeDriveDConfigStall) GetSleep() int32`

GetSleep returns the Sleep field if non-nil, zero value otherwise.

### GetSleepOk

`func (o *V10ClusterNodeDriveDConfigStall) GetSleepOk() (*int32, bool)`

GetSleepOk returns a tuple with the Sleep field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSleep

`func (o *V10ClusterNodeDriveDConfigStall) SetSleep(v int32)`

SetSleep sets Sleep field to given value.

### HasSleep

`func (o *V10ClusterNodeDriveDConfigStall) HasSleep() bool`

HasSleep returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


