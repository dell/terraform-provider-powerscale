# V12S3SettingsZoneSettings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BaseDomain** | Pointer to **string** | Specifies the S3 base domain name. | [optional] 
**BucketDirectoryCreateMode** | Pointer to **int32** | Create bucket directory with this permission mode | [optional] 
**ObjectAclPolicy** | Pointer to **string** | Default object ACL policy for S3 Buckets. | [optional] 
**RootPath** | Pointer to **string** | Specifies the S3 bucket root path. | [optional] 
**UseMd5ForEtag** | Pointer to **bool** | Use MD5 for Etag on upload | [optional] 
**ValidateContentMd5** | Pointer to **bool** | Validate given Content-MD5 | [optional] 

## Methods

### NewV12S3SettingsZoneSettings

`func NewV12S3SettingsZoneSettings() *V12S3SettingsZoneSettings`

NewV12S3SettingsZoneSettings instantiates a new V12S3SettingsZoneSettings object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12S3SettingsZoneSettingsWithDefaults

`func NewV12S3SettingsZoneSettingsWithDefaults() *V12S3SettingsZoneSettings`

NewV12S3SettingsZoneSettingsWithDefaults instantiates a new V12S3SettingsZoneSettings object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBaseDomain

`func (o *V12S3SettingsZoneSettings) GetBaseDomain() string`

GetBaseDomain returns the BaseDomain field if non-nil, zero value otherwise.

### GetBaseDomainOk

`func (o *V12S3SettingsZoneSettings) GetBaseDomainOk() (*string, bool)`

GetBaseDomainOk returns a tuple with the BaseDomain field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBaseDomain

`func (o *V12S3SettingsZoneSettings) SetBaseDomain(v string)`

SetBaseDomain sets BaseDomain field to given value.

### HasBaseDomain

`func (o *V12S3SettingsZoneSettings) HasBaseDomain() bool`

HasBaseDomain returns a boolean if a field has been set.

### GetBucketDirectoryCreateMode

`func (o *V12S3SettingsZoneSettings) GetBucketDirectoryCreateMode() int32`

GetBucketDirectoryCreateMode returns the BucketDirectoryCreateMode field if non-nil, zero value otherwise.

### GetBucketDirectoryCreateModeOk

`func (o *V12S3SettingsZoneSettings) GetBucketDirectoryCreateModeOk() (*int32, bool)`

GetBucketDirectoryCreateModeOk returns a tuple with the BucketDirectoryCreateMode field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBucketDirectoryCreateMode

`func (o *V12S3SettingsZoneSettings) SetBucketDirectoryCreateMode(v int32)`

SetBucketDirectoryCreateMode sets BucketDirectoryCreateMode field to given value.

### HasBucketDirectoryCreateMode

`func (o *V12S3SettingsZoneSettings) HasBucketDirectoryCreateMode() bool`

HasBucketDirectoryCreateMode returns a boolean if a field has been set.

### GetObjectAclPolicy

`func (o *V12S3SettingsZoneSettings) GetObjectAclPolicy() string`

GetObjectAclPolicy returns the ObjectAclPolicy field if non-nil, zero value otherwise.

### GetObjectAclPolicyOk

`func (o *V12S3SettingsZoneSettings) GetObjectAclPolicyOk() (*string, bool)`

GetObjectAclPolicyOk returns a tuple with the ObjectAclPolicy field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetObjectAclPolicy

`func (o *V12S3SettingsZoneSettings) SetObjectAclPolicy(v string)`

SetObjectAclPolicy sets ObjectAclPolicy field to given value.

### HasObjectAclPolicy

`func (o *V12S3SettingsZoneSettings) HasObjectAclPolicy() bool`

HasObjectAclPolicy returns a boolean if a field has been set.

### GetRootPath

`func (o *V12S3SettingsZoneSettings) GetRootPath() string`

GetRootPath returns the RootPath field if non-nil, zero value otherwise.

### GetRootPathOk

`func (o *V12S3SettingsZoneSettings) GetRootPathOk() (*string, bool)`

GetRootPathOk returns a tuple with the RootPath field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRootPath

`func (o *V12S3SettingsZoneSettings) SetRootPath(v string)`

SetRootPath sets RootPath field to given value.

### HasRootPath

`func (o *V12S3SettingsZoneSettings) HasRootPath() bool`

HasRootPath returns a boolean if a field has been set.

### GetUseMd5ForEtag

`func (o *V12S3SettingsZoneSettings) GetUseMd5ForEtag() bool`

GetUseMd5ForEtag returns the UseMd5ForEtag field if non-nil, zero value otherwise.

### GetUseMd5ForEtagOk

`func (o *V12S3SettingsZoneSettings) GetUseMd5ForEtagOk() (*bool, bool)`

GetUseMd5ForEtagOk returns a tuple with the UseMd5ForEtag field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUseMd5ForEtag

`func (o *V12S3SettingsZoneSettings) SetUseMd5ForEtag(v bool)`

SetUseMd5ForEtag sets UseMd5ForEtag field to given value.

### HasUseMd5ForEtag

`func (o *V12S3SettingsZoneSettings) HasUseMd5ForEtag() bool`

HasUseMd5ForEtag returns a boolean if a field has been set.

### GetValidateContentMd5

`func (o *V12S3SettingsZoneSettings) GetValidateContentMd5() bool`

GetValidateContentMd5 returns the ValidateContentMd5 field if non-nil, zero value otherwise.

### GetValidateContentMd5Ok

`func (o *V12S3SettingsZoneSettings) GetValidateContentMd5Ok() (*bool, bool)`

GetValidateContentMd5Ok returns a tuple with the ValidateContentMd5 field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValidateContentMd5

`func (o *V12S3SettingsZoneSettings) SetValidateContentMd5(v bool)`

SetValidateContentMd5 sets ValidateContentMd5 field to given value.

### HasValidateContentMd5

`func (o *V12S3SettingsZoneSettings) HasValidateContentMd5() bool`

HasValidateContentMd5 returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


