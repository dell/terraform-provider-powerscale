# V14CatalogList

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Artifacts** | Pointer to [**[]V14CatalogListArtifact**](V14CatalogListArtifact.md) | List of catalog entries | [optional] 

## Methods

### NewV14CatalogList

`func NewV14CatalogList() *V14CatalogList`

NewV14CatalogList instantiates a new V14CatalogList object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14CatalogListWithDefaults

`func NewV14CatalogListWithDefaults() *V14CatalogList`

NewV14CatalogListWithDefaults instantiates a new V14CatalogList object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetArtifacts

`func (o *V14CatalogList) GetArtifacts() []V14CatalogListArtifact`

GetArtifacts returns the Artifacts field if non-nil, zero value otherwise.

### GetArtifactsOk

`func (o *V14CatalogList) GetArtifactsOk() (*[]V14CatalogListArtifact, bool)`

GetArtifactsOk returns a tuple with the Artifacts field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetArtifacts

`func (o *V14CatalogList) SetArtifacts(v []V14CatalogListArtifact)`

SetArtifacts sets Artifacts field to given value.

### HasArtifacts

`func (o *V14CatalogList) HasArtifacts() bool`

HasArtifacts returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


