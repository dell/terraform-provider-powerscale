# V12SedStatusNode

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ErrorMsg** | **string** | information of the error if there is an error status. Empty if no error occurred. | 
**Id** | **int32** | Node ID (Device Number) of a node. | 
**Lnn** | **int32** | Logical Node Number (LNN) of a node. | 
**Location** | **string** | Current location of the key. | 
**RemoteKeyId** | **string** | Key ID in the remote KMIP server. | 
**Status** | **string** | Current key migration status. If no SEDs are avaiable and KMIP is not supported, it will show OFFLINE status. | 

## Methods

### NewV12SedStatusNode

`func NewV12SedStatusNode(errorMsg string, id int32, lnn int32, location string, remoteKeyId string, status string, ) *V12SedStatusNode`

NewV12SedStatusNode instantiates a new V12SedStatusNode object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SedStatusNodeWithDefaults

`func NewV12SedStatusNodeWithDefaults() *V12SedStatusNode`

NewV12SedStatusNodeWithDefaults instantiates a new V12SedStatusNode object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetErrorMsg

`func (o *V12SedStatusNode) GetErrorMsg() string`

GetErrorMsg returns the ErrorMsg field if non-nil, zero value otherwise.

### GetErrorMsgOk

`func (o *V12SedStatusNode) GetErrorMsgOk() (*string, bool)`

GetErrorMsgOk returns a tuple with the ErrorMsg field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetErrorMsg

`func (o *V12SedStatusNode) SetErrorMsg(v string)`

SetErrorMsg sets ErrorMsg field to given value.


### GetId

`func (o *V12SedStatusNode) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V12SedStatusNode) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V12SedStatusNode) SetId(v int32)`

SetId sets Id field to given value.


### GetLnn

`func (o *V12SedStatusNode) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V12SedStatusNode) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V12SedStatusNode) SetLnn(v int32)`

SetLnn sets Lnn field to given value.


### GetLocation

`func (o *V12SedStatusNode) GetLocation() string`

GetLocation returns the Location field if non-nil, zero value otherwise.

### GetLocationOk

`func (o *V12SedStatusNode) GetLocationOk() (*string, bool)`

GetLocationOk returns a tuple with the Location field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLocation

`func (o *V12SedStatusNode) SetLocation(v string)`

SetLocation sets Location field to given value.


### GetRemoteKeyId

`func (o *V12SedStatusNode) GetRemoteKeyId() string`

GetRemoteKeyId returns the RemoteKeyId field if non-nil, zero value otherwise.

### GetRemoteKeyIdOk

`func (o *V12SedStatusNode) GetRemoteKeyIdOk() (*string, bool)`

GetRemoteKeyIdOk returns a tuple with the RemoteKeyId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetRemoteKeyId

`func (o *V12SedStatusNode) SetRemoteKeyId(v string)`

SetRemoteKeyId sets RemoteKeyId field to given value.


### GetStatus

`func (o *V12SedStatusNode) GetStatus() string`

GetStatus returns the Status field if non-nil, zero value otherwise.

### GetStatusOk

`func (o *V12SedStatusNode) GetStatusOk() (*string, bool)`

GetStatusOk returns a tuple with the Status field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetStatus

`func (o *V12SedStatusNode) SetStatus(v string)`

SetStatus sets Status field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


