# Createv3EventEventResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | ID of created item that can be used to refer to item in the collection-item resource path. | 

## Methods

### NewCreatev3EventEventResponse

`func NewCreatev3EventEventResponse(id int32, ) *Createv3EventEventResponse`

NewCreatev3EventEventResponse instantiates a new Createv3EventEventResponse object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewCreatev3EventEventResponseWithDefaults

`func NewCreatev3EventEventResponseWithDefaults() *Createv3EventEventResponse`

NewCreatev3EventEventResponseWithDefaults instantiates a new Createv3EventEventResponse object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetId

`func (o *Createv3EventEventResponse) GetId() int32`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *Createv3EventEventResponse) GetIdOk() (*int32, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *Createv3EventEventResponse) SetId(v int32)`

SetId sets Id field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


