# V12QuotaQuotaUsage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Applogical** | **int32** | Bytes used by governed data apparent to application. | 
**ApplogicalReady** | **bool** | True if applogical resource accounting is accurate on the quota. If false, this quota is waiting on completion of a QuotaScan job. | 
**Fslogical** | **int32** | Bytes used by governed data apparent to filesystem. | 
**FslogicalReady** | **bool** | True if fslogical resource accounting is accurate on the quota. If false, this quota is waiting on completion of a QuotaScan job. | 
**Fsphysical** | Pointer to **int32** | Physical data usage adjusted to account for shadow store efficiency | [optional] 
**FsphysicalReady** | **bool** | True if fsphysical resource accounting is accurate on the quota. If false, this quota is waiting on completion of a QuotaScan job. | 
**Inodes** | **int32** | Number of inodes (filesystem entities) used by governed data. | 
**InodesReady** | **bool** | True if inodes resource accounting is accurate on the quota. If false, this quota is waiting on completion of a QuotaScan job. | 
**Physical** | **int32** | Bytes used for governed data and filesystem overhead. | 
**PhysicalData** | **int32** | Number of physical blocks for file data | 
**PhysicalDataReady** | **bool** | True if physical_data resource accounting is accurate on the quota. If false, this quota is waiting on completion of a QuotaScan job. | 
**PhysicalProtection** | **int32** | Number of physical blocks for file protection | 
**PhysicalProtectionReady** | **bool** | True if physical_protection resource accounting is accurate on the quota. If false, this quota is waiting on completion of a QuotaScan job. | 
**PhysicalReady** | **bool** | True if physical resource accounting is accurate on the quota. If false, this quota is waiting on completion of a QuotaScan job. | 
**ShadowRefs** | **int32** | Number of shadow references (cloned, deduplicated or packed filesystem blocks) used by governed data. | 
**ShadowRefsReady** | **bool** | True if shadow_refs resource accounting is accurate on the quota. If false, this quota is waiting on completion of a QuotaScan job. | 

## Methods

### NewV12QuotaQuotaUsage

`func NewV12QuotaQuotaUsage(applogical int32, applogicalReady bool, fslogical int32, fslogicalReady bool, fsphysicalReady bool, inodes int32, inodesReady bool, physical int32, physicalData int32, physicalDataReady bool, physicalProtection int32, physicalProtectionReady bool, physicalReady bool, shadowRefs int32, shadowRefsReady bool, ) *V12QuotaQuotaUsage`

NewV12QuotaQuotaUsage instantiates a new V12QuotaQuotaUsage object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12QuotaQuotaUsageWithDefaults

`func NewV12QuotaQuotaUsageWithDefaults() *V12QuotaQuotaUsage`

NewV12QuotaQuotaUsageWithDefaults instantiates a new V12QuotaQuotaUsage object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetApplogical

`func (o *V12QuotaQuotaUsage) GetApplogical() int32`

GetApplogical returns the Applogical field if non-nil, zero value otherwise.

### GetApplogicalOk

`func (o *V12QuotaQuotaUsage) GetApplogicalOk() (*int32, bool)`

GetApplogicalOk returns a tuple with the Applogical field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetApplogical

`func (o *V12QuotaQuotaUsage) SetApplogical(v int32)`

SetApplogical sets Applogical field to given value.


### GetApplogicalReady

`func (o *V12QuotaQuotaUsage) GetApplogicalReady() bool`

GetApplogicalReady returns the ApplogicalReady field if non-nil, zero value otherwise.

### GetApplogicalReadyOk

`func (o *V12QuotaQuotaUsage) GetApplogicalReadyOk() (*bool, bool)`

GetApplogicalReadyOk returns a tuple with the ApplogicalReady field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetApplogicalReady

`func (o *V12QuotaQuotaUsage) SetApplogicalReady(v bool)`

SetApplogicalReady sets ApplogicalReady field to given value.


### GetFslogical

`func (o *V12QuotaQuotaUsage) GetFslogical() int32`

GetFslogical returns the Fslogical field if non-nil, zero value otherwise.

### GetFslogicalOk

`func (o *V12QuotaQuotaUsage) GetFslogicalOk() (*int32, bool)`

GetFslogicalOk returns a tuple with the Fslogical field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFslogical

`func (o *V12QuotaQuotaUsage) SetFslogical(v int32)`

SetFslogical sets Fslogical field to given value.


### GetFslogicalReady

`func (o *V12QuotaQuotaUsage) GetFslogicalReady() bool`

GetFslogicalReady returns the FslogicalReady field if non-nil, zero value otherwise.

### GetFslogicalReadyOk

`func (o *V12QuotaQuotaUsage) GetFslogicalReadyOk() (*bool, bool)`

GetFslogicalReadyOk returns a tuple with the FslogicalReady field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFslogicalReady

`func (o *V12QuotaQuotaUsage) SetFslogicalReady(v bool)`

SetFslogicalReady sets FslogicalReady field to given value.


### GetFsphysical

`func (o *V12QuotaQuotaUsage) GetFsphysical() int32`

GetFsphysical returns the Fsphysical field if non-nil, zero value otherwise.

### GetFsphysicalOk

`func (o *V12QuotaQuotaUsage) GetFsphysicalOk() (*int32, bool)`

GetFsphysicalOk returns a tuple with the Fsphysical field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFsphysical

`func (o *V12QuotaQuotaUsage) SetFsphysical(v int32)`

SetFsphysical sets Fsphysical field to given value.

### HasFsphysical

`func (o *V12QuotaQuotaUsage) HasFsphysical() bool`

HasFsphysical returns a boolean if a field has been set.

### GetFsphysicalReady

`func (o *V12QuotaQuotaUsage) GetFsphysicalReady() bool`

GetFsphysicalReady returns the FsphysicalReady field if non-nil, zero value otherwise.

### GetFsphysicalReadyOk

`func (o *V12QuotaQuotaUsage) GetFsphysicalReadyOk() (*bool, bool)`

GetFsphysicalReadyOk returns a tuple with the FsphysicalReady field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFsphysicalReady

`func (o *V12QuotaQuotaUsage) SetFsphysicalReady(v bool)`

SetFsphysicalReady sets FsphysicalReady field to given value.


### GetInodes

`func (o *V12QuotaQuotaUsage) GetInodes() int32`

GetInodes returns the Inodes field if non-nil, zero value otherwise.

### GetInodesOk

`func (o *V12QuotaQuotaUsage) GetInodesOk() (*int32, bool)`

GetInodesOk returns a tuple with the Inodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInodes

`func (o *V12QuotaQuotaUsage) SetInodes(v int32)`

SetInodes sets Inodes field to given value.


### GetInodesReady

`func (o *V12QuotaQuotaUsage) GetInodesReady() bool`

GetInodesReady returns the InodesReady field if non-nil, zero value otherwise.

### GetInodesReadyOk

`func (o *V12QuotaQuotaUsage) GetInodesReadyOk() (*bool, bool)`

GetInodesReadyOk returns a tuple with the InodesReady field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetInodesReady

`func (o *V12QuotaQuotaUsage) SetInodesReady(v bool)`

SetInodesReady sets InodesReady field to given value.


### GetPhysical

`func (o *V12QuotaQuotaUsage) GetPhysical() int32`

GetPhysical returns the Physical field if non-nil, zero value otherwise.

### GetPhysicalOk

`func (o *V12QuotaQuotaUsage) GetPhysicalOk() (*int32, bool)`

GetPhysicalOk returns a tuple with the Physical field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysical

`func (o *V12QuotaQuotaUsage) SetPhysical(v int32)`

SetPhysical sets Physical field to given value.


### GetPhysicalData

`func (o *V12QuotaQuotaUsage) GetPhysicalData() int32`

GetPhysicalData returns the PhysicalData field if non-nil, zero value otherwise.

### GetPhysicalDataOk

`func (o *V12QuotaQuotaUsage) GetPhysicalDataOk() (*int32, bool)`

GetPhysicalDataOk returns a tuple with the PhysicalData field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysicalData

`func (o *V12QuotaQuotaUsage) SetPhysicalData(v int32)`

SetPhysicalData sets PhysicalData field to given value.


### GetPhysicalDataReady

`func (o *V12QuotaQuotaUsage) GetPhysicalDataReady() bool`

GetPhysicalDataReady returns the PhysicalDataReady field if non-nil, zero value otherwise.

### GetPhysicalDataReadyOk

`func (o *V12QuotaQuotaUsage) GetPhysicalDataReadyOk() (*bool, bool)`

GetPhysicalDataReadyOk returns a tuple with the PhysicalDataReady field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysicalDataReady

`func (o *V12QuotaQuotaUsage) SetPhysicalDataReady(v bool)`

SetPhysicalDataReady sets PhysicalDataReady field to given value.


### GetPhysicalProtection

`func (o *V12QuotaQuotaUsage) GetPhysicalProtection() int32`

GetPhysicalProtection returns the PhysicalProtection field if non-nil, zero value otherwise.

### GetPhysicalProtectionOk

`func (o *V12QuotaQuotaUsage) GetPhysicalProtectionOk() (*int32, bool)`

GetPhysicalProtectionOk returns a tuple with the PhysicalProtection field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysicalProtection

`func (o *V12QuotaQuotaUsage) SetPhysicalProtection(v int32)`

SetPhysicalProtection sets PhysicalProtection field to given value.


### GetPhysicalProtectionReady

`func (o *V12QuotaQuotaUsage) GetPhysicalProtectionReady() bool`

GetPhysicalProtectionReady returns the PhysicalProtectionReady field if non-nil, zero value otherwise.

### GetPhysicalProtectionReadyOk

`func (o *V12QuotaQuotaUsage) GetPhysicalProtectionReadyOk() (*bool, bool)`

GetPhysicalProtectionReadyOk returns a tuple with the PhysicalProtectionReady field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysicalProtectionReady

`func (o *V12QuotaQuotaUsage) SetPhysicalProtectionReady(v bool)`

SetPhysicalProtectionReady sets PhysicalProtectionReady field to given value.


### GetPhysicalReady

`func (o *V12QuotaQuotaUsage) GetPhysicalReady() bool`

GetPhysicalReady returns the PhysicalReady field if non-nil, zero value otherwise.

### GetPhysicalReadyOk

`func (o *V12QuotaQuotaUsage) GetPhysicalReadyOk() (*bool, bool)`

GetPhysicalReadyOk returns a tuple with the PhysicalReady field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetPhysicalReady

`func (o *V12QuotaQuotaUsage) SetPhysicalReady(v bool)`

SetPhysicalReady sets PhysicalReady field to given value.


### GetShadowRefs

`func (o *V12QuotaQuotaUsage) GetShadowRefs() int32`

GetShadowRefs returns the ShadowRefs field if non-nil, zero value otherwise.

### GetShadowRefsOk

`func (o *V12QuotaQuotaUsage) GetShadowRefsOk() (*int32, bool)`

GetShadowRefsOk returns a tuple with the ShadowRefs field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowRefs

`func (o *V12QuotaQuotaUsage) SetShadowRefs(v int32)`

SetShadowRefs sets ShadowRefs field to given value.


### GetShadowRefsReady

`func (o *V12QuotaQuotaUsage) GetShadowRefsReady() bool`

GetShadowRefsReady returns the ShadowRefsReady field if non-nil, zero value otherwise.

### GetShadowRefsReadyOk

`func (o *V12QuotaQuotaUsage) GetShadowRefsReadyOk() (*bool, bool)`

GetShadowRefsReadyOk returns a tuple with the ShadowRefsReady field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetShadowRefsReady

`func (o *V12QuotaQuotaUsage) SetShadowRefsReady(v bool)`

SetShadowRefsReady sets ShadowRefsReady field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


