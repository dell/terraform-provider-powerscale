# V11AvscanServerExtendedExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Enabled** | Pointer to **bool** | Whether the server is enabled. | [optional] 
**Id** | Pointer to **string** | A unique identifier for the server. | [optional] 
**NewName** | Pointer to **string** | New unique short name for the server. | [optional] 
**ServerUri** | Pointer to **string** | URI of the server. Typical format is: domain:port/path | [optional] 

## Methods

### NewV11AvscanServerExtendedExtended

`func NewV11AvscanServerExtendedExtended() *V11AvscanServerExtendedExtended`

NewV11AvscanServerExtendedExtended instantiates a new V11AvscanServerExtendedExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AvscanServerExtendedExtendedWithDefaults

`func NewV11AvscanServerExtendedExtendedWithDefaults() *V11AvscanServerExtendedExtended`

NewV11AvscanServerExtendedExtendedWithDefaults instantiates a new V11AvscanServerExtendedExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetEnabled

`func (o *V11AvscanServerExtendedExtended) GetEnabled() bool`

GetEnabled returns the Enabled field if non-nil, zero value otherwise.

### GetEnabledOk

`func (o *V11AvscanServerExtendedExtended) GetEnabledOk() (*bool, bool)`

GetEnabledOk returns a tuple with the Enabled field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetEnabled

`func (o *V11AvscanServerExtendedExtended) SetEnabled(v bool)`

SetEnabled sets Enabled field to given value.

### HasEnabled

`func (o *V11AvscanServerExtendedExtended) HasEnabled() bool`

HasEnabled returns a boolean if a field has been set.

### GetId

`func (o *V11AvscanServerExtendedExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V11AvscanServerExtendedExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V11AvscanServerExtendedExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V11AvscanServerExtendedExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetNewName

`func (o *V11AvscanServerExtendedExtended) GetNewName() string`

GetNewName returns the NewName field if non-nil, zero value otherwise.

### GetNewNameOk

`func (o *V11AvscanServerExtendedExtended) GetNewNameOk() (*string, bool)`

GetNewNameOk returns a tuple with the NewName field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNewName

`func (o *V11AvscanServerExtendedExtended) SetNewName(v string)`

SetNewName sets NewName field to given value.

### HasNewName

`func (o *V11AvscanServerExtendedExtended) HasNewName() bool`

HasNewName returns a boolean if a field has been set.

### GetServerUri

`func (o *V11AvscanServerExtendedExtended) GetServerUri() string`

GetServerUri returns the ServerUri field if non-nil, zero value otherwise.

### GetServerUriOk

`func (o *V11AvscanServerExtendedExtended) GetServerUriOk() (*string, bool)`

GetServerUriOk returns a tuple with the ServerUri field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetServerUri

`func (o *V11AvscanServerExtendedExtended) SetServerUri(v string)`

SetServerUri sets ServerUri field to given value.

### HasServerUri

`func (o *V11AvscanServerExtendedExtended) HasServerUri() bool`

HasServerUri returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


