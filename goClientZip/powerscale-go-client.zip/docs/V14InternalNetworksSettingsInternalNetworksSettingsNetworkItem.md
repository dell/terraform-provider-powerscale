# V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BackendConfig** | [**V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig**](V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig.md) |  | 
**Name** | **string** | Name of the backend network. | 

## Methods

### NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItem

`func NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItem(backendConfig V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig, name string, ) *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem`

NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItem instantiates a new V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItemWithDefaults

`func NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItemWithDefaults() *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem`

NewV14InternalNetworksSettingsInternalNetworksSettingsNetworkItemWithDefaults instantiates a new V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBackendConfig

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem) GetBackendConfig() V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig`

GetBackendConfig returns the BackendConfig field if non-nil, zero value otherwise.

### GetBackendConfigOk

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem) GetBackendConfigOk() (*V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig, bool)`

GetBackendConfigOk returns a tuple with the BackendConfig field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBackendConfig

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem) SetBackendConfig(v V14InternalNetworksSettingsInternalNetworksSettingsNetworkItemBackendConfig)`

SetBackendConfig sets BackendConfig field to given value.


### GetName

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V14InternalNetworksSettingsInternalNetworksSettingsNetworkItem) SetName(v string)`

SetName sets Name field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


