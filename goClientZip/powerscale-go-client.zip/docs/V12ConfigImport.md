# V12ConfigImport

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Components** | Pointer to **string** | Specifies the components which will be imported. | [optional] 
**ExportId** | **string** | The export ID given to the task. | 

## Methods

### NewV12ConfigImport

`func NewV12ConfigImport(exportId string, ) *V12ConfigImport`

NewV12ConfigImport instantiates a new V12ConfigImport object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ConfigImportWithDefaults

`func NewV12ConfigImportWithDefaults() *V12ConfigImport`

NewV12ConfigImportWithDefaults instantiates a new V12ConfigImport object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetComponents

`func (o *V12ConfigImport) GetComponents() string`

GetComponents returns the Components field if non-nil, zero value otherwise.

### GetComponentsOk

`func (o *V12ConfigImport) GetComponentsOk() (*string, bool)`

GetComponentsOk returns a tuple with the Components field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetComponents

`func (o *V12ConfigImport) SetComponents(v string)`

SetComponents sets Components field to given value.

### HasComponents

`func (o *V12ConfigImport) HasComponents() bool`

HasComponents returns a boolean if a field has been set.

### GetExportId

`func (o *V12ConfigImport) GetExportId() string`

GetExportId returns the ExportId field if non-nil, zero value otherwise.

### GetExportIdOk

`func (o *V12ConfigImport) GetExportIdOk() (*string, bool)`

GetExportIdOk returns a tuple with the ExportId field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetExportId

`func (o *V12ConfigImport) SetExportId(v string)`

SetExportId sets ExportId field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


