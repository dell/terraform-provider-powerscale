# V10PerformanceMetricsExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Metrics** | Pointer to [**[]V10PerformanceMetric**](V10PerformanceMetric.md) |  | [optional] 

## Methods

### NewV10PerformanceMetricsExtended

`func NewV10PerformanceMetricsExtended() *V10PerformanceMetricsExtended`

NewV10PerformanceMetricsExtended instantiates a new V10PerformanceMetricsExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10PerformanceMetricsExtendedWithDefaults

`func NewV10PerformanceMetricsExtendedWithDefaults() *V10PerformanceMetricsExtended`

NewV10PerformanceMetricsExtendedWithDefaults instantiates a new V10PerformanceMetricsExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetMetrics

`func (o *V10PerformanceMetricsExtended) GetMetrics() []V10PerformanceMetric`

GetMetrics returns the Metrics field if non-nil, zero value otherwise.

### GetMetricsOk

`func (o *V10PerformanceMetricsExtended) GetMetricsOk() (*[]V10PerformanceMetric, bool)`

GetMetricsOk returns a tuple with the Metrics field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetMetrics

`func (o *V10PerformanceMetricsExtended) SetMetrics(v []V10PerformanceMetric)`

SetMetrics sets Metrics field to given value.

### HasMetrics

`func (o *V10PerformanceMetricsExtended) HasMetrics() bool`

HasMetrics returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


