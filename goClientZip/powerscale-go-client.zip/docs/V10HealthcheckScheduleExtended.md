# V10HealthcheckScheduleExtended

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Base** | Pointer to **string** | Seconds from Epoc when schedule was created. | [optional] 
**Checklist** | Pointer to **string** | Checklist or Item for scheduling. | [optional] 
**Id** | Pointer to **string** | The ID of the newly created schedule. | [optional] 
**Name** | Pointer to **string** | The schedule name. | [optional] 
**NextRun** | Pointer to **string** | Seconds from Epoc when next evaluation will run. | [optional] 
**Schedule** | Pointer to **string** | The isi-schedule compatible natural language description of the schedule. | [optional] 

## Methods

### NewV10HealthcheckScheduleExtended

`func NewV10HealthcheckScheduleExtended() *V10HealthcheckScheduleExtended`

NewV10HealthcheckScheduleExtended instantiates a new V10HealthcheckScheduleExtended object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV10HealthcheckScheduleExtendedWithDefaults

`func NewV10HealthcheckScheduleExtendedWithDefaults() *V10HealthcheckScheduleExtended`

NewV10HealthcheckScheduleExtendedWithDefaults instantiates a new V10HealthcheckScheduleExtended object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetBase

`func (o *V10HealthcheckScheduleExtended) GetBase() string`

GetBase returns the Base field if non-nil, zero value otherwise.

### GetBaseOk

`func (o *V10HealthcheckScheduleExtended) GetBaseOk() (*string, bool)`

GetBaseOk returns a tuple with the Base field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetBase

`func (o *V10HealthcheckScheduleExtended) SetBase(v string)`

SetBase sets Base field to given value.

### HasBase

`func (o *V10HealthcheckScheduleExtended) HasBase() bool`

HasBase returns a boolean if a field has been set.

### GetChecklist

`func (o *V10HealthcheckScheduleExtended) GetChecklist() string`

GetChecklist returns the Checklist field if non-nil, zero value otherwise.

### GetChecklistOk

`func (o *V10HealthcheckScheduleExtended) GetChecklistOk() (*string, bool)`

GetChecklistOk returns a tuple with the Checklist field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetChecklist

`func (o *V10HealthcheckScheduleExtended) SetChecklist(v string)`

SetChecklist sets Checklist field to given value.

### HasChecklist

`func (o *V10HealthcheckScheduleExtended) HasChecklist() bool`

HasChecklist returns a boolean if a field has been set.

### GetId

`func (o *V10HealthcheckScheduleExtended) GetId() string`

GetId returns the Id field if non-nil, zero value otherwise.

### GetIdOk

`func (o *V10HealthcheckScheduleExtended) GetIdOk() (*string, bool)`

GetIdOk returns a tuple with the Id field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetId

`func (o *V10HealthcheckScheduleExtended) SetId(v string)`

SetId sets Id field to given value.

### HasId

`func (o *V10HealthcheckScheduleExtended) HasId() bool`

HasId returns a boolean if a field has been set.

### GetName

`func (o *V10HealthcheckScheduleExtended) GetName() string`

GetName returns the Name field if non-nil, zero value otherwise.

### GetNameOk

`func (o *V10HealthcheckScheduleExtended) GetNameOk() (*string, bool)`

GetNameOk returns a tuple with the Name field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetName

`func (o *V10HealthcheckScheduleExtended) SetName(v string)`

SetName sets Name field to given value.

### HasName

`func (o *V10HealthcheckScheduleExtended) HasName() bool`

HasName returns a boolean if a field has been set.

### GetNextRun

`func (o *V10HealthcheckScheduleExtended) GetNextRun() string`

GetNextRun returns the NextRun field if non-nil, zero value otherwise.

### GetNextRunOk

`func (o *V10HealthcheckScheduleExtended) GetNextRunOk() (*string, bool)`

GetNextRunOk returns a tuple with the NextRun field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNextRun

`func (o *V10HealthcheckScheduleExtended) SetNextRun(v string)`

SetNextRun sets NextRun field to given value.

### HasNextRun

`func (o *V10HealthcheckScheduleExtended) HasNextRun() bool`

HasNextRun returns a boolean if a field has been set.

### GetSchedule

`func (o *V10HealthcheckScheduleExtended) GetSchedule() string`

GetSchedule returns the Schedule field if non-nil, zero value otherwise.

### GetScheduleOk

`func (o *V10HealthcheckScheduleExtended) GetScheduleOk() (*string, bool)`

GetScheduleOk returns a tuple with the Schedule field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSchedule

`func (o *V10HealthcheckScheduleExtended) SetSchedule(v string)`

SetSchedule sets Schedule field to given value.

### HasSchedule

`func (o *V10HealthcheckScheduleExtended) HasSchedule() bool`

HasSchedule returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


