# \PerformanceDatasetsApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreatePerformanceDatasetsv10DatasetFilter**](PerformanceDatasetsApi.md#CreatePerformanceDatasetsv10DatasetFilter) | **Post** /platform/10/performance/datasets/{Dataset}/filters | 
[**CreatePerformanceDatasetsv10DatasetWorkload**](PerformanceDatasetsApi.md#CreatePerformanceDatasetsv10DatasetWorkload) | **Post** /platform/10/performance/datasets/{Dataset}/workloads | 
[**CreatePerformanceDatasetsv12DatasetFilter**](PerformanceDatasetsApi.md#CreatePerformanceDatasetsv12DatasetFilter) | **Post** /platform/12/performance/datasets/{Dataset}/filters | 
[**CreatePerformanceDatasetsv12DatasetWorkload**](PerformanceDatasetsApi.md#CreatePerformanceDatasetsv12DatasetWorkload) | **Post** /platform/12/performance/datasets/{Dataset}/workloads | 
[**CreatePerformanceDatasetsv16DatasetWorkload**](PerformanceDatasetsApi.md#CreatePerformanceDatasetsv16DatasetWorkload) | **Post** /platform/16/performance/datasets/{Dataset}/workloads | 
[**CreatePerformanceDatasetsv7DatasetFilter**](PerformanceDatasetsApi.md#CreatePerformanceDatasetsv7DatasetFilter) | **Post** /platform/7/performance/datasets/{Dataset}/filters | 
[**CreatePerformanceDatasetsv7DatasetWorkload**](PerformanceDatasetsApi.md#CreatePerformanceDatasetsv7DatasetWorkload) | **Post** /platform/7/performance/datasets/{Dataset}/workloads | 
[**CreatePerformanceDatasetsv9DatasetFilter**](PerformanceDatasetsApi.md#CreatePerformanceDatasetsv9DatasetFilter) | **Post** /platform/9/performance/datasets/{Dataset}/filters | 
[**CreatePerformanceDatasetsv9DatasetWorkload**](PerformanceDatasetsApi.md#CreatePerformanceDatasetsv9DatasetWorkload) | **Post** /platform/9/performance/datasets/{Dataset}/workloads | 
[**DeletePerformanceDatasetsv10DatasetFilters**](PerformanceDatasetsApi.md#DeletePerformanceDatasetsv10DatasetFilters) | **Delete** /platform/10/performance/datasets/{Dataset}/filters | 
[**DeletePerformanceDatasetsv10DatasetWorkloads**](PerformanceDatasetsApi.md#DeletePerformanceDatasetsv10DatasetWorkloads) | **Delete** /platform/10/performance/datasets/{Dataset}/workloads | 
[**DeletePerformanceDatasetsv12DatasetFilters**](PerformanceDatasetsApi.md#DeletePerformanceDatasetsv12DatasetFilters) | **Delete** /platform/12/performance/datasets/{Dataset}/filters | 
[**DeletePerformanceDatasetsv12DatasetWorkloads**](PerformanceDatasetsApi.md#DeletePerformanceDatasetsv12DatasetWorkloads) | **Delete** /platform/12/performance/datasets/{Dataset}/workloads | 
[**DeletePerformanceDatasetsv16DatasetWorkloads**](PerformanceDatasetsApi.md#DeletePerformanceDatasetsv16DatasetWorkloads) | **Delete** /platform/16/performance/datasets/{Dataset}/workloads | 
[**DeletePerformanceDatasetsv7DatasetFilters**](PerformanceDatasetsApi.md#DeletePerformanceDatasetsv7DatasetFilters) | **Delete** /platform/7/performance/datasets/{Dataset}/filters | 
[**DeletePerformanceDatasetsv7DatasetWorkloads**](PerformanceDatasetsApi.md#DeletePerformanceDatasetsv7DatasetWorkloads) | **Delete** /platform/7/performance/datasets/{Dataset}/workloads | 
[**DeletePerformanceDatasetsv9DatasetFilters**](PerformanceDatasetsApi.md#DeletePerformanceDatasetsv9DatasetFilters) | **Delete** /platform/9/performance/datasets/{Dataset}/filters | 
[**DeletePerformanceDatasetsv9DatasetWorkloads**](PerformanceDatasetsApi.md#DeletePerformanceDatasetsv9DatasetWorkloads) | **Delete** /platform/9/performance/datasets/{Dataset}/workloads | 
[**ListPerformanceDatasetsv10DatasetFilters**](PerformanceDatasetsApi.md#ListPerformanceDatasetsv10DatasetFilters) | **Get** /platform/10/performance/datasets/{Dataset}/filters | 
[**ListPerformanceDatasetsv10DatasetWorkloads**](PerformanceDatasetsApi.md#ListPerformanceDatasetsv10DatasetWorkloads) | **Get** /platform/10/performance/datasets/{Dataset}/workloads | 
[**ListPerformanceDatasetsv12DatasetFilters**](PerformanceDatasetsApi.md#ListPerformanceDatasetsv12DatasetFilters) | **Get** /platform/12/performance/datasets/{Dataset}/filters | 
[**ListPerformanceDatasetsv12DatasetWorkloads**](PerformanceDatasetsApi.md#ListPerformanceDatasetsv12DatasetWorkloads) | **Get** /platform/12/performance/datasets/{Dataset}/workloads | 
[**ListPerformanceDatasetsv16DatasetWorkloads**](PerformanceDatasetsApi.md#ListPerformanceDatasetsv16DatasetWorkloads) | **Get** /platform/16/performance/datasets/{Dataset}/workloads | 
[**ListPerformanceDatasetsv7DatasetFilters**](PerformanceDatasetsApi.md#ListPerformanceDatasetsv7DatasetFilters) | **Get** /platform/7/performance/datasets/{Dataset}/filters | 
[**ListPerformanceDatasetsv7DatasetWorkloads**](PerformanceDatasetsApi.md#ListPerformanceDatasetsv7DatasetWorkloads) | **Get** /platform/7/performance/datasets/{Dataset}/workloads | 
[**ListPerformanceDatasetsv9DatasetFilters**](PerformanceDatasetsApi.md#ListPerformanceDatasetsv9DatasetFilters) | **Get** /platform/9/performance/datasets/{Dataset}/filters | 
[**ListPerformanceDatasetsv9DatasetWorkloads**](PerformanceDatasetsApi.md#ListPerformanceDatasetsv9DatasetWorkloads) | **Get** /platform/9/performance/datasets/{Dataset}/workloads | 



## CreatePerformanceDatasetsv10DatasetFilter

> Createv10DatasetFilterResponse CreatePerformanceDatasetsv10DatasetFilter(ctx, dataset).V10DatasetFilter(v10DatasetFilter).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    v10DatasetFilter := *openapiclient.NewV10DatasetFilter(*openapiclient.NewV10DatasetFilterMetricValues()) // V10DatasetFilter | 
    force := true // bool | For use by support only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.CreatePerformanceDatasetsv10DatasetFilter(context.Background(), dataset).V10DatasetFilter(v10DatasetFilter).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.CreatePerformanceDatasetsv10DatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformanceDatasetsv10DatasetFilter`: Createv10DatasetFilterResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.CreatePerformanceDatasetsv10DatasetFilter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformanceDatasetsv10DatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v10DatasetFilter** | [**V10DatasetFilter**](V10DatasetFilter.md) |  | 
 **force** | **bool** | For use by support only. | 

### Return type

[**Createv10DatasetFilterResponse**](Createv10DatasetFilterResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformanceDatasetsv10DatasetWorkload

> Createv10DatasetWorkloadResponse CreatePerformanceDatasetsv10DatasetWorkload(ctx, dataset).V10DatasetWorkload(v10DatasetWorkload).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    v10DatasetWorkload := *openapiclient.NewV10DatasetWorkload(*openapiclient.NewV10DatasetFilterMetricValues()) // V10DatasetWorkload | 
    force := true // bool | For use by support only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.CreatePerformanceDatasetsv10DatasetWorkload(context.Background(), dataset).V10DatasetWorkload(v10DatasetWorkload).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.CreatePerformanceDatasetsv10DatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformanceDatasetsv10DatasetWorkload`: Createv10DatasetWorkloadResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.CreatePerformanceDatasetsv10DatasetWorkload`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformanceDatasetsv10DatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v10DatasetWorkload** | [**V10DatasetWorkload**](V10DatasetWorkload.md) |  | 
 **force** | **bool** | For use by support only. | 

### Return type

[**Createv10DatasetWorkloadResponse**](Createv10DatasetWorkloadResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformanceDatasetsv12DatasetFilter

> Createv10DatasetFilterResponse CreatePerformanceDatasetsv12DatasetFilter(ctx, dataset).V12DatasetFilter(v12DatasetFilter).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    v12DatasetFilter := *openapiclient.NewV12DatasetFilter(*openapiclient.NewV12DatasetFilterMetricValues()) // V12DatasetFilter | 
    force := true // bool | For use by support only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.CreatePerformanceDatasetsv12DatasetFilter(context.Background(), dataset).V12DatasetFilter(v12DatasetFilter).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.CreatePerformanceDatasetsv12DatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformanceDatasetsv12DatasetFilter`: Createv10DatasetFilterResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.CreatePerformanceDatasetsv12DatasetFilter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformanceDatasetsv12DatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12DatasetFilter** | [**V12DatasetFilter**](V12DatasetFilter.md) |  | 
 **force** | **bool** | For use by support only. | 

### Return type

[**Createv10DatasetFilterResponse**](Createv10DatasetFilterResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformanceDatasetsv12DatasetWorkload

> Createv10DatasetWorkloadResponse CreatePerformanceDatasetsv12DatasetWorkload(ctx, dataset).V12DatasetWorkload(v12DatasetWorkload).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    v12DatasetWorkload := *openapiclient.NewV12DatasetWorkload(*openapiclient.NewV12DatasetFilterMetricValues()) // V12DatasetWorkload | 
    force := true // bool | For use by support only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.CreatePerformanceDatasetsv12DatasetWorkload(context.Background(), dataset).V12DatasetWorkload(v12DatasetWorkload).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.CreatePerformanceDatasetsv12DatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformanceDatasetsv12DatasetWorkload`: Createv10DatasetWorkloadResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.CreatePerformanceDatasetsv12DatasetWorkload`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformanceDatasetsv12DatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v12DatasetWorkload** | [**V12DatasetWorkload**](V12DatasetWorkload.md) |  | 
 **force** | **bool** | For use by support only. | 

### Return type

[**Createv10DatasetWorkloadResponse**](Createv10DatasetWorkloadResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformanceDatasetsv16DatasetWorkload

> Createv10DatasetWorkloadResponse CreatePerformanceDatasetsv16DatasetWorkload(ctx, dataset).V16DatasetWorkload(v16DatasetWorkload).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    v16DatasetWorkload := *openapiclient.NewV16DatasetWorkload(*openapiclient.NewV12DatasetFilterMetricValues()) // V16DatasetWorkload | 
    force := true // bool | For use by support only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.CreatePerformanceDatasetsv16DatasetWorkload(context.Background(), dataset).V16DatasetWorkload(v16DatasetWorkload).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.CreatePerformanceDatasetsv16DatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformanceDatasetsv16DatasetWorkload`: Createv10DatasetWorkloadResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.CreatePerformanceDatasetsv16DatasetWorkload`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformanceDatasetsv16DatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v16DatasetWorkload** | [**V16DatasetWorkload**](V16DatasetWorkload.md) |  | 
 **force** | **bool** | For use by support only. | 

### Return type

[**Createv10DatasetWorkloadResponse**](Createv10DatasetWorkloadResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformanceDatasetsv7DatasetFilter

> Createv10DatasetFilterResponse CreatePerformanceDatasetsv7DatasetFilter(ctx, dataset).V7DatasetFilter(v7DatasetFilter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    v7DatasetFilter := *openapiclient.NewV7DatasetFilter(*openapiclient.NewV7DatasetFilterMetricValues()) // V7DatasetFilter | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.CreatePerformanceDatasetsv7DatasetFilter(context.Background(), dataset).V7DatasetFilter(v7DatasetFilter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.CreatePerformanceDatasetsv7DatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformanceDatasetsv7DatasetFilter`: Createv10DatasetFilterResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.CreatePerformanceDatasetsv7DatasetFilter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformanceDatasetsv7DatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7DatasetFilter** | [**V7DatasetFilter**](V7DatasetFilter.md) |  | 

### Return type

[**Createv10DatasetFilterResponse**](Createv10DatasetFilterResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformanceDatasetsv7DatasetWorkload

> Createv10DatasetWorkloadResponse CreatePerformanceDatasetsv7DatasetWorkload(ctx, dataset).V7DatasetWorkload(v7DatasetWorkload).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    v7DatasetWorkload := *openapiclient.NewV7DatasetWorkload(*openapiclient.NewV7DatasetFilterMetricValues()) // V7DatasetWorkload | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.CreatePerformanceDatasetsv7DatasetWorkload(context.Background(), dataset).V7DatasetWorkload(v7DatasetWorkload).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.CreatePerformanceDatasetsv7DatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformanceDatasetsv7DatasetWorkload`: Createv10DatasetWorkloadResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.CreatePerformanceDatasetsv7DatasetWorkload`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformanceDatasetsv7DatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v7DatasetWorkload** | [**V7DatasetWorkload**](V7DatasetWorkload.md) |  | 

### Return type

[**Createv10DatasetWorkloadResponse**](Createv10DatasetWorkloadResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformanceDatasetsv9DatasetFilter

> Createv10DatasetFilterResponse CreatePerformanceDatasetsv9DatasetFilter(ctx, dataset).V9DatasetFilter(v9DatasetFilter).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    v9DatasetFilter := *openapiclient.NewV9DatasetFilter(*openapiclient.NewV9DatasetFilterMetricValues()) // V9DatasetFilter | 
    force := true // bool | For use by support only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.CreatePerformanceDatasetsv9DatasetFilter(context.Background(), dataset).V9DatasetFilter(v9DatasetFilter).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.CreatePerformanceDatasetsv9DatasetFilter``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformanceDatasetsv9DatasetFilter`: Createv10DatasetFilterResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.CreatePerformanceDatasetsv9DatasetFilter`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformanceDatasetsv9DatasetFilterRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v9DatasetFilter** | [**V9DatasetFilter**](V9DatasetFilter.md) |  | 
 **force** | **bool** | For use by support only. | 

### Return type

[**Createv10DatasetFilterResponse**](Createv10DatasetFilterResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## CreatePerformanceDatasetsv9DatasetWorkload

> Createv10DatasetWorkloadResponse CreatePerformanceDatasetsv9DatasetWorkload(ctx, dataset).V9DatasetWorkload(v9DatasetWorkload).Force(force).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    v9DatasetWorkload := *openapiclient.NewV9DatasetWorkload(*openapiclient.NewV9DatasetFilterMetricValues()) // V9DatasetWorkload | 
    force := true // bool | For use by support only. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.CreatePerformanceDatasetsv9DatasetWorkload(context.Background(), dataset).V9DatasetWorkload(v9DatasetWorkload).Force(force).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.CreatePerformanceDatasetsv9DatasetWorkload``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `CreatePerformanceDatasetsv9DatasetWorkload`: Createv10DatasetWorkloadResponse
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.CreatePerformanceDatasetsv9DatasetWorkload`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiCreatePerformanceDatasetsv9DatasetWorkloadRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v9DatasetWorkload** | [**V9DatasetWorkload**](V9DatasetWorkload.md) |  | 
 **force** | **bool** | For use by support only. | 

### Return type

[**Createv10DatasetWorkloadResponse**](Createv10DatasetWorkloadResponse.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformanceDatasetsv10DatasetFilters

> DeletePerformanceDatasetsv10DatasetFilters(ctx, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceDatasetsApi.DeletePerformanceDatasetsv10DatasetFilters(context.Background(), dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.DeletePerformanceDatasetsv10DatasetFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformanceDatasetsv10DatasetFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformanceDatasetsv10DatasetWorkloads

> DeletePerformanceDatasetsv10DatasetWorkloads(ctx, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceDatasetsApi.DeletePerformanceDatasetsv10DatasetWorkloads(context.Background(), dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.DeletePerformanceDatasetsv10DatasetWorkloads``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformanceDatasetsv10DatasetWorkloadsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformanceDatasetsv12DatasetFilters

> DeletePerformanceDatasetsv12DatasetFilters(ctx, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceDatasetsApi.DeletePerformanceDatasetsv12DatasetFilters(context.Background(), dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.DeletePerformanceDatasetsv12DatasetFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformanceDatasetsv12DatasetFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformanceDatasetsv12DatasetWorkloads

> DeletePerformanceDatasetsv12DatasetWorkloads(ctx, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceDatasetsApi.DeletePerformanceDatasetsv12DatasetWorkloads(context.Background(), dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.DeletePerformanceDatasetsv12DatasetWorkloads``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformanceDatasetsv12DatasetWorkloadsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformanceDatasetsv16DatasetWorkloads

> DeletePerformanceDatasetsv16DatasetWorkloads(ctx, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceDatasetsApi.DeletePerformanceDatasetsv16DatasetWorkloads(context.Background(), dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.DeletePerformanceDatasetsv16DatasetWorkloads``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformanceDatasetsv16DatasetWorkloadsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformanceDatasetsv7DatasetFilters

> DeletePerformanceDatasetsv7DatasetFilters(ctx, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceDatasetsApi.DeletePerformanceDatasetsv7DatasetFilters(context.Background(), dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.DeletePerformanceDatasetsv7DatasetFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformanceDatasetsv7DatasetFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformanceDatasetsv7DatasetWorkloads

> DeletePerformanceDatasetsv7DatasetWorkloads(ctx, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceDatasetsApi.DeletePerformanceDatasetsv7DatasetWorkloads(context.Background(), dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.DeletePerformanceDatasetsv7DatasetWorkloads``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformanceDatasetsv7DatasetWorkloadsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformanceDatasetsv9DatasetFilters

> DeletePerformanceDatasetsv9DatasetFilters(ctx, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceDatasetsApi.DeletePerformanceDatasetsv9DatasetFilters(context.Background(), dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.DeletePerformanceDatasetsv9DatasetFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformanceDatasetsv9DatasetFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeletePerformanceDatasetsv9DatasetWorkloads

> DeletePerformanceDatasetsv9DatasetWorkloads(ctx, dataset).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.PerformanceDatasetsApi.DeletePerformanceDatasetsv9DatasetWorkloads(context.Background(), dataset).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.DeletePerformanceDatasetsv9DatasetWorkloads``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeletePerformanceDatasetsv9DatasetWorkloadsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformanceDatasetsv10DatasetFilters

> V10DatasetFilters ListPerformanceDatasetsv10DatasetFilters(ctx, dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.ListPerformanceDatasetsv10DatasetFilters(context.Background(), dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.ListPerformanceDatasetsv10DatasetFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformanceDatasetsv10DatasetFilters`: V10DatasetFilters
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.ListPerformanceDatasetsv10DatasetFilters`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListPerformanceDatasetsv10DatasetFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V10DatasetFilters**](V10DatasetFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformanceDatasetsv10DatasetWorkloads

> V10DatasetWorkloads ListPerformanceDatasetsv10DatasetWorkloads(ctx, dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.ListPerformanceDatasetsv10DatasetWorkloads(context.Background(), dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.ListPerformanceDatasetsv10DatasetWorkloads``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformanceDatasetsv10DatasetWorkloads`: V10DatasetWorkloads
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.ListPerformanceDatasetsv10DatasetWorkloads`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListPerformanceDatasetsv10DatasetWorkloadsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V10DatasetWorkloads**](V10DatasetWorkloads.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformanceDatasetsv12DatasetFilters

> V12DatasetFilters ListPerformanceDatasetsv12DatasetFilters(ctx, dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.ListPerformanceDatasetsv12DatasetFilters(context.Background(), dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.ListPerformanceDatasetsv12DatasetFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformanceDatasetsv12DatasetFilters`: V12DatasetFilters
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.ListPerformanceDatasetsv12DatasetFilters`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListPerformanceDatasetsv12DatasetFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V12DatasetFilters**](V12DatasetFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformanceDatasetsv12DatasetWorkloads

> V12DatasetWorkloads ListPerformanceDatasetsv12DatasetWorkloads(ctx, dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.ListPerformanceDatasetsv12DatasetWorkloads(context.Background(), dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.ListPerformanceDatasetsv12DatasetWorkloads``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformanceDatasetsv12DatasetWorkloads`: V12DatasetWorkloads
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.ListPerformanceDatasetsv12DatasetWorkloads`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListPerformanceDatasetsv12DatasetWorkloadsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V12DatasetWorkloads**](V12DatasetWorkloads.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformanceDatasetsv16DatasetWorkloads

> V16DatasetWorkloads ListPerformanceDatasetsv16DatasetWorkloads(ctx, dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.ListPerformanceDatasetsv16DatasetWorkloads(context.Background(), dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.ListPerformanceDatasetsv16DatasetWorkloads``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformanceDatasetsv16DatasetWorkloads`: V16DatasetWorkloads
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.ListPerformanceDatasetsv16DatasetWorkloads`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListPerformanceDatasetsv16DatasetWorkloadsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V16DatasetWorkloads**](V16DatasetWorkloads.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformanceDatasetsv7DatasetFilters

> V7DatasetFilters ListPerformanceDatasetsv7DatasetFilters(ctx, dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.ListPerformanceDatasetsv7DatasetFilters(context.Background(), dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.ListPerformanceDatasetsv7DatasetFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformanceDatasetsv7DatasetFilters`: V7DatasetFilters
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.ListPerformanceDatasetsv7DatasetFilters`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListPerformanceDatasetsv7DatasetFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7DatasetFilters**](V7DatasetFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformanceDatasetsv7DatasetWorkloads

> V7DatasetWorkloads ListPerformanceDatasetsv7DatasetWorkloads(ctx, dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.ListPerformanceDatasetsv7DatasetWorkloads(context.Background(), dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.ListPerformanceDatasetsv7DatasetWorkloads``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformanceDatasetsv7DatasetWorkloads`: V7DatasetWorkloads
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.ListPerformanceDatasetsv7DatasetWorkloads`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListPerformanceDatasetsv7DatasetWorkloadsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V7DatasetWorkloads**](V7DatasetWorkloads.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformanceDatasetsv9DatasetFilters

> V9DatasetFilters ListPerformanceDatasetsv9DatasetFilters(ctx, dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.ListPerformanceDatasetsv9DatasetFilters(context.Background(), dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.ListPerformanceDatasetsv9DatasetFilters``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformanceDatasetsv9DatasetFilters`: V9DatasetFilters
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.ListPerformanceDatasetsv9DatasetFilters`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListPerformanceDatasetsv9DatasetFiltersRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V9DatasetFilters**](V9DatasetFilters.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## ListPerformanceDatasetsv9DatasetWorkloads

> V9DatasetWorkloads ListPerformanceDatasetsv9DatasetWorkloads(ctx, dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    dataset := "dataset_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Return no more than this many results at once (see resume). (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)
    resume := "resume_example" // string | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.PerformanceDatasetsApi.ListPerformanceDatasetsv9DatasetWorkloads(context.Background(), dataset).Sort(sort).Limit(limit).Dir(dir).Resume(resume).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `PerformanceDatasetsApi.ListPerformanceDatasetsv9DatasetWorkloads``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `ListPerformanceDatasetsv9DatasetWorkloads`: V9DatasetWorkloads
    fmt.Fprintf(os.Stdout, "Response from `PerformanceDatasetsApi.ListPerformanceDatasetsv9DatasetWorkloads`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**dataset** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiListPerformanceDatasetsv9DatasetWorkloadsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Return no more than this many results at once (see resume). | 
 **dir** | **string** | The direction of the sort. | 
 **resume** | **string** | Continue returning results from previous call using this token (token should come from the previous call, resume cannot be used with other options). | 

### Return type

[**V9DatasetWorkloads**](V9DatasetWorkloads.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

