# DirectoryQueryScopeConditionsInner

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Attr** | Pointer to **string** |  | [optional] 
**Operator** | Pointer to **string** |  | [optional] 
**Value** | Pointer to **string** |  | [optional] 

## Methods

### NewDirectoryQueryScopeConditionsInner

`func NewDirectoryQueryScopeConditionsInner() *DirectoryQueryScopeConditionsInner`

NewDirectoryQueryScopeConditionsInner instantiates a new DirectoryQueryScopeConditionsInner object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewDirectoryQueryScopeConditionsInnerWithDefaults

`func NewDirectoryQueryScopeConditionsInnerWithDefaults() *DirectoryQueryScopeConditionsInner`

NewDirectoryQueryScopeConditionsInnerWithDefaults instantiates a new DirectoryQueryScopeConditionsInner object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAttr

`func (o *DirectoryQueryScopeConditionsInner) GetAttr() string`

GetAttr returns the Attr field if non-nil, zero value otherwise.

### GetAttrOk

`func (o *DirectoryQueryScopeConditionsInner) GetAttrOk() (*string, bool)`

GetAttrOk returns a tuple with the Attr field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAttr

`func (o *DirectoryQueryScopeConditionsInner) SetAttr(v string)`

SetAttr sets Attr field to given value.

### HasAttr

`func (o *DirectoryQueryScopeConditionsInner) HasAttr() bool`

HasAttr returns a boolean if a field has been set.

### GetOperator

`func (o *DirectoryQueryScopeConditionsInner) GetOperator() string`

GetOperator returns the Operator field if non-nil, zero value otherwise.

### GetOperatorOk

`func (o *DirectoryQueryScopeConditionsInner) GetOperatorOk() (*string, bool)`

GetOperatorOk returns a tuple with the Operator field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetOperator

`func (o *DirectoryQueryScopeConditionsInner) SetOperator(v string)`

SetOperator sets Operator field to given value.

### HasOperator

`func (o *DirectoryQueryScopeConditionsInner) HasOperator() bool`

HasOperator returns a boolean if a field has been set.

### GetValue

`func (o *DirectoryQueryScopeConditionsInner) GetValue() string`

GetValue returns the Value field if non-nil, zero value otherwise.

### GetValueOk

`func (o *DirectoryQueryScopeConditionsInner) GetValueOk() (*string, bool)`

GetValueOk returns a tuple with the Value field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetValue

`func (o *DirectoryQueryScopeConditionsInner) SetValue(v string)`

SetValue sets Value field to given value.

### HasValue

`func (o *DirectoryQueryScopeConditionsInner) HasValue() bool`

HasValue returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


