# \FsaApi

All URIs are relative to *https://YOUR_CLUSTER_HOSTNAME_OR_NODE_IP:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteFsav1FsaResult**](FsaApi.md#DeleteFsav1FsaResult) | **Delete** /platform/1/fsa/results/{v1FsaResultId} | 
[**DeleteFsav1FsaSettings**](FsaApi.md#DeleteFsav1FsaSettings) | **Delete** /platform/1/fsa/settings | 
[**DeleteFsav3FsaResult**](FsaApi.md#DeleteFsav3FsaResult) | **Delete** /platform/3/fsa/results/{v3FsaResultId} | 
[**GetFsav1FsaResult**](FsaApi.md#GetFsav1FsaResult) | **Get** /platform/1/fsa/results/{v1FsaResultId} | 
[**GetFsav1FsaResults**](FsaApi.md#GetFsav1FsaResults) | **Get** /platform/1/fsa/results | 
[**GetFsav1FsaSettings**](FsaApi.md#GetFsav1FsaSettings) | **Get** /platform/1/fsa/settings | 
[**GetFsav3FsaResult**](FsaApi.md#GetFsav3FsaResult) | **Get** /platform/3/fsa/results/{v3FsaResultId} | 
[**GetFsav3FsaResults**](FsaApi.md#GetFsav3FsaResults) | **Get** /platform/3/fsa/results | 
[**GetFsav3ResultsIdDirectory**](FsaApi.md#GetFsav3ResultsIdDirectory) | **Get** /platform/3/fsa/results/{Id}/directories/{v3ResultsIdDirectoryId} | 
[**GetFsav3ResultsIdHistogramStat**](FsaApi.md#GetFsav3ResultsIdHistogramStat) | **Get** /platform/3/fsa/results/{Id}/histogram/{v3ResultsIdHistogramStat} | 
[**GetFsav3ResultsIdHistogramStatByBreakout**](FsaApi.md#GetFsav3ResultsIdHistogramStatByBreakout) | **Get** /platform/3/fsa/results/{Id}/histogram/{Stat}/by/{v3ResultsIdHistogramStatByBreakout} | 
[**GetFsav3ResultsIdTopDir**](FsaApi.md#GetFsav3ResultsIdTopDir) | **Get** /platform/3/fsa/results/{Id}/top-dirs/{v3ResultsIdTopDirId} | 
[**GetFsav3ResultsIdTopFile**](FsaApi.md#GetFsav3ResultsIdTopFile) | **Get** /platform/3/fsa/results/{Id}/top-files/{v3ResultsIdTopFileId} | 
[**GetFsav8FsaIndex**](FsaApi.md#GetFsav8FsaIndex) | **Get** /platform/8/fsa/index | 
[**GetFsav8IndexNameLin**](FsaApi.md#GetFsav8IndexNameLin) | **Get** /platform/8/fsa/index/{Name}/lins/{v8IndexNameLinId} | 
[**GetFsav9ResultsIdDirPoolsUsageLin**](FsaApi.md#GetFsav9ResultsIdDirPoolsUsageLin) | **Get** /platform/9/fsa/results/{Id}/dir_pools_usage/{v9ResultsIdDirPoolsUsageLin} | 
[**UpdateFsav1FsaResult**](FsaApi.md#UpdateFsav1FsaResult) | **Put** /platform/1/fsa/results/{v1FsaResultId} | 
[**UpdateFsav1FsaSettings**](FsaApi.md#UpdateFsav1FsaSettings) | **Put** /platform/1/fsa/settings | 
[**UpdateFsav3FsaResult**](FsaApi.md#UpdateFsav3FsaResult) | **Put** /platform/3/fsa/results/{v3FsaResultId} | 



## DeleteFsav1FsaResult

> DeleteFsav1FsaResult(ctx, v1FsaResultId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1FsaResultId := "v1FsaResultId_example" // string | Delete the result set.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FsaApi.DeleteFsav1FsaResult(context.Background(), v1FsaResultId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.DeleteFsav1FsaResult``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1FsaResultId** | **string** | Delete the result set. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteFsav1FsaResultRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFsav1FsaSettings

> DeleteFsav1FsaSettings(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FsaApi.DeleteFsav1FsaSettings(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.DeleteFsav1FsaSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteFsav1FsaSettingsRequest struct via the builder pattern


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## DeleteFsav3FsaResult

> DeleteFsav3FsaResult(ctx, v3FsaResultId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3FsaResultId := "v3FsaResultId_example" // string | Delete the result set.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FsaApi.DeleteFsav3FsaResult(context.Background(), v3FsaResultId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.DeleteFsav3FsaResult``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3FsaResultId** | **string** | Delete the result set. | 

### Other Parameters

Other parameters are passed through a pointer to a apiDeleteFsav3FsaResultRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav1FsaResult

> V1FsaResultsExtended GetFsav1FsaResult(ctx, v1FsaResultId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1FsaResultId := "v1FsaResultId_example" // string | Retrieve result set information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav1FsaResult(context.Background(), v1FsaResultId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav1FsaResult``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav1FsaResult`: V1FsaResultsExtended
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav1FsaResult`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1FsaResultId** | **string** | Retrieve result set information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav1FsaResultRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V1FsaResultsExtended**](V1FsaResultsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav1FsaResults

> V1FsaResults GetFsav1FsaResults(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav1FsaResults(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav1FsaResults``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav1FsaResults`: V1FsaResults
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav1FsaResults`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav1FsaResultsRequest struct via the builder pattern


### Return type

[**V1FsaResults**](V1FsaResults.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav1FsaSettings

> V1FsaSettings GetFsav1FsaSettings(ctx).Scope(scope).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    scope := "scope_example" // string | If specified as effective or not specified, all fields are returned.  If specified as user, only fields with non-default values are shown.  If specified as default, the original values are returned. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav1FsaSettings(context.Background()).Scope(scope).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav1FsaSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav1FsaSettings`: V1FsaSettings
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav1FsaSettings`: %v\n", resp)
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav1FsaSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **scope** | **string** | If specified as effective or not specified, all fields are returned.  If specified as user, only fields with non-default values are shown.  If specified as default, the original values are returned. | 

### Return type

[**V1FsaSettings**](V1FsaSettings.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav3FsaResult

> V3FsaResultsExtended GetFsav3FsaResult(ctx, v3FsaResultId).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3FsaResultId := "v3FsaResultId_example" // string | Retrieve result set information.

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav3FsaResult(context.Background(), v3FsaResultId).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav3FsaResult``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav3FsaResult`: V3FsaResultsExtended
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav3FsaResult`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3FsaResultId** | **string** | Retrieve result set information. | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav3FsaResultRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


### Return type

[**V3FsaResultsExtended**](V3FsaResultsExtended.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav3FsaResults

> V3FsaResults GetFsav3FsaResults(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav3FsaResults(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav3FsaResults``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav3FsaResults`: V3FsaResults
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav3FsaResults`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav3FsaResultsRequest struct via the builder pattern


### Return type

[**V3FsaResults**](V3FsaResults.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav3ResultsIdDirectory

> V3ResultsIdDirectories GetFsav3ResultsIdDirectory(ctx, v3ResultsIdDirectoryId, id).Sort(sort).Limit(limit).CompReport(compReport).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ResultsIdDirectoryId := int32(56) // int32 | This resource retrieves directory information. ID in the resource path is the result set ID.
    id := "id_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    limit := int32(56) // int32 | Limit the number of reported subdirectories. (optional)
    compReport := int32(56) // int32 | Result set identifier for comparison of database results. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav3ResultsIdDirectory(context.Background(), v3ResultsIdDirectoryId, id).Sort(sort).Limit(limit).CompReport(compReport).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav3ResultsIdDirectory``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav3ResultsIdDirectory`: V3ResultsIdDirectories
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav3ResultsIdDirectory`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ResultsIdDirectoryId** | **int32** | This resource retrieves directory information. ID in the resource path is the result set ID. | 
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav3ResultsIdDirectoryRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **sort** | **string** | The field that will be used for sorting. | 
 **limit** | **int32** | Limit the number of reported subdirectories. | 
 **compReport** | **int32** | Result set identifier for comparison of database results. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3ResultsIdDirectories**](V3ResultsIdDirectories.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav3ResultsIdHistogramStat

> V3ResultHistogram GetFsav3ResultsIdHistogramStat(ctx, v3ResultsIdHistogramStat, id).DirectoryFilter(directoryFilter).AttributeFilter(attributeFilter).NodePoolFilter(nodePoolFilter).DiskPoolFilter(diskPoolFilter).TierFilter(tierFilter).CompReport(compReport).LogSizeFilter(logSizeFilter).PhysSizeFilter(physSizeFilter).PathExtFilter(pathExtFilter).CtimeFilter(ctimeFilter).AtimeFilter(atimeFilter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ResultsIdHistogramStat := "v3ResultsIdHistogramStat_example" // string | This resource retrieves a histogram of file counts for an individual FSA result set. ID in the resource path is the result set ID.
    id := "id_example" // string | 
    directoryFilter := "directoryFilter_example" // string | Filter according to a specific directory, which includes all of its subdirectories. (optional)
    attributeFilter := "attributeFilter_example" // string | Filter according to the name of a file user attribute. (optional)
    nodePoolFilter := "nodePoolFilter_example" // string | Filter according to the name of a node pool, which is a set of disk pools that belong to nodes of the same equivalence class. (optional)
    diskPoolFilter := "diskPoolFilter_example" // string | Filter according to the name of a disk pool, which is a set of drives that represent an independent failure domain. (optional)
    tierFilter := "tierFilter_example" // string | Filter according to the name of a storage tier, which is a user-created set of node pools. (optional)
    compReport := int32(56) // int32 | Result set identifier for comparison of database results. (optional)
    logSizeFilter := int32(56) // int32 | Filter according to file logical size, where the filter value specifies the lower bound in bytes to a set of files that have been grouped by logical size. The list of valid log_size filter values may be found by performing a histogram breakout by log_size and viewing the resulting key values. (optional)
    physSizeFilter := int32(56) // int32 | Filter according to file physical size, where the filter value specifies the lower bound in bytes to a set of files that have been grouped by physical size. The list of valid phys_size filter values may be found by performing a histogram breakout by phys_size and viewing the resulting key values. (optional)
    pathExtFilter := "pathExtFilter_example" // string | Filter according to the name of a single file extension. (optional)
    ctimeFilter := int32(56) // int32 | Filter according to file modified time, where the filter value specifies a negative number of seconds representing a time before the begin time of the report. The list of valid ctime filter values may be found by performing a histogram breakout by ctime and viewing the resulting key values. (optional)
    atimeFilter := int32(56) // int32 | Filter according to file accessed time, where the filter value specifies a negative number of seconds representing a time before the begin time of the report. The list of valid atime filter values may be found by performing a histogram breakout by atime and viewing the resulting key values. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav3ResultsIdHistogramStat(context.Background(), v3ResultsIdHistogramStat, id).DirectoryFilter(directoryFilter).AttributeFilter(attributeFilter).NodePoolFilter(nodePoolFilter).DiskPoolFilter(diskPoolFilter).TierFilter(tierFilter).CompReport(compReport).LogSizeFilter(logSizeFilter).PhysSizeFilter(physSizeFilter).PathExtFilter(pathExtFilter).CtimeFilter(ctimeFilter).AtimeFilter(atimeFilter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav3ResultsIdHistogramStat``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav3ResultsIdHistogramStat`: V3ResultHistogram
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav3ResultsIdHistogramStat`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ResultsIdHistogramStat** | **string** | This resource retrieves a histogram of file counts for an individual FSA result set. ID in the resource path is the result set ID. | 
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav3ResultsIdHistogramStatRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **directoryFilter** | **string** | Filter according to a specific directory, which includes all of its subdirectories. | 
 **attributeFilter** | **string** | Filter according to the name of a file user attribute. | 
 **nodePoolFilter** | **string** | Filter according to the name of a node pool, which is a set of disk pools that belong to nodes of the same equivalence class. | 
 **diskPoolFilter** | **string** | Filter according to the name of a disk pool, which is a set of drives that represent an independent failure domain. | 
 **tierFilter** | **string** | Filter according to the name of a storage tier, which is a user-created set of node pools. | 
 **compReport** | **int32** | Result set identifier for comparison of database results. | 
 **logSizeFilter** | **int32** | Filter according to file logical size, where the filter value specifies the lower bound in bytes to a set of files that have been grouped by logical size. The list of valid log_size filter values may be found by performing a histogram breakout by log_size and viewing the resulting key values. | 
 **physSizeFilter** | **int32** | Filter according to file physical size, where the filter value specifies the lower bound in bytes to a set of files that have been grouped by physical size. The list of valid phys_size filter values may be found by performing a histogram breakout by phys_size and viewing the resulting key values. | 
 **pathExtFilter** | **string** | Filter according to the name of a single file extension. | 
 **ctimeFilter** | **int32** | Filter according to file modified time, where the filter value specifies a negative number of seconds representing a time before the begin time of the report. The list of valid ctime filter values may be found by performing a histogram breakout by ctime and viewing the resulting key values. | 
 **atimeFilter** | **int32** | Filter according to file accessed time, where the filter value specifies a negative number of seconds representing a time before the begin time of the report. The list of valid atime filter values may be found by performing a histogram breakout by atime and viewing the resulting key values. | 

### Return type

[**V3ResultHistogram**](V3ResultHistogram.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav3ResultsIdHistogramStatByBreakout

> V3HistogramStatBy GetFsav3ResultsIdHistogramStatByBreakout(ctx, v3ResultsIdHistogramStatByBreakout, id, stat).DirectoryFilter(directoryFilter).AttributeFilter(attributeFilter).NodePoolFilter(nodePoolFilter).DiskPoolFilter(diskPoolFilter).TierFilter(tierFilter).CompReport(compReport).LogSizeFilter(logSizeFilter).PhysSizeFilter(physSizeFilter).Limit(limit).PathExtFilter(pathExtFilter).CtimeFilter(ctimeFilter).AtimeFilter(atimeFilter).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ResultsIdHistogramStatByBreakout := "v3ResultsIdHistogramStatByBreakout_example" // string | This resource retrieves a histogram breakout for an individual FSA result set. ID in the resource path is the result set ID.
    id := "id_example" // string | 
    stat := "stat_example" // string | 
    directoryFilter := "directoryFilter_example" // string | Filter according to a specific directory, which includes all of its subdirectories. (optional)
    attributeFilter := "attributeFilter_example" // string | Filter according to the name of a file user attribute. (optional)
    nodePoolFilter := "nodePoolFilter_example" // string | Filter according to the name of a node pool, which is a set of disk pools that belong to nodes of the same equivalence class. (optional)
    diskPoolFilter := "diskPoolFilter_example" // string | Filter according to the name of a disk pool, which is a set of drives that represent an independent failure domain. (optional)
    tierFilter := "tierFilter_example" // string | Filter according to the name of a storage tier, which is a user-created set of node pools. (optional)
    compReport := int32(56) // int32 | Result set identifier for comparison of database results. (optional)
    logSizeFilter := int32(56) // int32 | Filter according to file logical size, where the filter value specifies the lower bound in bytes to a set of files that have been grouped by logical size. The list of valid log_size filter values may be found by performing a histogram breakout by log_size and viewing the resulting key values. (optional)
    physSizeFilter := int32(56) // int32 | Filter according to file physical size, where the filter value specifies the lower bound in bytes to a set of files that have been grouped by physical size. The list of valid phys_size filter values may be found by performing a histogram breakout by phys_size and viewing the resulting key values. (optional)
    limit := int32(56) // int32 | Limit the number of breakout results. (optional)
    pathExtFilter := "pathExtFilter_example" // string | Filter according to the name of a single file extension. (optional)
    ctimeFilter := int32(56) // int32 | Filter according to file modified time, where the filter value specifies a negative number of seconds representing a time before the begin time of the report. The list of valid ctime filter values may be found by performing a histogram breakout by ctime and viewing the resulting key values. (optional)
    atimeFilter := int32(56) // int32 | Filter according to file accessed time, where the filter value specifies a negative number of seconds representing a time before the begin time of the report. The list of valid atime filter values may be found by performing a histogram breakout by atime and viewing the resulting key values. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav3ResultsIdHistogramStatByBreakout(context.Background(), v3ResultsIdHistogramStatByBreakout, id, stat).DirectoryFilter(directoryFilter).AttributeFilter(attributeFilter).NodePoolFilter(nodePoolFilter).DiskPoolFilter(diskPoolFilter).TierFilter(tierFilter).CompReport(compReport).LogSizeFilter(logSizeFilter).PhysSizeFilter(physSizeFilter).Limit(limit).PathExtFilter(pathExtFilter).CtimeFilter(ctimeFilter).AtimeFilter(atimeFilter).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav3ResultsIdHistogramStatByBreakout``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav3ResultsIdHistogramStatByBreakout`: V3HistogramStatBy
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav3ResultsIdHistogramStatByBreakout`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ResultsIdHistogramStatByBreakout** | **string** | This resource retrieves a histogram breakout for an individual FSA result set. ID in the resource path is the result set ID. | 
**id** | **string** |  | 
**stat** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav3ResultsIdHistogramStatByBreakoutRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------



 **directoryFilter** | **string** | Filter according to a specific directory, which includes all of its subdirectories. | 
 **attributeFilter** | **string** | Filter according to the name of a file user attribute. | 
 **nodePoolFilter** | **string** | Filter according to the name of a node pool, which is a set of disk pools that belong to nodes of the same equivalence class. | 
 **diskPoolFilter** | **string** | Filter according to the name of a disk pool, which is a set of drives that represent an independent failure domain. | 
 **tierFilter** | **string** | Filter according to the name of a storage tier, which is a user-created set of node pools. | 
 **compReport** | **int32** | Result set identifier for comparison of database results. | 
 **logSizeFilter** | **int32** | Filter according to file logical size, where the filter value specifies the lower bound in bytes to a set of files that have been grouped by logical size. The list of valid log_size filter values may be found by performing a histogram breakout by log_size and viewing the resulting key values. | 
 **physSizeFilter** | **int32** | Filter according to file physical size, where the filter value specifies the lower bound in bytes to a set of files that have been grouped by physical size. The list of valid phys_size filter values may be found by performing a histogram breakout by phys_size and viewing the resulting key values. | 
 **limit** | **int32** | Limit the number of breakout results. | 
 **pathExtFilter** | **string** | Filter according to the name of a single file extension. | 
 **ctimeFilter** | **int32** | Filter according to file modified time, where the filter value specifies a negative number of seconds representing a time before the begin time of the report. The list of valid ctime filter values may be found by performing a histogram breakout by ctime and viewing the resulting key values. | 
 **atimeFilter** | **int32** | Filter according to file accessed time, where the filter value specifies a negative number of seconds representing a time before the begin time of the report. The list of valid atime filter values may be found by performing a histogram breakout by atime and viewing the resulting key values. | 

### Return type

[**V3HistogramStatBy**](V3HistogramStatBy.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav3ResultsIdTopDir

> V3ResultTopDirs GetFsav3ResultsIdTopDir(ctx, v3ResultsIdTopDirId, id).Sort(sort).Start(start).Limit(limit).CompReport(compReport).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ResultsIdTopDirId := "v3ResultsIdTopDirId_example" // string | This resource retrieves the top directories. ID in the resource path is the result set ID.
    id := "id_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    start := int32(56) // int32 | Starting index for results. Default value of 0. (optional)
    limit := int32(56) // int32 | Number of results from start index. Default value of 1000. (optional)
    compReport := int32(56) // int32 | Result set identifier for comparison of database results. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav3ResultsIdTopDir(context.Background(), v3ResultsIdTopDirId, id).Sort(sort).Start(start).Limit(limit).CompReport(compReport).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav3ResultsIdTopDir``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav3ResultsIdTopDir`: V3ResultTopDirs
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav3ResultsIdTopDir`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ResultsIdTopDirId** | **string** | This resource retrieves the top directories. ID in the resource path is the result set ID. | 
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav3ResultsIdTopDirRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **sort** | **string** | The field that will be used for sorting. | 
 **start** | **int32** | Starting index for results. Default value of 0. | 
 **limit** | **int32** | Number of results from start index. Default value of 1000. | 
 **compReport** | **int32** | Result set identifier for comparison of database results. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3ResultTopDirs**](V3ResultTopDirs.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav3ResultsIdTopFile

> V3ResultTopFiles GetFsav3ResultsIdTopFile(ctx, v3ResultsIdTopFileId, id).Sort(sort).Start(start).Limit(limit).CompReport(compReport).Dir(dir).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3ResultsIdTopFileId := "v3ResultsIdTopFileId_example" // string | This resource retrieves the top files. ID in the resource path is the result set ID.
    id := "id_example" // string | 
    sort := "sort_example" // string | The field that will be used for sorting. (optional)
    start := int32(56) // int32 | Starting index for results. Default value of 0. (optional)
    limit := int32(56) // int32 | Number of results from start index. Default value of 1000. (optional)
    compReport := int32(56) // int32 | Result set identifier for comparison of database results. (optional)
    dir := "dir_example" // string | The direction of the sort. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav3ResultsIdTopFile(context.Background(), v3ResultsIdTopFileId, id).Sort(sort).Start(start).Limit(limit).CompReport(compReport).Dir(dir).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav3ResultsIdTopFile``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav3ResultsIdTopFile`: V3ResultTopFiles
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav3ResultsIdTopFile`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3ResultsIdTopFileId** | **string** | This resource retrieves the top files. ID in the resource path is the result set ID. | 
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav3ResultsIdTopFileRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **sort** | **string** | The field that will be used for sorting. | 
 **start** | **int32** | Starting index for results. Default value of 0. | 
 **limit** | **int32** | Number of results from start index. Default value of 1000. | 
 **compReport** | **int32** | Result set identifier for comparison of database results. | 
 **dir** | **string** | The direction of the sort. | 

### Return type

[**V3ResultTopFiles**](V3ResultTopFiles.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav8FsaIndex

> V8FsaIndex GetFsav8FsaIndex(ctx).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav8FsaIndex(context.Background()).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav8FsaIndex``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav8FsaIndex`: V8FsaIndex
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav8FsaIndex`: %v\n", resp)
}
```

### Path Parameters

This endpoint does not need any parameter.

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav8FsaIndexRequest struct via the builder pattern


### Return type

[**V8FsaIndex**](V8FsaIndex.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav8IndexNameLin

> V8IndexNameLins GetFsav8IndexNameLin(ctx, v8IndexNameLinId, name).Path(path).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v8IndexNameLinId := int32(56) // int32 | Get a single index entry from the index table.
    name := "name_example" // string | 
    path := true // bool | Resolve the path for an index entry. This query argument is invalid if an initial index job is in progress or incomplete or if an incremental index job is in progress or incomplete. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav8IndexNameLin(context.Background(), v8IndexNameLinId, name).Path(path).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav8IndexNameLin``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav8IndexNameLin`: V8IndexNameLins
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav8IndexNameLin`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v8IndexNameLinId** | **int32** | Get a single index entry from the index table. | 
**name** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav8IndexNameLinRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **path** | **bool** | Resolve the path for an index entry. This query argument is invalid if an initial index job is in progress or incomplete or if an incremental index job is in progress or incomplete. | 

### Return type

[**V8IndexNameLins**](V8IndexNameLins.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## GetFsav9ResultsIdDirPoolsUsageLin

> V9ResultDirPoolsUsage GetFsav9ResultsIdDirPoolsUsageLin(ctx, v9ResultsIdDirPoolsUsageLin, id).CompReport(compReport).StoragePoolType(storagePoolType).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v9ResultsIdDirPoolsUsageLin := int32(56) // int32 |  View pool usage information of a directory, classified by storage pools in response \"usage_data\". The storage pool type can be specified by query parameter \"storage_pool_type\". The directory is LIN token of URI. The response \"dir_usage\" is total disk usage of directory, over all pools at a given storage pool level. When LIN cannot be found within result, status code 404 and error message will be returned.
    id := "id_example" // string | 
    compReport := int32(56) // int32 | Result set identifier for comparison of database results. (optional)
    storagePoolType := "storagePoolType_example" // string | The type of the storage pool. (optional)

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    resp, r, err := apiClient.FsaApi.GetFsav9ResultsIdDirPoolsUsageLin(context.Background(), v9ResultsIdDirPoolsUsageLin, id).CompReport(compReport).StoragePoolType(storagePoolType).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.GetFsav9ResultsIdDirPoolsUsageLin``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
    // response from `GetFsav9ResultsIdDirPoolsUsageLin`: V9ResultDirPoolsUsage
    fmt.Fprintf(os.Stdout, "Response from `FsaApi.GetFsav9ResultsIdDirPoolsUsageLin`: %v\n", resp)
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v9ResultsIdDirPoolsUsageLin** | **int32** |  View pool usage information of a directory, classified by storage pools in response \&quot;usage_data\&quot;. The storage pool type can be specified by query parameter \&quot;storage_pool_type\&quot;. The directory is LIN token of URI. The response \&quot;dir_usage\&quot; is total disk usage of directory, over all pools at a given storage pool level. When LIN cannot be found within result, status code 404 and error message will be returned. | 
**id** | **string** |  | 

### Other Parameters

Other parameters are passed through a pointer to a apiGetFsav9ResultsIdDirPoolsUsageLinRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------


 **compReport** | **int32** | Result set identifier for comparison of database results. | 
 **storagePoolType** | **string** | The type of the storage pool. | 

### Return type

[**V9ResultDirPoolsUsage**](V9ResultDirPoolsUsage.md)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: Not defined
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFsav1FsaResult

> UpdateFsav1FsaResult(ctx, v1FsaResultId).V1FsaResult(v1FsaResult).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1FsaResultId := "v1FsaResultId_example" // string | Modify result set. Only the pinned property can be changed at this time.
    v1FsaResult := *openapiclient.NewV1FsaResultExtended() // V1FsaResultExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FsaApi.UpdateFsav1FsaResult(context.Background(), v1FsaResultId).V1FsaResult(v1FsaResult).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.UpdateFsav1FsaResult``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v1FsaResultId** | **string** | Modify result set. Only the pinned property can be changed at this time. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFsav1FsaResultRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v1FsaResult** | [**V1FsaResultExtended**](V1FsaResultExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFsav1FsaSettings

> UpdateFsav1FsaSettings(ctx).V1FsaSettings(v1FsaSettings).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v1FsaSettings := *openapiclient.NewV1FsaSettingsSettings() // V1FsaSettingsSettings | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FsaApi.UpdateFsav1FsaSettings(context.Background()).V1FsaSettings(v1FsaSettings).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.UpdateFsav1FsaSettings``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters



### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFsav1FsaSettingsRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **v1FsaSettings** | [**V1FsaSettingsSettings**](V1FsaSettingsSettings.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)


## UpdateFsav3FsaResult

> UpdateFsav3FsaResult(ctx, v3FsaResultId).V3FsaResult(v3FsaResult).Execute()





### Example

```go
package main

import (
    "context"
    "fmt"
    "os"
    openapiclient "github.com/GIT_USER_ID/GIT_REPO_ID"
)

func main() {
    v3FsaResultId := "v3FsaResultId_example" // string | Modify result set. Only the pinned property can be changed at this time.
    v3FsaResult := *openapiclient.NewV3FsaResultExtended(false) // V3FsaResultExtended | 

    configuration := openapiclient.NewConfiguration()
    apiClient := openapiclient.NewAPIClient(configuration)
    r, err := apiClient.FsaApi.UpdateFsav3FsaResult(context.Background(), v3FsaResultId).V3FsaResult(v3FsaResult).Execute()
    if err != nil {
        fmt.Fprintf(os.Stderr, "Error when calling `FsaApi.UpdateFsav3FsaResult``: %v\n", err)
        fmt.Fprintf(os.Stderr, "Full HTTP response: %v\n", r)
    }
}
```

### Path Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
**ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
**v3FsaResultId** | **string** | Modify result set. Only the pinned property can be changed at this time. | 

### Other Parameters

Other parameters are passed through a pointer to a apiUpdateFsav3FsaResultRequest struct via the builder pattern


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **v3FsaResult** | [**V3FsaResultExtended**](V3FsaResultExtended.md) |  | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

- **Content-Type**: application/json
- **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints)
[[Back to Model list]](../README.md#documentation-for-models)
[[Back to README]](../README.md)

