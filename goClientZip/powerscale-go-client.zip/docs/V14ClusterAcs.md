# V14ClusterAcs

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FailedNodesSn** | Pointer to **[]string** | list of failed nodes serial number. | [optional] 
**JoinedNodes** | Pointer to **int32** | the number of joined nodes. | [optional] 
**LicenseStatus** | Pointer to **string** | the status of license activation. | [optional] 
**SrsStatus** | Pointer to **string** | the status of SRS enablement. | [optional] 
**TotalNodes** | Pointer to **int32** | total nodes number of the cluster. | [optional] 
**UnresponsiveSn** | Pointer to **[]string** | list of unresponsive nodes serial number. | [optional] 

## Methods

### NewV14ClusterAcs

`func NewV14ClusterAcs() *V14ClusterAcs`

NewV14ClusterAcs instantiates a new V14ClusterAcs object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV14ClusterAcsWithDefaults

`func NewV14ClusterAcsWithDefaults() *V14ClusterAcs`

NewV14ClusterAcsWithDefaults instantiates a new V14ClusterAcs object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetFailedNodesSn

`func (o *V14ClusterAcs) GetFailedNodesSn() []string`

GetFailedNodesSn returns the FailedNodesSn field if non-nil, zero value otherwise.

### GetFailedNodesSnOk

`func (o *V14ClusterAcs) GetFailedNodesSnOk() (*[]string, bool)`

GetFailedNodesSnOk returns a tuple with the FailedNodesSn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetFailedNodesSn

`func (o *V14ClusterAcs) SetFailedNodesSn(v []string)`

SetFailedNodesSn sets FailedNodesSn field to given value.

### HasFailedNodesSn

`func (o *V14ClusterAcs) HasFailedNodesSn() bool`

HasFailedNodesSn returns a boolean if a field has been set.

### GetJoinedNodes

`func (o *V14ClusterAcs) GetJoinedNodes() int32`

GetJoinedNodes returns the JoinedNodes field if non-nil, zero value otherwise.

### GetJoinedNodesOk

`func (o *V14ClusterAcs) GetJoinedNodesOk() (*int32, bool)`

GetJoinedNodesOk returns a tuple with the JoinedNodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetJoinedNodes

`func (o *V14ClusterAcs) SetJoinedNodes(v int32)`

SetJoinedNodes sets JoinedNodes field to given value.

### HasJoinedNodes

`func (o *V14ClusterAcs) HasJoinedNodes() bool`

HasJoinedNodes returns a boolean if a field has been set.

### GetLicenseStatus

`func (o *V14ClusterAcs) GetLicenseStatus() string`

GetLicenseStatus returns the LicenseStatus field if non-nil, zero value otherwise.

### GetLicenseStatusOk

`func (o *V14ClusterAcs) GetLicenseStatusOk() (*string, bool)`

GetLicenseStatusOk returns a tuple with the LicenseStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLicenseStatus

`func (o *V14ClusterAcs) SetLicenseStatus(v string)`

SetLicenseStatus sets LicenseStatus field to given value.

### HasLicenseStatus

`func (o *V14ClusterAcs) HasLicenseStatus() bool`

HasLicenseStatus returns a boolean if a field has been set.

### GetSrsStatus

`func (o *V14ClusterAcs) GetSrsStatus() string`

GetSrsStatus returns the SrsStatus field if non-nil, zero value otherwise.

### GetSrsStatusOk

`func (o *V14ClusterAcs) GetSrsStatusOk() (*string, bool)`

GetSrsStatusOk returns a tuple with the SrsStatus field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSrsStatus

`func (o *V14ClusterAcs) SetSrsStatus(v string)`

SetSrsStatus sets SrsStatus field to given value.

### HasSrsStatus

`func (o *V14ClusterAcs) HasSrsStatus() bool`

HasSrsStatus returns a boolean if a field has been set.

### GetTotalNodes

`func (o *V14ClusterAcs) GetTotalNodes() int32`

GetTotalNodes returns the TotalNodes field if non-nil, zero value otherwise.

### GetTotalNodesOk

`func (o *V14ClusterAcs) GetTotalNodesOk() (*int32, bool)`

GetTotalNodesOk returns a tuple with the TotalNodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotalNodes

`func (o *V14ClusterAcs) SetTotalNodes(v int32)`

SetTotalNodes sets TotalNodes field to given value.

### HasTotalNodes

`func (o *V14ClusterAcs) HasTotalNodes() bool`

HasTotalNodes returns a boolean if a field has been set.

### GetUnresponsiveSn

`func (o *V14ClusterAcs) GetUnresponsiveSn() []string`

GetUnresponsiveSn returns the UnresponsiveSn field if non-nil, zero value otherwise.

### GetUnresponsiveSnOk

`func (o *V14ClusterAcs) GetUnresponsiveSnOk() (*[]string, bool)`

GetUnresponsiveSnOk returns a tuple with the UnresponsiveSn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetUnresponsiveSn

`func (o *V14ClusterAcs) SetUnresponsiveSn(v []string)`

SetUnresponsiveSn sets UnresponsiveSn field to given value.

### HasUnresponsiveSn

`func (o *V14ClusterAcs) HasUnresponsiveSn() bool`

HasUnresponsiveSn returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


