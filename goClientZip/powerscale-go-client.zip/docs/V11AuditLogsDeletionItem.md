# V11AuditLogsDeletionItem

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DeletedFiles** | Pointer to **int32** |  | [optional] 
**Lnn** | Pointer to **int32** |  | [optional] 
**SpaceFreed** | Pointer to **string** |  | [optional] 

## Methods

### NewV11AuditLogsDeletionItem

`func NewV11AuditLogsDeletionItem() *V11AuditLogsDeletionItem`

NewV11AuditLogsDeletionItem instantiates a new V11AuditLogsDeletionItem object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV11AuditLogsDeletionItemWithDefaults

`func NewV11AuditLogsDeletionItemWithDefaults() *V11AuditLogsDeletionItem`

NewV11AuditLogsDeletionItemWithDefaults instantiates a new V11AuditLogsDeletionItem object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetDeletedFiles

`func (o *V11AuditLogsDeletionItem) GetDeletedFiles() int32`

GetDeletedFiles returns the DeletedFiles field if non-nil, zero value otherwise.

### GetDeletedFilesOk

`func (o *V11AuditLogsDeletionItem) GetDeletedFilesOk() (*int32, bool)`

GetDeletedFilesOk returns a tuple with the DeletedFiles field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDeletedFiles

`func (o *V11AuditLogsDeletionItem) SetDeletedFiles(v int32)`

SetDeletedFiles sets DeletedFiles field to given value.

### HasDeletedFiles

`func (o *V11AuditLogsDeletionItem) HasDeletedFiles() bool`

HasDeletedFiles returns a boolean if a field has been set.

### GetLnn

`func (o *V11AuditLogsDeletionItem) GetLnn() int32`

GetLnn returns the Lnn field if non-nil, zero value otherwise.

### GetLnnOk

`func (o *V11AuditLogsDeletionItem) GetLnnOk() (*int32, bool)`

GetLnnOk returns a tuple with the Lnn field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetLnn

`func (o *V11AuditLogsDeletionItem) SetLnn(v int32)`

SetLnn sets Lnn field to given value.

### HasLnn

`func (o *V11AuditLogsDeletionItem) HasLnn() bool`

HasLnn returns a boolean if a field has been set.

### GetSpaceFreed

`func (o *V11AuditLogsDeletionItem) GetSpaceFreed() string`

GetSpaceFreed returns the SpaceFreed field if non-nil, zero value otherwise.

### GetSpaceFreedOk

`func (o *V11AuditLogsDeletionItem) GetSpaceFreedOk() (*string, bool)`

GetSpaceFreedOk returns a tuple with the SpaceFreed field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetSpaceFreed

`func (o *V11AuditLogsDeletionItem) SetSpaceFreed(v string)`

SetSpaceFreed sets SpaceFreed field to given value.

### HasSpaceFreed

`func (o *V11AuditLogsDeletionItem) HasSpaceFreed() bool`

HasSpaceFreed returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


