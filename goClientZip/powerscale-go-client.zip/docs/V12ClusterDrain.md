# V12ClusterDrain

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Action** | **string** | The desired drain action, ex. delay or skip. | 
**DrainNodes** | **[]int32** | The nodes to alter drain action in the existing upgrade.For skip action only, &#39;all&#39; is valid.  | 
**Task** | **string** | The desired drain task, ex. add or remove nodes. | 

## Methods

### NewV12ClusterDrain

`func NewV12ClusterDrain(action string, drainNodes []int32, task string, ) *V12ClusterDrain`

NewV12ClusterDrain instantiates a new V12ClusterDrain object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12ClusterDrainWithDefaults

`func NewV12ClusterDrainWithDefaults() *V12ClusterDrain`

NewV12ClusterDrainWithDefaults instantiates a new V12ClusterDrain object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetAction

`func (o *V12ClusterDrain) GetAction() string`

GetAction returns the Action field if non-nil, zero value otherwise.

### GetActionOk

`func (o *V12ClusterDrain) GetActionOk() (*string, bool)`

GetActionOk returns a tuple with the Action field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetAction

`func (o *V12ClusterDrain) SetAction(v string)`

SetAction sets Action field to given value.


### GetDrainNodes

`func (o *V12ClusterDrain) GetDrainNodes() []int32`

GetDrainNodes returns the DrainNodes field if non-nil, zero value otherwise.

### GetDrainNodesOk

`func (o *V12ClusterDrain) GetDrainNodesOk() (*[]int32, bool)`

GetDrainNodesOk returns a tuple with the DrainNodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetDrainNodes

`func (o *V12ClusterDrain) SetDrainNodes(v []int32)`

SetDrainNodes sets DrainNodes field to given value.


### GetTask

`func (o *V12ClusterDrain) GetTask() string`

GetTask returns the Task field if non-nil, zero value otherwise.

### GetTaskOk

`func (o *V12ClusterDrain) GetTaskOk() (*string, bool)`

GetTaskOk returns a tuple with the Task field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTask

`func (o *V12ClusterDrain) SetTask(v string)`

SetTask sets Task field to given value.



[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


