# V12SedStatus

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Nodes** | Pointer to [**[]V12SedStatusNode**](V12SedStatusNode.md) |  | [optional] 
**Resume** | Pointer to **string** | Provide this token as the &#39;resume&#39; query argument to continue listing results. | [optional] 
**Total** | Pointer to **int64** | Total number of items available. | [optional] 

## Methods

### NewV12SedStatus

`func NewV12SedStatus() *V12SedStatus`

NewV12SedStatus instantiates a new V12SedStatus object
This constructor will assign default values to properties that have it defined,
and makes sure properties required by API are set, but the set of arguments
will change when the set of required properties is changed

### NewV12SedStatusWithDefaults

`func NewV12SedStatusWithDefaults() *V12SedStatus`

NewV12SedStatusWithDefaults instantiates a new V12SedStatus object
This constructor will only assign default values to properties that have it defined,
but it doesn't guarantee that properties required by API are set

### GetNodes

`func (o *V12SedStatus) GetNodes() []V12SedStatusNode`

GetNodes returns the Nodes field if non-nil, zero value otherwise.

### GetNodesOk

`func (o *V12SedStatus) GetNodesOk() (*[]V12SedStatusNode, bool)`

GetNodesOk returns a tuple with the Nodes field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetNodes

`func (o *V12SedStatus) SetNodes(v []V12SedStatusNode)`

SetNodes sets Nodes field to given value.

### HasNodes

`func (o *V12SedStatus) HasNodes() bool`

HasNodes returns a boolean if a field has been set.

### GetResume

`func (o *V12SedStatus) GetResume() string`

GetResume returns the Resume field if non-nil, zero value otherwise.

### GetResumeOk

`func (o *V12SedStatus) GetResumeOk() (*string, bool)`

GetResumeOk returns a tuple with the Resume field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetResume

`func (o *V12SedStatus) SetResume(v string)`

SetResume sets Resume field to given value.

### HasResume

`func (o *V12SedStatus) HasResume() bool`

HasResume returns a boolean if a field has been set.

### GetTotal

`func (o *V12SedStatus) GetTotal() int64`

GetTotal returns the Total field if non-nil, zero value otherwise.

### GetTotalOk

`func (o *V12SedStatus) GetTotalOk() (*int64, bool)`

GetTotalOk returns a tuple with the Total field if it's non-nil, zero value otherwise
and a boolean to check if the value has been set.

### SetTotal

`func (o *V12SedStatus) SetTotal(v int64)`

SetTotal sets Total field to given value.

### HasTotal

`func (o *V12SedStatus) HasTotal() bool`

HasTotal returns a boolean if a field has been set.


[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


